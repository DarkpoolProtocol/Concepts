var require = meteorInstall({"imports":{"api":{"accounts":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/accounts/server/methods.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);

const fetchFromUrl = url => {
  try {
    let res = HTTP.get(LCD + url);

    if (res.statusCode == 200) {
      return res;
    }

    ;
  } catch (e) {
    console.log(e);
  }
};

Meteor.methods({
  'accounts.getAccountDetail': function (address) {
    this.unblock();
    let url = LCD + '/auth/accounts/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        let response = JSON.parse(available.content).result;
        let account;
        if (response.type === 'cosmos-sdk/Account') account = response.value;else if (response.type === 'cosmos-sdk/DelayedVestingAccount' || response.type === 'cosmos-sdk/ContinuousVestingAccount') account = response.value.BaseVestingAccount.BaseAccount;
        if (account && account.account_number != null) return account;
        return null;
      }
    } catch (e) {
      console.log(e);
    }
  },
  'accounts.getBalance': function (address) {
    this.unblock();
    let balance = {}; // get available atoms

    let url = LCD + '/bank/balances/' + address;

    try {
      let available = HTTP.get(url);

      if (available.statusCode == 200) {
        balance.available = JSON.parse(available.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get delegated amnounts


    url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        balance.delegations = JSON.parse(delegations.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get unbonding


    url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbonding = HTTP.get(url);

      if (unbonding.statusCode == 200) {
        balance.unbonding = JSON.parse(unbonding.content).result;
      }
    } catch (e) {
      console.log(e);
    } // get rewards


    url = LCD + '/distribution/delegators/' + address + '/rewards';

    try {
      let rewards = HTTP.get(url);

      if (rewards.statusCode == 200) {
        //get seperate rewards value
        balance.rewards = JSON.parse(rewards.content).result.rewards; //get total rewards value

        balance.total_rewards = JSON.parse(rewards.content).result.total;
      }
    } catch (e) {
      console.log(e);
    } // get commission


    let validator = Validators.findOne({
      $or: [{
        operator_address: address
      }, {
        delegator_address: address
      }, {
        address: address
      }]
    });

    if (validator) {
      let url = LCD + '/distribution/validators/' + validator.operator_address;
      balance.operator_address = validator.operator_address;

      try {
        let rewards = HTTP.get(url);

        if (rewards.statusCode == 200) {
          let content = JSON.parse(rewards.content).result;
          if (content.val_commission && content.val_commission.length > 0) balance.commission = content.val_commission;
        }
      } catch (e) {
        console.log(e);
      }
    }

    return balance;
  },

  'accounts.getDelegation'(address, validator) {
    let url = "/staking/delegators/".concat(address, "/delegations/").concat(validator);
    let delegations = fetchFromUrl(url);
    delegations = delegations && delegations.data.result;
    if (delegations && delegations.shares) delegations.shares = parseFloat(delegations.shares);
    url = "/staking/redelegations?delegator=".concat(address, "&validator_to=").concat(validator);
    let relegations = fetchFromUrl(url);
    relegations = relegations && relegations.data.result;
    let completionTime;

    if (relegations) {
      relegations.forEach(relegation => {
        let entries = relegation.entries;
        let time = new Date(entries[entries.length - 1].completion_time);
        if (!completionTime || time > completionTime) completionTime = time;
      });
      delegations.redelegationCompletionTime = completionTime;
    }

    url = "/staking/delegators/".concat(address, "/unbonding_delegations/").concat(validator);
    let undelegations = fetchFromUrl(url);
    undelegations = undelegations && undelegations.data.result;

    if (undelegations) {
      delegations.unbonding = undelegations.entries.length;
      delegations.unbondingCompletionTime = undelegations.entries[0].completion_time;
    }

    return delegations;
  },

  'accounts.getAllDelegations'(address) {
    let url = LCD + '/staking/delegators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;

        if (delegations && delegations.length > 0) {
          delegations.forEach((delegation, i) => {
            if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
          });
        }

        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllUnbondings'(address) {
    let url = LCD + '/staking/delegators/' + address + '/unbonding_delegations';

    try {
      let unbondings = HTTP.get(url);

      if (unbondings.statusCode == 200) {
        unbondings = JSON.parse(unbondings.content).result;
        return unbondings;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  },

  'accounts.getAllRedelegations'(address, validator) {
    let url = "/staking/redelegations?delegator=".concat(address, "&validator_from=").concat(validator);
    let result = fetchFromUrl(url);

    if (result && result.data) {
      let redelegations = {};
      result.data.forEach(redelegation => {
        let entries = redelegation.entries;
        redelegations[redelegation.validator_dst_address] = {
          count: entries.length,
          completionTime: entries[0].completion_time
        };
      });
      return redelegations;
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"blocks":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Promise;
module.link("meteor/promise", {
  Promise(v) {
    Promise = v;
  }

}, 2);
let Blockscon;
module.link("/imports/api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 3);
let Chain;
module.link("/imports/api/chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 4);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 5);
let Validators;
module.link("/imports/api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 6);
let ValidatorRecords, Analytics, VPDistributions;
module.link("/imports/api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 7);
let VotingPowerHistory;
module.link("/imports/api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 8);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 9);
let Evidences;
module.link("../../evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 10);
let sha256;
module.link("js-sha256", {
  sha256(v) {
    sha256 = v;
  }

}, 11);
let getAddress;
module.link("tendermint/lib/pubkey", {
  getAddress(v) {
    getAddress = v;
  }

}, 12);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 13);

// import Block from '../../../ui/components/Block';
// getValidatorVotingPower = (validators, address) => {
//     for (v in validators){
//         if (validators[v].address == address){
//             return parseInt(validators[v].voting_power);
//         }
//     }
// }
getRemovedValidators = (prevValidators, validators) => {
  // let removeValidators = [];
  for (p in prevValidators) {
    for (v in validators) {
      if (prevValidators[p].address == validators[v].address) {
        prevValidators.splice(p, 1);
      }
    }
  }

  return prevValidators;
};

getValidatorProfileUrl = identity => {
  if (identity.length == 16) {
    let response = HTTP.get("https://keybase.io/_/api/1.0/user/lookup.json?key_suffix=".concat(identity, "&fields=pictures"));

    if (response.statusCode == 200) {
      let them = response.data.them;
      return them && them.length && them[0].pictures && them[0].pictures.primary && them[0].pictures.primary.url;
    } else {
      console.log(JSON.stringify(response));
    }
  } else if (identity.indexOf("keybase.io/team/") > 0) {
    let teamPage = HTTP.get(identity);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    } else {
      console.log(JSON.stringify(teamPage));
    }
  }
}; // var filtered = [1, 2, 3, 4, 5].filter(notContainedIn([1, 2, 3, 5]));
// console.log(filtered); // [4]


Meteor.methods({
  'blocks.averageBlockTime'(address) {
    let blocks = Blockscon.find({
      proposerAddress: address
    }).fetch();
    let heights = blocks.map((block, i) => {
      return block.height;
    });
    let blocksStats = Analytics.find({
      height: {
        $in: heights
      }
    }).fetch(); // console.log(blocksStats);

    let totalBlockDiff = 0;

    for (b in blocksStats) {
      totalBlockDiff += blocksStats[b].timeDiff;
    }

    return totalBlockDiff / heights.length;
  },

  'blocks.findUpTime'(address) {
    let collection = ValidatorRecords.rawCollection(); // let aggregateQuery = Meteor.wrapAsync(collection.aggregate, collection);

    var pipeline = [{
      $match: {
        "address": address
      }
    }, // {$project:{address:1,height:1,exists:1}},
    {
      $sort: {
        "height": -1
      }
    }, {
      $limit: Meteor.settings.public.uptimeWindow - 1
    }, {
      $unwind: "$_id"
    }, {
      $group: {
        "_id": "$address",
        "uptime": {
          "$sum": {
            $cond: [{
              $eq: ['$exists', true]
            }, 1, 0]
          }
        }
      }
    }]; // let result = aggregateQuery(pipeline, { cursor: {} });

    return Promise.await(collection.aggregate(pipeline).toArray()); // return .aggregate()
  },

  'blocks.getLatestHeight': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      return status.result.sync_info.latest_block_height;
    } catch (e) {
      return 0;
    }
  },
  'blocks.getCurrentHeight': function () {
    this.unblock();
    let currHeight = Blockscon.find({}, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch(); // console.log("currentHeight:"+currHeight);

    let startHeight = Meteor.settings.params.startHeight;

    if (currHeight && currHeight.length == 1) {
      let height = currHeight[0].height;
      if (height > startHeight) return height;
    }

    return startHeight;
  },
  'blocks.blocksUpdate': function () {
    if (SYNCING) return "Syncing...";else console.log("start to sync"); // Meteor.clearInterval(Meteor.timerHandle);
    // get the latest height

    let until = Meteor.call('blocks.getLatestHeight'); // console.log(until);
    // get the current height in db

    let curr = Meteor.call('blocks.getCurrentHeight');
    console.log(curr); // loop if there's update in db

    if (until > curr) {
      SYNCING = true;
      let validatorSet = {}; // get latest validator candidate information

      url = LCD + '/staking/validators';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonding';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      url = LCD + '/staking/validators?status=unbonded';

      try {
        response = HTTP.get(url);
        JSON.parse(response.content).result.forEach(validator => validatorSet[validator.consensus_pubkey] = validator);
      } catch (e) {
        console.log(e);
      }

      let totalValidators = Object.keys(validatorSet).length;
      console.log("all validators: " + totalValidators);

      for (let height = curr + 1; height <= until; height++) {
        let startBlockTime = new Date(); // add timeout here? and outside this loop (for catched up and keep fetching)?

        this.unblock();
        let url = RPC + '/block?height=' + height;
        let analyticsData = {};
        console.log(url);

        try {
          const bulkValidators = Validators.rawCollection().initializeUnorderedBulkOp();
          const bulkValidatorRecords = ValidatorRecords.rawCollection().initializeUnorderedBulkOp();
          const bulkVPHistory = VotingPowerHistory.rawCollection().initializeUnorderedBulkOp();
          const bulkTransations = Transactions.rawCollection().initializeUnorderedBulkOp();
          let startGetHeightTime = new Date();
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let block = JSON.parse(response.content);
            block = block.result; // store height, hash, numtransaction and time in db

            let blockData = {};
            blockData.height = height;
            blockData.hash = block.block_meta.block_id.hash;
            blockData.transNum = block.block_meta.header.num_txs;
            blockData.time = new Date(block.block.header.time);
            blockData.lastBlockHash = block.block.header.last_block_id.hash;
            blockData.proposerAddress = block.block.header.proposer_address;
            blockData.validators = [];
            let precommits = block.block.last_commit.precommits;

            if (precommits != null) {
              // console.log(precommits.length);
              for (let i = 0; i < precommits.length; i++) {
                if (precommits[i] != null) {
                  blockData.validators.push(precommits[i].validator_address);
                }
              }

              analyticsData.precommits = precommits.length; // record for analytics
              // PrecommitRecords.insert({height:height, precommits:precommits.length});
            } // save txs in database


            if (block.block.data.txs && block.block.data.txs.length > 0) {
              for (t in block.block.data.txs) {
                Meteor.call('Transactions.index', sha256(Buffer.from(block.block.data.txs[t], 'base64')), blockData.time, (err, result) => {
                  if (err) {
                    console.log(err);
                  }
                });
              }
            } // save double sign evidences


            if (block.block.evidence.evidence) {
              Evidences.insert({
                height: height,
                evidence: block.block.evidence.evidence
              });
            }

            blockData.precommitsCount = blockData.validators.length;
            analyticsData.height = height;
            let endGetHeightTime = new Date();
            console.log("Get height time: " + (endGetHeightTime - startGetHeightTime) / 1000 + "seconds.");
            let startGetValidatorsTime = new Date(); // update chain status

            url = RPC + '/validators?height=' + height;
            response = HTTP.get(url);
            console.log(url);
            let validators = JSON.parse(response.content);
            validators.result.block_height = parseInt(validators.result.block_height);
            ValidatorSets.insert(validators.result);
            blockData.validatorsCount = validators.result.validators.length;
            let startBlockInsertTime = new Date();
            Blockscon.insert(blockData);
            let endBlockInsertTime = new Date();
            console.log("Block insert time: " + (endBlockInsertTime - startBlockInsertTime) / 1000 + "seconds."); // store valdiators exist records

            let existingValidators = Validators.find({
              address: {
                $exists: true
              }
            }).fetch();

            if (height > 1) {
              // record precommits and calculate uptime
              // only record from block 2
              for (i in validators.result.validators) {
                let address = validators.result.validators[i].address;
                let record = {
                  height: height,
                  address: address,
                  exists: false,
                  voting_power: parseInt(validators.result.validators[i].voting_power) //getValidatorVotingPower(existingValidators, address)

                };

                for (j in precommits) {
                  if (precommits[j] != null) {
                    if (address == precommits[j].validator_address) {
                      record.exists = true;
                      precommits.splice(j, 1);
                      break;
                    }
                  }
                } // calculate the uptime based on the records stored in previous blocks
                // only do this every 15 blocks ~


                if (height % 15 == 0) {
                  // let startAggTime = new Date();
                  let numBlocks = Meteor.call('blocks.findUpTime', address);
                  let uptime = 0; // let endAggTime = new Date();
                  // console.log("Get aggregated uptime for "+existingValidators[i].address+": "+((endAggTime-startAggTime)/1000)+"seconds.");

                  if (numBlocks[0] != null && numBlocks[0].uptime != null) {
                    uptime = numBlocks[0].uptime;
                  }

                  let base = Meteor.settings.public.uptimeWindow;

                  if (height < base) {
                    base = height;
                  }

                  if (record.exists) {
                    if (uptime < base) {
                      uptime++;
                    }

                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime,
                        lastSeen: blockData.time
                      }
                    });
                  } else {
                    uptime = uptime / base * 100;
                    bulkValidators.find({
                      address: address
                    }).upsert().updateOne({
                      $set: {
                        uptime: uptime
                      }
                    });
                  }
                }

                bulkValidatorRecords.insert(record); // ValidatorRecords.update({height:height,address:record.address},record);
              }
            }

            let chainStatus = Chain.findOne({
              chainId: block.block_meta.header.chain_id
            });
            let lastSyncedTime = chainStatus ? chainStatus.lastSyncedTime : 0;
            let timeDiff;
            let blockTime = Meteor.settings.params.defaultBlockTime;

            if (lastSyncedTime) {
              let dateLatest = blockData.time;
              let dateLast = new Date(lastSyncedTime);
              timeDiff = Math.abs(dateLatest.getTime() - dateLast.getTime());
              blockTime = (chainStatus.blockTime * (blockData.height - 1) + timeDiff) / blockData.height;
            }

            let endGetValidatorsTime = new Date();
            console.log("Get height validators time: " + (endGetValidatorsTime - startGetValidatorsTime) / 1000 + "seconds.");
            Chain.update({
              chainId: block.block_meta.header.chain_id
            }, {
              $set: {
                lastSyncedTime: blockData.time,
                blockTime: blockTime
              }
            });
            analyticsData.averageBlockTime = blockTime;
            analyticsData.timeDiff = timeDiff;
            analyticsData.time = blockData.time; // initialize validator data at first block
            // if (height == 1){
            //     Validators.remove({});
            // }

            analyticsData.voting_power = 0;
            let startFindValidatorsNameTime = new Date();

            if (validators.result) {
              // validators are all the validators in the current height
              console.log("validatorSet size: " + validators.result.validators.length);

              for (v in validators.result.validators) {
                // Validators.insert(validators.result.validators[v]);
                let validator = validators.result.validators[v];
                validator.voting_power = parseInt(validator.voting_power);
                validator.proposer_priority = parseInt(validator.proposer_priority);
                let valExist = Validators.findOne({
                  "pub_key.value": validator.pub_key.value
                });

                if (!valExist) {
                  console.log("validator pub_key ".concat(validator.address, " ").concat(validator.pub_key.value, " not in db")); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+validator.pub_key.value;
                  // console.log(command);
                  // let tempVal = validator;

                  validator.address = getAddress(validator.pub_key);
                  validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                  validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
                  validator.consensus_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixConsPub);
                  let validatorData = validatorSet[validator.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description.identity) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.operator_address = validatorData.operator_address;
                    validator.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.min_self_delegation = validatorData.min_self_delegation;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission;
                    validator.self_delegation = validator.delegator_shares; // validator.removed = false,
                    // validator.removedAt = 0
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  } // bulkValidators.insert(validator);


                  bulkValidators.find({
                    address: validator.address
                  }).upsert().updateOne({
                    $set: validator
                  }); // console.log("validator first appears: "+bulkValidators.length);

                  bulkVPHistory.insert({
                    address: validator.address,
                    prev_voting_power: 0,
                    voting_power: validator.voting_power,
                    type: 'add',
                    height: blockData.height,
                    block_time: blockData.time
                  }); // Meteor.call('runCode', command, function(error, result){
                  // validator.address = result.match(/\s[0-9A-F]{40}$/igm);
                  // validator.address = validator.address[0].trim();
                  // validator.hex = result.match(/\s[0-9A-F]{64}$/igm);
                  // validator.hex = validator.hex[0].trim();
                  // validator.cosmosaccpub = result.match(/cosmospub.*$/igm);
                  // validator.cosmosaccpub = validator.cosmosaccpub[0].trim();
                  // validator.operator_pubkey = result.match(/cosmosvaloperpub.*$/igm);
                  // validator.operator_pubkey = validator.operator_pubkey[0].trim();
                  // validator.consensus_pubkey = result.match(/cosmosvalconspub.*$/igm);
                  // validator.consensus_pubkey = validator.consensus_pubkey[0].trim();
                  // });
                } else {
                  let validatorData = validatorSet[valExist.consensus_pubkey];

                  if (validatorData) {
                    if (validatorData.description && (!valExist.description || validatorData.description.identity !== valExist.description.identity)) validator.profile_url = getValidatorProfileUrl(validatorData.description.identity);
                    validator.jailed = validatorData.jailed;
                    validator.status = validatorData.status;
                    validator.tokens = validatorData.tokens;
                    validator.delegator_shares = validatorData.delegator_shares;
                    validator.description = validatorData.description;
                    validator.bond_height = validatorData.bond_height;
                    validator.bond_intra_tx_counter = validatorData.bond_intra_tx_counter;
                    validator.unbonding_height = validatorData.unbonding_height;
                    validator.unbonding_time = validatorData.unbonding_time;
                    validator.commission = validatorData.commission; // calculate self delegation percentage every 30 blocks

                    if (height % 30 == 1) {
                      try {
                        let response = HTTP.get(LCD + '/staking/delegators/' + valExist.delegator_address + '/delegations/' + valExist.operator_address);

                        if (response.statusCode == 200) {
                          let selfDelegation = JSON.parse(response.content).result;

                          if (selfDelegation.shares) {
                            validator.self_delegation = parseFloat(selfDelegation.shares) / parseFloat(validator.delegator_shares);
                          }
                        }
                      } catch (e) {// console.log(e);
                      }
                    }

                    bulkValidators.find({
                      consensus_pubkey: valExist.consensus_pubkey
                    }).updateOne({
                      $set: validator
                    }); // console.log("validator exisits: "+bulkValidators.length);
                    // validatorSet.splice(val, 1);
                  } else {
                    console.log('no con pub key?');
                  }

                  let prevVotingPower = VotingPowerHistory.findOne({
                    address: validator.address
                  }, {
                    height: -1,
                    limit: 1
                  });

                  if (prevVotingPower) {
                    if (prevVotingPower.voting_power != validator.voting_power) {
                      let changeType = prevVotingPower.voting_power > validator.voting_power ? 'down' : 'up';
                      let changeData = {
                        address: validator.address,
                        prev_voting_power: prevVotingPower.voting_power,
                        voting_power: validator.voting_power,
                        type: changeType,
                        height: blockData.height,
                        block_time: blockData.time
                      }; // console.log('voting power changed.');
                      // console.log(changeData);

                      bulkVPHistory.insert(changeData);
                    }
                  }
                } // console.log(validator);


                analyticsData.voting_power += validator.voting_power;
              } // if there is validator removed


              let prevValidators = ValidatorSets.findOne({
                block_height: height - 1
              });

              if (prevValidators) {
                let removedValidators = getRemovedValidators(prevValidators.validators, validators.result.validators);

                for (r in removedValidators) {
                  bulkVPHistory.insert({
                    address: removedValidators[r].address,
                    prev_voting_power: removedValidators[r].voting_power,
                    voting_power: 0,
                    type: 'remove',
                    height: blockData.height,
                    block_time: blockData.time
                  });
                }
              }
            } // check if there's any validator not in db 14400 blocks(~1 day)


            if (height % 14400 == 0) {
              try {
                console.log('Checking all validators against db...');
                let dbValidators = {};
                Validators.find({}, {
                  fields: {
                    consensus_pubkey: 1,
                    status: 1
                  }
                }).forEach(v => dbValidators[v.consensus_pubkey] = v.status);
                Object.keys(validatorSet).forEach(conPubKey => {
                  let validatorData = validatorSet[conPubKey]; // Active validators should have been updated in previous steps

                  if (validatorData.status === 2) return;

                  if (dbValidators[conPubKey] == undefined) {
                    console.log("validator with consensus_pubkey ".concat(conPubKey, " not in db"));
                    let pubkeyType = Meteor.settings.public.secp256k1 ? 'tendermint/PubKeySecp256k1' : 'tendermint/PubKeyEd25519';
                    validatorData.pub_key = {
                      "type": pubkeyType,
                      "value": Meteor.call('bech32ToPubkey', conPubKey)
                    };
                    validatorData.address = getAddress(validatorData.pub_key);
                    validatorData.delegator_address = Meteor.call('getDelegator', validatorData.operator_address);
                    validatorData.accpub = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixAccPub);
                    validatorData.operator_pubkey = Meteor.call('pubkeyToBech32', validatorData.pub_key, Meteor.settings.public.bech32PrefixValPub);
                    console.log(JSON.stringify(validatorData));
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  } else if (dbValidators[conPubKey] == 2) {
                    bulkValidators.find({
                      consensus_pubkey: conPubKey
                    }).upsert().updateOne({
                      $set: validatorData
                    });
                  }
                });
              } catch (e) {
                console.log(e);
              }
            } // fetching keybase every 14400 blocks(~1 day)


            if (height % 14400 == 1) {
              console.log('Fetching keybase...');
              Validators.find({}).forEach(validator => {
                try {
                  let profileUrl = getValidatorProfileUrl(validator.description.identity);

                  if (profileUrl) {
                    bulkValidators.find({
                      address: validator.address
                    }).upsert().updateOne({
                      $set: {
                        'profile_url': profileUrl
                      }
                    });
                  }
                } catch (e) {
                  console.log(e);
                }
              });
            }

            let endFindValidatorsNameTime = new Date();
            console.log("Get validators name time: " + (endFindValidatorsNameTime - startFindValidatorsNameTime) / 1000 + "seconds."); // record for analytics

            let startAnayticsInsertTime = new Date();
            Analytics.insert(analyticsData);
            let endAnalyticsInsertTime = new Date();
            console.log("Analytics insert time: " + (endAnalyticsInsertTime - startAnayticsInsertTime) / 1000 + "seconds.");
            let startVUpTime = new Date();

            if (bulkValidators.length > 0) {
              // console.log(bulkValidators.length);
              bulkValidators.execute((err, result) => {
                if (err) {
                  console.log(err);
                }

                if (result) {// console.log(result);
                }
              });
            }

            let endVUpTime = new Date();
            console.log("Validator update time: " + (endVUpTime - startVUpTime) / 1000 + "seconds.");
            let startVRTime = new Date();

            if (bulkValidatorRecords.length > 0) {
              bulkValidatorRecords.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            let endVRTime = new Date();
            console.log("Validator records update time: " + (endVRTime - startVRTime) / 1000 + "seconds.");

            if (bulkVPHistory.length > 0) {
              bulkVPHistory.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            }

            if (bulkTransations.length > 0) {
              bulkTransations.execute((err, result) => {
                if (err) {
                  console.log(err);
                }
              });
            } // calculate voting power distribution every 60 blocks ~ 5mins


            if (height % 60 == 1) {
              console.log("===== calculate voting power distribution =====");
              let activeValidators = Validators.find({
                status: 2,
                jailed: false
              }, {
                sort: {
                  voting_power: -1
                }
              }).fetch();
              let numTopTwenty = Math.ceil(activeValidators.length * 0.2);
              let numBottomEighty = activeValidators.length - numTopTwenty;
              let topTwentyPower = 0;
              let bottomEightyPower = 0;
              let numTopThirtyFour = 0;
              let numBottomSixtySix = 0;
              let topThirtyFourPercent = 0;
              let bottomSixtySixPercent = 0;

              for (v in activeValidators) {
                if (v < numTopTwenty) {
                  topTwentyPower += activeValidators[v].voting_power;
                } else {
                  bottomEightyPower += activeValidators[v].voting_power;
                }

                if (topThirtyFourPercent < 0.34) {
                  topThirtyFourPercent += activeValidators[v].voting_power / analyticsData.voting_power;
                  numTopThirtyFour++;
                }
              }

              bottomSixtySixPercent = 1 - topThirtyFourPercent;
              numBottomSixtySix = activeValidators.length - numTopThirtyFour;
              let vpDist = {
                height: height,
                numTopTwenty: numTopTwenty,
                topTwentyPower: topTwentyPower,
                numBottomEighty: numBottomEighty,
                bottomEightyPower: bottomEightyPower,
                numTopThirtyFour: numTopThirtyFour,
                topThirtyFourPercent: topThirtyFourPercent,
                numBottomSixtySix: numBottomSixtySix,
                bottomSixtySixPercent: bottomSixtySixPercent,
                numValidators: activeValidators.length,
                totalVotingPower: analyticsData.voting_power,
                blockTime: blockData.time,
                createAt: new Date()
              };
              console.log(vpDist);
              VPDistributions.insert(vpDist);
            }
          }
        } catch (e) {
          console.log(e);
          SYNCING = false;
          return "Stopped";
        }

        let endBlockTime = new Date();
        console.log("This block used: " + (endBlockTime - startBlockTime) / 1000 + "seconds.");
      }

      SYNCING = false;
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          lastBlocksSyncedTime: new Date(),
          totalValidators: totalValidators
        }
      });
    }

    return until;
  },
  'addLimit': function (limit) {
    // console.log(limit+10)
    return limit + 10;
  },
  'hasMore': function (limit) {
    if (limit > Meteor.call('getCurrentHeight')) {
      return false;
    } else {
      return true;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Blockscon;
module.link("../blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
publishComposite('blocks.height', function (limit) {
  return {
    find() {
      return Blockscon.find({}, {
        limit: limit,
        sort: {
          height: -1
        }
      });
    },

    children: [{
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
publishComposite('blocks.findOne', function (height) {
  return {
    find() {
      return Blockscon.find({
        height: height
      });
    },

    children: [{
      find(block) {
        return Transactions.find({
          height: block.height
        });
      }

    }, {
      find(block) {
        return Validators.find({
          address: block.proposerAddress
        }, {
          limit: 1
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"blocks.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/blocks/blocks.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Blockscon: () => Blockscon
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Blockscon = new Mongo.Collection('blocks');
Blockscon.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

}); // Blockscon.helpers({
//     sorted(limit) {
//         return Blockscon.find({}, {sort: {height:-1}, limit: limit});
//     }
// });
// Meteor.setInterval(function() {
//     Meteor.call('blocksUpdate', (error, result) => {
//         console.log(result);
//     })
// }, 30000000);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/methods.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let getAddress;
module.link("tendermint/lib/pubkey.js", {
  getAddress(v) {
    getAddress = v;
  }

}, 2);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 3);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 4);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 5);
let Coin;
module.link("../../../../both/utils/coins.js", {
  default(v) {
    Coin = v;
  }

}, 6);

findVotingPower = (validator, genValidators) => {
  for (let v in genValidators) {
    if (validator.pub_key.value == genValidators[v].pub_key.value) {
      return parseInt(genValidators[v].power);
    }
  }
};

Meteor.methods({
  'chain.getConsensusState': function () {
    this.unblock();
    let url = RPC + '/dump_consensus_state';

    try {
      let response = HTTP.get(url);
      let consensus = JSON.parse(response.content);
      consensus = consensus.result;
      let height = consensus.round_state.height;
      let round = consensus.round_state.round;
      let step = consensus.round_state.step;
      let votedPower = Math.round(parseFloat(consensus.round_state.votes[round].prevotes_bit_array.split(" ")[3]) * 100);
      Chain.update({
        chainId: Meteor.settings.public.chainId
      }, {
        $set: {
          votingHeight: height,
          votingRound: round,
          votingStep: step,
          votedPower: votedPower,
          proposerAddress: consensus.round_state.validators.proposer.address,
          prevotes: consensus.round_state.votes[round].prevotes,
          precommits: consensus.round_state.votes[round].precommits
        }
      });
    } catch (e) {
      console.log(e);
    }
  },
  'chain.updateStatus': function () {
    this.unblock();
    let url = RPC + '/status';

    try {
      let response = HTTP.get(url);
      let status = JSON.parse(response.content);
      status = status.result;
      let chain = {};
      chain.chainId = status.node_info.network;
      chain.latestBlockHeight = status.sync_info.latest_block_height;
      chain.latestBlockTime = status.sync_info.latest_block_time;
      let latestState = ChainStates.findOne({}, {
        sort: {
          height: -1
        }
      });

      if (latestState && latestState.height >= chain.latestBlockHeight) {
        return "no updates (getting block ".concat(chain.latestBlockHeight, " at block ").concat(latestState.height, ")");
      }

      url = RPC + '/validators';
      response = HTTP.get(url);
      let validators = JSON.parse(response.content);
      validators = validators.result.validators;
      chain.validators = validators.length;
      let activeVP = 0;

      for (v in validators) {
        activeVP += parseInt(validators[v].voting_power);
      }

      chain.activeVotingPower = activeVP;
      Chain.update({
        chainId: chain.chainId
      }, {
        $set: chain
      }, {
        upsert: true
      }); // Get chain states

      if (parseInt(chain.latestBlockHeight) > 0) {
        let chainStates = {};
        chainStates.height = parseInt(status.sync_info.latest_block_height);
        chainStates.time = new Date(status.sync_info.latest_block_time);
        url = LCD + '/staking/pool';

        try {
          response = HTTP.get(url);
          let bonding = JSON.parse(response.content).result; // chain.bondedTokens = bonding.bonded_tokens;
          // chain.notBondedTokens = bonding.not_bonded_tokens;

          chainStates.bondedTokens = parseInt(bonding.bonded_tokens);
          chainStates.notBondedTokens = parseInt(bonding.not_bonded_tokens);
        } catch (e) {
          console.log(e);
        }

        if (Coin.StakingCoin.denom) {
          url = LCD + '/supply/total/' + Coin.StakingCoin.denom;

          try {
            response = HTTP.get(url);
            let supply = JSON.parse(response.content).result;
            chainStates.totalSupply = parseInt(supply);
          } catch (e) {
            console.log(e);
          }

          url = LCD + '/distribution/community_pool';

          try {
            response = HTTP.get(url);
            let pool = JSON.parse(response.content).result;

            if (pool && pool.length > 0) {
              chainStates.communityPool = [];
              pool.forEach((amount, i) => {
                chainStates.communityPool.push({
                  denom: amount.denom,
                  amount: parseFloat(amount.amount)
                });
              });
            }
          } catch (e) {
            console.log(e);
          }

          url = LCD + '/minting/inflation';

          try {
            response = HTTP.get(url);
            let inflation = JSON.parse(response.content).result;

            if (inflation) {
              chainStates.inflation = parseFloat(inflation);
            }
          } catch (e) {
            console.log(e);
          }

          url = LCD + '/minting/annual-provisions';

          try {
            response = HTTP.get(url);
            let provisions = JSON.parse(response.content);

            if (provisions) {
              chainStates.annualProvisions = parseFloat(provisions.result);
            }
          } catch (e) {
            console.log(e);
          }
        }

        ChainStates.insert(chainStates);
      } // chain.totalVotingPower = totalVP;
      // validators = Validators.find({}).fetch();
      // console.log(validators);


      return chain.latestBlockHeight;
    } catch (e) {
      console.log(e);
      return "Error getting chain status.";
    }
  },
  'chain.getLatestStatus': function () {
    Chain.find().sort({
      created: -1
    }).limit(1);
  },
  'chain.genesis': function () {
    let chain = Chain.findOne({
      chainId: Meteor.settings.public.chainId
    });

    if (chain && chain.readGenesis) {
      console.log('Genesis file has been processed');
    } else if (Meteor.settings.debug.readGenesis) {
      console.log('=== Start processing genesis file ===');
      let response = HTTP.get(Meteor.settings.genesisFile);
      let genesis = JSON.parse(response.content);
      let distr = genesis.app_state.distr || genesis.app_state.distribution;
      let chainParams = {
        chainId: genesis.chain_id,
        genesisTime: genesis.genesis_time,
        consensusParams: genesis.consensus_params,
        auth: genesis.app_state.auth,
        bank: genesis.app_state.bank,
        staking: {
          pool: genesis.app_state.staking.pool,
          params: genesis.app_state.staking.params
        },
        mint: genesis.app_state.mint,
        distr: {
          communityTax: distr.community_tax,
          baseProposerReward: distr.base_proposer_reward,
          bonusProposerReward: distr.bonus_proposer_reward,
          withdrawAddrEnabled: distr.withdraw_addr_enabled
        },
        gov: {
          startingProposalId: 0,
          depositParams: {},
          votingParams: {},
          tallyParams: {}
        },
        slashing: {
          params: genesis.app_state.slashing.params
        },
        supply: genesis.app_state.supply,
        crisis: genesis.app_state.crisis
      };

      if (genesis.app_state.gov) {
        chainParams.gov = {
          startingProposalId: genesis.app_state.gov.starting_proposal_id,
          depositParams: genesis.app_state.gov.deposit_params,
          votingParams: genesis.app_state.gov.voting_params,
          tallyParams: genesis.app_state.gov.tally_params
        };
      }

      let totalVotingPower = 0; // read gentx

      if (genesis.app_state.genutil && genesis.app_state.genutil.gentxs && genesis.app_state.genutil.gentxs.length > 0) {
        for (i in genesis.app_state.genutil.gentxs) {
          let msg = genesis.app_state.genutil.gentxs[i].value.msg; // console.log(msg.type);

          for (m in msg) {
            if (msg[m].type == "cosmos-sdk/MsgCreateValidator") {
              console.log(msg[m].value); // let command = Meteor.settings.bin.gaiadebug+" pubkey "+msg[m].value.pubkey;

              let validator = {
                consensus_pubkey: msg[m].value.pubkey,
                description: msg[m].value.description,
                commission: msg[m].value.commission,
                min_self_delegation: msg[m].value.min_self_delegation,
                operator_address: msg[m].value.validator_address,
                delegator_address: msg[m].value.delegator_address,
                voting_power: Math.floor(parseInt(msg[m].value.value.amount) / Coin.StakingCoin.fraction),
                jailed: false,
                status: 2
              };
              totalVotingPower += validator.voting_power;
              let pubkeyType = Meteor.settings.public.secp256k1 ? 'tendermint/PubKeySecp256k1' : 'tendermint/PubKeyEd25519';
              let pubkeyValue = Meteor.call('bech32ToPubkey', msg[m].value.pubkey, pubkeyType); // Validators.upsert({consensus_pubkey:msg[m].value.pubkey},validator);

              validator.pub_key = {
                "type": pubkeyType,
                "value": pubkeyValue
              };
              validator.address = getAddress(validator.pub_key);
              validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
              validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
              VotingPowerHistory.insert({
                address: validator.address,
                prev_voting_power: 0,
                voting_power: validator.voting_power,
                type: 'add',
                height: 0,
                block_time: genesis.genesis_time
              });
              Validators.insert(validator);
            }
          }
        }
      } // read validators from previous chain


      console.log('read validators from previous chain');

      if (genesis.app_state.staking.validators && genesis.app_state.staking.validators.length > 0) {
        console.log(genesis.app_state.staking.validators.length);
        let genValidatorsSet = genesis.app_state.staking.validators;
        let genValidators = genesis.validators;

        for (let v in genValidatorsSet) {
          // console.log(genValidators[v]);
          let validator = genValidatorsSet[v];
          validator.delegator_address = Meteor.call('getDelegator', genValidatorsSet[v].operator_address);
          let pubkeyType = Meteor.settings.public.secp256k1 ? 'tendermint/PubKeySecp256k1' : 'tendermint/PubKeyEd25519';
          let pubkeyValue = Meteor.call('bech32ToPubkey', validator.consensus_pubkey, pubkeyType);
          validator.pub_key = {
            "type": pubkeyType,
            "value": pubkeyValue
          };
          validator.address = getAddress(validator.pub_key);
          validator.pub_key = validator.pub_key;
          validator.accpub = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixAccPub);
          validator.operator_pubkey = Meteor.call('pubkeyToBech32', validator.pub_key, Meteor.settings.public.bech32PrefixValPub);
          validator.voting_power = findVotingPower(validator, genValidators);
          totalVotingPower += validator.voting_power;
          Validators.upsert({
            consensus_pubkey: validator.consensus_pubkey
          }, validator);
          VotingPowerHistory.insert({
            address: validator.address,
            prev_voting_power: 0,
            voting_power: validator.voting_power,
            type: 'add',
            height: 0,
            block_time: genesis.genesis_time
          });
        }
      }

      chainParams.readGenesis = true;
      chainParams.activeVotingPower = totalVotingPower;
      let result = Chain.upsert({
        chainId: chainParams.chainId
      }, {
        $set: chainParams
      });
      console.log('=== Finished processing genesis file ===');
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/server/publications.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Chain, ChainStates;
module.link("../chain.js", {
  Chain(v) {
    Chain = v;
  },

  ChainStates(v) {
    ChainStates = v;
  }

}, 1);
let CoinStats;
module.link("../../coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
Meteor.publish('chainStates.latest', function () {
  return [ChainStates.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  }), CoinStats.find({}, {
    sort: {
      last_updated_at: -1
    },
    limit: 1
  })];
});
publishComposite('chain.status', function () {
  return {
    find() {
      return Chain.find({
        chainId: Meteor.settings.public.chainId
      });
    },

    children: [{
      find(chain) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1,
            status: -1,
            jailed: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chain.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chain/chain.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Chain: () => Chain,
  ChainStates: () => ChainStates
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const Chain = new Mongo.Collection('chain');
const ChainStates = new Mongo.Collection('chain_states');
Chain.helpers({
  proposer() {
    return Validators.findOne({
      address: this.proposerAddress
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let CoinStats;
module.link("../coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 1);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 2);
Meteor.methods({
  'coinStats.getCoinStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      try {
        let now = new Date();
        now.setMinutes(0);
        let url = "https://api.coingecko.com/api/v3/simple/price?ids=" + coinId + "&vs_currencies=usd&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true&include_last_updated_at=true";
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          // console.log(JSON.parse(response.content));
          let data = JSON.parse(response.content);
          data = data[coinId]; // console.log(coinStats);

          return CoinStats.upsert({
            last_updated_at: data.last_updated_at
          }, {
            $set: data
          });
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      return "No coingecko Id provided.";
    }
  },
  'coinStats.getStats': function () {
    this.unblock();
    let coinId = Meteor.settings.public.coingeckoId;

    if (coinId) {
      return CoinStats.findOne({}, {
        sort: {
          last_updated_at: -1
        }
      });
    } else {
      return "No coingecko Id provided.";
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"coin-stats.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/coin-stats/coin-stats.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  CoinStats: () => CoinStats
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const CoinStats = new Mongo.Collection('coin_stats');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/methods.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Delegations;
module.link("../delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.methods({
  'delegations.getDelegations': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let delegations = [];
    console.log("=== Getting delegations ===");

    for (v in validators) {
      if (validators[v].operator_address) {
        let url = LCD + '/staking/validators/' + validators[v].operator_address + "/delegations";

        try {
          let response = HTTP.get(url);

          if (response.statusCode == 200) {
            let delegation = JSON.parse(response.content).result; // console.log(delegation);

            delegations = delegations.concat(delegation);
          } else {
            console.log(response.statusCode);
          }
        } catch (e) {
          console.log(e);
        }
      }
    }

    for (i in delegations) {
      if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
    } // console.log(delegations);


    let data = {
      delegations: delegations,
      createdAt: new Date()
    };
    return Delegations.insert(data);
  } // 'blocks.averageBlockTime'(address){
  //     let blocks = Blockscon.find({proposerAddress:address}).fetch();
  //     let heights = blocks.map((block, i) => {
  //         return block.height;
  //     });
  //     let blocksStats = Analytics.find({height:{$in:heights}}).fetch();
  //     // console.log(blocksStats);
  //     let totalBlockDiff = 0;
  //     for (b in blocksStats){
  //         totalBlockDiff += blocksStats[b].timeDiff;
  //     }
  //     return totalBlockDiff/heights.length;
  // }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/server/publications.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"delegations.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/delegations/delegations.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Delegations: () => Delegations
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Delegations = new Mongo.Collection('delegations');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"ledger":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/ledger/server/methods.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 0);
Meteor.methods({
  'transaction.submit': function (txInfo) {
    const url = "".concat(LCD, "/txs");
    data = {
      "tx": txInfo.value,
      "mode": "sync"
    };
    const timestamp = new Date().getTime();
    console.log("submitting transaction".concat(timestamp, " ").concat(url, " with data ").concat(JSON.stringify(data)));
    let response = HTTP.post(url, {
      data
    });
    console.log("response for transaction".concat(timestamp, " ").concat(url, ": ").concat(JSON.stringify(response)));

    if (response.statusCode == 200) {
      let data = response.data;
      if (data.code) throw new Meteor.Error(data.code, JSON.parse(data.raw_log).message);
      return response.data.txhash;
    }
  },
  'transaction.execute': function (body, path) {
    const url = "".concat(LCD, "/").concat(path);
    data = {
      "base_req": _objectSpread({}, body, {
        "chain_id": Meteor.settings.public.chainId,
        "simulate": false
      })
    };
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content);
    }
  },
  'transaction.simulate': function (txMsg, from, path) {
    let adjustment = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '1.2';
    const url = "".concat(LCD, "/").concat(path);
    data = _objectSpread({}, txMsg, {
      "base_req": {
        "from": from,
        "chain_id": Meteor.settings.public.chainId,
        "gas_adjustment": adjustment,
        "simulate": true
      }
    });
    let response = HTTP.post(url, {
      data
    });

    if (response.statusCode == 200) {
      return JSON.parse(response.content).gas_estimate;
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"proposals":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/server/methods.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let _objectSpread;

module.link("@babel/runtime/helpers/objectSpread2", {
  default(v) {
    _objectSpread = v;
  }

}, 0);
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Proposals;
module.link("../proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
// import { Promise } from 'meteor/promise';
Meteor.methods({
  'proposals.getProposals': function () {
    this.unblock();

    try {
      let url = LCD + '/gov/proposals';
      let response = HTTP.get(url);
      let proposals = JSON.parse(response.content).result; // console.log(proposals);

      let finishedProposalIds = new Set(Proposals.find({
        "proposal_status": {
          $in: ["Passed", "Rejected", "Removed"]
        }
      }).fetch().map(p => p.proposalId));
      let proposalIds = [];

      if (proposals.length > 0) {
        // Proposals.upsert()
        const bulkProposals = Proposals.rawCollection().initializeUnorderedBulkOp();

        for (let i in proposals) {
          let proposal = proposals[i];
          proposal.proposalId = parseInt(proposal.id);

          if (proposal.proposalId > 0 && !finishedProposalIds.has(proposal.proposalId)) {
            try {
              let url = LCD + '/gov/proposals/' + proposal.proposalId + '/proposer';
              let response = HTTP.get(url);

              if (response.statusCode == 200) {
                let proposer = JSON.parse(response.content).result;

                if (proposer.proposal_id && proposer.proposal_id == proposal.id) {
                  proposal.proposer = proposer.proposer;
                }
              }

              bulkProposals.find({
                proposalId: proposal.proposalId
              }).upsert().updateOne({
                $set: proposal
              });
              proposalIds.push(proposal.proposalId);
            } catch (e) {
              bulkProposals.find({
                proposalId: proposal.proposalId
              }).upsert().updateOne({
                $set: proposal
              });
              proposalIds.push(proposal.proposalId);
              console.log(e.response.content);
            }
          }
        }

        bulkProposals.find({
          proposalId: {
            $nin: proposalIds
          },
          proposal_status: {
            $nin: ["Passed", "Rejected", "Removed"]
          }
        }).update({
          $set: {
            "proposal_status": "Removed"
          }
        });
        bulkProposals.execute();
      }

      return true;
    } catch (e) {
      console.log(e);
    }
  },
  'proposals.getProposalResults': function () {
    this.unblock();
    let proposals = Proposals.find({
      "proposal_status": {
        $nin: ["Passed", "Rejected", "Removed"]
      }
    }).fetch();

    if (proposals && proposals.length > 0) {
      for (let i in proposals) {
        if (parseInt(proposals[i].proposalId) > 0) {
          try {
            // get proposal deposits
            let url = LCD + '/gov/proposals/' + proposals[i].proposalId + '/deposits';
            let response = HTTP.get(url);
            let proposal = {
              proposalId: proposals[i].proposalId
            };

            if (response.statusCode == 200) {
              let deposits = JSON.parse(response.content).result;
              proposal.deposits = deposits;
            }

            url = LCD + '/gov/proposals/' + proposals[i].proposalId + '/votes';
            response = HTTP.get(url);

            if (response.statusCode == 200) {
              let votes = JSON.parse(response.content).result;
              proposal.votes = getVoteDetail(votes);
            }

            url = LCD + '/gov/proposals/' + proposals[i].proposalId + '/tally';
            response = HTTP.get(url);

            if (response.statusCode == 200) {
              let tally = JSON.parse(response.content).result;
              proposal.tally = tally;
            }

            proposal.updatedAt = new Date();
            Proposals.update({
              proposalId: proposals[i].proposalId
            }, {
              $set: proposal
            });
          } catch (e) {}
        }
      }
    }

    return true;
  }
});

const getVoteDetail = votes => {
  if (!votes) {
    return [];
  }

  let voters = votes.map(vote => vote.voter);
  let votingPowerMap = {};
  let validatorAddressMap = {};
  Validators.find({
    delegator_address: {
      $in: voters
    }
  }).forEach(validator => {
    votingPowerMap[validator.delegator_address] = {
      moniker: validator.description.moniker,
      address: validator.address,
      tokens: parseFloat(validator.tokens),
      delegatorShares: parseFloat(validator.delegator_shares),
      deductedShares: parseFloat(validator.delegator_shares)
    };
    validatorAddressMap[validator.operator_address] = validator.delegator_address;
  });
  voters.forEach(voter => {
    if (!votingPowerMap[voter]) {
      // voter is not a validator
      let url = "".concat(LCD, "/staking/delegators/").concat(voter, "/delegations");
      let delegations;
      let votingPower = 0;

      try {
        let response = HTTP.get(url);

        if (response.statusCode == 200) {
          delegations = JSON.parse(response.content).result;

          if (delegations && delegations.length > 0) {
            delegations.forEach(delegation => {
              let shares = parseFloat(delegation.shares);

              if (validatorAddressMap[delegation.validator_address]) {
                // deduct delegated shareds from validator if a delegator votes
                let validator = votingPowerMap[validatorAddressMap[delegation.validator_address]];
                validator.deductedShares -= shares;

                if (validator.delegator_shares != 0) {
                  // avoiding division by zero
                  votingPower += shares / validator.delegatorShares * validator.tokens;
                }
              } else {
                let validator = Validators.findOne({
                  operator_address: delegation.validator_address
                });

                if (validator && validator.delegator_shares != 0) {
                  // avoiding division by zero
                  votingPower += shares / parseFloat(validator.delegator_shares) * parseFloat(validator.tokens);
                }
              }
            });
          }
        }
      } catch (e) {
        console.log(e);
      }

      votingPowerMap[voter] = {
        votingPower: votingPower
      };
    }
  });
  return votes.map(vote => {
    let voter = votingPowerMap[vote.voter];
    let votingPower = voter.votingPower;

    if (votingPower == undefined) {
      // voter is a validator
      votingPower = voter.delegatorShares ? voter.deductedShares / voter.delegatorShares * voter.tokens : 0;
    }

    return _objectSpread({}, vote, {
      votingPower
    });
  });
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/server/publications.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Proposals;
module.link("../proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 1);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 2);
Meteor.publish('proposals.list', function () {
  return Proposals.find({}, {
    sort: {
      proposalId: -1
    }
  });
});
Meteor.publish('proposals.one', function (id) {
  check(id, Number);
  return Proposals.find({
    proposalId: id
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"proposals.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/proposals/proposals.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Proposals: () => Proposals
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Proposals = new Mongo.Collection('proposals');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/methods.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
let ValidatorRecords, Analytics, AverageData, AverageValidatorData;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let ValidatorSets;
module.link("/imports/api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Status;
module.link("../../status/status.js", {
  Status(v) {
    Status = v;
  }

}, 5);
let MissedBlocksStats;
module.link("../records.js", {
  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  }

}, 6);
let MissedBlocks;
module.link("../records.js", {
  MissedBlocks(v) {
    MissedBlocks = v;
  }

}, 7);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 8);
let Chain;
module.link("../../chain/chain.js", {
  Chain(v) {
    Chain = v;
  }

}, 9);

let _;

module.link("lodash", {
  default(v) {
    _ = v;
  }

}, 10);
const BULKUPDATEMAXSIZE = 1000;

const getBlockStats = (startHeight, latestHeight) => {
  let blockStats = {};
  const cond = {
    $and: [{
      height: {
        $gt: startHeight
      }
    }, {
      height: {
        $lte: latestHeight
      }
    }]
  };
  const options = {
    sort: {
      height: 1
    }
  };
  Blockscon.find(cond, options).forEach(block => {
    blockStats[block.height] = {
      height: block.height,
      proposerAddress: block.proposerAddress,
      precommitsCount: block.precommitsCount,
      validatorsCount: block.validatorsCount,
      validators: block.validators,
      time: block.time
    };
  });
  Analytics.find(cond, options).forEach(block => {
    if (!blockStats[block.height]) {
      blockStats[block.height] = {
        height: block.height
      };
      console.log("block ".concat(block.height, " does not have an entry"));
    }

    _.assign(blockStats[block.height], {
      precommits: block.precommits,
      averageBlockTime: block.averageBlockTime,
      timeDiff: block.timeDiff,
      voting_power: block.voting_power
    });
  });
  return blockStats;
};

const getPreviousRecord = (voterAddress, proposerAddress) => {
  let previousRecord = MissedBlocks.findOne({
    voter: voterAddress,
    proposer: proposerAddress,
    blockHeight: -1
  });
  let lastUpdatedHeight = Meteor.settings.params.startHeight;
  let prevStats = {};

  if (previousRecord) {
    prevStats = _.pick(previousRecord, ['missCount', 'totalCount']);
  } else {
    prevStats = {
      missCount: 0,
      totalCount: 0
    };
  }

  return prevStats;
};

Meteor.methods({
  'ValidatorRecords.calculateMissedBlocks': function () {
    if (!COUNTMISSEDBLOCKS) {
      try {
        let startTime = Date.now();
        COUNTMISSEDBLOCKS = true;
        console.log('calulate missed blocks count');
        this.unblock();
        let validators = Validators.find({}).fetch();
        let latestHeight = Meteor.call('blocks.getCurrentHeight');
        let explorerStatus = Status.findOne({
          chainId: Meteor.settings.public.chainId
        });
        let startHeight = explorerStatus && explorerStatus.lastProcessedMissedBlockHeight ? explorerStatus.lastProcessedMissedBlockHeight : Meteor.settings.params.startHeight;
        latestHeight = Math.min(startHeight + BULKUPDATEMAXSIZE, latestHeight);
        const bulkMissedStats = MissedBlocks.rawCollection().initializeOrderedBulkOp();
        let validatorsMap = {};
        validators.forEach(validator => validatorsMap[validator.address] = validator); // a map of block height to block stats

        let blockStats = getBlockStats(startHeight, latestHeight); // proposerVoterStats is a proposer-voter map counting numbers of proposed blocks of which voter is an active validator

        let proposerVoterStats = {};

        _.forEach(blockStats, (block, blockHeight) => {
          let proposerAddress = block.proposerAddress;
          let votedValidators = new Set(block.validators);
          let validatorSets = ValidatorSets.findOne({
            block_height: block.height
          });
          let votedVotingPower = 0;
          validatorSets.validators.forEach(activeValidator => {
            if (votedValidators.has(activeValidator.address)) votedVotingPower += parseFloat(activeValidator.voting_power);
          });
          validatorSets.validators.forEach(activeValidator => {
            let currentValidator = activeValidator.address;

            if (!_.has(proposerVoterStats, [proposerAddress, currentValidator])) {
              let prevStats = getPreviousRecord(currentValidator, proposerAddress);

              _.set(proposerVoterStats, [proposerAddress, currentValidator], prevStats);
            }

            _.update(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'], n => n + 1);

            if (!votedValidators.has(currentValidator)) {
              _.update(proposerVoterStats, [proposerAddress, currentValidator, 'missCount'], n => n + 1);

              bulkMissedStats.insert({
                voter: currentValidator,
                blockHeight: block.height,
                proposer: proposerAddress,
                precommitsCount: block.precommitsCount,
                validatorsCount: block.validatorsCount,
                time: block.time,
                precommits: block.precommits,
                averageBlockTime: block.averageBlockTime,
                timeDiff: block.timeDiff,
                votingPower: block.voting_power,
                votedVotingPower,
                updatedAt: latestHeight,
                missCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'missCount']),
                totalCount: _.get(proposerVoterStats, [proposerAddress, currentValidator, 'totalCount'])
              });
            }
          });
        });

        _.forEach(proposerVoterStats, (voters, proposerAddress) => {
          _.forEach(voters, (stats, voterAddress) => {
            bulkMissedStats.find({
              voter: voterAddress,
              proposer: proposerAddress,
              blockHeight: -1
            }).upsert().updateOne({
              $set: {
                voter: voterAddress,
                proposer: proposerAddress,
                blockHeight: -1,
                updatedAt: latestHeight,
                missCount: _.get(stats, 'missCount'),
                totalCount: _.get(stats, 'totalCount')
              }
            });
          });
        });

        let message = '';

        if (bulkMissedStats.length > 0) {
          const client = MissedBlocks._driver.mongo.client; // TODO: add transaction back after replica set(#146) is set up
          // let session = client.startSession();
          // session.startTransaction();

          let bulkPromise = bulkMissedStats.execute(null
          /*, {session}*/
          ).then(Meteor.bindEnvironment((result, err) => {
            if (err) {
              COUNTMISSEDBLOCKS = false; // Promise.await(session.abortTransaction());

              throw err;
            }

            if (result) {
              // Promise.await(session.commitTransaction());
              message = "(".concat(result.result.nInserted, " inserted, ") + "".concat(result.result.nUpserted, " upserted, ") + "".concat(result.result.nModified, " modified)");
            }
          }));
          Promise.await(bulkPromise);
        }

        COUNTMISSEDBLOCKS = false;
        Status.upsert({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastProcessedMissedBlockHeight: latestHeight,
            lastProcessedMissedBlockTime: new Date()
          }
        });
        return "done in ".concat(Date.now() - startTime, "ms ").concat(message);
      } catch (e) {
        COUNTMISSEDBLOCKS = false;
        throw e;
      }
    } else {
      return "updating...";
    }
  },
  'ValidatorRecords.calculateMissedBlocksStats': function () {
    // TODO: deprecate this method and MissedBlocksStats collection
    // console.log("ValidatorRecords.calculateMissedBlocks: "+COUNTMISSEDBLOCKS);
    if (!COUNTMISSEDBLOCKSSTATS) {
      COUNTMISSEDBLOCKSSTATS = true;
      console.log('calulate missed blocks stats');
      this.unblock();
      let validators = Validators.find({}).fetch();
      let latestHeight = Meteor.call('blocks.getCurrentHeight');
      let explorerStatus = Status.findOne({
        chainId: Meteor.settings.public.chainId
      });
      let startHeight = explorerStatus && explorerStatus.lastMissedBlockHeight ? explorerStatus.lastMissedBlockHeight : Meteor.settings.params.startHeight; // console.log(latestHeight);
      // console.log(startHeight);

      const bulkMissedStats = MissedBlocksStats.rawCollection().initializeUnorderedBulkOp();

      for (i in validators) {
        // if ((validators[i].address == "B8552EAC0D123A6BF609123047A5181D45EE90B5") || (validators[i].address == "69D99B2C66043ACBEAA8447525C356AFC6408E0C") || (validators[i].address == "35AD7A2CD2FC71711A675830EC1158082273D457")){
        let voterAddress = validators[i].address;
        let missedRecords = ValidatorRecords.find({
          address: voterAddress,
          exists: false,
          $and: [{
            height: {
              $gt: startHeight
            }
          }, {
            height: {
              $lte: latestHeight
            }
          }]
        }).fetch();
        let counts = {}; // console.log("missedRecords to process: "+missedRecords.length);

        for (b in missedRecords) {
          let block = Blockscon.findOne({
            height: missedRecords[b].height
          });
          let existingRecord = MissedBlocksStats.findOne({
            voter: voterAddress,
            proposer: block.proposerAddress
          });

          if (typeof counts[block.proposerAddress] === 'undefined') {
            if (existingRecord) {
              counts[block.proposerAddress] = existingRecord.count + 1;
            } else {
              counts[block.proposerAddress] = 1;
            }
          } else {
            counts[block.proposerAddress]++;
          }
        }

        for (address in counts) {
          let data = {
            voter: voterAddress,
            proposer: address,
            count: counts[address]
          };
          bulkMissedStats.find({
            voter: voterAddress,
            proposer: address
          }).upsert().updateOne({
            $set: data
          });
        } // }

      }

      if (bulkMissedStats.length > 0) {
        bulkMissedStats.execute(Meteor.bindEnvironment((err, result) => {
          if (err) {
            COUNTMISSEDBLOCKSSTATS = false;
            console.log(err);
          }

          if (result) {
            Status.upsert({
              chainId: Meteor.settings.public.chainId
            }, {
              $set: {
                lastMissedBlockHeight: latestHeight,
                lastMissedBlockTime: new Date()
              }
            });
            COUNTMISSEDBLOCKSSTATS = false;
            console.log("done");
          }
        }));
      } else {
        COUNTMISSEDBLOCKSSTATS = false;
      }

      return true;
    } else {
      return "updating...";
    }
  },
  'Analytics.aggregateBlockTimeAndVotingPower': function (time) {
    this.unblock();
    let now = new Date();

    if (time == 'm') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastMinuteVotingPower: averageVotingPower,
            lastMinuteBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'h') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastHourVotingPower: averageVotingPower,
            lastHourBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    }

    if (time == 'd') {
      let averageBlockTime = 0;
      let averageVotingPower = 0;
      let analytics = Analytics.find({
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }).fetch();

      if (analytics.length > 0) {
        for (i in analytics) {
          averageBlockTime += analytics[i].timeDiff;
          averageVotingPower += analytics[i].voting_power;
        }

        averageBlockTime = averageBlockTime / analytics.length;
        averageVotingPower = averageVotingPower / analytics.length;
        Chain.update({
          chainId: Meteor.settings.public.chainId
        }, {
          $set: {
            lastDayVotingPower: averageVotingPower,
            lastDayBlockTime: averageBlockTime
          }
        });
        AverageData.insert({
          averageBlockTime: averageBlockTime,
          averageVotingPower: averageVotingPower,
          type: time,
          createdAt: now
        });
      }
    } // return analytics.length;

  },
  'Analytics.aggregateValidatorDailyBlockTime': function () {
    this.unblock();
    let validators = Validators.find({}).fetch();
    let now = new Date();

    for (i in validators) {
      let averageBlockTime = 0;
      let blocks = Blockscon.find({
        proposerAddress: validators[i].address,
        "time": {
          $gt: new Date(Date.now() - 24 * 60 * 60 * 1000)
        }
      }, {
        fields: {
          height: 1
        }
      }).fetch();

      if (blocks.length > 0) {
        let blockHeights = [];

        for (b in blocks) {
          blockHeights.push(blocks[b].height);
        }

        let analytics = Analytics.find({
          height: {
            $in: blockHeights
          }
        }, {
          fields: {
            height: 1,
            timeDiff: 1
          }
        }).fetch();

        for (a in analytics) {
          averageBlockTime += analytics[a].timeDiff;
        }

        averageBlockTime = averageBlockTime / analytics.length;
      }

      AverageValidatorData.insert({
        proposerAddress: validators[i].address,
        averageBlockTime: averageBlockTime,
        type: 'ValidatorDailyAverageBlockTime',
        createdAt: now
      });
    }

    return true;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/server/publications.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let ValidatorRecords, Analytics, MissedBlocks, MissedBlocksStats, VPDistributions;
module.link("../records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  VPDistributions(v) {
    VPDistributions = v;
  }

}, 1);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 2);
Meteor.publish('validator_records.all', function () {
  return ValidatorRecords.find();
});
Meteor.publish('validator_records.uptime', function (address, num) {
  return ValidatorRecords.find({
    address: address
  }, {
    limit: num,
    sort: {
      height: -1
    }
  });
});
Meteor.publish('analytics.history', function () {
  return Analytics.find({}, {
    sort: {
      height: -1
    },
    limit: 50
  });
});
Meteor.publish('vpDistribution.latest', function () {
  return VPDistributions.find({}, {
    sort: {
      height: -1
    },
    limit: 1
  });
});
publishComposite('missedblocks.validator', function (address, type) {
  let conditions = {};

  if (type == 'voter') {
    conditions = {
      voter: address
    };
  } else {
    conditions = {
      proposer: address
    };
  }

  return {
    find() {
      return MissedBlocksStats.find(conditions);
    },

    children: [{
      find(stats) {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            profile_url: 1
          }
        });
      }

    }]
  };
});
publishComposite('missedrecords.validator', function (address, type) {
  return {
    find() {
      return MissedBlocks.find({
        [type]: address
      }, {
        sort: {
          updatedAt: -1
        }
      });
    },

    children: [{
      find() {
        return Validators.find({}, {
          fields: {
            address: 1,
            description: 1,
            operator_address: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"records.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/records/records.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorRecords: () => ValidatorRecords,
  Analytics: () => Analytics,
  MissedBlocksStats: () => MissedBlocksStats,
  MissedBlocks: () => MissedBlocks,
  VPDistributions: () => VPDistributions,
  AverageData: () => AverageData,
  AverageValidatorData: () => AverageValidatorData
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Validators;
module.link("../validators/validators", {
  Validators(v) {
    Validators = v;
  }

}, 1);
const ValidatorRecords = new Mongo.Collection('validator_records');
const Analytics = new Mongo.Collection('analytics');
const MissedBlocksStats = new Mongo.Collection('missed_blocks_stats');
const MissedBlocks = new Mongo.Collection('missed_blocks');
const VPDistributions = new Mongo.Collection('voting_power_distributions');
const AverageData = new Mongo.Collection('average_data');
const AverageValidatorData = new Mongo.Collection('average_validator_data');
MissedBlocksStats.helpers({
  proposerMoniker() {
    let validator = Validators.findOne({
      address: this.proposer
    });
    return validator.description ? validator.description.moniker : this.proposer;
  },

  voterMoniker() {
    let validator = Validators.findOne({
      address: this.voter
    });
    return validator.description ? validator.description.moniker : this.voter;
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status":{"server":{"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/server/publications.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Status;
module.link("../status.js", {
  Status(v) {
    Status = v;
  }

}, 2);
Meteor.publish('status.status', function () {
  return Status.find({
    chainId: Meteor.settings.public.chainId
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"status.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/status/status.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Status: () => Status
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Status = new Mongo.Collection('status');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/methods.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 2);
let Validators;
module.link("../../validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 3);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 4);
const AddressLength = 40;
Meteor.methods({
  'Transactions.index': function (hash, blockTime) {
    this.unblock();
    hash = hash.toUpperCase();
    console.log("Get tx: " + hash);

    try {
      let url = LCD + '/txs/' + hash;
      let response = HTTP.get(url);
      let tx = JSON.parse(response.content);
      console.log(hash);
      tx.height = parseInt(tx.height);
      let txId = Transactions.insert(tx);

      if (txId) {
        return txId;
      } else return false;
    } catch (e) {
      console.log(e);
    }
  },
  'Transactions.findDelegation': function (address, height) {
    // following cosmos-sdk/x/slashing/spec/06_events.md and cosmos-sdk/x/staking/spec/06_events.md
    return Transactions.find({
      $or: [{
        $and: [{
          "events.type": "delegate"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.attributes.key": "action"
        }, {
          "events.attributes.value": "unjail"
        }, {
          "events.attributes.key": "sender"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "create_validator"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "unbond"
        }, {
          "events.attributes.key": "validator"
        }, {
          "events.attributes.value": address
        }]
      }, {
        $and: [{
          "events.type": "redelegate"
        }, {
          "events.attributes.key": "destination_validator"
        }, {
          "events.attributes.value": address
        }]
      }],
      "code": {
        $exists: false
      },
      height: {
        $lt: height
      }
    }, {
      sort: {
        height: -1
      },
      limit: 1
    }).fetch();
  },
  'Transactions.findUser': function (address) {
    let fields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    // address is either delegator address or validator operator address
    let validator;
    if (!fields) fields = {
      address: 1,
      description: 1,
      operator_address: 1,
      delegator_address: 1
    };

    if (address.includes(Meteor.settings.public.bech32PrefixValAddr)) {
      // validator operator address
      validator = Validators.findOne({
        operator_address: address
      }, {
        fields
      });
    } else if (address.includes(Meteor.settings.public.bech32PrefixAccAddr)) {
      // delegator address
      validator = Validators.findOne({
        delegator_address: address
      }, {
        fields
      });
    } else if (address.length === AddressLength) {
      validator = Validators.findOne({
        address: address
      }, {
        fields
      });
    }

    if (validator) {
      return validator;
    }

    return false;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
publishComposite('transactions.list', function () {
  let limit = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 30;
  return {
    find() {
      return Transactions.find({}, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.validator', function (validatorAddress, delegatorAddress) {
  let limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 100;
  let query = {};

  if (validatorAddress && delegatorAddress) {
    query = {
      $or: [{
        "events.attributes.value": validatorAddress
      }, {
        "events.attributes.value": delegatorAddress
      }]
    };
  }

  if (!validatorAddress && delegatorAddress) {
    query = {
      "events.attributes.value": delegatorAddress
    };
  }

  return {
    find() {
      return Transactions.find(query, {
        sort: {
          height: -1
        },
        limit: limit
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.findOne', function (hash) {
  return {
    find() {
      return Transactions.find({
        txhash: hash
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
publishComposite('transactions.height', function (height) {
  return {
    find() {
      return Transactions.find({
        height: height
      });
    },

    children: [{
      find(tx) {
        return Blockscon.find({
          height: tx.height
        }, {
          fields: {
            time: 1,
            height: 1
          }
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"transactions.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/transactions/transactions.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Transactions: () => Transactions
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Blockscon;
module.link("../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 1);
let TxIcon;
module.link("../../ui/components/Icons.jsx", {
  TxIcon(v) {
    TxIcon = v;
  }

}, 2);
const Transactions = new Mongo.Collection('transactions');
Transactions.helpers({
  block() {
    return Blockscon.findOne({
      height: this.height
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/methods.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Transactions;
module.link("../../transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 1);
let Blockscon;
module.link("../../blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 2);
let Delegations;
module.link("../../delegations/delegations.js", {
  Delegations(v) {
    Delegations = v;
  }

}, 3);
Meteor.methods({
  'Validators.findCreateValidatorTime': function (address) {
    // look up the create validator time to consider if the validator has never updated the commission
    let tx = Transactions.findOne({
      $and: [{
        "tx.value.msg.value.delegator_address": address
      }, {
        "tx.value.msg.type": "cosmos-sdk/MsgCreateValidator"
      }, {
        code: {
          $exists: false
        }
      }]
    });

    if (tx) {
      let block = Blockscon.findOne({
        height: tx.height
      });

      if (block) {
        return block.time;
      }
    } else {
      // no such create validator tx
      return false;
    }
  },

  // async 'Validators.getAllDelegations'(address){
  'Validators.getAllDelegations'(address) {
    let url = LCD + '/staking/validators/' + address + '/delegations';

    try {
      let delegations = HTTP.get(url);

      if (delegations.statusCode == 200) {
        delegations = JSON.parse(delegations.content).result;
        delegations.forEach((delegation, i) => {
          if (delegations[i] && delegations[i].shares) delegations[i].shares = parseFloat(delegations[i].shares);
        });
        return delegations;
      }

      ;
    } catch (e) {
      console.log(e);
    }
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/server/publications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Validators;
module.link("../validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 1);
let ValidatorRecords;
module.link("../../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 2);
let VotingPowerHistory;
module.link("../../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 3);
Meteor.publish('validators.all', function () {
  let sort = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "description.moniker";
  let direction = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : -1;
  let fields = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return Validators.find({}, {
    sort: {
      [sort]: direction
    },
    fields: fields
  });
});
publishComposite('validators.firstSeen', {
  find() {
    return Validators.find({});
  },

  children: [{
    find(val) {
      return ValidatorRecords.find({
        address: val.address
      }, {
        sort: {
          height: 1
        },
        limit: 1
      });
    }

  }]
});
Meteor.publish('validators.voting_power', function () {
  return Validators.find({
    status: 2,
    jailed: false
  }, {
    sort: {
      voting_power: -1
    },
    fields: {
      address: 1,
      description: 1,
      voting_power: 1,
      profile_url: 1
    }
  });
});
publishComposite('validator.details', function (address) {
  let options = {
    address: address
  };

  if (address.indexOf(Meteor.settings.public.bech32PrefixValAddr) != -1) {
    options = {
      operator_address: address
    };
  }

  return {
    find() {
      return Validators.find(options);
    },

    children: [{
      find(val) {
        return VotingPowerHistory.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: 50
        });
      }

    }, {
      find(val) {
        return ValidatorRecords.find({
          address: val.address
        }, {
          sort: {
            height: -1
          },
          limit: Meteor.settings.public.uptimeWindow
        });
      }

    }]
  };
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validators.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validators/validators.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Validators: () => Validators
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let ValidatorRecords;
module.link("../records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  }

}, 1);
let VotingPowerHistory;
module.link("../voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 2);
const Validators = new Mongo.Collection('validators');
Validators.helpers({
  firstSeen() {
    return ValidatorRecords.findOne({
      address: this.address
    });
  },

  history() {
    return VotingPowerHistory.find({
      address: this.address
    }, {
      sort: {
        height: -1
      },
      limit: 50
    }).fetch();
  }

}); // Validators.helpers({
//     uptime(){
//         // console.log(this.address);
//         let lastHundred = ValidatorRecords.find({address:this.address}, {sort:{height:-1}, limit:100}).fetch();
//         console.log(lastHundred);
//         let uptime = 0;
//         for (i in lastHundred){
//             if (lastHundred[i].exists){
//                 uptime+=1;
//             }
//         }
//         return uptime;
//     }
// })
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"voting-power":{"server":{"publications.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/server/publications.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"history.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/voting-power/history.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  VotingPowerHistory: () => VotingPowerHistory
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const VotingPowerHistory = new Mongo.Collection('voting_power_history');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"evidences":{"evidences.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/evidences/evidences.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  Evidences: () => Evidences
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Evidences = new Mongo.Collection('evidences');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"validator-sets":{"validator-sets.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/validator-sets/validator-sets.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  ValidatorSets: () => ValidatorSets
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const ValidatorSets = new Mongo.Collection('validator_sets');
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/both/index.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Import modules used by both client and server through a single index entry point
// e.g. useraccounts configuration file.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"create-indexes.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/create-indexes.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let Blockscon;
module.link("../../api/blocks/blocks.js", {
  Blockscon(v) {
    Blockscon = v;
  }

}, 0);
let Proposals;
module.link("../../api/proposals/proposals.js", {
  Proposals(v) {
    Proposals = v;
  }

}, 1);
let ValidatorRecords, Analytics, MissedBlocksStats, MissedBlocks, AverageData, AverageValidatorData;
module.link("../../api/records/records.js", {
  ValidatorRecords(v) {
    ValidatorRecords = v;
  },

  Analytics(v) {
    Analytics = v;
  },

  MissedBlocksStats(v) {
    MissedBlocksStats = v;
  },

  MissedBlocks(v) {
    MissedBlocks = v;
  },

  AverageData(v) {
    AverageData = v;
  },

  AverageValidatorData(v) {
    AverageValidatorData = v;
  }

}, 2);
let Transactions;
module.link("../../api/transactions/transactions.js", {
  Transactions(v) {
    Transactions = v;
  }

}, 3);
let ValidatorSets;
module.link("../../api/validator-sets/validator-sets.js", {
  ValidatorSets(v) {
    ValidatorSets = v;
  }

}, 4);
let Validators;
module.link("../../api/validators/validators.js", {
  Validators(v) {
    Validators = v;
  }

}, 5);
let VotingPowerHistory;
module.link("../../api/voting-power/history.js", {
  VotingPowerHistory(v) {
    VotingPowerHistory = v;
  }

}, 6);
let Evidences;
module.link("../../api/evidences/evidences.js", {
  Evidences(v) {
    Evidences = v;
  }

}, 7);
let CoinStats;
module.link("../../api/coin-stats/coin-stats.js", {
  CoinStats(v) {
    CoinStats = v;
  }

}, 8);
let ChainStates;
module.link("../../api/chain/chain.js", {
  ChainStates(v) {
    ChainStates = v;
  }

}, 9);
ChainStates.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
Blockscon.rawCollection().createIndex({
  proposerAddress: 1
});
Evidences.rawCollection().createIndex({
  height: -1
});
Proposals.rawCollection().createIndex({
  proposalId: 1
}, {
  unique: true
});
ValidatorRecords.rawCollection().createIndex({
  address: 1,
  height: -1
}, {
  unique: 1
});
ValidatorRecords.rawCollection().createIndex({
  address: 1,
  exists: 1,
  height: -1
});
Analytics.rawCollection().createIndex({
  height: -1
}, {
  unique: true
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  voter: 1,
  updatedAt: -1
});
MissedBlocks.rawCollection().createIndex({
  proposer: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  blockHeight: -1
});
MissedBlocks.rawCollection().createIndex({
  voter: 1,
  proposer: 1,
  blockHeight: -1
}, {
  unique: true
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1
});
MissedBlocksStats.rawCollection().createIndex({
  voter: 1
});
MissedBlocksStats.rawCollection().createIndex({
  proposer: 1,
  voter: 1
}, {
  unique: true
});
AverageData.rawCollection().createIndex({
  type: 1,
  createdAt: -1
}, {
  unique: true
});
AverageValidatorData.rawCollection().createIndex({
  proposerAddress: 1,
  createdAt: -1
}, {
  unique: true
}); // Status.rawCollection.createIndex({})

Transactions.rawCollection().createIndex({
  txhash: 1
}, {
  unique: true
});
Transactions.rawCollection().createIndex({
  height: -1
}); // Transactions.rawCollection().createIndex({action:1});

Transactions.rawCollection().createIndex({
  "events.attributes.key": 1
});
Transactions.rawCollection().createIndex({
  "events.attributes.value": 1
});
ValidatorSets.rawCollection().createIndex({
  block_height: -1
});
Validators.rawCollection().createIndex({
  address: 1
}, {
  unique: true,
  partialFilterExpression: {
    address: {
      $exists: true
    }
  }
});
Validators.rawCollection().createIndex({
  consensus_pubkey: 1
}, {
  unique: true
});
Validators.rawCollection().createIndex({
  "pub_key.value": 1
}, {
  unique: true,
  partialFilterExpression: {
    "pub_key.value": {
      $exists: true
    }
  }
});
VotingPowerHistory.rawCollection().createIndex({
  address: 1,
  height: -1
});
VotingPowerHistory.rawCollection().createIndex({
  type: 1
});
CoinStats.rawCollection().createIndex({
  last_updated_at: -1
}, {
  unique: true
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/index.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("./util.js");
module.link("./register-api.js");
module.link("./create-indexes.js");
let onPageLoad;
module.link("meteor/server-render", {
  onPageLoad(v) {
    onPageLoad = v;
  }

}, 0);
let Helmet;
module.link("react-helmet", {
  Helmet(v) {
    Helmet = v;
  }

}, 1);
// import App from '../../ui/App.jsx';
onPageLoad(sink => {
  // const context = {};
  // const sheet = new ServerStyleSheet()
  // const html = renderToString(sheet.collectStyles(
  //     <StaticRouter location={sink.request.url} context={context}>
  //         <App />
  //     </StaticRouter>
  //   ));
  // sink.renderIntoElementById('app', html);
  const helmet = Helmet.renderStatic();
  sink.appendToHead(helmet.meta.toString());
  sink.appendToHead(helmet.title.toString()); // sink.appendToHead(sheet.getStyleTags());
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register-api.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/register-api.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("../../api/ledger/server/methods.js");
module.link("../../api/chain/server/methods.js");
module.link("../../api/chain/server/publications.js");
module.link("../../api/blocks/server/methods.js");
module.link("../../api/blocks/server/publications.js");
module.link("../../api/validators/server/methods.js");
module.link("../../api/validators/server/publications.js");
module.link("../../api/records/server/methods.js");
module.link("../../api/records/server/publications.js");
module.link("../../api/proposals/server/methods.js");
module.link("../../api/proposals/server/publications.js");
module.link("../../api/voting-power/server/publications.js");
module.link("../../api/transactions/server/methods.js");
module.link("../../api/transactions/server/publications.js");
module.link("../../api/delegations/server/methods.js");
module.link("../../api/delegations/server/publications.js");
module.link("../../api/status/server/publications.js");
module.link("../../api/accounts/server/methods.js");
module.link("../../api/coin-stats/server/methods.js");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"util.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/server/util.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
let bech32;
module.link("bech32", {
  default(v) {
    bech32 = v;
  }

}, 0);
let HTTP;
module.link("meteor/http", {
  HTTP(v) {
    HTTP = v;
  }

}, 1);
let cheerio;
module.link("cheerio", {
  "*"(v) {
    cheerio = v;
  }

}, 2);

// Load future from fibers
var Future = Npm.require("fibers/future"); // Load exec


var exec = Npm.require("child_process").exec;

function toHexString(byteArray) {
  return byteArray.map(function (byte) {
    return ('0' + (byte & 0xFF).toString(16)).slice(-2);
  }).join('');
}

Meteor.methods({
  pubkeyToBech32: function (pubkey, prefix) {
    let buffer;

    if (pubkey.type.indexOf("PubKeyEd25519") > 0) {
      // '1624DE6420' is ed25519 pubkey prefix
      let pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
      buffer = Buffer.alloc(37);
      pubkeyAminoPrefix.copy(buffer, 0);
      Buffer.from(pubkey.value, 'base64').copy(buffer, pubkeyAminoPrefix.length);
    } else if (pubkey.type.indexOf("PubKeySecp256k1") > 0) {
      // 'EB5AE98721' is secp256k1 pubkey prefix
      let pubkeyAminoPrefix = Buffer.from('EB5AE98721', 'hex');
      buffer = Buffer.alloc(38);
      pubkeyAminoPrefix.copy(buffer, 0);
      Buffer.from(pubkey.value, 'base64').copy(buffer, pubkeyAminoPrefix.length);
    } else {
      console.log("Pubkey type not supported.");
      return false;
    }

    return bech32.encode(prefix, bech32.toWords(buffer));
  },
  bech32ToPubkey: function (pubkey, type) {
    // type can only be either 'tendermint/PubKeySecp256k1' or 'tendermint/PubKeyEd25519'
    let pubkeyAminoPrefix, buffer;

    if (type.indexOf("PubKeyEd25519") > 0) {
      // '1624DE6420' is ed25519 pubkey prefix
      pubkeyAminoPrefix = Buffer.from('1624DE6420', 'hex');
      buffer = Buffer.from(bech32.fromWords(bech32.decode(pubkey).words));
    } else if (type.indexOf("PubKeySecp256k1") > 0) {
      // 'EB5AE98721' is secp256k1 pubkey prefix
      pubkeyAminoPrefix = Buffer.from('EB5AE98721', 'hex');
      buffer = Buffer.from(bech32.fromWords(bech32.decode(pubkey).words));
    } else {
      console.log("Pubkey type not supported.");
      return false;
    }

    return buffer.slice(pubkeyAminoPrefix.length).toString('base64');
  },
  getDelegator: function (operatorAddr) {
    let address = bech32.decode(operatorAddr);
    return bech32.encode(Meteor.settings.public.bech32PrefixAccAddr, address.words);
  },
  getKeybaseTeamPic: function (keybaseUrl) {
    let teamPage = HTTP.get(keybaseUrl);

    if (teamPage.statusCode == 200) {
      let page = cheerio.load(teamPage.content);
      return page(".kb-main-card img").attr('src');
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"ui":{"components":{"Icons.jsx":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/ui/components/Icons.jsx                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  DenomSymbol: () => DenomSymbol,
  ProposalStatusIcon: () => ProposalStatusIcon,
  VoteIcon: () => VoteIcon,
  TxIcon: () => TxIcon,
  InfoIcon: () => InfoIcon
});
let React;
module.link("react", {
  default(v) {
    React = v;
  }

}, 0);
let UncontrolledTooltip;
module.link("reactstrap", {
  UncontrolledTooltip(v) {
    UncontrolledTooltip = v;
  }

}, 1);

const DenomSymbol = props => {
  switch (props.denom) {
    case "steak":
      return '🥩';

    default:
      return '🍅';
  }
};

const ProposalStatusIcon = props => {
  switch (props.status) {
    case 'Passed':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-check-circle text-success"
      });

    case 'Rejected':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-times-circle text-danger"
      });

    case 'Removed':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-trash-alt text-dark"
      });

    case 'DepositPeriod':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-battery-half text-warning"
      });

    case 'VotingPeriod':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-hand-paper text-info"
      });

    default:
      return /*#__PURE__*/React.createElement("i", null);
  }
};

const VoteIcon = props => {
  switch (props.vote) {
    case 'yes':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-check text-success"
      });

    case 'no':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-times text-danger"
      });

    case 'abstain':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-user-slash text-warning"
      });

    case 'no_with_veto':
      return /*#__PURE__*/React.createElement("i", {
        className: "fas fa-exclamation-triangle text-info"
      });

    default:
      return /*#__PURE__*/React.createElement("i", null);
  }
};

const TxIcon = props => {
  if (props.valid) {
    return /*#__PURE__*/React.createElement("span", {
      className: "text-success text-nowrap"
    }, /*#__PURE__*/React.createElement("i", {
      className: "fas fa-check-circle"
    }));
  } else {
    return /*#__PURE__*/React.createElement("span", {
      className: "text-danger text-nowrap"
    }, /*#__PURE__*/React.createElement("i", {
      className: "fas fa-times-circle"
    }));
  }
};

class InfoIcon extends React.Component {
  constructor(props) {
    super(props);
    this.ref = React.createRef();
  }

  render() {
    return [/*#__PURE__*/React.createElement("i", {
      key: "icon",
      className: "material-icons info-icon",
      ref: this.ref
    }, "info"), /*#__PURE__*/React.createElement(UncontrolledTooltip, {
      key: "tooltip",
      placement: "right",
      target: this.ref
    }, this.props.children ? this.props.children : this.props.tooltipText)];
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"both":{"i18n":{"en-us.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/en-us.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('en-US','',{"common":{"height":"Height","voter":"Voter","votingPower":"Mining Power","addresses":"Addresses","amounts":"Amounts","delegators":"delegators","block":"block","blocks":"blocks","precommit":"precommit","precommits":"precommits","last":"last","backToList":"Back to List","information":"Information","time":"Time","hash":"Hash","more":"More","fullStop":".","searchPlaceholder":"Search with tx hash / block height / address","cancel":"Cancel","retry":"Retry","rewards":"Rewards"},"navbar":{"siteName":"DP Explorer","version":"beta","validators":"Validators","blocks":"Blocks","transactions":"Transactions","proposals":"Proposals","votingPower":"Mining Power","lang":"ENG","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"OSS"},"consensus":{"consensusState":"Consensus State","round":"Round","step":"Step"},"chainStates":{"price":"Price","marketCap":"Market Cap","inflation":"Inflation","communityPool":"Community Pool"},"chainStatus":{"startMessage":"The chain is going to start in","stopWarning":"The chain appears to be stopped for <em>{$time}</em>! Feed me with new blocks 😭!","latestHeight":"Latest Block Height","averageBlockTime":"Average Block Time","all":"All","now":"Now","allTime":"All Time","lastMinute":"Last Minute","lastHour":"Last Hour","lastDay":"Last Day","seconds":"seconds","activeValidators":"Active Validators","outOfValidators":"out of {$totalValidators} validators","onlineVotingPower":"Online Mining Power","fromTotalStakes":"{$percent} from {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Block Time History","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"Random Validators","moniker":"Moniker","uptime":"Uptime","selfPercentage":"Self%","commission":"Commission","lastSeen":"Last Seen","status":"Status","jailed":"Jailed","navActive":"Active","navInactive":"Inactive","active":"Active Validators","inactive":"Inactive Validators","listOfActive":"Here is a list of active validators.","listOfInactive":"Here is a list of inactive validators.","validatorDetails":"Validator Details","lastNumBlocks":"Last {$numBlocks} blocks","validatorInfo":"Validator Info","operatorAddress":"Operator Address","selfDelegationAddress":"Self-Delegate Address","commissionRate":"Commission Rate","maxRate":"Max Rate","maxChangeRate":"Max Change Rate","selfDelegationRatio":"Self Delegation Ratio","proposerPriority":"Proposer Priority","delegatorShares":"Delegator Shares","userDelegateShares":"Shares Delegated by you","tokens":"Tokens","unbondingHeight":"Unbonding Height","unbondingTime":"Unbonding Time","powerChange":"Power Change","delegations":"Delegations","transactions":"Transactions","validatorNotExists":"Validator does not exist.","backToValidator":"Back to Validator","missedBlocks":"Missed Blocks","missedPrecommits":"Missed Precommits","missedBlocksTitle":"Missed blocks of {$moniker}","totalMissed":"Total missed","block":"Block","missedCount":"Miss Count","iDontMiss":"I do not miss ","lastSyncTime":"Last sync time","delegator":"Delegator","amount":"Amount"},"blocks":{"block":"Block","proposer":"Proposer","latestBlocks":"Latest blocks","noBlock":"No block.","numOfTxs":"No. of Txs","numOfTransactions":"No. of Transactions","notFound":"No such block found."},"transactions":{"transaction":"Transaction","transactions":"Transactions","notFound":"No transaction found.","activities":"Activities","txHash":"Tx Hash","valid":"Valid","fee":"Fee","noFee":"No fee","gasUsedWanted":"Gas (used / wanted)","noTxFound":"No such transaction found.","noValidatorTxsFound":"No transaction related to this validator was found.","memo":"Memo","transfer":"Transfer","staking":"Staking","distribution":"Distribution","governance":"Governance","slashing":"Slashing"},"proposals":{"notFound":"No proposal found.","listOfProposals":"Here is a list of governance proposals.","proposer":"Proposer","proposal":"proposal","proposals":"Proposals","proposalID":"Proposal ID","title":"Title","status":"Status","submitTime":"Submit Time","depositEndTime":"Deposit End Time","votingStartTime":"Voting Start Time","votingEndTime":"End Voting Time","totalDeposit":"Total Deposit","description":"Description","proposalType":"Proposal Type","proposalStatus":"Proposal Status","notStarted":"not started","final":"final","deposit":"Deposit","tallyResult":"Tally Result","yes":"Yes","abstain":"Abstain","no":"No","noWithVeto":"No with Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> of online mining power has been voted.","validMessage":"This proposal is {$tentative}<strong>valid</strong>.","invalidMessage":"Less than {$quorum} of mining power is voted. This proposal is <strong>invalid</strong>.","moreVoteMessage":"It will be a valid proposal once <span class=\"text-info\">{$moreVotes}</span> more votes are casted.","key":"Key","value":"Value","amount":"Amount","recipient":"Recipient","changes":"Changes","subspace":"Subspace"},"votingPower":{"distribution":"Mining Power Distribution","pareto":"Pareto Principle (20/80 rule)","minValidators34":"Min no. of validators hold 34%+ power"},"accounts":{"accountDetails":"Account Details","available":"Available","delegated":"Delegated","unbonding":"Unbonding","rewards":"Rewards","total":"Total","notFound":"This account does not exist. Are you looking for a wrong address?","validators":"Validators","shares":"Shares","mature":"Mature","no":"No ","none":"No ","delegation":"Delegation","plural":"s","signOut":"Sign out","signInText":"You are signed in as ","toLoginAs":"To log in as","signInWithLedger":"Sign In With Ledger","signInWarning":"Please make sure your Ledger device is connected and <strong class=\"text-primary\">Cosmos App 1.5.0 or above</strong> is opened.","pleaseAccept":"please accept in your Ledger device.","noRewards":"No Rewards"},"activities":{"single":"A","happened":"happened.","senders":"The following sender(s)","sent":"sent","receivers":"to the following receipient(s)","received":"received","failedTo":"failed to ","to":"to","from":"from","operatingAt":"operating at","withMoniker":"with moniker","withTitle":"with title","withA":"with a","withAmount":"with <span class=\"text-info\">{$amount}</span>"},"messageTypes":{"send":"Send","multiSend":"Multi Send","createValidator":"Create Validator","editValidator":"Edit Validator","delegate":"Delegate","undelegate":"Undelegate","redelegate":"Redelegate","submitProposal":"Submit Proposal","deposit":"Deposit","vote":"Vote","withdrawComission":"Withdraw Commission","withdrawReward":"Withdraw Reward","modifyWithdrawAddress":"Modify Withdraw Address","unjail":"Unjail","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"es-es.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/es-es.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('es-ES','',{"common":{"height":"Altura","voter":"Votante","votingPower":"Poder de votación","addresses":"Direcciones","amounts":"Cantidades","delegators":"delegadores","block":"bloque","blocks":"bloques","precommit":"precommit","precommits":"precommits","last":"último","backToList":"Volver a la lista","information":"Información","time":"Tiempo","hash":"Hash","more":"Más","fullStop":".","searchPlaceholder":"Buscar con el tx hash / altura de bloque / dirección","cancel":"Cancelar","retry":"Reintentar"},"navbar":{"siteName":"DP Explorer","version":"beta","validators":"Validadores","blocks":"Bloques","transactions":"Transacciones","proposals":"Propuestas","votingPower":"Poder de voto","lang":"ES","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENCIA","forkMe":"OSS"},"consensus":{"consensusState":"Estado de consenso","round":"Ronda","step":"Paso"},"chainStates":{"price":"Precio","marketCap":"Capitalización de mercado","inflation":"Inflación","communityPool":"Community Pool"},"chainStatus":{"startMessage":"La cadena comenzará en","stopWarning":"La cadena parece estar parada por <em>{$time}</em>! Dame de comer nuevos bloques 😭!","latestHeight":"Última altura de bloque","averageBlockTime":"Tiempo medio de bloque","all":"Todo","now":"Ahora","allTime":"Todo el tiempo","lastMinute":"Último minuto","lastHour":"Última hora","lastDay":"Último día","seconds":"segundos","activeValidators":"Validadores activos","outOfValidators":"fuera de {$totalValidators} validadores","onlineVotingPower":"Poder de voto en línea","fromTotalStakes":"{$percent} de {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Historial de tiempo de bloque","averageBlockTime":"Tiempo medio de bloque","blockInterval":"Intervalo de bloque","noOfValidators":"No. de validadores"},"validators":{"randomValidators":"Validadores aleatorios","moniker":"Moniker","uptime":"Tiempo de funcionamiento","selfPercentage":"Self%","commission":"Comisión","lastSeen":"Última vez visto","status":"Estado","jailed":"Encarcelado","navActive":"Activo","navInactive":"Inactivo","active":"Validadores activos","inactive":"Validadores inactivos","listOfActive":"Esta es una lista de los validadores activos.","listOfInactive":"Esta es una lista de los validadores inactivos.","validatorDetails":"Detalles del validador","lastNumBlocks":"Último {$numBlocks} bloques","validatorInfo":"Información del validador","operatorAddress":"Dirección de operador","selfDelegationAddress":"Dirección de autodelegación","commissionRate":"Ratio de comisión","maxRate":"Ratio máximo","maxChangeRate":"Ratio máximo de cambio","selfDelegationRatio":"Ratio de autodelegación","proposerPriority":"","delegatorShares":"Acciones del delegador","userDelegateShares":"Acciones delegadas por ti","tokens":"Tokens","unbondingHeight":"Altura ","unbondingTime":"Tiempo para desvincularse","powerChange":"Power Change","delegations":"Delegaciones","transactions":"Transacciones","validatorNotExists":"El validador no existe.","backToValidator":"Volver al validador","missedBlocks":"Bloques perdidos","missedPrecommits":"Precommits perdidos","missedBlocksTitle":"Bloques perdidos de {$moniker}","totalMissed":"Total perdido","block":"Bloque","missedCount":"Perdidos","iDontMiss":"No he perdido ","lastSyncTime":"Último tiempo de sincronización","delegator":"Delegador","amount":"Cantidad"},"blocks":{"block":"Bloque","proposer":"Proposer","latestBlocks":"Últimos bloques","noBlock":"No bloque.","numOfTxs":"No. de txs","numOfTransactions":"No. de transacciones","notFound":"No se ha encontrado tal bloque."},"transactions":{"transaction":"Transacción","transactions":"Transacciones","notFound":"No se encuentra la transacción.","activities":"Movimientos","txHash":"Tx Hash","valid":"Validez","fee":"Comisión","noFee":"No fee","gasUsedWanted":"Gas (usado / deseado)","noTxFound":"No se encontró ninguna transacción de este tipo.","noValidatorTxsFound":"No se encontró ninguna transaccion relacionada con este validador.","memo":"Memo","transfer":"Transferencia","staking":"Participación","distribution":"Distribución","governance":"Gobernanza","slashing":"Recorte"},"proposals":{"notFound":"No se ha encontrado el proposal.","listOfProposals":"Here is a list of governance proposals.","proposer":"Proposer","proposal":"propuesta","proposals":"Propuestas","proposalID":"ID de la propuesta","title":"Título","status":"Estado","submitTime":"Plazo de entrega","depositEndTime":"Final del tiempo de depósito","votingStartTime":"Hora de inicio de la votación","votingEndTime":"Fin del tiempo de votación","totalDeposit":"Depósito total","description":"Descripción","proposalType":"Tipo de propuesta","proposalStatus":"Estado de la propuesta","notStarted":"no iniciado","final":"final","deposit":"Depósito","tallyResult":"Resultado del recuento","yes":"Si","abstain":"Abstención","no":"No","none":"None","noWithVeto":"No con Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> del poder de voto online ha votado.","validMessage":"Este proposal es {$tentative}<strong>valido</strong>.","invalidMessage":"Menos del {$quorum} del poder de voto ha votado. Este proposal es <strong>invalido</strong>.","moreVoteMessage":"Será una propuesta válida una vez que <span class=\"text-info\">{$moreVotes}</span> más votos se emitan.","key":"Key","value":"Value","amount":"Amount","recipient":"Recipient","changes":"Changes","subspace":"Subspace"},"votingPower":{"distribution":"Distribución del poder de Voto","pareto":"Pareto Principle (20/80 rule)","minValidators34":"Min no. of validators hold 34%+ power"},"accounts":{"accountDetails":"Detalles de la cuenta","available":"Disponible","delegated":"Delegado","unbonding":"Unbonding","rewards":"Rewards","total":"Total","notFound":"Esta cuenta no existe. ¿Estas buscando una dirección equivocada?","validators":"Validadores","shares":"Shares","mature":"Mature","no":"No ","delegation":"Delegación","plural":"s","signOut":"Cerrar sesión","signInText":"Estas registrado como ","toLoginAs":"Para conectarse como","signInWithLedger":"Registrarse con Ledger","signInWarning":"Por favor, asegúrese de que su dispositivo Ledger esté conectado y <strong class=\"text-primary\">la App de Cosmos con la version 1.5.0 o superior</strong> esta abierta.","pleaseAccept":"por favor, acepta en tu dispositivo Ledger.","noRewards":"No Rewards"},"activities":{"single":"A","happened":"sucedió.","senders":"Los siguientes remitentes","sent":"enviado a","receivers":"al siguiente destinatario","received":"recibido","failedTo":"failed to ","to":"a","from":"desde","operatingAt":"operando en","withMoniker":"con el moniker","withTitle":"con el título","withA":"con"},"messageTypes":{"send":"Enviar","multiSend":"Multi Envío","createValidator":"Crear validador","editValidator":"Editar validador","delegate":"Delegar","undelegate":"Undelegar","redelegate":"Redelegar","submitProposal":"Enviar Proposal","deposit":"Depositar","vote":"Voto","withdrawComission":"Enviar comisión","withdrawReward":"Retirar recompensa","modifyWithdrawAddress":"Modificar la dirección de envío","unjail":"Unjail","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"it-IT.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/it-IT.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('it-IT','',{"common":{"height":"Altezza","voter":"Votante","votingPower":"Potere di voto","addresses":"Indirizzi","amounts":"Importi","delegators":"delegatori","block":"blocco","blocks":"blocchi","precommit":"precommit","precommits":"precommit","last":"ultimo","backToList":"Torna alla Lista","information":"Informazioni","time":"Tempo","hash":"Hash","more":"Di più","fullStop":".","searchPlaceholder":"Cerca hash transazione / altezza blocco / indirizzo","cancel":"Annulla","retry":"Riprova","rewards":"Reward"},"navbar":{"siteName":"DP Explorer","version":"beta","validators":"Validatori","blocks":"Blocchi","transactions":"Transazioni","proposals":"Proposte","votingPower":"Potere di Voto","lang":"IT","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENZA","forkMe":"OSS!"},"consensus":{"consensusState":"Stato del consenso","round":"Round","step":"Step"},"chainStates":{"price":"Prezzo","marketCap":"Market Cap","inflation":"Inflazione","communityPool":"Community Pool"},"chainStatus":{"startMessage":"The chain partirà tra","stopWarning":"La chain sembra essersi fermata per <em>{$time}</em>! Dammi nuovi blocchi 😭!","latestHeight":"Ultima Altezza di Blocco","averageBlockTime":"Tempo di Blocco Medio","all":"Tutti","now":"Ora","allTime":"Tutti i tempi","lastMinute":"Ultimo Minuto","lastHour":"Ultima ora","lastDay":"Ultimo giorno","seconds":"secondi","activeValidators":"Validatori Attivi","outOfValidators":"di {$totalValidators} validatori","onlineVotingPower":"Mining Power Attivo","fromTotalStakes":"{$percent} di {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Storia Tempo di Blocco","averageBlockTime":"Tempo di Blocco Medio","blockInterval":"Intervallo di Blocco","noOfValidators":"N. Validatori"},"validators":{"randomValidators":"Validatori random","moniker":"Moniker","uptime":"Uptime","selfPercentage":"% autodelegata","commission":"Commissioni","lastSeen":"Visto per ultimo","status":"Stato","jailed":"Jailato","navActive":"Attivo","navInactive":"Inattivo","active":"Tutti i Validatori","inactive":"Validatori inattivi","listOfActive":"Ecco una lista di validatori attivi.","listOfInactive":"Ecco una lista di validatori inattivi.","validatorDetails":"Dettagli validatore","lastNumBlocks":"Utlimi {$numBlocks} blocchi","validatorInfo":"Info Validatore","operatorAddress":"Indirizzo Operatore","selfDelegationAddress":"Indirizzo di Auto-Delega","commissionRate":"Tasso di commissioni","maxRate":"Tasso massima","maxChangeRate":"Cambiamento del tasso massimo","selfDelegationRatio":"Tasso di Auto Delega","proposerPriority":"Priorità del proponente","delegatorShares":"Percentuale dei delegati","userDelegateShares":"Percentuale delega personale","tokens":"Token","unbondingHeight":"Altezza di unbond","unbondingTime":"Tempo di unbond","powerChange":"Modifica del potere","delegations":"Delegazioni","transactions":"Transazioni","validatorNotExists":"Validatore inesistente","backToValidator":"Torna al validatore","missedBlocks":"Blocchi mancanti","missedPrecommits":"Precommit mancati","missedBlocksTitle":"Manca il blocco: {$moniker}","totalMissed":"Totale perso","block":"Blocco","missedCount":"Mancato conteggio","iDontMiss":"Non mi manca","lastSyncTime":"Ultima sincronizzazione ora","delegator":"Delegante","amount":"Importo"},"blocks":{"block":"Blocco","proposer":"Proponente","latestBlocks":"Ultimi blocchi","noBlock":"Nessun blocco","numOfTxs":"N. Txs","numOfTransactions":"N. di transazioni","notFound":"Nessun blocco trovato."},"transactions":{"transaction":"Transazione","transactions":"Transazioni","notFound":"Nessuna transazione trovata","activities":"Attività","txHash":"Hash Tx","valid":"Valido","fee":"Fee","noFee":"Nessuna fee","gasUsedWanted":"Gas (usato / voluto)","noTxFound":"Nessuna transazione trovata.","noValidatorTxsFound":"Nessuna transazione relativa a questo validatore trovata","memo":"Memo","transfer":"Trasferimento","staking":"Staking","distribution":"Distribuzione","governance":"Governance","slashing":"Slashing"},"proposals":{"notFound":"Nessuna proposta trovata.","listOfProposals":"Questa è la lista delle proposte di governance","proposer":"Proponente","proposal":"Proposta","proposals":"Proposte","proposalID":"ID Proposta","title":"Titolo","status":"Stato","submitTime":"Ora invio","depositEndTime":"Ora di fine deposito","votingStartTime":"Ora di inizio votazione","votingEndTime":"Ora di fine votazione","totalDeposit":"Deposito totale","description":"Descrizione","proposalType":"Tipo di proposta","proposalStatus":"Stato della proposta","notStarted":"Non iniziato","final":"Finale","deposit":"Deposito","tallyResult":"Risultato conteggio","yes":"Sì","abstain":"Astenersi","no":"No","noWithVeto":"No con Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> di voti raccolti tra i votanti attivi.","validMessage":"Questa proposta è {$tentative}<strong>valida</strong>.","invalidMessage":"Sono stati raccolti meno del {$quorum} di voti. Questa proposta è <strong>invalida</strong>.","moreVoteMessage":"Sarà una proposta valida quando <span class=\"text-info\">{$moreVotes}</span> più voti di ora saranno raccolti.","key":"Key","value":"Value","amount":"Amount","recipient":"Recipient","changes":"Changes","subspace":"Subspace"},"votingPower":{"distribution":"Distribuzione del potere di voto","pareto":"Principio di Pareto (regola 20/80)","minValidators34":"Min n. di validatori che possiede il 34%+ di potere"},"accounts":{"accountDetails":"Dettagli account","available":"Disponibile","delegated":"Delegati","unbonding":"Unbonding","rewards":"Rewards","total":"Totale","notFound":"Questo account non esiste. Forse hai inserito l'indirizzo sbagliato?","validators":"Validatori","shares":"Share","mature":"Maturo","no":"No ","none":"Nessuno","delegation":"Delega","plural":"","signOut":"Esci","signInText":"Registrati come","toLoginAs":"Accedi come","signInWithLedger":"Registrati con un Ledger","signInWarning":"Per favore assicurati che il tuo Ledger sia connesso e <strong class=\"text-primary\">Cosmos App 1.5.0 or above</strong> che sia aperto.","pleaseAccept":"Per favore accetta nel tuo Ledger","noRewards":"Nessun reward"},"activities":{"single":"Un (male), una (female)","happened":"è accaduto.","senders":"I seguenti mittenti","sent":"Inviato","receivers":"I seguenti destinatati","received":"Ricevuto","failedTo":"Ha fallito a ","to":"A","from":"Da","operatingAt":"che operano presso","withMoniker":"con moniker","withTitle":"con titolo","withA":"con un (male) / una (female)"},"messageTypes":{"send":"Invia","multiSend":"Invio multipo","createValidator":"Crea un validatore","editValidator":"Modifica un validatore","delegate":"Delega","undelegate":"Rimuovi delega","redelegate":"Ridelega","submitProposal":"Invia proposta","deposit":"Deposita","vote":"Vota","withdrawComission":"Ritira una commissione","withdrawReward":"Ottieni un reward","modifyWithdrawAddress":"Modifica indirizzo di ritiro","unjail":"Unjail","IBCTransfer":"Trasferisci IBC","IBCReceive":"Ricevi IBC"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pl-PL.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/pl-PL.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('pl-PL','',{"common":{"height":"Wysokość","voter":"Głosujący","votingPower":"Siła Głosu","addresses":"Adres","amounts":"Kwota","delegators":"Delegatorzy","block":"blok","blocks":"bloki","precommit":"precommit","precommits":"precommits","last":"ostatni","backToList":"Powrtót do Listy","information":"Informacje","time":"Czas","hash":"Hash","more":"Więcej","fullStop":".","searchPlaceholder":"Wyszukaj adres / transakcję / wysokość bloku","cancel":"Anuluj","retry":"Spróbuj ponownie","rewards":"Nagrody"},"navbar":{"siteName":"DP Explorer","version":"beta","validators":"Walidatorzy","blocks":"Bloki","transactions":"Transakcje","proposals":"Propozycje","votingPower":"Siła Głosu","lang":"PL","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENCJA","forkMe":"OSS"},"consensus":{"consensusState":"Status Konsensusu","round":"Runda","step":"Etap"},"chainStates":{"price":"Cena","marketCap":"Kapitalizacja rynkowa","inflation":"Inflacja","communityPool":"Zasoby Społeczności"},"chainStatus":{"startMessage":"Łańcuch bloków danych rozpocznie działanie za ","topWarning":"Wygląda na to że, łańcuch bloków danych zatrzymał się na <em>{$time}</em>! Odśwież stronę i nakarm mnie nowymi blokami 😭!","latestHeight":"Ostatnia wysokość bloku","averageBlockTime":"Średni Czas Bloku","all":"Całość","now":"Teraz","allTime":"Cały Czas","lastMinute":"Ostatnia Minuta","lastHour":"Ostatnia Godzina","lastDay":"Ostatni Dzień","seconds":"sekund","activeValidators":"Aktywni Walidatorzy","outOfValidators":"z grona {$totalValidators} walidatorów","onlineVotingPower":"Siła Głosu Online","fromTotalStakes":"{$percent} spośród {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"Czas Bloków","averageBlockTime":"Średni Czas Bloku","blockInterval":"Interwał Bloku","noOfValidators":"Liczba Walidatorów"},"validators":{"randomValidators":"Losowo Wybrani Walidatorzy","moniker":"Moniker","uptime":"Dyspozycyjność","selfPercentage":"Self%","commission":"Prowizja","lastSeen":"Ostatnio widziany","status":"Status","jailed":"Jailed","navActive":"Aktywni","navInactive":"Nieaktywni","active":"Aktywni Walidatorzy","inactive":"Nieaktywni Walidatorzy","listOfActive":"Lista aktywnych Walidatorów","listOfInactive":"Lista nieaktywnych Walidatorów","validatorDetails":"Szczegóły Walidatora","lastNumBlocks":"Ostatnie {$numBlocks} bloków","validatorInfo":"Szczegóły Walidatora","operatorAddress":"Adres Operatora","selfDelegationAddress":"Adres Delegacji Self","commissionRate":"Wysokość prowizji","maxRate":"Maksymalna Stawka","maxChangeRate":"Maksymalna Stawka Zmiany Prowizji","selfDelegationRatio":"Proporcja Delegacji Self","proposerPriority":"Piorytet Propozycji","delegatorShares":"Akcje Delegującego","userDelegateShares":"Akcje Oddelegowane przez Ciebie","tokens":"Tokeny","unbondingHeight":"Wysokość Unbonding","unbondingTime":"Czas Unbonding","powerChange":"Zmiana Siły Głosu","delegations":"Delegacje","transactions":"Transakcje","validatorNotExists":"Walidator nie istnieje.","backToValidator":"Powrtót do Walidatora","missedBlocks":"Pominięte Bloki","missedPrecommits":"Pominięte Precommits","missedBlocksTitle":"‘Pominięte Bloki od {$moniker}'","totalMissed":"Łącznie pominięto","block":"Blok","missedCount":"Liczba pominiętych","iDontMiss":"Żadne bloki nie zostały pominięte","lastSyncTime":"Ostatni czas synch","delegator":"Delegujący","amount":"Kwota"},"blocks":{"block":"Blok","proposer":"Autor Propozycji","latestBlocks":"Ostatnie Bloki","noBlock":"Ilość Bloków","numOfTxs":"Liczba Txs","numOfTransactions":"Liczba Transakcji","notFound":"Nie znaleziono bloku."},"transactions":{"transaction":"Transakcja","transactions":"Transakcje","notFound":"Nie znaleziono transakcji.","activities":"Aktywność","txHash":"Tx Hash","valid":"Ważna","fee":"Opłata","noFee":"Bezpłatnie","gasUsedWanted":"Gaz (użyty/ wymagany)","noTxFound":"Nie znaleziono podanej transakcji.","noValidatorTxsFound":"Nie znaleziono żadnej transakcji dla podanego Walidatora","memo":"Memo","transfer":"Wysłane","staking":"Udziały","distribution":"Dystrybucja","governance":"Administracja","slashing":"Cięcia"},"proposals":{"notFound":"Nie znaleziono propozycji.'","listOfProposals":"Poniżej znajduje się lista propozycji administracyjnych.","proposer":"Autor Propozycji","proposal":"propozycja","proposals":"Propozycje","proposalID":"ID Propozycji","title":"Tytuł","status":"Status","submitTime":"Czas Wysłania","depositEndTime":"Czas Końcowy dla Skladania Depozytu","votingStartTime":"Czas Rozpoczęcia Głosowania","votingEndTime":"Czas Końcowy Głosowania","totalDeposit":"Kwota Depozytu","description":"Szczegóły","proposalType":"Typ Propozycji","proposalStatus":"Status Propozycji","notStarted":"nie rozpoczęto","final":"końcowy","deposit":"Depozyt","tallyResult":"Wyniki Tally","yes":"Tak","abstain":"Wstrzymaj się od Głosu","no":"Nie","noWithVeto":"Nie z Veto","percentageVoted":"<span class=\"text-info\">{$percent}</span> Głosów Online zostalo oddanych","validMessage":"Podana propozycja jest {$tentative}<strong>ważna</strong>.","invalidMessage":"Mniej niż {$quorum} głosów zostało oddanych. Podana propozycja jest <strong>nieważna</strong>.","moreVoteMessage":"Propozycja zostanie uznana za ważną jeśli <span class=\"text-info\">{$moreVotes}</span> lub więcej głosów zostanie oddanych.","key":"Key","value":"Value","amount":"Kwota","recipient":"Odbiorca","changes":"Zmiany","subspace":"Subspace"},"votingPower":{"distribution":"Podział Siły Głosu","pareto":"Zasada Pareta (zasada 20/80)","minValidators34":"Co najmniej 34% Walidatorów ma prawo do głosowania."},"accounts":{"accountDetails":"Szczegóły Konta","available":"Dostępe","delegated":"Oddelegowane","unbonding":"Unbonding","rewards":"Nagrody","total":"Łącznie","notFound":"Konto nie istnieje. Sprawdź, czy adres odbiorcy został prawidłowo wpisany.","validators":"Walidatorzy","shares":"Akcje","mature":"Dojrzały","no":"Nie ","none":"Brak ","delegation":"Delegacja","plural":"","signOut":"Wyloguj","signInText":"Zalogowany jako ","toLoginAs":"Aby zalogować się jako ","signInWithLedger":"Zaloguj się z Ledgerem","signInWarning":"Upewnij się, że Twój Ledger jest podłączony do komputera oraz aplikacja <strong class=\"text-primary\">Cosmos App 1.5.0 lub nowsza </strong> jest uruchomiona.","pleaseAccept":"zaakceptuj połączenie na Twoim Ledgerze.","noRewards":"Brak Nagród"},"activities":{"single":" ","happened":"został wykonany","senders":"Nadawca","sent":"wysłał","receivers":"do podanych odbiorców/cy","received":"otrzymał","failedTo":"Nie udało się","to":"do","from":"od","operatingAt":"operujący pod adresem","withMoniker":"z monikerem","withTitle":"pod tytułem","withA":"razem z"},"messageTypes":{"send":"Wysłał","multiSend":"Wysłał Multi","createValidator":"Utwórz Walidatora","editValidator":"Edytuj Walidatora","delegate":"Oddelegował","undelegate":"Wycofał Oddelegowane Tokeny","redelegate":"Oddelegował Ponownie","submitProposal":"Wyśłał Propozycję","deposit":"Wpłacił Depozyt","vote":"Zagłosował","withdrawComission":"Wypłacił Prowizję","withdrawReward":"Wypłacił Nagrody","modifyWithdrawAddress":"Zmienił adres do wypłaty","unjail":"Unjail","IBCTransfer":"Wyślij IBC","IBCReceive":"Odbierz IBC"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ru-RU.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/ru-RU.i18n.yml.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('ru-RU','',{"common":{"height":"высота блока","voter":"избиратель","votingPower":"право голоса","addresses":"Адреса","amounts":"Суммы","delegators":"делегаторы","block":"блок","blocks":"блоки","precommit":"прикоммит","precommits":"прикоммиты","last":"последний","backToList":"назад к списку","information":"информация","time":"время","hash":"хэш","more":"дальше","fullStop":".","searchPlaceholder":"Поиск с хэшем сделки / высотой блока / адресом","cancel":"отменять","retry":"Повторить попытку","rewards":"награды"},"navbar":{"siteName":"DP Explorer","version":"бета","validators":"валидаторы","blocks":"блоки","transactions":"транзакции","proposals":"Предложения","votingPower":"право голоса","lang":"RU","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","license":"ЛИЦЕНЗИЯ","forkMe":"OSS!"},"consensus":{"consensusState":"состояние консенсуса","round":"раунд","step":"этап"},"chainStates":{"price":"расценка","marketCap":"рыночная капитализация","inflation":"Инфляция","communityPool":"коммьюнити пул"},"chainStatus":{"startMessage":"Чейн собирается начать в","stopWarning":"Наверное, чейн остановлен из-за ! Накорми меня новыми блоками 😭!","latestHeight":"Последняя Высота Блока","averageBlockTime":"Среднее Время Блока","all":"Всё","now":"Сейчас","allTime":"всё время","lastMinute":"последняя минута","lastHour":"последний час","lastDay":"последний день","seconds":"секунды","activeValidators":"активные валидаторы","outOfValidators":"из {$totalValidators} валидаторах","onlineVotingPower":"онлайн право голоса","fromTotalStakes":"{$percent} от {$totalStakes} {$denomPlural}"},"analytics":{"blockTimeHistory":"История Времени Блока","averageBlockTime":"Среднее Время Блока","blockInterval":"Интервал Блока","noOfValidators":"количество валидаторов"},"validators":{"randomValidators":"Случайные Валидаторы","moniker":"Кличка","uptime":"Рабочее время","selfPercentage":"Сам%","commission":"Комиссия","lastSeen":"Последний увиденный","status":"Статус","jailed":"Тюрьма","navActive":"Активный","navInactive":"Неактивный","active":"Активные валидаторы","inactive":"Неактивные валидаторы","listOfActive":"Вот список активных валидаторов.","listOfInactive":"Вот список неактивных валидаторов.","validatorDetails":"Детали валидатора","lastNumBlocks":"Последние {$numBlocks} блоки","validatorInfo":"Информация о валидаторе","operatorAddress":"Адрес оператора","selfDelegationAddress":"Адрес самоделегирования","commissionRate":"Ставка Комиссии","maxRate":"Максимальная Ставка","maxChangeRate":"Максимальная Ставка Изменения","selfDelegationRatio":"Коэффициент самостоятельной делегации","proposerPriority":"Приоритет предложения","delegatorShares":"Доли делегатора","userDelegateShares":"Доли, делегированные вами","tokens":"Токены","unbondingHeight":"высота Un-Бондинг","unbondingTime":"Время Un-Бондинг","powerChange":"Изменение власти","delegations":"Делегации","transactions":"транзакции","validatorNotExists":"Валидатор не существует.","backToValidator":"Назад к валидатору","missedBlocks":"Пропущенные блоки","missedPrecommits":"опущенные прикоммиты","missedBlocksTitle":"опущенные блоки {$moniker}","totalMissed":"Всего пропущено","block":"Блок","missedCount":"опущенные отсчеты","iDontMiss":"Я не пропускаю","lastSyncTime":"Последнее время синхронизации","delegator":"Делегатор","amount":"Сумма"},"blocks":{"block":"Блок","proposer":"Предложение","latestBlocks":"Последние блоки","noBlock":"Нет блока.","numOfTxs":"количество сделок","numOfTransactions":"количество сделок","notFound":"Такого блока не найдено."},"transactions":{"transaction":"Сделка","transactions":"Сделки","notFound":"Не найдено.","activities":"Деятельность","txHash":"хэш сделки","valid":"Действительны","fee":"Плата","gasUsedWanted":"Газ (используется / хотел)","noTxFound":"Сделка не найдена","noValidatorTxsFound":"Сделка связанной с этом валидатором не найдена.","memo":"Записка","transfer":"Передача","staking":"Стейкать","distribution":"Распределение","governance":"Управление","slashing":"Сокращение"},"proposals":{"notFound":"Ни одно предложение не найдено.","listOfProposals":"список предложений по управлению","proposer":"Предлагающий","proposal":"Предложение","proposals":"Предложения","proposalID":"ID предложений","title":"Название","status":"Статус","submitTime":"Время Отправки","depositEndTime":"Время Окончания Депозита","votingStartTime":"Время Начала Голосования","votingEndTime":"Время Окончания Голосования","totalDeposit":"Общий депозит","description":"Описание","proposalType":"Тип Предложения","proposalStatus":"Статус Предложения","notStarted":"не начался","final":"окончательный","deposit":"Депозит","tallyResult":"Итог Подсчета","yes":"За","abstain":"Воздержался","no":"Против","noWithVeto":"Против с правом Вето","percentageVoted":"<span class=\"text-info\">{$percent}</span> количество голосов онлайн проголосовало.","validMessage":"Это предположение {$tentative}<strong>действительное</strong>.","invalidMessage":"Меньше чем {$quorum} количество голосов проголосовало. Это предположение <strong>недействительное</strong>.","moreVoteMessage":"Это будет действительным если<span class=\"text-info\">{$moreVotes}</span> большее количество голосов."},"votingPower":{"distribution":"Распределение количество голосов","pareto":"Принцип Парето (правило 20/80)","minValidators34":"Минимальное количество валидаторов c 34%+ количеством голосов"},"accounts":{"accountDetails":"Детали счета","available":"Доступный","delegated":"Делегирование","unbonding":"Un-Бондинг","rewards":"Награды","total":"Общее количество","notFound":"Такого счета не существует. Вы ищете неправильный адрес?","validators":"Валидаторы","shares":"Доли","mature":"Зрелые","no":"Нет","delegation":"Делегация","plural":"множественное число","signOut":"Выйти","signInText":"Войти","toLoginAs":"Войти","signInWithLedger":"Войти с Ledger","signInWarning":"Пожалуйста, убедитесь, что устройство Ledger подключен и <strong class=\"text-primary\">Cosmos App 1.5.0 или выше </strong> открыто.","pleaseAccept":"пожалуйста, примите в свой Ledger устройство."},"activities":{"single":" ","happened":"получилось.","senders":"Следующие отправителя (ей)","sent":"отправлено","receivers":"к следующему получателю(ам)","received":"полученный","failedTo":"не удалось","to":"к","from":"из'","operatingAt":"работающих на","withMoniker":"с кличкой","withTitle":"с названием","withA":"с"},"messageTypes":{"send":"Отправить","multiSend":"Отправить многократно","createValidator":"Создание валидатор","editValidator":"Редактировать валидатор","delegate":"делегировать","undelegate":"Un-делегировать","redelegate":"Ре-делегировать","submitProposal":"Отправлять Предложение","deposit":"Депозит","vote":"Голосовать","withdrawComission":"Выводить Комиссии","withdrawReward":"Выводить Награду","modifyWithdrawAddress":"Изменить Адрес Вывода","unjail":"Un-Джейл","IBCTransfer":"IBC Трансферт","IBCReceive":"IBC Получение"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hans.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hans.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hans','',{"common":{"height":"高度","voter":"投票人","votingPower":"算力","addresses":"地址","amounts":"数量","delegators":"委托人","block":"区块","blocks":"区块","precommit":"建块前保证","precommits":"建块前保证","last":"最后","backToList":"回到列表","information":"资讯","time":"时间","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜寻交易哈希 / 区块高度 / 地址","cancel":"取消","retry":"重试"},"navbar":{"siteName":"DP Explorer","version":"beta","validators":"验证人","blocks":"区块","transactions":"交易","proposals":"治理提案","votingPower":"算力分布","lang":"中文（简）","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"OSS"},"consensus":{"consensusState":"共识状态","round":"轮数","step":"阶数"},"chainStates":{"price":"价格","marketCap":"市值","inflation":"通胀率","communityPool":"社区储备"},"chainStatus":{"startMessage":"这链将还有以下时间便会开始","stopWarning":"这链似乎已经停了 <em>{$time}</em>！ 请继续喂我吃新的区块 😭!","latestHeight":"最新区块高度","averageBlockTime":"平均区块时间","all":"全部","now":"现在","allTime":"全部","lastMinute":"前一分钟","lastHour":"前一小时","lastDay":"前一天","seconds":"秒","activeValidators":"有效验证人","outOfValidators":"来自总共 {$totalValidators} 个验证人","onlineVotingPower":"在线挖礦算力","fromTotalStakes":"为 {$totalStakes} 颗 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在线投票权","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"随机验证人","moniker":"验证人代号","uptime":"上线时间比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最后投票时间","status":"状态","jailed":"被禁制","navActive":"有效","navInactive":"无效","active":"有效验证人","inactive":"无效验证人","listOfActive":"这名单显示所有有效验证人","listOfInactive":"这名单显示所有无效验证人","validatorDetails":"验证人详情","lastNumBlocks":"最后 {$numBlocks} 个区块","validatorInfo":"验证人资讯","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金变化限制","selfDelegationRatio":"自我委托比例","proposerPriority":"建块优先权","delegatorShares":"委托股数","userDelegateShares":"你委托的股数","tokens":"代币数量","unbondingHeight":"解绑高度","unbondingTime":"解绑时间","powerChange":"投票权变更","delegations":"委托","transactions":"交易","validatorNotExists":"验证人不存在。","backToValidator":"回到验证人页面","missedBlocks":"错过了的区块","missedPrecommits":"遗留了的建块前保证","missedBlocksTitle":"错过了 {$moniker} 的区块","totalMissed":"一共错过了","block":"区块","missedCount":"错过数量","iDontMiss":"我不会错过任何一个","lastSyncTime":"上一次同步时间","delegator":"委托人","amount":"数量"},"blocks":{"proposer":"建块人","block":"区块","latestBlocks":"最近区块","noBlock":"没有区块。","numOfTxs":"交易数量","numOfTransactions":"交易数量","notFound":"没有这个区块。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活动","txHash":"交易哈希","valid":"有效","fee":"费用","noFee":"No fee","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"没有这笔交易。","noValidatorTxsFound":"没有跟这个验证人有关的交易","memo":"备忘录","transfer":"代币转移","staking":"委托","distribution":"收益分配","governance":"链上治理","slashing":"削减"},"proposals":{"notFound":"没有治理提案","listOfProposals":"这名单显示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案编号","title":"主题","status":"状态","submitTime":"提案时间","depositEndTime":"存入押金","votingStartTime":"投票开始时间","votingEndTime":"投票结束时间","totalDeposit":"押金总额","description":"详细内容","proposalType":"提案类型","proposalStatus":"提案状态","notStarted":"未开始","final":"最后结果","deposit":"押金","tallyResult":"投票结果","yes":"赞成","abstain":"弃权","no":"反对","noWithVeto":"强烈反对","percentageVoted":"现时在线投票权的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"这个提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在线投票权少于 {$quorum}。这个提案 <strong>無效</strong>。","moreVoteMessage":"当再有多 <span class=\"text-info\">{$moreVotes}</span> 投票权投了票的话，这个提案将会有效。","key":"Key","value":"Value","amount":"Amount","recipient":"Recipient","changes":"Changes","subspace":"Subspace"},"votingPower":{"distribution":"投票权分布","pareto":"帕累托原则 (20/80 定率)","minValidators34":"最少合共有超过 34% 投票权的验证人"},"accounts":{"accountDetails":"帐户详情","available":"可用的","delegated":"委托中","unbonding":"解绑中","rewards":"未取回收益","total":"总共","notFound":"这个帐户不存在。你是否在查看一个错误的地址？","validators":"验证人","shares":"股数","mature":"成熟日期","no":"没有","none":"没有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登录以下帐户","toLoginAs":"登录以下帐户","signInWithLedger":"透过 Ledger 登录","signInWarning":"请确定你已经连接 Ledger 设备，并已开启 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"请从你的 Ledger 设备确认。","noRewards":"No Rewards"},"activities":{"single":"一个","happened":"发生了","senders":"以下的帐户","sent":"发了","receivers":"到以下的帐户","received":"收到","failedTo":"未能","to":"到","from":"从","operatingAt":"操作地址为","withMoniker":"而验证人代号为","withTitle":"治理提案主题为","withA":"投了"},"messageTypes":{"send":"发送","multiSend":"多重发送","createValidator":"建立验证人","editValidator":"编辑验证人资料","delegate":"委托","undelegate":"解委托","redelegate":"转委托","submitProposal":"提交议案","deposit":"存入","vote":"投票","withdrawComission":"提取手续费","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"zh-hant.i18n.yml.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/i18n/zh-hant.i18n.yml.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Package['universe:i18n'].i18n.addTranslations('zh-Hant','',{"common":{"height":"高度","voter":"投票人","votingPower":"算力權","addresses":"地址","amounts":"數量","delegators":"委托人","block":"區塊","blocks":"區塊","precommit":"建塊前保證","precommits":"建塊前保證","last":"最後","backToList":"回到列表","information":"資訊","time":"時間","hash":"哈希","more":"更多","fullStop":"。","searchPlaceholder":"搜尋交易哈希 / 區塊高度 / 地址","cancel":"取消","retry":"重試"},"navbar":{"siteName":"DP Explorer","version":"beta","validators":"驗證人","blocks":"區塊","transactions":"交易","proposals":"治理提案","votingPower":"算力權分佈","lang":"中文（繁）","english":"English","spanish":"Español","italian":"Italiano","polish":"Polski","russian":"Русский","chinese":"中文（繁）","simChinese":"中文（简）","license":"LICENSE","forkMe":"OSS"},"consensus":{"consensusState":"共識狀態","round":"輪數","step":"階數"},"chainStates":{"price":"價格","marketCap":"市值","inflation":"通漲率","communityPool":"社區儲備"},"chainStatus":{"startMessage":"這鏈將還有以下時間便會開始","stopWarning":"這鏈似乎已經停了 <em>{$time}</em>！ 請繼續餵我吃新的區塊 😭!","latestHeight":"最新區塊高度","averageBlockTime":"平均區塊時間","all":"全部","now":"現在","allTime":"全部","lastMinute":"前一分鐘","lastHour":"前一小時","lastDay":"前一天","seconds":"秒","activeValidators":"有效驗證人","outOfValidators":"來自總共 {$totalValidators} 個驗證人","onlineVotingPower":"在線挖礦","fromTotalStakes":"為 {$totalStakes} 顆 {$denom} 的 {$percent}"},"analytics":{"blockTimeHistory":"在線投票權","averageBlockTime":"Average Block Time","blockInterval":"Block Interval","noOfValidators":"No. of Validators"},"validators":{"randomValidators":"隨機驗證人","moniker":"驗證人代號","uptime":"上線時間比重","selfPercentage":"自我委托%","commission":"佣金","lastSeen":"最後投票時間","status":"狀態","jailed":"被禁制","navActive":"有效","navInactive":"無效","active":"有效驗證人","inactive":"無效驗證人","listOfActive":"這名單顯示所有有效驗證人","listOfInactive":"這名單顯示所有無效驗證人","validatorDetails":"驗證人詳情","lastNumBlocks":"最後 {$numBlocks} 個區塊","validatorInfo":"驗證人資訊","operatorAddress":"操作地址","selfDelegationAddress":"自我委托地址","commissionRate":"佣金","maxRate":"最大佣金限制","maxChangeRate":"每天最大佣金變化限制","selfDelegationRatio":"自我委托比列","proposerPriority":"建塊優先權","delegatorShares":"委托股數","userDelegateShares":"你委托的股數","tokens":"代幣數量","unbondingHeight":"解綁高度","unbondingTime":"解綁時間","powerChange":"投票權變更","delegations":"委托","transactions":"交易","validatorNotExists":"驗證人不存在。","backToValidator":"回到驗證人頁面","missedBlocks":"錯過了的區塊","missedPrecommits":"遺留了的建塊前保證","missedBlocksTitle":"錯過了 {$moniker} 的區塊","totalMissed":"一共錯過了","block":"區塊","missedCount":"錯過數量","iDontMiss":"我不會錯過任何一個","lastSyncTime":"上一次同步時間","delegator":"委托人","amount":"數量"},"blocks":{"proposer":"建塊人","block":"區塊","latestBlocks":"最近區塊","noBlock":"沒有區塊。","numOfTxs":"交易數量","numOfTransactions":"交易數量","notFound":"沒有這個區塊。"},"transactions":{"transaction":"交易","transactions":"交易","notFound":"沒有交易。","activities":"活動","txHash":"交易哈希","valid":"有效","fee":"費用","noFee":"No fee","gasUsedWanted":"瓦斯 (已用 / 要求)","noTxFound":"沒有這筆交易。","noValidatorTxsFound":"沒有跟這個驗證人有關的交易","memo":"備忘錄","transfer":"代幣轉移","staking":"委托","distribution":"收益分配","governance":"鏈上治理","slashing":"削減"},"proposals":{"notFound":"沒有治理提案","listOfProposals":"這名單顯示所有治理提案","proposer":"提案人","proposal":"治理提案","proposals":"治理提案","proposalID":"提案編號","title":"主題","status":"狀態","submitTime":"提案時間","depositEndTime":"存入押金","votingStartTime":"投票開始時間","votingEndTime":"投票結束時間","totalDeposit":"押金總額","description":"詳細內容","proposalType":"提案類型","proposalStatus":"提案狀態","notStarted":"未開始","final":"最後結果","deposit":"押金","tallyResult":"投票結果","yes":"贊成","abstain":"棄權","no":"反對","none":"反對","noWithVeto":"強烈反對","percentageVoted":"現時在線投票權的投票率是 <span class=\"text-info\">{$percent}</span>。","validMessage":"這個提案 {$tentative} <strong>有效</strong>.","invalidMessage":"已投票的在線投票權少於 {$quorum}。這個 <strong>無效</strong>。","moreVoteMessage":"當再有多 <span class=\"text-info\">{$moreVotes}</span> 投票權投了票的話，這個提案將會有效。","key":"Key","value":"Value","amount":"Amount","recipient":"Recipient","changes":"Changes","subspace":"Subspace"},"votingPower":{"distribution":"投票權分佈","pareto":"帕累托原則 (20/80 定率)","minValidators34":"最少合共有超過 34% 投票權的驗證人"},"accounts":{"accountDetails":"帳戶詳情","available":"可用的","delegated":"委托中","unbonding":"解綁中","rewards":"未取回收益","total":"總共","notFound":"這個帳戶不存在。你是否在查看一個錯誤的地址？","validators":"驗證人","shares":"股數","mature":"成熟日期","no":"沒有","delegation":"委托","plural":"","signOut":"登出","signInText":"你已登入以下帳戶","toLoginAs":"登入以下帳戶","signInWithLedger":"透過 Ledger 登入","signInWarning":"請確定你已經連接 Ledger 設備，並已開啓 <strong class=\"text-primary\">Cosmos App 版本 1.5.0 或以上</strong>。","pleaseAccept":"請從你的 Ledger 設備確認。","noRewards":"No Rewards"},"activities":{"single":"一個","happened":"發生了","senders":"以下的帳戶","sent":"發了","receivers":"到以下的帳戶","received":"收到","failedTo":"未能","to":"到","from":"從","operatingAt":"操作地止為","withMoniker":"而驗證人代號為","withTitle":"治理提案主題為","withA":"投了"},"messageTypes":{"send":"發送","multiSend":"多重發送","createValidator":"建立驗證人","editValidator":"編輯驗證人資料","delegate":"委托","undelegate":"解委托","redelegate":"轉委托","submitProposal":"提交議案","deposit":"存入","vote":"投票","withdrawComission":"提取手續費","withdrawReward":"提取收益","modifyWithdrawAddress":"更改收益取回地址","unjail":"赦免","IBCTransfer":"IBC Transfer","IBCReceive":"IBC Receive"}});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"utils":{"coins.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// both/utils/coins.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  default: () => Coin
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let numbro;
module.link("numbro", {
  default(v) {
    numbro = v;
  }

}, 1);

autoformat = value => {
  let formatter = '0,0.0000';
  value = Math.round(value * 1000) / 1000;
  if (Math.round(value) === value) formatter = '0,0';else if (Math.round(value * 10) === value * 10) formatter = '0,0.0';else if (Math.round(value * 100) === value * 100) formatter = '0,0.00';else if (Math.round(value * 1000) === value * 1000) formatter = '0,0.000';
  return numbro(value).format(formatter);
};

const coinList = Meteor.settings.public.coins;
console.log("loaded coin", coinList);

for (let i in coinList) {
  const coin = coinList[i];

  if (!coin.displayNamePlural) {
    coin.displayNamePlural = coin.displayName + 's';
  }
}

class Coin {
  constructor(amount) {
    let denom = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : Meteor.settings.public.bondDenom;
    const lowerDenom = denom.toLowerCase();
    this._coin = coinList.find(coin => coin.denom.toLowerCase() === lowerDenom || coin.displayName.toLowerCase() === lowerDenom);

    if (this._coin) {
      if (lowerDenom === this._coin.denom.toLowerCase()) {
        this._amount = Number(amount);
      } else if (lowerDenom === this._coin.displayName.toLowerCase()) {
        this._amount = Number(amount) * this._coin.fraction;
      }
    } else {
      this._coin = "";
      this._amount = Number(amount);
    }
  }

  get amount() {
    return this._amount;
  }

  get stakingAmount() {
    return this._coin ? this._amount / this._coin.fraction : this._amount;
  }

  toString(precision) {
    // default to display in mint denom if it has more than 4 decimal places
    let minStake = Coin.StakingCoin.fraction / (precision ? Math.pow(10, precision) : 10000);

    if (this.amount < minStake) {
      return "".concat(numbro(this.amount).format('0,0.0000'), " ").concat(this._coin.denom);
    } else {
      return "".concat(precision ? numbro(this.stakingAmount).format('0,0.' + '0'.repeat(precision)) : autoformat(this.stakingAmount), " ").concat(this._coin.displayName);
    }
  }

  mintString(formatter) {
    let amount = this.amount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    let denom = this._coin == "" ? Coin.StakingCoin.displayName : this._coin.denom;
    return "".concat(amount, " ").concat(denom);
  }

  stakeString(formatter) {
    let amount = this.stakingAmount;

    if (formatter) {
      amount = numbro(amount).format(formatter);
    }

    return "".concat(amount, " ").concat(Coin.StakingCoin.displayName);
  }

}

Coin.StakingCoin = coinList.find(coin => coin.denom === Meteor.settings.public.bondDenom);
Coin.MinStake = 1 / Number(Coin.StakingCoin.fraction);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.link("/imports/startup/server");
module.link("/imports/startup/both");
// import moment from 'moment';
// import '/imports/api/blocks/blocks.js';
SYNCING = false;
COUNTMISSEDBLOCKS = false;
COUNTMISSEDBLOCKSSTATS = false;
RPC = Meteor.settings.remote.rpc;
LCD = Meteor.settings.remote.lcd;
timerBlocks = 0;
timerChain = 0;
timerConsensus = 0;
timerProposal = 0;
timerProposalsResults = 0;
timerMissedBlock = 0;
timerDelegation = 0;
timerAggregate = 0;
const DEFAULTSETTINGS = '/default_settings.json';

updateChainStatus = () => {
  Meteor.call('chain.updateStatus', (error, result) => {
    if (error) {
      console.log("updateStatus: " + error);
    } else {
      console.log("updateStatus: " + result);
    }
  });
};

updateBlock = () => {
  Meteor.call('blocks.blocksUpdate', (error, result) => {
    if (error) {
      console.log("updateBlocks: " + error);
    } else {
      console.log("updateBlocks: " + result);
    }
  });
};

getConsensusState = () => {
  Meteor.call('chain.getConsensusState', (error, result) => {
    if (error) {
      console.log("get consensus: " + error);
    }
  });
};

getProposals = () => {
  Meteor.call('proposals.getProposals', (error, result) => {
    if (error) {
      console.log("get proposal: " + error);
    }

    if (result) {
      console.log("get proposal: " + result);
    }
  });
};

getProposalsResults = () => {
  Meteor.call('proposals.getProposalResults', (error, result) => {
    if (error) {
      console.log("get proposals result: " + error);
    }

    if (result) {
      console.log("get proposals result: " + result);
    }
  });
};

updateMissedBlocks = () => {
  Meteor.call('ValidatorRecords.calculateMissedBlocks', (error, result) => {
    if (error) {
      console.log("missed blocks error: " + error);
    }

    if (result) {
      console.log("missed blocks ok:" + result);
    }
  });
  /*
      Meteor.call('ValidatorRecords.calculateMissedBlocksStats', (error, result) =>{
          if (error){
              console.log("missed blocks stats error: "+ error)
          }
          if (result){
              console.log("missed blocks stats ok:" + result);
          }
      });
  */
};

getDelegations = () => {
  Meteor.call('delegations.getDelegations', (error, result) => {
    if (error) {
      console.log("get delegations error: " + error);
    } else {
      console.log("get delegations ok: " + result);
    }
  });
};

aggregateMinutely = () => {
  // doing something every min
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "m", (error, result) => {
    if (error) {
      console.log("aggregate minutely block time error: " + error);
    } else {
      console.log("aggregate minutely block time ok: " + result);
    }
  });
  Meteor.call('coinStats.getCoinStats', (error, result) => {
    if (error) {
      console.log("get coin stats error: " + error);
    } else {
      console.log("get coin stats ok: " + result);
    }
  });
};

aggregateHourly = () => {
  // doing something every hour
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "h", (error, result) => {
    if (error) {
      console.log("aggregate hourly block time error: " + error);
    } else {
      console.log("aggregate hourly block time ok: " + result);
    }
  });
};

aggregateDaily = () => {
  // doing somthing every day
  Meteor.call('Analytics.aggregateBlockTimeAndVotingPower', "d", (error, result) => {
    if (error) {
      console.log("aggregate daily block time error: " + error);
    } else {
      console.log("aggregate daily block time ok: " + result);
    }
  });
  Meteor.call('Analytics.aggregateValidatorDailyBlockTime', (error, result) => {
    if (error) {
      console.log("aggregate validators block time error:" + error);
    } else {
      console.log("aggregate validators block time ok:" + result);
    }
  });
};

Meteor.startup(function () {
  if (Meteor.isDevelopment) {
    let DEFAULTSETTINGSJSON;
    module.link("../default_settings.json", {
      default(v) {
        DEFAULTSETTINGSJSON = v;
      }

    }, 0);
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;
    Object.keys(DEFAULTSETTINGSJSON).forEach(key => {
      if (Meteor.settings[key] == undefined) {
        console.warn("CHECK SETTINGS JSON: ".concat(key, " is missing from settings"));
        Meteor.settings[key] = {};
      }

      Object.keys(DEFAULTSETTINGSJSON[key]).forEach(param => {
        if (Meteor.settings[key][param] == undefined) {
          console.warn("CHECK SETTINGS JSON: ".concat(key, ".").concat(param, " is missing from settings"));
          Meteor.settings[key][param] = DEFAULTSETTINGSJSON[key][param];
        }
      });
    });
  }

  Meteor.call('chain.genesis', (err, result) => {
    if (err) {
      console.log(err);
    }

    if (result) {
      if (Meteor.settings.debug.startTimer) {
        timerConsensus = Meteor.setInterval(function () {
          getConsensusState();
        }, Meteor.settings.params.consensusInterval);
        timerBlocks = Meteor.setInterval(function () {
          updateBlock();
        }, Meteor.settings.params.blockInterval);
        timerChain = Meteor.setInterval(function () {
          updateChainStatus();
        }, Meteor.settings.params.statusInterval);

        if (Meteor.settings.params.proposalInterval >= 0) {
          timerProposal = Meteor.setInterval(function () {
            getProposals();
          }, Meteor.settings.params.proposalInterval);
          timerProposalsResults = Meteor.setInterval(function () {
            getProposalsResults();
          }, Meteor.settings.params.proposalInterval);
        }

        timerMissedBlock = Meteor.setInterval(function () {
          updateMissedBlocks();
        }, Meteor.settings.params.missedBlocksInterval);
        timerDelegation = Meteor.setInterval(function () {
          getDelegations();
        }, Meteor.settings.params.delegationInterval);
        timerAggregate = Meteor.setInterval(function () {
          let now = new Date();

          if (now.getUTCSeconds() == 0) {
            aggregateMinutely();
          }

          if (now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateHourly();
          }

          if (now.getUTCHours() == 0 && now.getUTCMinutes() == 0 && now.getUTCSeconds() == 0) {
            aggregateDaily();
          }
        }, 1000);
      }
    }
  });
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"default_settings.json":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// default_settings.json                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.exports = {
  "public": {
    "chainName": "Cosmos Testnet",
    "chainId": "{Chain ID}",
    "gtm": "{Add your Google Tag Manager ID here}",
    "slashingWindow": 10000,
    "uptimeWindow": 250,
    "initialPageSize": 30,
    "secp256k1": false,
    "bech32PrefixAccAddr": "cosmos",
    "bech32PrefixAccPub": "cosmospub",
    "bech32PrefixValAddr": "cosmosvaloper",
    "bech32PrefixValPub": "cosmosvaloperpub",
    "bech32PrefixConsAddr": "cosmosvalcons",
    "bech32PrefixConsPub": "cosmosvalconspub",
    "bondDenom": "uatom",
    "powerReduction": 1000000,
    "coins": [
      {
        "denom": "uatom",
        "displayName": "ATOM",
        "displayNamePlural": "ATOMS",
        "fraction": 1000000
      },
      {
        "denom": "umuon",
        "displayName": "MUON",
        "displayNamePlural": "MUONS",
        "fraction": 1000000
      }
    ],
    "gasPrice": 0.02,
    "coingeckoId": "cosmos"
  },
  "genesisFile": "{Replace the address of the genesis file of the chain}",
  "remote": {
    "rpc": "https://gaia-seeds.interblock.io",
    "lcd": "https://gaia-seeds.interblock.io:1317"
  },
  "debug": {
    "startTimer": true,
    "readGenesis": true
  },
  "params": {
    "startHeight": 0,
    "defaultBlockTime": 5000,
    "blockInterval": 15000,
    "consensusInterval": 1000,
    "statusInterval": 7500,
    "signingInfoInterval": 1800000,
    "proposalInterval": 5000,
    "missedBlocksInterval": 60000,
    "delegationInterval": 900000
  }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx",
    ".mjs",
    ".i18n.yml"
  ]
});

require("/both/i18n/en-us.i18n.yml.js");
require("/both/i18n/es-es.i18n.yml.js");
require("/both/i18n/it-IT.i18n.yml.js");
require("/both/i18n/pl-PL.i18n.yml.js");
require("/both/i18n/ru-RU.i18n.yml.js");
require("/both/i18n/zh-hans.i18n.yml.js");
require("/both/i18n/zh-hant.i18n.yml.js");
require("/both/utils/coins.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYWNjb3VudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvYmxvY2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2NoYWluL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9jaGFpbi9jaGFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9kZWxlZ2F0aW9ucy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvZGVsZWdhdGlvbnMvZGVsZWdhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2xlZGdlci9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcHJvcG9zYWxzL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9wcm9wb3NhbHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcHJvcG9zYWxzL3Byb3Bvc2Fscy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVjb3Jkcy9zZXJ2ZXIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcmVjb3Jkcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9yZWNvcmRzL3JlY29yZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3N0YXR1cy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9zdGF0dXMvc3RhdHVzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2FjdGlvbnMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3RyYW5zYWN0aW9ucy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3NlcnZlci9tZXRob2RzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdm90aW5nLXBvd2VyL2hpc3RvcnkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2V2aWRlbmNlcy9ldmlkZW5jZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3ZhbGlkYXRvci1zZXRzL3ZhbGlkYXRvci1zZXRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvYm90aC9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9jcmVhdGUtaW5kZXhlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9yZWdpc3Rlci1hcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvdXRpbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91aS9jb21wb25lbnRzL0ljb25zLmpzeCIsIm1ldGVvcjovL/CfkrthcHAvYm90aC91dGlscy9jb2lucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwibGluayIsInYiLCJIVFRQIiwiVmFsaWRhdG9ycyIsImZldGNoRnJvbVVybCIsInVybCIsInJlcyIsImdldCIsIkxDRCIsInN0YXR1c0NvZGUiLCJlIiwiY29uc29sZSIsImxvZyIsIm1ldGhvZHMiLCJhZGRyZXNzIiwidW5ibG9jayIsImF2YWlsYWJsZSIsInJlc3BvbnNlIiwiSlNPTiIsInBhcnNlIiwiY29udGVudCIsInJlc3VsdCIsImFjY291bnQiLCJ0eXBlIiwidmFsdWUiLCJCYXNlVmVzdGluZ0FjY291bnQiLCJCYXNlQWNjb3VudCIsImFjY291bnRfbnVtYmVyIiwiYmFsYW5jZSIsImRlbGVnYXRpb25zIiwidW5ib25kaW5nIiwicmV3YXJkcyIsInRvdGFsX3Jld2FyZHMiLCJ0b3RhbCIsInZhbGlkYXRvciIsImZpbmRPbmUiLCIkb3IiLCJvcGVyYXRvcl9hZGRyZXNzIiwiZGVsZWdhdG9yX2FkZHJlc3MiLCJ2YWxfY29tbWlzc2lvbiIsImxlbmd0aCIsImNvbW1pc3Npb24iLCJkYXRhIiwic2hhcmVzIiwicGFyc2VGbG9hdCIsInJlbGVnYXRpb25zIiwiY29tcGxldGlvblRpbWUiLCJmb3JFYWNoIiwicmVsZWdhdGlvbiIsImVudHJpZXMiLCJ0aW1lIiwiRGF0ZSIsImNvbXBsZXRpb25fdGltZSIsInJlZGVsZWdhdGlvbkNvbXBsZXRpb25UaW1lIiwidW5kZWxlZ2F0aW9ucyIsInVuYm9uZGluZ0NvbXBsZXRpb25UaW1lIiwiZGVsZWdhdGlvbiIsImkiLCJ1bmJvbmRpbmdzIiwicmVkZWxlZ2F0aW9ucyIsInJlZGVsZWdhdGlvbiIsInZhbGlkYXRvcl9kc3RfYWRkcmVzcyIsImNvdW50IiwiUHJvbWlzZSIsIkJsb2Nrc2NvbiIsIkNoYWluIiwiVmFsaWRhdG9yU2V0cyIsIlZhbGlkYXRvclJlY29yZHMiLCJBbmFseXRpY3MiLCJWUERpc3RyaWJ1dGlvbnMiLCJWb3RpbmdQb3dlckhpc3RvcnkiLCJUcmFuc2FjdGlvbnMiLCJFdmlkZW5jZXMiLCJzaGEyNTYiLCJnZXRBZGRyZXNzIiwiY2hlZXJpbyIsImdldFJlbW92ZWRWYWxpZGF0b3JzIiwicHJldlZhbGlkYXRvcnMiLCJ2YWxpZGF0b3JzIiwicCIsInNwbGljZSIsImdldFZhbGlkYXRvclByb2ZpbGVVcmwiLCJpZGVudGl0eSIsInRoZW0iLCJwaWN0dXJlcyIsInByaW1hcnkiLCJzdHJpbmdpZnkiLCJpbmRleE9mIiwidGVhbVBhZ2UiLCJwYWdlIiwibG9hZCIsImF0dHIiLCJibG9ja3MiLCJmaW5kIiwicHJvcG9zZXJBZGRyZXNzIiwiZmV0Y2giLCJoZWlnaHRzIiwibWFwIiwiYmxvY2siLCJoZWlnaHQiLCJibG9ja3NTdGF0cyIsIiRpbiIsInRvdGFsQmxvY2tEaWZmIiwiYiIsInRpbWVEaWZmIiwiY29sbGVjdGlvbiIsInJhd0NvbGxlY3Rpb24iLCJwaXBlbGluZSIsIiRtYXRjaCIsIiRzb3J0IiwiJGxpbWl0Iiwic2V0dGluZ3MiLCJwdWJsaWMiLCJ1cHRpbWVXaW5kb3ciLCIkdW53aW5kIiwiJGdyb3VwIiwiJGNvbmQiLCIkZXEiLCJhd2FpdCIsImFnZ3JlZ2F0ZSIsInRvQXJyYXkiLCJSUEMiLCJzdGF0dXMiLCJzeW5jX2luZm8iLCJsYXRlc3RfYmxvY2tfaGVpZ2h0IiwiY3VyckhlaWdodCIsInNvcnQiLCJsaW1pdCIsInN0YXJ0SGVpZ2h0IiwicGFyYW1zIiwiU1lOQ0lORyIsInVudGlsIiwiY2FsbCIsImN1cnIiLCJ2YWxpZGF0b3JTZXQiLCJjb25zZW5zdXNfcHVia2V5IiwidG90YWxWYWxpZGF0b3JzIiwiT2JqZWN0Iiwia2V5cyIsInN0YXJ0QmxvY2tUaW1lIiwiYW5hbHl0aWNzRGF0YSIsImJ1bGtWYWxpZGF0b3JzIiwiaW5pdGlhbGl6ZVVub3JkZXJlZEJ1bGtPcCIsImJ1bGtWYWxpZGF0b3JSZWNvcmRzIiwiYnVsa1ZQSGlzdG9yeSIsImJ1bGtUcmFuc2F0aW9ucyIsInN0YXJ0R2V0SGVpZ2h0VGltZSIsImJsb2NrRGF0YSIsImhhc2giLCJibG9ja19tZXRhIiwiYmxvY2tfaWQiLCJ0cmFuc051bSIsImhlYWRlciIsIm51bV90eHMiLCJsYXN0QmxvY2tIYXNoIiwibGFzdF9ibG9ja19pZCIsInByb3Bvc2VyX2FkZHJlc3MiLCJwcmVjb21taXRzIiwibGFzdF9jb21taXQiLCJwdXNoIiwidmFsaWRhdG9yX2FkZHJlc3MiLCJ0eHMiLCJ0IiwiQnVmZmVyIiwiZnJvbSIsImVyciIsImV2aWRlbmNlIiwiaW5zZXJ0IiwicHJlY29tbWl0c0NvdW50IiwiZW5kR2V0SGVpZ2h0VGltZSIsInN0YXJ0R2V0VmFsaWRhdG9yc1RpbWUiLCJibG9ja19oZWlnaHQiLCJwYXJzZUludCIsInZhbGlkYXRvcnNDb3VudCIsInN0YXJ0QmxvY2tJbnNlcnRUaW1lIiwiZW5kQmxvY2tJbnNlcnRUaW1lIiwiZXhpc3RpbmdWYWxpZGF0b3JzIiwiJGV4aXN0cyIsInJlY29yZCIsImV4aXN0cyIsInZvdGluZ19wb3dlciIsImoiLCJudW1CbG9ja3MiLCJ1cHRpbWUiLCJiYXNlIiwidXBzZXJ0IiwidXBkYXRlT25lIiwiJHNldCIsImxhc3RTZWVuIiwiY2hhaW5TdGF0dXMiLCJjaGFpbklkIiwiY2hhaW5faWQiLCJsYXN0U3luY2VkVGltZSIsImJsb2NrVGltZSIsImRlZmF1bHRCbG9ja1RpbWUiLCJkYXRlTGF0ZXN0IiwiZGF0ZUxhc3QiLCJNYXRoIiwiYWJzIiwiZ2V0VGltZSIsImVuZEdldFZhbGlkYXRvcnNUaW1lIiwidXBkYXRlIiwiYXZlcmFnZUJsb2NrVGltZSIsInN0YXJ0RmluZFZhbGlkYXRvcnNOYW1lVGltZSIsInByb3Bvc2VyX3ByaW9yaXR5IiwidmFsRXhpc3QiLCJwdWJfa2V5IiwiYWNjcHViIiwiYmVjaDMyUHJlZml4QWNjUHViIiwib3BlcmF0b3JfcHVia2V5IiwiYmVjaDMyUHJlZml4VmFsUHViIiwiYmVjaDMyUHJlZml4Q29uc1B1YiIsInZhbGlkYXRvckRhdGEiLCJkZXNjcmlwdGlvbiIsInByb2ZpbGVfdXJsIiwiamFpbGVkIiwibWluX3NlbGZfZGVsZWdhdGlvbiIsInRva2VucyIsImRlbGVnYXRvcl9zaGFyZXMiLCJib25kX2hlaWdodCIsImJvbmRfaW50cmFfdHhfY291bnRlciIsInVuYm9uZGluZ19oZWlnaHQiLCJ1bmJvbmRpbmdfdGltZSIsInNlbGZfZGVsZWdhdGlvbiIsInByZXZfdm90aW5nX3Bvd2VyIiwiYmxvY2tfdGltZSIsInNlbGZEZWxlZ2F0aW9uIiwicHJldlZvdGluZ1Bvd2VyIiwiY2hhbmdlVHlwZSIsImNoYW5nZURhdGEiLCJyZW1vdmVkVmFsaWRhdG9ycyIsInIiLCJkYlZhbGlkYXRvcnMiLCJmaWVsZHMiLCJjb25QdWJLZXkiLCJ1bmRlZmluZWQiLCJwdWJrZXlUeXBlIiwic2VjcDI1NmsxIiwicHJvZmlsZVVybCIsImVuZEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUiLCJzdGFydEFuYXl0aWNzSW5zZXJ0VGltZSIsImVuZEFuYWx5dGljc0luc2VydFRpbWUiLCJzdGFydFZVcFRpbWUiLCJleGVjdXRlIiwiZW5kVlVwVGltZSIsInN0YXJ0VlJUaW1lIiwiZW5kVlJUaW1lIiwiYWN0aXZlVmFsaWRhdG9ycyIsIm51bVRvcFR3ZW50eSIsImNlaWwiLCJudW1Cb3R0b21FaWdodHkiLCJ0b3BUd2VudHlQb3dlciIsImJvdHRvbUVpZ2h0eVBvd2VyIiwibnVtVG9wVGhpcnR5Rm91ciIsIm51bUJvdHRvbVNpeHR5U2l4IiwidG9wVGhpcnR5Rm91clBlcmNlbnQiLCJib3R0b21TaXh0eVNpeFBlcmNlbnQiLCJ2cERpc3QiLCJudW1WYWxpZGF0b3JzIiwidG90YWxWb3RpbmdQb3dlciIsImNyZWF0ZUF0IiwiZW5kQmxvY2tUaW1lIiwibGFzdEJsb2Nrc1N5bmNlZFRpbWUiLCJwdWJsaXNoQ29tcG9zaXRlIiwiY2hpbGRyZW4iLCJleHBvcnQiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJoZWxwZXJzIiwicHJvcG9zZXIiLCJDaGFpblN0YXRlcyIsIkNvaW4iLCJkZWZhdWx0IiwiZmluZFZvdGluZ1Bvd2VyIiwiZ2VuVmFsaWRhdG9ycyIsInBvd2VyIiwiY29uc2Vuc3VzIiwicm91bmRfc3RhdGUiLCJyb3VuZCIsInN0ZXAiLCJ2b3RlZFBvd2VyIiwidm90ZXMiLCJwcmV2b3Rlc19iaXRfYXJyYXkiLCJzcGxpdCIsInZvdGluZ0hlaWdodCIsInZvdGluZ1JvdW5kIiwidm90aW5nU3RlcCIsInByZXZvdGVzIiwiY2hhaW4iLCJub2RlX2luZm8iLCJuZXR3b3JrIiwibGF0ZXN0QmxvY2tIZWlnaHQiLCJsYXRlc3RCbG9ja1RpbWUiLCJsYXRlc3RfYmxvY2tfdGltZSIsImxhdGVzdFN0YXRlIiwiYWN0aXZlVlAiLCJhY3RpdmVWb3RpbmdQb3dlciIsImNoYWluU3RhdGVzIiwiYm9uZGluZyIsImJvbmRlZFRva2VucyIsImJvbmRlZF90b2tlbnMiLCJub3RCb25kZWRUb2tlbnMiLCJub3RfYm9uZGVkX3Rva2VucyIsIlN0YWtpbmdDb2luIiwiZGVub20iLCJzdXBwbHkiLCJ0b3RhbFN1cHBseSIsInBvb2wiLCJjb21tdW5pdHlQb29sIiwiYW1vdW50IiwiaW5mbGF0aW9uIiwicHJvdmlzaW9ucyIsImFubnVhbFByb3Zpc2lvbnMiLCJjcmVhdGVkIiwicmVhZEdlbmVzaXMiLCJkZWJ1ZyIsImdlbmVzaXNGaWxlIiwiZ2VuZXNpcyIsImRpc3RyIiwiYXBwX3N0YXRlIiwiZGlzdHJpYnV0aW9uIiwiY2hhaW5QYXJhbXMiLCJnZW5lc2lzVGltZSIsImdlbmVzaXNfdGltZSIsImNvbnNlbnN1c1BhcmFtcyIsImNvbnNlbnN1c19wYXJhbXMiLCJhdXRoIiwiYmFuayIsInN0YWtpbmciLCJtaW50IiwiY29tbXVuaXR5VGF4IiwiY29tbXVuaXR5X3RheCIsImJhc2VQcm9wb3NlclJld2FyZCIsImJhc2VfcHJvcG9zZXJfcmV3YXJkIiwiYm9udXNQcm9wb3NlclJld2FyZCIsImJvbnVzX3Byb3Bvc2VyX3Jld2FyZCIsIndpdGhkcmF3QWRkckVuYWJsZWQiLCJ3aXRoZHJhd19hZGRyX2VuYWJsZWQiLCJnb3YiLCJzdGFydGluZ1Byb3Bvc2FsSWQiLCJkZXBvc2l0UGFyYW1zIiwidm90aW5nUGFyYW1zIiwidGFsbHlQYXJhbXMiLCJzbGFzaGluZyIsImNyaXNpcyIsInN0YXJ0aW5nX3Byb3Bvc2FsX2lkIiwiZGVwb3NpdF9wYXJhbXMiLCJ2b3RpbmdfcGFyYW1zIiwidGFsbHlfcGFyYW1zIiwiZ2VudXRpbCIsImdlbnR4cyIsIm1zZyIsIm0iLCJwdWJrZXkiLCJmbG9vciIsImZyYWN0aW9uIiwicHVia2V5VmFsdWUiLCJnZW5WYWxpZGF0b3JzU2V0IiwiQ29pblN0YXRzIiwicHVibGlzaCIsImxhc3RfdXBkYXRlZF9hdCIsImNvaW5JZCIsImNvaW5nZWNrb0lkIiwibm93Iiwic2V0TWludXRlcyIsIkRlbGVnYXRpb25zIiwiY29uY2F0IiwiY3JlYXRlZEF0IiwiX29iamVjdFNwcmVhZCIsInR4SW5mbyIsInRpbWVzdGFtcCIsInBvc3QiLCJjb2RlIiwiRXJyb3IiLCJyYXdfbG9nIiwibWVzc2FnZSIsInR4aGFzaCIsImJvZHkiLCJwYXRoIiwidHhNc2ciLCJhZGp1c3RtZW50IiwiZ2FzX2VzdGltYXRlIiwiUHJvcG9zYWxzIiwicHJvcG9zYWxzIiwiZmluaXNoZWRQcm9wb3NhbElkcyIsIlNldCIsInByb3Bvc2FsSWQiLCJwcm9wb3NhbElkcyIsImJ1bGtQcm9wb3NhbHMiLCJwcm9wb3NhbCIsImlkIiwiaGFzIiwicHJvcG9zYWxfaWQiLCIkbmluIiwicHJvcG9zYWxfc3RhdHVzIiwiZGVwb3NpdHMiLCJnZXRWb3RlRGV0YWlsIiwidGFsbHkiLCJ1cGRhdGVkQXQiLCJ2b3RlcnMiLCJ2b3RlIiwidm90ZXIiLCJ2b3RpbmdQb3dlck1hcCIsInZhbGlkYXRvckFkZHJlc3NNYXAiLCJtb25pa2VyIiwiZGVsZWdhdG9yU2hhcmVzIiwiZGVkdWN0ZWRTaGFyZXMiLCJ2b3RpbmdQb3dlciIsImNoZWNrIiwiTnVtYmVyIiwiQXZlcmFnZURhdGEiLCJBdmVyYWdlVmFsaWRhdG9yRGF0YSIsIlN0YXR1cyIsIk1pc3NlZEJsb2Nrc1N0YXRzIiwiTWlzc2VkQmxvY2tzIiwiXyIsIkJVTEtVUERBVEVNQVhTSVpFIiwiZ2V0QmxvY2tTdGF0cyIsImxhdGVzdEhlaWdodCIsImJsb2NrU3RhdHMiLCJjb25kIiwiJGFuZCIsIiRndCIsIiRsdGUiLCJvcHRpb25zIiwiYXNzaWduIiwiZ2V0UHJldmlvdXNSZWNvcmQiLCJ2b3RlckFkZHJlc3MiLCJwcmV2aW91c1JlY29yZCIsImJsb2NrSGVpZ2h0IiwibGFzdFVwZGF0ZWRIZWlnaHQiLCJwcmV2U3RhdHMiLCJwaWNrIiwibWlzc0NvdW50IiwidG90YWxDb3VudCIsIkNPVU5UTUlTU0VEQkxPQ0tTIiwic3RhcnRUaW1lIiwiZXhwbG9yZXJTdGF0dXMiLCJsYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tIZWlnaHQiLCJtaW4iLCJidWxrTWlzc2VkU3RhdHMiLCJpbml0aWFsaXplT3JkZXJlZEJ1bGtPcCIsInZhbGlkYXRvcnNNYXAiLCJwcm9wb3NlclZvdGVyU3RhdHMiLCJ2b3RlZFZhbGlkYXRvcnMiLCJ2YWxpZGF0b3JTZXRzIiwidm90ZWRWb3RpbmdQb3dlciIsImFjdGl2ZVZhbGlkYXRvciIsImN1cnJlbnRWYWxpZGF0b3IiLCJzZXQiLCJuIiwic3RhdHMiLCJjbGllbnQiLCJfZHJpdmVyIiwibW9uZ28iLCJidWxrUHJvbWlzZSIsInRoZW4iLCJiaW5kRW52aXJvbm1lbnQiLCJuSW5zZXJ0ZWQiLCJuVXBzZXJ0ZWQiLCJuTW9kaWZpZWQiLCJsYXN0UHJvY2Vzc2VkTWlzc2VkQmxvY2tUaW1lIiwiQ09VTlRNSVNTRURCTE9DS1NTVEFUUyIsImxhc3RNaXNzZWRCbG9ja0hlaWdodCIsIm1pc3NlZFJlY29yZHMiLCJjb3VudHMiLCJleGlzdGluZ1JlY29yZCIsImxhc3RNaXNzZWRCbG9ja1RpbWUiLCJhdmVyYWdlVm90aW5nUG93ZXIiLCJhbmFseXRpY3MiLCJsYXN0TWludXRlVm90aW5nUG93ZXIiLCJsYXN0TWludXRlQmxvY2tUaW1lIiwibGFzdEhvdXJWb3RpbmdQb3dlciIsImxhc3RIb3VyQmxvY2tUaW1lIiwibGFzdERheVZvdGluZ1Bvd2VyIiwibGFzdERheUJsb2NrVGltZSIsImJsb2NrSGVpZ2h0cyIsImEiLCJudW0iLCJjb25kaXRpb25zIiwicHJvcG9zZXJNb25pa2VyIiwidm90ZXJNb25pa2VyIiwiQWRkcmVzc0xlbmd0aCIsInRvVXBwZXJDYXNlIiwidHgiLCJ0eElkIiwiJGx0IiwiaW5jbHVkZXMiLCJiZWNoMzJQcmVmaXhWYWxBZGRyIiwiYmVjaDMyUHJlZml4QWNjQWRkciIsInZhbGlkYXRvckFkZHJlc3MiLCJkZWxlZ2F0b3JBZGRyZXNzIiwicXVlcnkiLCJUeEljb24iLCJkaXJlY3Rpb24iLCJ2YWwiLCJmaXJzdFNlZW4iLCJoaXN0b3J5IiwiY3JlYXRlSW5kZXgiLCJ1bmlxdWUiLCJwYXJ0aWFsRmlsdGVyRXhwcmVzc2lvbiIsIm9uUGFnZUxvYWQiLCJIZWxtZXQiLCJzaW5rIiwiaGVsbWV0IiwicmVuZGVyU3RhdGljIiwiYXBwZW5kVG9IZWFkIiwibWV0YSIsInRvU3RyaW5nIiwidGl0bGUiLCJiZWNoMzIiLCJGdXR1cmUiLCJOcG0iLCJyZXF1aXJlIiwiZXhlYyIsInRvSGV4U3RyaW5nIiwiYnl0ZUFycmF5IiwiYnl0ZSIsInNsaWNlIiwiam9pbiIsInB1YmtleVRvQmVjaDMyIiwicHJlZml4IiwiYnVmZmVyIiwicHVia2V5QW1pbm9QcmVmaXgiLCJhbGxvYyIsImNvcHkiLCJlbmNvZGUiLCJ0b1dvcmRzIiwiYmVjaDMyVG9QdWJrZXkiLCJmcm9tV29yZHMiLCJkZWNvZGUiLCJ3b3JkcyIsImdldERlbGVnYXRvciIsIm9wZXJhdG9yQWRkciIsImdldEtleWJhc2VUZWFtUGljIiwia2V5YmFzZVVybCIsIkRlbm9tU3ltYm9sIiwiUHJvcG9zYWxTdGF0dXNJY29uIiwiVm90ZUljb24iLCJJbmZvSWNvbiIsIlJlYWN0IiwiVW5jb250cm9sbGVkVG9vbHRpcCIsInByb3BzIiwidmFsaWQiLCJDb21wb25lbnQiLCJjb25zdHJ1Y3RvciIsInJlZiIsImNyZWF0ZVJlZiIsInJlbmRlciIsInRvb2x0aXBUZXh0IiwibnVtYnJvIiwiYXV0b2Zvcm1hdCIsImZvcm1hdHRlciIsImZvcm1hdCIsImNvaW5MaXN0IiwiY29pbnMiLCJjb2luIiwiZGlzcGxheU5hbWVQbHVyYWwiLCJkaXNwbGF5TmFtZSIsImJvbmREZW5vbSIsImxvd2VyRGVub20iLCJ0b0xvd2VyQ2FzZSIsIl9jb2luIiwiX2Ftb3VudCIsInN0YWtpbmdBbW91bnQiLCJwcmVjaXNpb24iLCJtaW5TdGFrZSIsInBvdyIsInJlcGVhdCIsIm1pbnRTdHJpbmciLCJzdGFrZVN0cmluZyIsIk1pblN0YWtlIiwicmVtb3RlIiwicnBjIiwibGNkIiwidGltZXJCbG9ja3MiLCJ0aW1lckNoYWluIiwidGltZXJDb25zZW5zdXMiLCJ0aW1lclByb3Bvc2FsIiwidGltZXJQcm9wb3NhbHNSZXN1bHRzIiwidGltZXJNaXNzZWRCbG9jayIsInRpbWVyRGVsZWdhdGlvbiIsInRpbWVyQWdncmVnYXRlIiwiREVGQVVMVFNFVFRJTkdTIiwidXBkYXRlQ2hhaW5TdGF0dXMiLCJlcnJvciIsInVwZGF0ZUJsb2NrIiwiZ2V0Q29uc2Vuc3VzU3RhdGUiLCJnZXRQcm9wb3NhbHMiLCJnZXRQcm9wb3NhbHNSZXN1bHRzIiwidXBkYXRlTWlzc2VkQmxvY2tzIiwiZ2V0RGVsZWdhdGlvbnMiLCJhZ2dyZWdhdGVNaW51dGVseSIsImFnZ3JlZ2F0ZUhvdXJseSIsImFnZ3JlZ2F0ZURhaWx5Iiwic3RhcnR1cCIsImlzRGV2ZWxvcG1lbnQiLCJERUZBVUxUU0VUVElOR1NKU09OIiwicHJvY2VzcyIsImVudiIsIk5PREVfVExTX1JFSkVDVF9VTkFVVEhPUklaRUQiLCJrZXkiLCJ3YXJuIiwicGFyYW0iLCJzdGFydFRpbWVyIiwic2V0SW50ZXJ2YWwiLCJjb25zZW5zdXNJbnRlcnZhbCIsImJsb2NrSW50ZXJ2YWwiLCJzdGF0dXNJbnRlcnZhbCIsInByb3Bvc2FsSW50ZXJ2YWwiLCJtaXNzZWRCbG9ja3NJbnRlcnZhbCIsImRlbGVnYXRpb25JbnRlcnZhbCIsImdldFVUQ1NlY29uZHMiLCJnZXRVVENNaW51dGVzIiwiZ2V0VVRDSG91cnMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksdUNBQVosRUFBb0Q7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQXBELEVBQWtGLENBQWxGOztBQUd2SSxNQUFNRyxZQUFZLEdBQUlDLEdBQUQsSUFBUztBQUMxQixNQUFHO0FBQ0MsUUFBSUMsR0FBRyxHQUFHSixJQUFJLENBQUNLLEdBQUwsQ0FBU0MsR0FBRyxHQUFHSCxHQUFmLENBQVY7O0FBQ0EsUUFBSUMsR0FBRyxDQUFDRyxVQUFKLElBQWtCLEdBQXRCLEVBQTBCO0FBQ3RCLGFBQU9ILEdBQVA7QUFDSDs7QUFBQTtBQUNKLEdBTEQsQ0FNQSxPQUFPSSxDQUFQLEVBQVM7QUFDTEMsV0FBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLENBVkQ7O0FBWUFaLE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsK0JBQTZCLFVBQVNDLE9BQVQsRUFBaUI7QUFDMUMsU0FBS0MsT0FBTDtBQUNBLFFBQUlWLEdBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXlCTSxPQUFuQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSUUsU0FBUyxHQUFHZCxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFoQjs7QUFDQSxVQUFJVyxTQUFTLENBQUNQLFVBQVYsSUFBd0IsR0FBNUIsRUFBZ0M7QUFDNUIsWUFBSVEsUUFBUSxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0gsU0FBUyxDQUFDSSxPQUFyQixFQUE4QkMsTUFBN0M7QUFDQSxZQUFJQyxPQUFKO0FBQ0EsWUFBSUwsUUFBUSxDQUFDTSxJQUFULEtBQWtCLG9CQUF0QixFQUNJRCxPQUFPLEdBQUdMLFFBQVEsQ0FBQ08sS0FBbkIsQ0FESixLQUVLLElBQUlQLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQixrQ0FBbEIsSUFBd0ROLFFBQVEsQ0FBQ00sSUFBVCxLQUFrQixxQ0FBOUUsRUFDREQsT0FBTyxHQUFHTCxRQUFRLENBQUNPLEtBQVQsQ0FBZUMsa0JBQWYsQ0FBa0NDLFdBQTVDO0FBQ0osWUFBSUosT0FBTyxJQUFJQSxPQUFPLENBQUNLLGNBQVIsSUFBMEIsSUFBekMsRUFDSSxPQUFPTCxPQUFQO0FBQ0osZUFBTyxJQUFQO0FBQ0g7QUFDSixLQWJELENBY0EsT0FBT1osQ0FBUCxFQUFTO0FBQ0xDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQXJCVTtBQXNCWCx5QkFBdUIsVUFBU0ksT0FBVCxFQUFpQjtBQUNwQyxTQUFLQyxPQUFMO0FBQ0EsUUFBSWEsT0FBTyxHQUFHLEVBQWQsQ0FGb0MsQ0FJcEM7O0FBQ0EsUUFBSXZCLEdBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXlCTSxPQUFuQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSUUsU0FBUyxHQUFHZCxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFoQjs7QUFDQSxVQUFJVyxTQUFTLENBQUNQLFVBQVYsSUFBd0IsR0FBNUIsRUFBZ0M7QUFDNUJtQixlQUFPLENBQUNaLFNBQVIsR0FBb0JFLElBQUksQ0FBQ0MsS0FBTCxDQUFXSCxTQUFTLENBQUNJLE9BQXJCLEVBQThCQyxNQUFsRDtBQUVIO0FBQ0osS0FORCxDQU9BLE9BQU9YLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNILEtBZm1DLENBaUJwQzs7O0FBQ0FMLE9BQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyxjQUEzQzs7QUFDQSxRQUFHO0FBQ0MsVUFBSWUsV0FBVyxHQUFHM0IsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBbEI7O0FBQ0EsVUFBSXdCLFdBQVcsQ0FBQ3BCLFVBQVosSUFBMEIsR0FBOUIsRUFBa0M7QUFDOUJtQixlQUFPLENBQUNDLFdBQVIsR0FBc0JYLElBQUksQ0FBQ0MsS0FBTCxDQUFXVSxXQUFXLENBQUNULE9BQXZCLEVBQWdDQyxNQUF0RDtBQUNIO0FBQ0osS0FMRCxDQU1BLE9BQU9YLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNILEtBM0JtQyxDQTRCcEM7OztBQUNBTCxPQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsd0JBQTNDOztBQUNBLFFBQUc7QUFDQyxVQUFJZ0IsU0FBUyxHQUFHNUIsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBaEI7O0FBQ0EsVUFBSXlCLFNBQVMsQ0FBQ3JCLFVBQVYsSUFBd0IsR0FBNUIsRUFBZ0M7QUFDNUJtQixlQUFPLENBQUNFLFNBQVIsR0FBb0JaLElBQUksQ0FBQ0MsS0FBTCxDQUFXVyxTQUFTLENBQUNWLE9BQXJCLEVBQThCQyxNQUFsRDtBQUNIO0FBQ0osS0FMRCxDQU1BLE9BQU9YLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNILEtBdENtQyxDQXdDcEM7OztBQUNBTCxPQUFHLEdBQUdHLEdBQUcsR0FBRywyQkFBTixHQUFrQ00sT0FBbEMsR0FBMEMsVUFBaEQ7O0FBQ0EsUUFBRztBQUNDLFVBQUlpQixPQUFPLEdBQUc3QixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFkOztBQUNBLFVBQUkwQixPQUFPLENBQUN0QixVQUFSLElBQXNCLEdBQTFCLEVBQThCO0FBQzFCO0FBQ0FtQixlQUFPLENBQUNHLE9BQVIsR0FBa0JiLElBQUksQ0FBQ0MsS0FBTCxDQUFXWSxPQUFPLENBQUNYLE9BQW5CLEVBQTRCQyxNQUE1QixDQUFtQ1UsT0FBckQsQ0FGMEIsQ0FHMUI7O0FBQ0FILGVBQU8sQ0FBQ0ksYUFBUixHQUF1QmQsSUFBSSxDQUFDQyxLQUFMLENBQVdZLE9BQU8sQ0FBQ1gsT0FBbkIsRUFBNEJDLE1BQTVCLENBQW1DWSxLQUExRDtBQUVIO0FBQ0osS0FURCxDQVVBLE9BQU92QixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSCxLQXREbUMsQ0F3RHBDOzs7QUFDQSxRQUFJd0IsU0FBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUNaO0FBQUNDLFNBQUcsRUFBRSxDQUFDO0FBQUNDLHdCQUFnQixFQUFDdkI7QUFBbEIsT0FBRCxFQUE2QjtBQUFDd0IseUJBQWlCLEVBQUN4QjtBQUFuQixPQUE3QixFQUEwRDtBQUFDQSxlQUFPLEVBQUNBO0FBQVQsT0FBMUQ7QUFBTixLQURZLENBQWhCOztBQUVBLFFBQUlvQixTQUFKLEVBQWU7QUFDWCxVQUFJN0IsR0FBRyxHQUFHRyxHQUFHLEdBQUcsMkJBQU4sR0FBb0MwQixTQUFTLENBQUNHLGdCQUF4RDtBQUNBVCxhQUFPLENBQUNTLGdCQUFSLEdBQTJCSCxTQUFTLENBQUNHLGdCQUFyQzs7QUFDQSxVQUFJO0FBQ0EsWUFBSU4sT0FBTyxHQUFHN0IsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZDs7QUFDQSxZQUFJMEIsT0FBTyxDQUFDdEIsVUFBUixJQUFzQixHQUExQixFQUE4QjtBQUMxQixjQUFJVyxPQUFPLEdBQUdGLElBQUksQ0FBQ0MsS0FBTCxDQUFXWSxPQUFPLENBQUNYLE9BQW5CLEVBQTRCQyxNQUExQztBQUNBLGNBQUlELE9BQU8sQ0FBQ21CLGNBQVIsSUFBMEJuQixPQUFPLENBQUNtQixjQUFSLENBQXVCQyxNQUF2QixHQUFnQyxDQUE5RCxFQUNJWixPQUFPLENBQUNhLFVBQVIsR0FBcUJyQixPQUFPLENBQUNtQixjQUE3QjtBQUVQO0FBRUosT0FURCxDQVVBLE9BQU83QixDQUFQLEVBQVM7QUFDTEMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKOztBQUVELFdBQU9rQixPQUFQO0FBQ0gsR0FwR1U7O0FBcUdYLDJCQUF5QmQsT0FBekIsRUFBa0NvQixTQUFsQyxFQUE0QztBQUN4QyxRQUFJN0IsR0FBRyxpQ0FBMEJTLE9BQTFCLDBCQUFpRG9CLFNBQWpELENBQVA7QUFDQSxRQUFJTCxXQUFXLEdBQUd6QixZQUFZLENBQUNDLEdBQUQsQ0FBOUI7QUFDQXdCLGVBQVcsR0FBR0EsV0FBVyxJQUFJQSxXQUFXLENBQUNhLElBQVosQ0FBaUJyQixNQUE5QztBQUNBLFFBQUlRLFdBQVcsSUFBSUEsV0FBVyxDQUFDYyxNQUEvQixFQUNJZCxXQUFXLENBQUNjLE1BQVosR0FBcUJDLFVBQVUsQ0FBQ2YsV0FBVyxDQUFDYyxNQUFiLENBQS9CO0FBRUp0QyxPQUFHLDhDQUF1Q1MsT0FBdkMsMkJBQStEb0IsU0FBL0QsQ0FBSDtBQUNBLFFBQUlXLFdBQVcsR0FBR3pDLFlBQVksQ0FBQ0MsR0FBRCxDQUE5QjtBQUNBd0MsZUFBVyxHQUFHQSxXQUFXLElBQUlBLFdBQVcsQ0FBQ0gsSUFBWixDQUFpQnJCLE1BQTlDO0FBQ0EsUUFBSXlCLGNBQUo7O0FBQ0EsUUFBSUQsV0FBSixFQUFpQjtBQUNiQSxpQkFBVyxDQUFDRSxPQUFaLENBQXFCQyxVQUFELElBQWdCO0FBQ2hDLFlBQUlDLE9BQU8sR0FBR0QsVUFBVSxDQUFDQyxPQUF6QjtBQUNBLFlBQUlDLElBQUksR0FBRyxJQUFJQyxJQUFKLENBQVNGLE9BQU8sQ0FBQ0EsT0FBTyxDQUFDVCxNQUFSLEdBQWUsQ0FBaEIsQ0FBUCxDQUEwQlksZUFBbkMsQ0FBWDtBQUNBLFlBQUksQ0FBQ04sY0FBRCxJQUFtQkksSUFBSSxHQUFHSixjQUE5QixFQUNJQSxjQUFjLEdBQUdJLElBQWpCO0FBQ1AsT0FMRDtBQU1BckIsaUJBQVcsQ0FBQ3dCLDBCQUFaLEdBQXlDUCxjQUF6QztBQUNIOztBQUVEekMsT0FBRyxpQ0FBMEJTLE9BQTFCLG9DQUEyRG9CLFNBQTNELENBQUg7QUFDQSxRQUFJb0IsYUFBYSxHQUFHbEQsWUFBWSxDQUFDQyxHQUFELENBQWhDO0FBQ0FpRCxpQkFBYSxHQUFHQSxhQUFhLElBQUlBLGFBQWEsQ0FBQ1osSUFBZCxDQUFtQnJCLE1BQXBEOztBQUNBLFFBQUlpQyxhQUFKLEVBQW1CO0FBQ2Z6QixpQkFBVyxDQUFDQyxTQUFaLEdBQXdCd0IsYUFBYSxDQUFDTCxPQUFkLENBQXNCVCxNQUE5QztBQUNBWCxpQkFBVyxDQUFDMEIsdUJBQVosR0FBc0NELGFBQWEsQ0FBQ0wsT0FBZCxDQUFzQixDQUF0QixFQUF5QkcsZUFBL0Q7QUFDSDs7QUFDRCxXQUFPdkIsV0FBUDtBQUNILEdBbElVOztBQW1JWCwrQkFBNkJmLE9BQTdCLEVBQXFDO0FBQ2pDLFFBQUlULEdBQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyxjQUEvQzs7QUFFQSxRQUFHO0FBQ0MsVUFBSWUsV0FBVyxHQUFHM0IsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBbEI7O0FBQ0EsVUFBSXdCLFdBQVcsQ0FBQ3BCLFVBQVosSUFBMEIsR0FBOUIsRUFBa0M7QUFDOUJvQixtQkFBVyxHQUFHWCxJQUFJLENBQUNDLEtBQUwsQ0FBV1UsV0FBVyxDQUFDVCxPQUF2QixFQUFnQ0MsTUFBOUM7O0FBQ0EsWUFBSVEsV0FBVyxJQUFJQSxXQUFXLENBQUNXLE1BQVosR0FBcUIsQ0FBeEMsRUFBMEM7QUFDdENYLHFCQUFXLENBQUNrQixPQUFaLENBQW9CLENBQUNTLFVBQUQsRUFBYUMsQ0FBYixLQUFtQjtBQUNuQyxnQkFBSTVCLFdBQVcsQ0FBQzRCLENBQUQsQ0FBWCxJQUFrQjVCLFdBQVcsQ0FBQzRCLENBQUQsQ0FBWCxDQUFlZCxNQUFyQyxFQUNJZCxXQUFXLENBQUM0QixDQUFELENBQVgsQ0FBZWQsTUFBZixHQUF3QkMsVUFBVSxDQUFDZixXQUFXLENBQUM0QixDQUFELENBQVgsQ0FBZWQsTUFBaEIsQ0FBbEM7QUFDUCxXQUhEO0FBSUg7O0FBRUQsZUFBT2QsV0FBUDtBQUNIOztBQUFBO0FBQ0osS0FiRCxDQWNBLE9BQU9uQixDQUFQLEVBQVM7QUFDTEMsYUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLEdBdkpVOztBQXdKWCw4QkFBNEJJLE9BQTVCLEVBQW9DO0FBQ2hDLFFBQUlULEdBQUcsR0FBR0csR0FBRyxHQUFHLHNCQUFOLEdBQTZCTSxPQUE3QixHQUFxQyx3QkFBL0M7O0FBRUEsUUFBRztBQUNDLFVBQUk0QyxVQUFVLEdBQUd4RCxJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFqQjs7QUFDQSxVQUFJcUQsVUFBVSxDQUFDakQsVUFBWCxJQUF5QixHQUE3QixFQUFpQztBQUM3QmlELGtCQUFVLEdBQUd4QyxJQUFJLENBQUNDLEtBQUwsQ0FBV3VDLFVBQVUsQ0FBQ3RDLE9BQXRCLEVBQStCQyxNQUE1QztBQUNBLGVBQU9xQyxVQUFQO0FBQ0g7O0FBQUE7QUFDSixLQU5ELENBT0EsT0FBT2hELENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0FyS1U7O0FBc0tYLGlDQUErQkksT0FBL0IsRUFBd0NvQixTQUF4QyxFQUFrRDtBQUM5QyxRQUFJN0IsR0FBRyw4Q0FBdUNTLE9BQXZDLDZCQUFpRW9CLFNBQWpFLENBQVA7QUFDQSxRQUFJYixNQUFNLEdBQUdqQixZQUFZLENBQUNDLEdBQUQsQ0FBekI7O0FBQ0EsUUFBSWdCLE1BQU0sSUFBSUEsTUFBTSxDQUFDcUIsSUFBckIsRUFBMkI7QUFDdkIsVUFBSWlCLGFBQWEsR0FBRyxFQUFwQjtBQUNBdEMsWUFBTSxDQUFDcUIsSUFBUCxDQUFZSyxPQUFaLENBQXFCYSxZQUFELElBQWtCO0FBQ2xDLFlBQUlYLE9BQU8sR0FBR1csWUFBWSxDQUFDWCxPQUEzQjtBQUNBVSxxQkFBYSxDQUFDQyxZQUFZLENBQUNDLHFCQUFkLENBQWIsR0FBb0Q7QUFDaERDLGVBQUssRUFBRWIsT0FBTyxDQUFDVCxNQURpQztBQUVoRE0sd0JBQWMsRUFBRUcsT0FBTyxDQUFDLENBQUQsQ0FBUCxDQUFXRztBQUZxQixTQUFwRDtBQUlILE9BTkQ7QUFPQSxhQUFPTyxhQUFQO0FBQ0g7QUFDSjs7QUFwTFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBLElBQUk3RCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFBK0MsSUFBSThELE9BQUo7QUFBWWhFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdCQUFaLEVBQTZCO0FBQUMrRCxTQUFPLENBQUM5RCxDQUFELEVBQUc7QUFBQzhELFdBQU8sR0FBQzlELENBQVI7QUFBVTs7QUFBdEIsQ0FBN0IsRUFBcUQsQ0FBckQ7QUFBd0QsSUFBSStELFNBQUo7QUFBY2pFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtCQUFaLEVBQTRDO0FBQUNnRSxXQUFTLENBQUMvRCxDQUFELEVBQUc7QUFBQytELGFBQVMsR0FBQy9ELENBQVY7QUFBWTs7QUFBMUIsQ0FBNUMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSWdFLEtBQUo7QUFBVWxFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNpRSxPQUFLLENBQUNoRSxDQUFELEVBQUc7QUFBQ2dFLFNBQUssR0FBQ2hFLENBQU47QUFBUTs7QUFBbEIsQ0FBMUMsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSWlFLGFBQUo7QUFBa0JuRSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQ0FBWixFQUE0RDtBQUFDa0UsZUFBYSxDQUFDakUsQ0FBRCxFQUFHO0FBQUNpRSxpQkFBYSxHQUFDakUsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBNUQsRUFBZ0csQ0FBaEc7QUFBbUcsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSx1Q0FBWixFQUFvRDtBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBcEQsRUFBa0YsQ0FBbEY7QUFBcUYsSUFBSWtFLGdCQUFKLEVBQXFCQyxTQUFyQixFQUErQkMsZUFBL0I7QUFBK0N0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxpQ0FBWixFQUE4QztBQUFDbUUsa0JBQWdCLENBQUNsRSxDQUFELEVBQUc7QUFBQ2tFLG9CQUFnQixHQUFDbEUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDbUUsV0FBUyxDQUFDbkUsQ0FBRCxFQUFHO0FBQUNtRSxhQUFTLEdBQUNuRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1Fb0UsaUJBQWUsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0UsbUJBQWUsR0FBQ3BFLENBQWhCO0FBQWtCOztBQUF4RyxDQUE5QyxFQUF3SixDQUF4SjtBQUEySixJQUFJcUUsa0JBQUo7QUFBdUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxzQ0FBWixFQUFtRDtBQUFDc0Usb0JBQWtCLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLHNCQUFrQixHQUFDckUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQW5ELEVBQWlHLENBQWpHO0FBQW9HLElBQUlzRSxZQUFKO0FBQWlCeEUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3VFLGNBQVksQ0FBQ3RFLENBQUQsRUFBRztBQUFDc0UsZ0JBQVksR0FBQ3RFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSXVFLFNBQUo7QUFBY3pFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDhCQUFaLEVBQTJDO0FBQUN3RSxXQUFTLENBQUN2RSxDQUFELEVBQUc7QUFBQ3VFLGFBQVMsR0FBQ3ZFLENBQVY7QUFBWTs7QUFBMUIsQ0FBM0MsRUFBdUUsRUFBdkU7QUFBMkUsSUFBSXdFLE1BQUo7QUFBVzFFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ3lFLFFBQU0sQ0FBQ3hFLENBQUQsRUFBRztBQUFDd0UsVUFBTSxHQUFDeEUsQ0FBUDtBQUFTOztBQUFwQixDQUF4QixFQUE4QyxFQUE5QztBQUFrRCxJQUFJeUUsVUFBSjtBQUFlM0UsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQzBFLFlBQVUsQ0FBQ3pFLENBQUQsRUFBRztBQUFDeUUsY0FBVSxHQUFDekUsQ0FBWDtBQUFhOztBQUE1QixDQUFwQyxFQUFrRSxFQUFsRTtBQUFzRSxJQUFJMEUsT0FBSjtBQUFZNUUsTUFBTSxDQUFDQyxJQUFQLENBQVksU0FBWixFQUFzQjtBQUFDLE1BQUlDLENBQUosRUFBTTtBQUFDMEUsV0FBTyxHQUFDMUUsQ0FBUjtBQUFVOztBQUFsQixDQUF0QixFQUEwQyxFQUExQzs7QUFlNXRDO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTJFLG9CQUFvQixHQUFHLENBQUNDLGNBQUQsRUFBaUJDLFVBQWpCLEtBQWdDO0FBQ25EO0FBQ0EsT0FBS0MsQ0FBTCxJQUFVRixjQUFWLEVBQXlCO0FBQ3JCLFNBQUs1RSxDQUFMLElBQVU2RSxVQUFWLEVBQXFCO0FBQ2pCLFVBQUlELGNBQWMsQ0FBQ0UsQ0FBRCxDQUFkLENBQWtCakUsT0FBbEIsSUFBNkJnRSxVQUFVLENBQUM3RSxDQUFELENBQVYsQ0FBY2EsT0FBL0MsRUFBdUQ7QUFDbkQrRCxzQkFBYyxDQUFDRyxNQUFmLENBQXNCRCxDQUF0QixFQUF3QixDQUF4QjtBQUNIO0FBQ0o7QUFDSjs7QUFFRCxTQUFPRixjQUFQO0FBQ0gsQ0FYRDs7QUFhQUksc0JBQXNCLEdBQUlDLFFBQUQsSUFBYztBQUNuQyxNQUFJQSxRQUFRLENBQUMxQyxNQUFULElBQW1CLEVBQXZCLEVBQTBCO0FBQ3RCLFFBQUl2QixRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxvRUFBcUUyRSxRQUFyRSxzQkFBZjs7QUFDQSxRQUFJakUsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQWdDO0FBQzVCLFVBQUkwRSxJQUFJLEdBQUdsRSxRQUFRLENBQUN5QixJQUFULENBQWN5QyxJQUF6QjtBQUNBLGFBQU9BLElBQUksSUFBSUEsSUFBSSxDQUFDM0MsTUFBYixJQUF1QjJDLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUUMsUUFBL0IsSUFBMkNELElBQUksQ0FBQyxDQUFELENBQUosQ0FBUUMsUUFBUixDQUFpQkMsT0FBNUQsSUFBdUVGLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUUMsUUFBUixDQUFpQkMsT0FBakIsQ0FBeUJoRixHQUF2RztBQUNILEtBSEQsTUFHTztBQUNITSxhQUFPLENBQUNDLEdBQVIsQ0FBWU0sSUFBSSxDQUFDb0UsU0FBTCxDQUFlckUsUUFBZixDQUFaO0FBQ0g7QUFDSixHQVJELE1BUU8sSUFBSWlFLFFBQVEsQ0FBQ0ssT0FBVCxDQUFpQixrQkFBakIsSUFBcUMsQ0FBekMsRUFBMkM7QUFDOUMsUUFBSUMsUUFBUSxHQUFHdEYsSUFBSSxDQUFDSyxHQUFMLENBQVMyRSxRQUFULENBQWY7O0FBQ0EsUUFBSU0sUUFBUSxDQUFDL0UsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixVQUFJZ0YsSUFBSSxHQUFHZCxPQUFPLENBQUNlLElBQVIsQ0FBYUYsUUFBUSxDQUFDcEUsT0FBdEIsQ0FBWDtBQUNBLGFBQU9xRSxJQUFJLENBQUMsbUJBQUQsQ0FBSixDQUEwQkUsSUFBMUIsQ0FBK0IsS0FBL0IsQ0FBUDtBQUNILEtBSEQsTUFHTztBQUNIaEYsYUFBTyxDQUFDQyxHQUFSLENBQVlNLElBQUksQ0FBQ29FLFNBQUwsQ0FBZUUsUUFBZixDQUFaO0FBQ0g7QUFDSjtBQUNKLENBbEJELEMsQ0FvQkE7QUFDQTs7O0FBRUExRixNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLDRCQUEwQkMsT0FBMUIsRUFBa0M7QUFDOUIsUUFBSThFLE1BQU0sR0FBRzVCLFNBQVMsQ0FBQzZCLElBQVYsQ0FBZTtBQUFDQyxxQkFBZSxFQUFDaEY7QUFBakIsS0FBZixFQUEwQ2lGLEtBQTFDLEVBQWI7QUFDQSxRQUFJQyxPQUFPLEdBQUdKLE1BQU0sQ0FBQ0ssR0FBUCxDQUFXLENBQUNDLEtBQUQsRUFBUXpDLENBQVIsS0FBYztBQUNuQyxhQUFPeUMsS0FBSyxDQUFDQyxNQUFiO0FBQ0gsS0FGYSxDQUFkO0FBR0EsUUFBSUMsV0FBVyxHQUFHaEMsU0FBUyxDQUFDeUIsSUFBVixDQUFlO0FBQUNNLFlBQU0sRUFBQztBQUFDRSxXQUFHLEVBQUNMO0FBQUw7QUFBUixLQUFmLEVBQXVDRCxLQUF2QyxFQUFsQixDQUw4QixDQU05Qjs7QUFFQSxRQUFJTyxjQUFjLEdBQUcsQ0FBckI7O0FBQ0EsU0FBS0MsQ0FBTCxJQUFVSCxXQUFWLEVBQXNCO0FBQ2xCRSxvQkFBYyxJQUFJRixXQUFXLENBQUNHLENBQUQsQ0FBWCxDQUFlQyxRQUFqQztBQUNIOztBQUNELFdBQU9GLGNBQWMsR0FBQ04sT0FBTyxDQUFDeEQsTUFBOUI7QUFDSCxHQWRVOztBQWVYLHNCQUFvQjFCLE9BQXBCLEVBQTRCO0FBQ3hCLFFBQUkyRixVQUFVLEdBQUd0QyxnQkFBZ0IsQ0FBQ3VDLGFBQWpCLEVBQWpCLENBRHdCLENBRXhCOztBQUNBLFFBQUlDLFFBQVEsR0FBRyxDQUNYO0FBQUNDLFlBQU0sRUFBQztBQUFDLG1CQUFVOUY7QUFBWDtBQUFSLEtBRFcsRUFFWDtBQUNBO0FBQUMrRixXQUFLLEVBQUM7QUFBQyxrQkFBUyxDQUFDO0FBQVg7QUFBUCxLQUhXLEVBSVg7QUFBQ0MsWUFBTSxFQUFFaEgsTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJDLFlBQXZCLEdBQW9DO0FBQTdDLEtBSlcsRUFLWDtBQUFDQyxhQUFPLEVBQUU7QUFBVixLQUxXLEVBTVg7QUFBQ0MsWUFBTSxFQUFDO0FBQ0osZUFBTyxVQURIO0FBRUosa0JBQVU7QUFDTixrQkFBTztBQUNIQyxpQkFBSyxFQUFFLENBQUM7QUFBQ0MsaUJBQUcsRUFBRSxDQUFDLFNBQUQsRUFBWSxJQUFaO0FBQU4sYUFBRCxFQUEyQixDQUEzQixFQUE4QixDQUE5QjtBQURKO0FBREQ7QUFGTjtBQUFSLEtBTlcsQ0FBZixDQUh3QixDQWtCeEI7O0FBRUEsV0FBT3RELE9BQU8sQ0FBQ3VELEtBQVIsQ0FBY2IsVUFBVSxDQUFDYyxTQUFYLENBQXFCWixRQUFyQixFQUErQmEsT0FBL0IsRUFBZCxDQUFQLENBcEJ3QixDQXFCeEI7QUFDSCxHQXJDVTs7QUFzQ1gsNEJBQTBCLFlBQVc7QUFDakMsU0FBS3pHLE9BQUw7QUFDQSxRQUFJVixHQUFHLEdBQUdvSCxHQUFHLEdBQUMsU0FBZDs7QUFDQSxRQUFHO0FBQ0MsVUFBSXhHLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLFVBQUlxSCxNQUFNLEdBQUd4RyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFiO0FBQ0EsYUFBUXNHLE1BQU0sQ0FBQ3JHLE1BQVAsQ0FBY3NHLFNBQWQsQ0FBd0JDLG1CQUFoQztBQUNILEtBSkQsQ0FLQSxPQUFPbEgsQ0FBUCxFQUFTO0FBQ0wsYUFBTyxDQUFQO0FBQ0g7QUFDSixHQWpEVTtBQWtEWCw2QkFBMkIsWUFBVztBQUNsQyxTQUFLSyxPQUFMO0FBQ0EsUUFBSThHLFVBQVUsR0FBRzdELFNBQVMsQ0FBQzZCLElBQVYsQ0FBZSxFQUFmLEVBQWtCO0FBQUNpQyxVQUFJLEVBQUM7QUFBQzNCLGNBQU0sRUFBQyxDQUFDO0FBQVQsT0FBTjtBQUFrQjRCLFdBQUssRUFBQztBQUF4QixLQUFsQixFQUE4Q2hDLEtBQTlDLEVBQWpCLENBRmtDLENBR2xDOztBQUNBLFFBQUlpQyxXQUFXLEdBQUdsSSxNQUFNLENBQUNpSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJELFdBQXpDOztBQUNBLFFBQUlILFVBQVUsSUFBSUEsVUFBVSxDQUFDckYsTUFBWCxJQUFxQixDQUF2QyxFQUEwQztBQUN0QyxVQUFJMkQsTUFBTSxHQUFHMEIsVUFBVSxDQUFDLENBQUQsQ0FBVixDQUFjMUIsTUFBM0I7QUFDQSxVQUFJQSxNQUFNLEdBQUc2QixXQUFiLEVBQ0ksT0FBTzdCLE1BQVA7QUFDUDs7QUFDRCxXQUFPNkIsV0FBUDtBQUNILEdBN0RVO0FBOERYLHlCQUF1QixZQUFXO0FBQzlCLFFBQUlFLE9BQUosRUFDSSxPQUFPLFlBQVAsQ0FESixLQUVLdkgsT0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWixFQUh5QixDQUk5QjtBQUNBOztBQUNBLFFBQUl1SCxLQUFLLEdBQUdySSxNQUFNLENBQUNzSSxJQUFQLENBQVksd0JBQVosQ0FBWixDQU44QixDQU85QjtBQUNBOztBQUNBLFFBQUlDLElBQUksR0FBR3ZJLE1BQU0sQ0FBQ3NJLElBQVAsQ0FBWSx5QkFBWixDQUFYO0FBQ0F6SCxXQUFPLENBQUNDLEdBQVIsQ0FBWXlILElBQVosRUFWOEIsQ0FXOUI7O0FBQ0EsUUFBSUYsS0FBSyxHQUFHRSxJQUFaLEVBQWtCO0FBQ2RILGFBQU8sR0FBRyxJQUFWO0FBRUEsVUFBSUksWUFBWSxHQUFHLEVBQW5CLENBSGMsQ0FJZDs7QUFDQWpJLFNBQUcsR0FBR0csR0FBRyxHQUFDLHFCQUFWOztBQUVBLFVBQUc7QUFDQ1MsZ0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBYSxZQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBN0IsQ0FBb0MwQixPQUFwQyxDQUE2Q2IsU0FBRCxJQUFlb0csWUFBWSxDQUFDcEcsU0FBUyxDQUFDcUcsZ0JBQVgsQ0FBWixHQUEyQ3JHLFNBQXRHO0FBQ0gsT0FIRCxDQUlBLE9BQU14QixDQUFOLEVBQVE7QUFDSkMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFFREwsU0FBRyxHQUFHRyxHQUFHLEdBQUMsc0NBQVY7O0FBRUEsVUFBRztBQUNDUyxnQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FhLFlBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE3QixDQUFvQzBCLE9BQXBDLENBQTZDYixTQUFELElBQWVvRyxZQUFZLENBQUNwRyxTQUFTLENBQUNxRyxnQkFBWCxDQUFaLEdBQTJDckcsU0FBdEc7QUFDSCxPQUhELENBSUEsT0FBTXhCLENBQU4sRUFBUTtBQUNKQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVETCxTQUFHLEdBQUdHLEdBQUcsR0FBQyxxQ0FBVjs7QUFFQSxVQUFHO0FBQ0NTLGdCQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQWEsWUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTdCLENBQW9DMEIsT0FBcEMsQ0FBNkNiLFNBQUQsSUFBZW9HLFlBQVksQ0FBQ3BHLFNBQVMsQ0FBQ3FHLGdCQUFYLENBQVosR0FBMkNyRyxTQUF0RztBQUNILE9BSEQsQ0FJQSxPQUFNeEIsQ0FBTixFQUFRO0FBQ0pDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBQ0QsVUFBSThILGVBQWUsR0FBR0MsTUFBTSxDQUFDQyxJQUFQLENBQVlKLFlBQVosRUFBMEI5RixNQUFoRDtBQUNBN0IsYUFBTyxDQUFDQyxHQUFSLENBQVkscUJBQW9CNEgsZUFBaEM7O0FBQ0EsV0FBSyxJQUFJckMsTUFBTSxHQUFHa0MsSUFBSSxHQUFDLENBQXZCLEVBQTJCbEMsTUFBTSxJQUFJZ0MsS0FBckMsRUFBNkNoQyxNQUFNLEVBQW5ELEVBQXVEO0FBQ25ELFlBQUl3QyxjQUFjLEdBQUcsSUFBSXhGLElBQUosRUFBckIsQ0FEbUQsQ0FFbkQ7O0FBQ0EsYUFBS3BDLE9BQUw7QUFDQSxZQUFJVixHQUFHLEdBQUdvSCxHQUFHLEdBQUMsZ0JBQUosR0FBdUJ0QixNQUFqQztBQUNBLFlBQUl5QyxhQUFhLEdBQUcsRUFBcEI7QUFFQWpJLGVBQU8sQ0FBQ0MsR0FBUixDQUFZUCxHQUFaOztBQUNBLFlBQUc7QUFDQyxnQkFBTXdJLGNBQWMsR0FBRzFJLFVBQVUsQ0FBQ3VHLGFBQVgsR0FBMkJvQyx5QkFBM0IsRUFBdkI7QUFDQSxnQkFBTUMsb0JBQW9CLEdBQUc1RSxnQkFBZ0IsQ0FBQ3VDLGFBQWpCLEdBQWlDb0MseUJBQWpDLEVBQTdCO0FBQ0EsZ0JBQU1FLGFBQWEsR0FBRzFFLGtCQUFrQixDQUFDb0MsYUFBbkIsR0FBbUNvQyx5QkFBbkMsRUFBdEI7QUFDQSxnQkFBTUcsZUFBZSxHQUFHMUUsWUFBWSxDQUFDbUMsYUFBYixHQUE2Qm9DLHlCQUE3QixFQUF4QjtBQUVBLGNBQUlJLGtCQUFrQixHQUFHLElBQUkvRixJQUFKLEVBQXpCO0FBQ0EsY0FBSWxDLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjs7QUFDQSxjQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsZ0JBQUl5RixLQUFLLEdBQUdoRixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFaO0FBQ0E4RSxpQkFBSyxHQUFHQSxLQUFLLENBQUM3RSxNQUFkLENBRjJCLENBRzNCOztBQUNBLGdCQUFJOEgsU0FBUyxHQUFHLEVBQWhCO0FBQ0FBLHFCQUFTLENBQUNoRCxNQUFWLEdBQW1CQSxNQUFuQjtBQUNBZ0QscUJBQVMsQ0FBQ0MsSUFBVixHQUFpQmxELEtBQUssQ0FBQ21ELFVBQU4sQ0FBaUJDLFFBQWpCLENBQTBCRixJQUEzQztBQUNBRCxxQkFBUyxDQUFDSSxRQUFWLEdBQXFCckQsS0FBSyxDQUFDbUQsVUFBTixDQUFpQkcsTUFBakIsQ0FBd0JDLE9BQTdDO0FBQ0FOLHFCQUFTLENBQUNqRyxJQUFWLEdBQWlCLElBQUlDLElBQUosQ0FBUytDLEtBQUssQ0FBQ0EsS0FBTixDQUFZc0QsTUFBWixDQUFtQnRHLElBQTVCLENBQWpCO0FBQ0FpRyxxQkFBUyxDQUFDTyxhQUFWLEdBQTBCeEQsS0FBSyxDQUFDQSxLQUFOLENBQVlzRCxNQUFaLENBQW1CRyxhQUFuQixDQUFpQ1AsSUFBM0Q7QUFDQUQscUJBQVMsQ0FBQ3JELGVBQVYsR0FBNEJJLEtBQUssQ0FBQ0EsS0FBTixDQUFZc0QsTUFBWixDQUFtQkksZ0JBQS9DO0FBQ0FULHFCQUFTLENBQUNyRSxVQUFWLEdBQXVCLEVBQXZCO0FBQ0EsZ0JBQUkrRSxVQUFVLEdBQUczRCxLQUFLLENBQUNBLEtBQU4sQ0FBWTRELFdBQVosQ0FBd0JELFVBQXpDOztBQUNBLGdCQUFJQSxVQUFVLElBQUksSUFBbEIsRUFBdUI7QUFDbkI7QUFDQSxtQkFBSyxJQUFJcEcsQ0FBQyxHQUFDLENBQVgsRUFBY0EsQ0FBQyxHQUFDb0csVUFBVSxDQUFDckgsTUFBM0IsRUFBbUNpQixDQUFDLEVBQXBDLEVBQXVDO0FBQ25DLG9CQUFJb0csVUFBVSxDQUFDcEcsQ0FBRCxDQUFWLElBQWlCLElBQXJCLEVBQTBCO0FBQ3RCMEYsMkJBQVMsQ0FBQ3JFLFVBQVYsQ0FBcUJpRixJQUFyQixDQUEwQkYsVUFBVSxDQUFDcEcsQ0FBRCxDQUFWLENBQWN1RyxpQkFBeEM7QUFDSDtBQUNKOztBQUVEcEIsMkJBQWEsQ0FBQ2lCLFVBQWQsR0FBMkJBLFVBQVUsQ0FBQ3JILE1BQXRDLENBUm1CLENBU25CO0FBQ0E7QUFDSCxhQXhCMEIsQ0EwQjNCOzs7QUFDQSxnQkFBSTBELEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQnVILEdBQWpCLElBQXdCL0QsS0FBSyxDQUFDQSxLQUFOLENBQVl4RCxJQUFaLENBQWlCdUgsR0FBakIsQ0FBcUJ6SCxNQUFyQixHQUE4QixDQUExRCxFQUE0RDtBQUN4RCxtQkFBSzBILENBQUwsSUFBVWhFLEtBQUssQ0FBQ0EsS0FBTixDQUFZeEQsSUFBWixDQUFpQnVILEdBQTNCLEVBQStCO0FBQzNCbkssc0JBQU0sQ0FBQ3NJLElBQVAsQ0FBWSxvQkFBWixFQUFrQzNELE1BQU0sQ0FBQzBGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZbEUsS0FBSyxDQUFDQSxLQUFOLENBQVl4RCxJQUFaLENBQWlCdUgsR0FBakIsQ0FBcUJDLENBQXJCLENBQVosRUFBcUMsUUFBckMsQ0FBRCxDQUF4QyxFQUEwRmYsU0FBUyxDQUFDakcsSUFBcEcsRUFBMEcsQ0FBQ21ILEdBQUQsRUFBTWhKLE1BQU4sS0FBaUI7QUFDdkgsc0JBQUlnSixHQUFKLEVBQVE7QUFDSjFKLDJCQUFPLENBQUNDLEdBQVIsQ0FBWXlKLEdBQVo7QUFDSDtBQUNKLGlCQUpEO0FBS0g7QUFDSixhQW5DMEIsQ0FxQzNCOzs7QUFDQSxnQkFBSW5FLEtBQUssQ0FBQ0EsS0FBTixDQUFZb0UsUUFBWixDQUFxQkEsUUFBekIsRUFBa0M7QUFDOUI5Rix1QkFBUyxDQUFDK0YsTUFBVixDQUFpQjtBQUNicEUsc0JBQU0sRUFBRUEsTUFESztBQUVibUUsd0JBQVEsRUFBRXBFLEtBQUssQ0FBQ0EsS0FBTixDQUFZb0UsUUFBWixDQUFxQkE7QUFGbEIsZUFBakI7QUFJSDs7QUFFRG5CLHFCQUFTLENBQUNxQixlQUFWLEdBQTRCckIsU0FBUyxDQUFDckUsVUFBVixDQUFxQnRDLE1BQWpEO0FBRUFvRyx5QkFBYSxDQUFDekMsTUFBZCxHQUF1QkEsTUFBdkI7QUFFQSxnQkFBSXNFLGdCQUFnQixHQUFHLElBQUl0SCxJQUFKLEVBQXZCO0FBQ0F4QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksc0JBQXFCLENBQUM2SixnQkFBZ0IsR0FBQ3ZCLGtCQUFsQixJQUFzQyxJQUEzRCxHQUFpRSxVQUE3RTtBQUdBLGdCQUFJd0Isc0JBQXNCLEdBQUcsSUFBSXZILElBQUosRUFBN0IsQ0FyRDJCLENBc0QzQjs7QUFDQTlDLGVBQUcsR0FBR29ILEdBQUcsR0FBQyxxQkFBSixHQUEwQnRCLE1BQWhDO0FBQ0FsRixvQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0FNLG1CQUFPLENBQUNDLEdBQVIsQ0FBWVAsR0FBWjtBQUNBLGdCQUFJeUUsVUFBVSxHQUFHNUQsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBakI7QUFDQTBELHNCQUFVLENBQUN6RCxNQUFYLENBQWtCc0osWUFBbEIsR0FBaUNDLFFBQVEsQ0FBQzlGLFVBQVUsQ0FBQ3pELE1BQVgsQ0FBa0JzSixZQUFuQixDQUF6QztBQUNBekcseUJBQWEsQ0FBQ3FHLE1BQWQsQ0FBcUJ6RixVQUFVLENBQUN6RCxNQUFoQztBQUVBOEgscUJBQVMsQ0FBQzBCLGVBQVYsR0FBNEIvRixVQUFVLENBQUN6RCxNQUFYLENBQWtCeUQsVUFBbEIsQ0FBNkJ0QyxNQUF6RDtBQUNBLGdCQUFJc0ksb0JBQW9CLEdBQUcsSUFBSTNILElBQUosRUFBM0I7QUFDQWEscUJBQVMsQ0FBQ3VHLE1BQVYsQ0FBaUJwQixTQUFqQjtBQUNBLGdCQUFJNEIsa0JBQWtCLEdBQUcsSUFBSTVILElBQUosRUFBekI7QUFDQXhDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBdUIsQ0FBQ21LLGtCQUFrQixHQUFDRCxvQkFBcEIsSUFBMEMsSUFBakUsR0FBdUUsVUFBbkYsRUFsRTJCLENBb0UzQjs7QUFDQSxnQkFBSUUsa0JBQWtCLEdBQUc3SyxVQUFVLENBQUMwRixJQUFYLENBQWdCO0FBQUMvRSxxQkFBTyxFQUFDO0FBQUNtSyx1QkFBTyxFQUFDO0FBQVQ7QUFBVCxhQUFoQixFQUEwQ2xGLEtBQTFDLEVBQXpCOztBQUVBLGdCQUFJSSxNQUFNLEdBQUcsQ0FBYixFQUFlO0FBQ1g7QUFDQTtBQUNBLG1CQUFLMUMsQ0FBTCxJQUFVcUIsVUFBVSxDQUFDekQsTUFBWCxDQUFrQnlELFVBQTVCLEVBQXVDO0FBQ25DLG9CQUFJaEUsT0FBTyxHQUFHZ0UsVUFBVSxDQUFDekQsTUFBWCxDQUFrQnlELFVBQWxCLENBQTZCckIsQ0FBN0IsRUFBZ0MzQyxPQUE5QztBQUNBLG9CQUFJb0ssTUFBTSxHQUFHO0FBQ1QvRSx3QkFBTSxFQUFFQSxNQURDO0FBRVRyRix5QkFBTyxFQUFFQSxPQUZBO0FBR1RxSyx3QkFBTSxFQUFFLEtBSEM7QUFJVEMsOEJBQVksRUFBRVIsUUFBUSxDQUFDOUYsVUFBVSxDQUFDekQsTUFBWCxDQUFrQnlELFVBQWxCLENBQTZCckIsQ0FBN0IsRUFBZ0MySCxZQUFqQyxDQUpiLENBSTJEOztBQUozRCxpQkFBYjs7QUFPQSxxQkFBS0MsQ0FBTCxJQUFVeEIsVUFBVixFQUFxQjtBQUNqQixzQkFBSUEsVUFBVSxDQUFDd0IsQ0FBRCxDQUFWLElBQWlCLElBQXJCLEVBQTBCO0FBQ3RCLHdCQUFJdkssT0FBTyxJQUFJK0ksVUFBVSxDQUFDd0IsQ0FBRCxDQUFWLENBQWNyQixpQkFBN0IsRUFBK0M7QUFDM0NrQiw0QkFBTSxDQUFDQyxNQUFQLEdBQWdCLElBQWhCO0FBQ0F0QixnQ0FBVSxDQUFDN0UsTUFBWCxDQUFrQnFHLENBQWxCLEVBQW9CLENBQXBCO0FBQ0E7QUFDSDtBQUNKO0FBQ0osaUJBakJrQyxDQW1CbkM7QUFDQTs7O0FBRUEsb0JBQUtsRixNQUFNLEdBQUcsRUFBVixJQUFpQixDQUFyQixFQUF1QjtBQUNuQjtBQUNBLHNCQUFJbUYsU0FBUyxHQUFHeEwsTUFBTSxDQUFDc0ksSUFBUCxDQUFZLG1CQUFaLEVBQWlDdEgsT0FBakMsQ0FBaEI7QUFDQSxzQkFBSXlLLE1BQU0sR0FBRyxDQUFiLENBSG1CLENBSW5CO0FBQ0E7O0FBQ0Esc0JBQUtELFNBQVMsQ0FBQyxDQUFELENBQVQsSUFBZ0IsSUFBakIsSUFBMkJBLFNBQVMsQ0FBQyxDQUFELENBQVQsQ0FBYUMsTUFBYixJQUF1QixJQUF0RCxFQUE0RDtBQUN4REEsMEJBQU0sR0FBR0QsU0FBUyxDQUFDLENBQUQsQ0FBVCxDQUFhQyxNQUF0QjtBQUNIOztBQUVELHNCQUFJQyxJQUFJLEdBQUcxTCxNQUFNLENBQUNpSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QkMsWUFBbEM7O0FBQ0Esc0JBQUlkLE1BQU0sR0FBR3FGLElBQWIsRUFBa0I7QUFDZEEsd0JBQUksR0FBR3JGLE1BQVA7QUFDSDs7QUFFRCxzQkFBSStFLE1BQU0sQ0FBQ0MsTUFBWCxFQUFrQjtBQUNkLHdCQUFJSSxNQUFNLEdBQUdDLElBQWIsRUFBa0I7QUFDZEQsNEJBQU07QUFDVDs7QUFDREEsMEJBQU0sR0FBSUEsTUFBTSxHQUFHQyxJQUFWLEdBQWdCLEdBQXpCO0FBQ0EzQyxrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDL0UsNkJBQU8sRUFBQ0E7QUFBVCxxQkFBcEIsRUFBdUMySyxNQUF2QyxHQUFnREMsU0FBaEQsQ0FBMEQ7QUFBQ0MsMEJBQUksRUFBQztBQUFDSiw4QkFBTSxFQUFDQSxNQUFSO0FBQWdCSyxnQ0FBUSxFQUFDekMsU0FBUyxDQUFDakc7QUFBbkM7QUFBTixxQkFBMUQ7QUFDSCxtQkFORCxNQU9JO0FBQ0FxSSwwQkFBTSxHQUFJQSxNQUFNLEdBQUdDLElBQVYsR0FBZ0IsR0FBekI7QUFDQTNDLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMvRSw2QkFBTyxFQUFDQTtBQUFULHFCQUFwQixFQUF1QzJLLE1BQXZDLEdBQWdEQyxTQUFoRCxDQUEwRDtBQUFDQywwQkFBSSxFQUFDO0FBQUNKLDhCQUFNLEVBQUNBO0FBQVI7QUFBTixxQkFBMUQ7QUFDSDtBQUNKOztBQUVEeEMsb0NBQW9CLENBQUN3QixNQUFyQixDQUE0QlcsTUFBNUIsRUFsRG1DLENBbURuQztBQUNIO0FBQ0o7O0FBRUQsZ0JBQUlXLFdBQVcsR0FBRzVILEtBQUssQ0FBQzlCLE9BQU4sQ0FBYztBQUFDMkoscUJBQU8sRUFBQzVGLEtBQUssQ0FBQ21ELFVBQU4sQ0FBaUJHLE1BQWpCLENBQXdCdUM7QUFBakMsYUFBZCxDQUFsQjtBQUNBLGdCQUFJQyxjQUFjLEdBQUdILFdBQVcsR0FBQ0EsV0FBVyxDQUFDRyxjQUFiLEdBQTRCLENBQTVEO0FBQ0EsZ0JBQUl4RixRQUFKO0FBQ0EsZ0JBQUl5RixTQUFTLEdBQUduTSxNQUFNLENBQUNpSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJpRSxnQkFBdkM7O0FBQ0EsZ0JBQUlGLGNBQUosRUFBbUI7QUFDZixrQkFBSUcsVUFBVSxHQUFHaEQsU0FBUyxDQUFDakcsSUFBM0I7QUFDQSxrQkFBSWtKLFFBQVEsR0FBRyxJQUFJakosSUFBSixDQUFTNkksY0FBVCxDQUFmO0FBQ0F4RixzQkFBUSxHQUFHNkYsSUFBSSxDQUFDQyxHQUFMLENBQVNILFVBQVUsQ0FBQ0ksT0FBWCxLQUF1QkgsUUFBUSxDQUFDRyxPQUFULEVBQWhDLENBQVg7QUFDQU4sdUJBQVMsR0FBRyxDQUFDSixXQUFXLENBQUNJLFNBQVosSUFBeUI5QyxTQUFTLENBQUNoRCxNQUFWLEdBQW1CLENBQTVDLElBQWlESyxRQUFsRCxJQUE4RDJDLFNBQVMsQ0FBQ2hELE1BQXBGO0FBQ0g7O0FBRUQsZ0JBQUlxRyxvQkFBb0IsR0FBRyxJQUFJckosSUFBSixFQUEzQjtBQUNBeEMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFnQyxDQUFDNEwsb0JBQW9CLEdBQUM5QixzQkFBdEIsSUFBOEMsSUFBOUUsR0FBb0YsVUFBaEc7QUFFQXpHLGlCQUFLLENBQUN3SSxNQUFOLENBQWE7QUFBQ1gscUJBQU8sRUFBQzVGLEtBQUssQ0FBQ21ELFVBQU4sQ0FBaUJHLE1BQWpCLENBQXdCdUM7QUFBakMsYUFBYixFQUF5RDtBQUFDSixrQkFBSSxFQUFDO0FBQUNLLDhCQUFjLEVBQUM3QyxTQUFTLENBQUNqRyxJQUExQjtBQUFnQytJLHlCQUFTLEVBQUNBO0FBQTFDO0FBQU4sYUFBekQ7QUFFQXJELHlCQUFhLENBQUM4RCxnQkFBZCxHQUFpQ1QsU0FBakM7QUFDQXJELHlCQUFhLENBQUNwQyxRQUFkLEdBQXlCQSxRQUF6QjtBQUVBb0MseUJBQWEsQ0FBQzFGLElBQWQsR0FBcUJpRyxTQUFTLENBQUNqRyxJQUEvQixDQXBKMkIsQ0FzSjNCO0FBQ0E7QUFDQTtBQUNBOztBQUVBMEYseUJBQWEsQ0FBQ3dDLFlBQWQsR0FBNkIsQ0FBN0I7QUFFQSxnQkFBSXVCLDJCQUEyQixHQUFHLElBQUl4SixJQUFKLEVBQWxDOztBQUNBLGdCQUFJMkIsVUFBVSxDQUFDekQsTUFBZixFQUFzQjtBQUNsQjtBQUNBVixxQkFBTyxDQUFDQyxHQUFSLENBQVksd0JBQXNCa0UsVUFBVSxDQUFDekQsTUFBWCxDQUFrQnlELFVBQWxCLENBQTZCdEMsTUFBL0Q7O0FBQ0EsbUJBQUt2QyxDQUFMLElBQVU2RSxVQUFVLENBQUN6RCxNQUFYLENBQWtCeUQsVUFBNUIsRUFBdUM7QUFDbkM7QUFDQSxvQkFBSTVDLFNBQVMsR0FBRzRDLFVBQVUsQ0FBQ3pELE1BQVgsQ0FBa0J5RCxVQUFsQixDQUE2QjdFLENBQTdCLENBQWhCO0FBQ0FpQyx5QkFBUyxDQUFDa0osWUFBVixHQUF5QlIsUUFBUSxDQUFDMUksU0FBUyxDQUFDa0osWUFBWCxDQUFqQztBQUNBbEoseUJBQVMsQ0FBQzBLLGlCQUFWLEdBQThCaEMsUUFBUSxDQUFDMUksU0FBUyxDQUFDMEssaUJBQVgsQ0FBdEM7QUFFQSxvQkFBSUMsUUFBUSxHQUFHMU0sVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDLG1DQUFnQkQsU0FBUyxDQUFDNEssT0FBVixDQUFrQnRMO0FBQW5DLGlCQUFuQixDQUFmOztBQUNBLG9CQUFJLENBQUNxTCxRQUFMLEVBQWM7QUFDVmxNLHlCQUFPLENBQUNDLEdBQVIsNkJBQWlDc0IsU0FBUyxDQUFDcEIsT0FBM0MsY0FBc0RvQixTQUFTLENBQUM0SyxPQUFWLENBQWtCdEwsS0FBeEUsaUJBRFUsQ0FFVjtBQUNBO0FBQ0E7O0FBRUFVLDJCQUFTLENBQUNwQixPQUFWLEdBQW9CNEQsVUFBVSxDQUFDeEMsU0FBUyxDQUFDNEssT0FBWCxDQUE5QjtBQUNBNUssMkJBQVMsQ0FBQzZLLE1BQVYsR0FBbUJqTixNQUFNLENBQUNzSSxJQUFQLENBQVksZ0JBQVosRUFBOEJsRyxTQUFTLENBQUM0SyxPQUF4QyxFQUFpRGhOLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ0csa0JBQXhFLENBQW5CO0FBQ0E5SywyQkFBUyxDQUFDK0ssZUFBVixHQUE0Qm5OLE1BQU0sQ0FBQ3NJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmxHLFNBQVMsQ0FBQzRLLE9BQXhDLEVBQWlEaE4sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJrRyxrQkFBeEUsQ0FBNUI7QUFDQWhMLDJCQUFTLENBQUNxRyxnQkFBVixHQUE2QnpJLE1BQU0sQ0FBQ3NJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmxHLFNBQVMsQ0FBQzRLLE9BQXhDLEVBQWlEaE4sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJtRyxtQkFBeEUsQ0FBN0I7QUFFQSxzQkFBSUMsYUFBYSxHQUFHOUUsWUFBWSxDQUFDcEcsU0FBUyxDQUFDcUcsZ0JBQVgsQ0FBaEM7O0FBQ0Esc0JBQUk2RSxhQUFKLEVBQWtCO0FBQ2Qsd0JBQUlBLGFBQWEsQ0FBQ0MsV0FBZCxDQUEwQm5JLFFBQTlCLEVBQ0loRCxTQUFTLENBQUNvTCxXQUFWLEdBQXlCckksc0JBQXNCLENBQUNtSSxhQUFhLENBQUNDLFdBQWQsQ0FBMEJuSSxRQUEzQixDQUEvQztBQUNKaEQsNkJBQVMsQ0FBQ0csZ0JBQVYsR0FBNkIrSyxhQUFhLENBQUMvSyxnQkFBM0M7QUFDQUgsNkJBQVMsQ0FBQ0ksaUJBQVYsR0FBOEJ4QyxNQUFNLENBQUNzSSxJQUFQLENBQVksY0FBWixFQUE0QmdGLGFBQWEsQ0FBQy9LLGdCQUExQyxDQUE5QjtBQUNBSCw2QkFBUyxDQUFDcUwsTUFBVixHQUFtQkgsYUFBYSxDQUFDRyxNQUFqQztBQUNBckwsNkJBQVMsQ0FBQ3dGLE1BQVYsR0FBbUIwRixhQUFhLENBQUMxRixNQUFqQztBQUNBeEYsNkJBQVMsQ0FBQ3NMLG1CQUFWLEdBQWdDSixhQUFhLENBQUNJLG1CQUE5QztBQUNBdEwsNkJBQVMsQ0FBQ3VMLE1BQVYsR0FBbUJMLGFBQWEsQ0FBQ0ssTUFBakM7QUFDQXZMLDZCQUFTLENBQUN3TCxnQkFBVixHQUE2Qk4sYUFBYSxDQUFDTSxnQkFBM0M7QUFDQXhMLDZCQUFTLENBQUNtTCxXQUFWLEdBQXdCRCxhQUFhLENBQUNDLFdBQXRDO0FBQ0FuTCw2QkFBUyxDQUFDeUwsV0FBVixHQUF3QlAsYUFBYSxDQUFDTyxXQUF0QztBQUNBekwsNkJBQVMsQ0FBQzBMLHFCQUFWLEdBQWtDUixhQUFhLENBQUNRLHFCQUFoRDtBQUNBMUwsNkJBQVMsQ0FBQzJMLGdCQUFWLEdBQTZCVCxhQUFhLENBQUNTLGdCQUEzQztBQUNBM0wsNkJBQVMsQ0FBQzRMLGNBQVYsR0FBMkJWLGFBQWEsQ0FBQ1UsY0FBekM7QUFDQTVMLDZCQUFTLENBQUNPLFVBQVYsR0FBdUIySyxhQUFhLENBQUMzSyxVQUFyQztBQUNBUCw2QkFBUyxDQUFDNkwsZUFBVixHQUE0QjdMLFNBQVMsQ0FBQ3dMLGdCQUF0QyxDQWhCYyxDQWlCZDtBQUNBO0FBQ0E7QUFDSCxtQkFwQkQsTUFvQk87QUFDSC9NLDJCQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjtBQUNILG1CQWxDUyxDQW9DVjs7O0FBQ0FpSSxnQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDL0UsMkJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCO0FBQXBCLG1CQUFwQixFQUFrRDJLLE1BQWxELEdBQTJEQyxTQUEzRCxDQUFxRTtBQUFDQyx3QkFBSSxFQUFDeko7QUFBTixtQkFBckUsRUFyQ1UsQ0FzQ1Y7O0FBQ0E4RywrQkFBYSxDQUFDdUIsTUFBZCxDQUFxQjtBQUNqQnpKLDJCQUFPLEVBQUVvQixTQUFTLENBQUNwQixPQURGO0FBRWpCa04scUNBQWlCLEVBQUUsQ0FGRjtBQUdqQjVDLGdDQUFZLEVBQUVsSixTQUFTLENBQUNrSixZQUhQO0FBSWpCN0osd0JBQUksRUFBRSxLQUpXO0FBS2pCNEUsMEJBQU0sRUFBRWdELFNBQVMsQ0FBQ2hELE1BTEQ7QUFNakI4SCw4QkFBVSxFQUFFOUUsU0FBUyxDQUFDakc7QUFOTCxtQkFBckIsRUF2Q1UsQ0FnRFY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBO0FBQ0gsaUJBL0RELE1BZ0VJO0FBQ0Esc0JBQUlrSyxhQUFhLEdBQUc5RSxZQUFZLENBQUN1RSxRQUFRLENBQUN0RSxnQkFBVixDQUFoQzs7QUFDQSxzQkFBSTZFLGFBQUosRUFBa0I7QUFDZCx3QkFBSUEsYUFBYSxDQUFDQyxXQUFkLEtBQThCLENBQUNSLFFBQVEsQ0FBQ1EsV0FBVixJQUF5QkQsYUFBYSxDQUFDQyxXQUFkLENBQTBCbkksUUFBMUIsS0FBdUMySCxRQUFRLENBQUNRLFdBQVQsQ0FBcUJuSSxRQUFuSCxDQUFKLEVBQ0loRCxTQUFTLENBQUNvTCxXQUFWLEdBQXlCckksc0JBQXNCLENBQUNtSSxhQUFhLENBQUNDLFdBQWQsQ0FBMEJuSSxRQUEzQixDQUEvQztBQUNKaEQsNkJBQVMsQ0FBQ3FMLE1BQVYsR0FBbUJILGFBQWEsQ0FBQ0csTUFBakM7QUFDQXJMLDZCQUFTLENBQUN3RixNQUFWLEdBQW1CMEYsYUFBYSxDQUFDMUYsTUFBakM7QUFDQXhGLDZCQUFTLENBQUN1TCxNQUFWLEdBQW1CTCxhQUFhLENBQUNLLE1BQWpDO0FBQ0F2TCw2QkFBUyxDQUFDd0wsZ0JBQVYsR0FBNkJOLGFBQWEsQ0FBQ00sZ0JBQTNDO0FBQ0F4TCw2QkFBUyxDQUFDbUwsV0FBVixHQUF3QkQsYUFBYSxDQUFDQyxXQUF0QztBQUNBbkwsNkJBQVMsQ0FBQ3lMLFdBQVYsR0FBd0JQLGFBQWEsQ0FBQ08sV0FBdEM7QUFDQXpMLDZCQUFTLENBQUMwTCxxQkFBVixHQUFrQ1IsYUFBYSxDQUFDUSxxQkFBaEQ7QUFDQTFMLDZCQUFTLENBQUMyTCxnQkFBVixHQUE2QlQsYUFBYSxDQUFDUyxnQkFBM0M7QUFDQTNMLDZCQUFTLENBQUM0TCxjQUFWLEdBQTJCVixhQUFhLENBQUNVLGNBQXpDO0FBQ0E1TCw2QkFBUyxDQUFDTyxVQUFWLEdBQXVCMkssYUFBYSxDQUFDM0ssVUFBckMsQ0FaYyxDQWNkOztBQUVBLHdCQUFJMEQsTUFBTSxHQUFHLEVBQVQsSUFBZSxDQUFuQixFQUFxQjtBQUNqQiwwQkFBRztBQUNDLDRCQUFJbEYsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0MsR0FBRyxHQUFHLHNCQUFOLEdBQTZCcU0sUUFBUSxDQUFDdkssaUJBQXRDLEdBQXdELGVBQXhELEdBQXdFdUssUUFBUSxDQUFDeEssZ0JBQTFGLENBQWY7O0FBRUEsNEJBQUlwQixRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0IsOEJBQUl5TixjQUFjLEdBQUdoTixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBbEQ7O0FBQ0EsOEJBQUk2TSxjQUFjLENBQUN2TCxNQUFuQixFQUEwQjtBQUN0QlQscUNBQVMsQ0FBQzZMLGVBQVYsR0FBNEJuTCxVQUFVLENBQUNzTCxjQUFjLENBQUN2TCxNQUFoQixDQUFWLEdBQWtDQyxVQUFVLENBQUNWLFNBQVMsQ0FBQ3dMLGdCQUFYLENBQXhFO0FBQ0g7QUFDSjtBQUNKLHVCQVRELENBVUEsT0FBTWhOLENBQU4sRUFBUSxDQUNKO0FBQ0g7QUFDSjs7QUFFRG1JLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMwQyxzQ0FBZ0IsRUFBRXNFLFFBQVEsQ0FBQ3RFO0FBQTVCLHFCQUFwQixFQUFtRW1ELFNBQW5FLENBQTZFO0FBQUNDLDBCQUFJLEVBQUN6SjtBQUFOLHFCQUE3RSxFQWhDYyxDQWlDZDtBQUNBO0FBQ0gsbUJBbkNELE1BbUNRO0FBQ0p2QiwyQkFBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7QUFDSDs7QUFDRCxzQkFBSXVOLGVBQWUsR0FBRzdKLGtCQUFrQixDQUFDbkMsT0FBbkIsQ0FBMkI7QUFBQ3JCLDJCQUFPLEVBQUNvQixTQUFTLENBQUNwQjtBQUFuQixtQkFBM0IsRUFBd0Q7QUFBQ3FGLDBCQUFNLEVBQUMsQ0FBQyxDQUFUO0FBQVk0Qix5QkFBSyxFQUFDO0FBQWxCLG1CQUF4RCxDQUF0Qjs7QUFFQSxzQkFBSW9HLGVBQUosRUFBb0I7QUFDaEIsd0JBQUlBLGVBQWUsQ0FBQy9DLFlBQWhCLElBQWdDbEosU0FBUyxDQUFDa0osWUFBOUMsRUFBMkQ7QUFDdkQsMEJBQUlnRCxVQUFVLEdBQUlELGVBQWUsQ0FBQy9DLFlBQWhCLEdBQStCbEosU0FBUyxDQUFDa0osWUFBMUMsR0FBd0QsTUFBeEQsR0FBK0QsSUFBaEY7QUFDQSwwQkFBSWlELFVBQVUsR0FBRztBQUNidk4sK0JBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BRE47QUFFYmtOLHlDQUFpQixFQUFFRyxlQUFlLENBQUMvQyxZQUZ0QjtBQUdiQSxvQ0FBWSxFQUFFbEosU0FBUyxDQUFDa0osWUFIWDtBQUliN0osNEJBQUksRUFBRTZNLFVBSk87QUFLYmpJLDhCQUFNLEVBQUVnRCxTQUFTLENBQUNoRCxNQUxMO0FBTWI4SCxrQ0FBVSxFQUFFOUUsU0FBUyxDQUFDakc7QUFOVCx1QkFBakIsQ0FGdUQsQ0FVdkQ7QUFDQTs7QUFDQThGLG1DQUFhLENBQUN1QixNQUFkLENBQXFCOEQsVUFBckI7QUFDSDtBQUNKO0FBRUosaUJBbElrQyxDQXFJbkM7OztBQUVBekYsNkJBQWEsQ0FBQ3dDLFlBQWQsSUFBOEJsSixTQUFTLENBQUNrSixZQUF4QztBQUNILGVBM0lpQixDQTZJbEI7OztBQUVBLGtCQUFJdkcsY0FBYyxHQUFHWCxhQUFhLENBQUMvQixPQUFkLENBQXNCO0FBQUN3SSw0QkFBWSxFQUFDeEUsTUFBTSxHQUFDO0FBQXJCLGVBQXRCLENBQXJCOztBQUVBLGtCQUFJdEIsY0FBSixFQUFtQjtBQUNmLG9CQUFJeUosaUJBQWlCLEdBQUcxSixvQkFBb0IsQ0FBQ0MsY0FBYyxDQUFDQyxVQUFoQixFQUE0QkEsVUFBVSxDQUFDekQsTUFBWCxDQUFrQnlELFVBQTlDLENBQTVDOztBQUVBLHFCQUFLeUosQ0FBTCxJQUFVRCxpQkFBVixFQUE0QjtBQUN4QnRGLCtCQUFhLENBQUN1QixNQUFkLENBQXFCO0FBQ2pCekosMkJBQU8sRUFBRXdOLGlCQUFpQixDQUFDQyxDQUFELENBQWpCLENBQXFCek4sT0FEYjtBQUVqQmtOLHFDQUFpQixFQUFFTSxpQkFBaUIsQ0FBQ0MsQ0FBRCxDQUFqQixDQUFxQm5ELFlBRnZCO0FBR2pCQSxnQ0FBWSxFQUFFLENBSEc7QUFJakI3Six3QkFBSSxFQUFFLFFBSlc7QUFLakI0RSwwQkFBTSxFQUFFZ0QsU0FBUyxDQUFDaEQsTUFMRDtBQU1qQjhILDhCQUFVLEVBQUU5RSxTQUFTLENBQUNqRztBQU5MLG1CQUFyQjtBQVFIO0FBQ0o7QUFFSixhQTlUMEIsQ0FpVTNCOzs7QUFDQSxnQkFBSWlELE1BQU0sR0FBRyxLQUFULElBQWtCLENBQXRCLEVBQXdCO0FBQ3BCLGtCQUFJO0FBQ0F4Rix1QkFBTyxDQUFDQyxHQUFSLENBQVksdUNBQVo7QUFDQSxvQkFBSTROLFlBQVksR0FBRyxFQUFuQjtBQUNBck8sMEJBQVUsQ0FBQzBGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0I7QUFBQzRJLHdCQUFNLEVBQUU7QUFBQ2xHLG9DQUFnQixFQUFFLENBQW5CO0FBQXNCYiwwQkFBTSxFQUFFO0FBQTlCO0FBQVQsaUJBQXBCLEVBQ00zRSxPQUROLENBQ2U5QyxDQUFELElBQU91TyxZQUFZLENBQUN2TyxDQUFDLENBQUNzSSxnQkFBSCxDQUFaLEdBQW1DdEksQ0FBQyxDQUFDeUgsTUFEMUQ7QUFFQWUsc0JBQU0sQ0FBQ0MsSUFBUCxDQUFZSixZQUFaLEVBQTBCdkYsT0FBMUIsQ0FBbUMyTCxTQUFELElBQWU7QUFDN0Msc0JBQUl0QixhQUFhLEdBQUc5RSxZQUFZLENBQUNvRyxTQUFELENBQWhDLENBRDZDLENBRTdDOztBQUNBLHNCQUFJdEIsYUFBYSxDQUFDMUYsTUFBZCxLQUF5QixDQUE3QixFQUNJOztBQUVKLHNCQUFJOEcsWUFBWSxDQUFDRSxTQUFELENBQVosSUFBMkJDLFNBQS9CLEVBQTBDO0FBQ3RDaE8sMkJBQU8sQ0FBQ0MsR0FBUiwyQ0FBK0M4TixTQUEvQztBQUNBLHdCQUFJRSxVQUFVLEdBQUc5TyxNQUFNLENBQUNpSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZILFNBQXZCLEdBQWlDLDRCQUFqQyxHQUE4RCwwQkFBL0U7QUFDQXpCLGlDQUFhLENBQUNOLE9BQWQsR0FBd0I7QUFDcEIsOEJBQVM4QixVQURXO0FBRXBCLCtCQUFTOU8sTUFBTSxDQUFDc0ksSUFBUCxDQUFZLGdCQUFaLEVBQThCc0csU0FBOUI7QUFGVyxxQkFBeEI7QUFJQXRCLGlDQUFhLENBQUN0TSxPQUFkLEdBQXdCNEQsVUFBVSxDQUFDMEksYUFBYSxDQUFDTixPQUFmLENBQWxDO0FBQ0FNLGlDQUFhLENBQUM5SyxpQkFBZCxHQUFrQ3hDLE1BQU0sQ0FBQ3NJLElBQVAsQ0FBWSxjQUFaLEVBQTRCZ0YsYUFBYSxDQUFDL0ssZ0JBQTFDLENBQWxDO0FBRUErSyxpQ0FBYSxDQUFDTCxNQUFkLEdBQXVCak4sTUFBTSxDQUFDc0ksSUFBUCxDQUFZLGdCQUFaLEVBQThCZ0YsYUFBYSxDQUFDTixPQUE1QyxFQUFxRGhOLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCZ0csa0JBQTVFLENBQXZCO0FBQ0FJLGlDQUFhLENBQUNILGVBQWQsR0FBZ0NuTixNQUFNLENBQUNzSSxJQUFQLENBQVksZ0JBQVosRUFBOEJnRixhQUFhLENBQUNOLE9BQTVDLEVBQXFEaE4sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJrRyxrQkFBNUUsQ0FBaEM7QUFDQXZNLDJCQUFPLENBQUNDLEdBQVIsQ0FBWU0sSUFBSSxDQUFDb0UsU0FBTCxDQUFlOEgsYUFBZixDQUFaO0FBQ0F2RSxrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDMEMsc0NBQWdCLEVBQUVtRztBQUFuQixxQkFBcEIsRUFBbURqRCxNQUFuRCxHQUE0REMsU0FBNUQsQ0FBc0U7QUFBQ0MsMEJBQUksRUFBQ3lCO0FBQU4scUJBQXRFO0FBQ0gsbUJBZEQsTUFjTyxJQUFJb0IsWUFBWSxDQUFDRSxTQUFELENBQVosSUFBMkIsQ0FBL0IsRUFBa0M7QUFDckM3RixrQ0FBYyxDQUFDaEQsSUFBZixDQUFvQjtBQUFDMEMsc0NBQWdCLEVBQUVtRztBQUFuQixxQkFBcEIsRUFBbURqRCxNQUFuRCxHQUE0REMsU0FBNUQsQ0FBc0U7QUFBQ0MsMEJBQUksRUFBQ3lCO0FBQU4scUJBQXRFO0FBQ0g7QUFDSixpQkF2QkQ7QUF3QkgsZUE3QkQsQ0E2QkUsT0FBTzFNLENBQVAsRUFBUztBQUNQQyx1QkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKLGFBblcwQixDQXFXM0I7OztBQUNBLGdCQUFJeUYsTUFBTSxHQUFHLEtBQVQsSUFBa0IsQ0FBdEIsRUFBd0I7QUFDcEJ4RixxQkFBTyxDQUFDQyxHQUFSLENBQVkscUJBQVo7QUFDQVQsd0JBQVUsQ0FBQzBGLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0I5QyxPQUFwQixDQUE2QmIsU0FBRCxJQUFlO0FBQ3ZDLG9CQUFJO0FBQ0Esc0JBQUk0TSxVQUFVLEdBQUk3SixzQkFBc0IsQ0FBQy9DLFNBQVMsQ0FBQ21MLFdBQVYsQ0FBc0JuSSxRQUF2QixDQUF4Qzs7QUFDQSxzQkFBSTRKLFVBQUosRUFBZ0I7QUFDWmpHLGtDQUFjLENBQUNoRCxJQUFmLENBQW9CO0FBQUMvRSw2QkFBTyxFQUFFb0IsU0FBUyxDQUFDcEI7QUFBcEIscUJBQXBCLEVBQ00ySyxNQUROLEdBQ2VDLFNBRGYsQ0FDeUI7QUFBQ0MsMEJBQUksRUFBQztBQUFDLHVDQUFjbUQ7QUFBZjtBQUFOLHFCQUR6QjtBQUVIO0FBQ0osaUJBTkQsQ0FNRSxPQUFPcE8sQ0FBUCxFQUFVO0FBQ1JDLHlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osZUFWRDtBQVdIOztBQUVELGdCQUFJcU8seUJBQXlCLEdBQUcsSUFBSTVMLElBQUosRUFBaEM7QUFDQXhDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSwrQkFBOEIsQ0FBQ21PLHlCQUF5QixHQUFDcEMsMkJBQTNCLElBQXdELElBQXRGLEdBQTRGLFVBQXhHLEVBdFgyQixDQXdYM0I7O0FBQ0EsZ0JBQUlxQyx1QkFBdUIsR0FBRyxJQUFJN0wsSUFBSixFQUE5QjtBQUNBaUIscUJBQVMsQ0FBQ21HLE1BQVYsQ0FBaUIzQixhQUFqQjtBQUNBLGdCQUFJcUcsc0JBQXNCLEdBQUcsSUFBSTlMLElBQUosRUFBN0I7QUFDQXhDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBMkIsQ0FBQ3FPLHNCQUFzQixHQUFDRCx1QkFBeEIsSUFBaUQsSUFBNUUsR0FBa0YsVUFBOUY7QUFFQSxnQkFBSUUsWUFBWSxHQUFHLElBQUkvTCxJQUFKLEVBQW5COztBQUNBLGdCQUFJMEYsY0FBYyxDQUFDckcsTUFBZixHQUF3QixDQUE1QixFQUE4QjtBQUMxQjtBQUNBcUcsNEJBQWMsQ0FBQ3NHLE9BQWYsQ0FBdUIsQ0FBQzlFLEdBQUQsRUFBTWhKLE1BQU4sS0FBaUI7QUFDcEMsb0JBQUlnSixHQUFKLEVBQVE7QUFDSjFKLHlCQUFPLENBQUNDLEdBQVIsQ0FBWXlKLEdBQVo7QUFDSDs7QUFDRCxvQkFBSWhKLE1BQUosRUFBVyxDQUNQO0FBQ0g7QUFDSixlQVBEO0FBUUg7O0FBRUQsZ0JBQUkrTixVQUFVLEdBQUcsSUFBSWpNLElBQUosRUFBakI7QUFDQXhDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBMkIsQ0FBQ3dPLFVBQVUsR0FBQ0YsWUFBWixJQUEwQixJQUFyRCxHQUEyRCxVQUF2RTtBQUVBLGdCQUFJRyxXQUFXLEdBQUcsSUFBSWxNLElBQUosRUFBbEI7O0FBQ0EsZ0JBQUk0RixvQkFBb0IsQ0FBQ3ZHLE1BQXJCLEdBQThCLENBQWxDLEVBQW9DO0FBQ2hDdUcsa0NBQW9CLENBQUNvRyxPQUFyQixDQUE2QixDQUFDOUUsR0FBRCxFQUFNaEosTUFBTixLQUFpQjtBQUMxQyxvQkFBSWdKLEdBQUosRUFBUTtBQUNKMUoseUJBQU8sQ0FBQ0MsR0FBUixDQUFZeUosR0FBWjtBQUNIO0FBQ0osZUFKRDtBQUtIOztBQUVELGdCQUFJaUYsU0FBUyxHQUFHLElBQUluTSxJQUFKLEVBQWhCO0FBQ0F4QyxtQkFBTyxDQUFDQyxHQUFSLENBQVksb0NBQW1DLENBQUMwTyxTQUFTLEdBQUNELFdBQVgsSUFBd0IsSUFBM0QsR0FBaUUsVUFBN0U7O0FBRUEsZ0JBQUlyRyxhQUFhLENBQUN4RyxNQUFkLEdBQXVCLENBQTNCLEVBQTZCO0FBQ3pCd0csMkJBQWEsQ0FBQ21HLE9BQWQsQ0FBc0IsQ0FBQzlFLEdBQUQsRUFBTWhKLE1BQU4sS0FBaUI7QUFDbkMsb0JBQUlnSixHQUFKLEVBQVE7QUFDSjFKLHlCQUFPLENBQUNDLEdBQVIsQ0FBWXlKLEdBQVo7QUFDSDtBQUNKLGVBSkQ7QUFLSDs7QUFFRCxnQkFBSXBCLGVBQWUsQ0FBQ3pHLE1BQWhCLEdBQXlCLENBQTdCLEVBQStCO0FBQzNCeUcsNkJBQWUsQ0FBQ2tHLE9BQWhCLENBQXdCLENBQUM5RSxHQUFELEVBQU1oSixNQUFOLEtBQWlCO0FBQ3JDLG9CQUFJZ0osR0FBSixFQUFRO0FBQ0oxSix5QkFBTyxDQUFDQyxHQUFSLENBQVl5SixHQUFaO0FBQ0g7QUFDSixlQUpEO0FBS0gsYUF4YTBCLENBMGEzQjs7O0FBRUEsZ0JBQUlsRSxNQUFNLEdBQUcsRUFBVCxJQUFlLENBQW5CLEVBQXFCO0FBQ2pCeEYscUJBQU8sQ0FBQ0MsR0FBUixDQUFZLGlEQUFaO0FBQ0Esa0JBQUkyTyxnQkFBZ0IsR0FBR3BQLFVBQVUsQ0FBQzBGLElBQVgsQ0FBZ0I7QUFBQzZCLHNCQUFNLEVBQUMsQ0FBUjtBQUFVNkYsc0JBQU0sRUFBQztBQUFqQixlQUFoQixFQUF3QztBQUFDekYsb0JBQUksRUFBQztBQUFDc0QsOEJBQVksRUFBQyxDQUFDO0FBQWY7QUFBTixlQUF4QyxFQUFrRXJGLEtBQWxFLEVBQXZCO0FBQ0Esa0JBQUl5SixZQUFZLEdBQUduRCxJQUFJLENBQUNvRCxJQUFMLENBQVVGLGdCQUFnQixDQUFDL00sTUFBakIsR0FBd0IsR0FBbEMsQ0FBbkI7QUFDQSxrQkFBSWtOLGVBQWUsR0FBR0gsZ0JBQWdCLENBQUMvTSxNQUFqQixHQUEwQmdOLFlBQWhEO0FBRUEsa0JBQUlHLGNBQWMsR0FBRyxDQUFyQjtBQUNBLGtCQUFJQyxpQkFBaUIsR0FBRyxDQUF4QjtBQUVBLGtCQUFJQyxnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLGtCQUFJQyxpQkFBaUIsR0FBRyxDQUF4QjtBQUNBLGtCQUFJQyxvQkFBb0IsR0FBRyxDQUEzQjtBQUNBLGtCQUFJQyxxQkFBcUIsR0FBRyxDQUE1Qjs7QUFJQSxtQkFBSy9QLENBQUwsSUFBVXNQLGdCQUFWLEVBQTJCO0FBQ3ZCLG9CQUFJdFAsQ0FBQyxHQUFHdVAsWUFBUixFQUFxQjtBQUNqQkcsZ0NBQWMsSUFBSUosZ0JBQWdCLENBQUN0UCxDQUFELENBQWhCLENBQW9CbUwsWUFBdEM7QUFDSCxpQkFGRCxNQUdJO0FBQ0F3RSxtQ0FBaUIsSUFBSUwsZ0JBQWdCLENBQUN0UCxDQUFELENBQWhCLENBQW9CbUwsWUFBekM7QUFDSDs7QUFHRCxvQkFBSTJFLG9CQUFvQixHQUFHLElBQTNCLEVBQWdDO0FBQzVCQSxzQ0FBb0IsSUFBSVIsZ0JBQWdCLENBQUN0UCxDQUFELENBQWhCLENBQW9CbUwsWUFBcEIsR0FBbUN4QyxhQUFhLENBQUN3QyxZQUF6RTtBQUNBeUUsa0NBQWdCO0FBQ25CO0FBQ0o7O0FBRURHLG1DQUFxQixHQUFHLElBQUlELG9CQUE1QjtBQUNBRCwrQkFBaUIsR0FBR1AsZ0JBQWdCLENBQUMvTSxNQUFqQixHQUEwQnFOLGdCQUE5QztBQUVBLGtCQUFJSSxNQUFNLEdBQUc7QUFDVDlKLHNCQUFNLEVBQUVBLE1BREM7QUFFVHFKLDRCQUFZLEVBQUVBLFlBRkw7QUFHVEcsOEJBQWMsRUFBRUEsY0FIUDtBQUlURCwrQkFBZSxFQUFFQSxlQUpSO0FBS1RFLGlDQUFpQixFQUFFQSxpQkFMVjtBQU1UQyxnQ0FBZ0IsRUFBRUEsZ0JBTlQ7QUFPVEUsb0NBQW9CLEVBQUVBLG9CQVBiO0FBUVRELGlDQUFpQixFQUFFQSxpQkFSVjtBQVNURSxxQ0FBcUIsRUFBRUEscUJBVGQ7QUFVVEUsNkJBQWEsRUFBRVgsZ0JBQWdCLENBQUMvTSxNQVZ2QjtBQVdUMk4sZ0NBQWdCLEVBQUV2SCxhQUFhLENBQUN3QyxZQVh2QjtBQVlUYSx5QkFBUyxFQUFFOUMsU0FBUyxDQUFDakcsSUFaWjtBQWFUa04sd0JBQVEsRUFBRSxJQUFJak4sSUFBSjtBQWJELGVBQWI7QUFnQkF4QyxxQkFBTyxDQUFDQyxHQUFSLENBQVlxUCxNQUFaO0FBRUE1TCw2QkFBZSxDQUFDa0csTUFBaEIsQ0FBdUIwRixNQUF2QjtBQUNIO0FBQ0o7QUFDSixTQTNlRCxDQTRlQSxPQUFPdlAsQ0FBUCxFQUFTO0FBQ0xDLGlCQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNBd0gsaUJBQU8sR0FBRyxLQUFWO0FBQ0EsaUJBQU8sU0FBUDtBQUNIOztBQUNELFlBQUltSSxZQUFZLEdBQUcsSUFBSWxOLElBQUosRUFBbkI7QUFDQXhDLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFxQixDQUFDeVAsWUFBWSxHQUFDMUgsY0FBZCxJQUE4QixJQUFuRCxHQUF5RCxVQUFyRTtBQUNIOztBQUNEVCxhQUFPLEdBQUcsS0FBVjtBQUNBakUsV0FBSyxDQUFDd0ksTUFBTixDQUFhO0FBQUNYLGVBQU8sRUFBQ2hNLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBaEMsT0FBYixFQUF1RDtBQUFDSCxZQUFJLEVBQUM7QUFBQzJFLDhCQUFvQixFQUFDLElBQUluTixJQUFKLEVBQXRCO0FBQWtDcUYseUJBQWUsRUFBQ0E7QUFBbEQ7QUFBTixPQUF2RDtBQUNIOztBQUVELFdBQU9MLEtBQVA7QUFDSCxHQS9tQlU7QUFnbkJYLGNBQVksVUFBU0osS0FBVCxFQUFnQjtBQUN4QjtBQUNBLFdBQVFBLEtBQUssR0FBQyxFQUFkO0FBQ0gsR0FubkJVO0FBb25CWCxhQUFXLFVBQVNBLEtBQVQsRUFBZ0I7QUFDdkIsUUFBSUEsS0FBSyxHQUFHakksTUFBTSxDQUFDc0ksSUFBUCxDQUFZLGtCQUFaLENBQVosRUFBNkM7QUFDekMsYUFBUSxLQUFSO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsYUFBUSxJQUFSO0FBQ0g7QUFDSjtBQTFuQlUsQ0FBZixFOzs7Ozs7Ozs7OztBQzdEQSxJQUFJdEksTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJK0QsU0FBSjtBQUFjakUsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDZ0UsV0FBUyxDQUFDL0QsQ0FBRCxFQUFHO0FBQUMrRCxhQUFTLEdBQUMvRCxDQUFWO0FBQVk7O0FBQTFCLENBQTNCLEVBQXVELENBQXZEO0FBQTBELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBQThFLElBQUlzRSxZQUFKO0FBQWlCeEUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3VFLGNBQVksQ0FBQ3RFLENBQUQsRUFBRztBQUFDc0UsZ0JBQVksR0FBQ3RFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFLdFBzUSxnQkFBZ0IsQ0FBQyxlQUFELEVBQWtCLFVBQVN4SSxLQUFULEVBQWU7QUFDN0MsU0FBTztBQUNIbEMsUUFBSSxHQUFFO0FBQ0YsYUFBTzdCLFNBQVMsQ0FBQzZCLElBQVYsQ0FBZSxFQUFmLEVBQW1CO0FBQUNrQyxhQUFLLEVBQUVBLEtBQVI7QUFBZUQsWUFBSSxFQUFFO0FBQUMzQixnQkFBTSxFQUFFLENBQUM7QUFBVjtBQUFyQixPQUFuQixDQUFQO0FBQ0gsS0FIRTs7QUFJSHFLLFlBQVEsRUFBRSxDQUNOO0FBQ0kzSyxVQUFJLENBQUNLLEtBQUQsRUFBTztBQUNQLGVBQU8vRixVQUFVLENBQUMwRixJQUFYLENBQ0g7QUFBQy9FLGlCQUFPLEVBQUNvRixLQUFLLENBQUNKO0FBQWYsU0FERyxFQUVIO0FBQUNpQyxlQUFLLEVBQUM7QUFBUCxTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCO0FBa0JBd0ksZ0JBQWdCLENBQUMsZ0JBQUQsRUFBbUIsVUFBU3BLLE1BQVQsRUFBZ0I7QUFDL0MsU0FBTztBQUNITixRQUFJLEdBQUU7QUFDRixhQUFPN0IsU0FBUyxDQUFDNkIsSUFBVixDQUFlO0FBQUNNLGNBQU0sRUFBQ0E7QUFBUixPQUFmLENBQVA7QUFDSCxLQUhFOztBQUlIcUssWUFBUSxFQUFFLENBQ047QUFDSTNLLFVBQUksQ0FBQ0ssS0FBRCxFQUFPO0FBQ1AsZUFBTzNCLFlBQVksQ0FBQ3NCLElBQWIsQ0FDSDtBQUFDTSxnQkFBTSxFQUFDRCxLQUFLLENBQUNDO0FBQWQsU0FERyxDQUFQO0FBR0g7O0FBTEwsS0FETSxFQVFOO0FBQ0lOLFVBQUksQ0FBQ0ssS0FBRCxFQUFPO0FBQ1AsZUFBTy9GLFVBQVUsQ0FBQzBGLElBQVgsQ0FDSDtBQUFDL0UsaUJBQU8sRUFBQ29GLEtBQUssQ0FBQ0o7QUFBZixTQURHLEVBRUg7QUFBQ2lDLGVBQUssRUFBQztBQUFQLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBUk07QUFKUCxHQUFQO0FBc0JILENBdkJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDdkJBaEksTUFBTSxDQUFDMFEsTUFBUCxDQUFjO0FBQUN6TSxXQUFTLEVBQUMsTUFBSUE7QUFBZixDQUFkO0FBQXlDLElBQUkwTSxLQUFKO0FBQVUzUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMwUSxPQUFLLENBQUN6USxDQUFELEVBQUc7QUFBQ3lRLFNBQUssR0FBQ3pRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSw2QkFBWixFQUEwQztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBMUMsRUFBd0UsQ0FBeEU7QUFHN0csTUFBTStELFNBQVMsR0FBRyxJQUFJME0sS0FBSyxDQUFDQyxVQUFWLENBQXFCLFFBQXJCLENBQWxCO0FBRVAzTSxTQUFTLENBQUM0TSxPQUFWLENBQWtCO0FBQ2RDLFVBQVEsR0FBRTtBQUNOLFdBQU8xUSxVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUNyQixhQUFPLEVBQUMsS0FBS2dGO0FBQWQsS0FBbkIsQ0FBUDtBQUNIOztBQUhhLENBQWxCLEUsQ0FNQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQjs7Ozs7Ozs7Ozs7QUN0QkEsSUFBSWhHLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJeUUsVUFBSjtBQUFlM0UsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQzBFLFlBQVUsQ0FBQ3pFLENBQUQsRUFBRztBQUFDeUUsY0FBVSxHQUFDekUsQ0FBWDtBQUFhOztBQUE1QixDQUF2QyxFQUFxRSxDQUFyRTtBQUF3RSxJQUFJZ0UsS0FBSixFQUFVNk0sV0FBVjtBQUFzQi9RLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ2lFLE9BQUssQ0FBQ2hFLENBQUQsRUFBRztBQUFDZ0UsU0FBSyxHQUFDaEUsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQjZRLGFBQVcsQ0FBQzdRLENBQUQsRUFBRztBQUFDNlEsZUFBVyxHQUFDN1EsQ0FBWjtBQUFjOztBQUFoRCxDQUExQixFQUE0RSxDQUE1RTtBQUErRSxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUE4RSxJQUFJcUUsa0JBQUo7QUFBdUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDc0Usb0JBQWtCLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLHNCQUFrQixHQUFDckUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQTVDLEVBQTBGLENBQTFGO0FBQTZGLElBQUk4USxJQUFKO0FBQVNoUixNQUFNLENBQUNDLElBQVAsQ0FBWSxpQ0FBWixFQUE4QztBQUFDZ1IsU0FBTyxDQUFDL1EsQ0FBRCxFQUFHO0FBQUM4USxRQUFJLEdBQUM5USxDQUFMO0FBQU87O0FBQW5CLENBQTlDLEVBQW1FLENBQW5FOztBQVE5Z0JnUixlQUFlLEdBQUcsQ0FBQy9PLFNBQUQsRUFBWWdQLGFBQVosS0FBOEI7QUFDNUMsT0FBSyxJQUFJalIsQ0FBVCxJQUFjaVIsYUFBZCxFQUE0QjtBQUN4QixRQUFJaFAsU0FBUyxDQUFDNEssT0FBVixDQUFrQnRMLEtBQWxCLElBQTJCMFAsYUFBYSxDQUFDalIsQ0FBRCxDQUFiLENBQWlCNk0sT0FBakIsQ0FBeUJ0TCxLQUF4RCxFQUE4RDtBQUMxRCxhQUFPb0osUUFBUSxDQUFDc0csYUFBYSxDQUFDalIsQ0FBRCxDQUFiLENBQWlCa1IsS0FBbEIsQ0FBZjtBQUNIO0FBQ0o7QUFDSixDQU5EOztBQVFBclIsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw2QkFBMkIsWUFBVTtBQUNqQyxTQUFLRSxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHb0gsR0FBRyxHQUFDLHVCQUFkOztBQUNBLFFBQUc7QUFDQyxVQUFJeEcsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsVUFBSStRLFNBQVMsR0FBR2xRLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWhCO0FBQ0FnUSxlQUFTLEdBQUdBLFNBQVMsQ0FBQy9QLE1BQXRCO0FBQ0EsVUFBSThFLE1BQU0sR0FBR2lMLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQmxMLE1BQW5DO0FBQ0EsVUFBSW1MLEtBQUssR0FBR0YsU0FBUyxDQUFDQyxXQUFWLENBQXNCQyxLQUFsQztBQUNBLFVBQUlDLElBQUksR0FBR0gsU0FBUyxDQUFDQyxXQUFWLENBQXNCRSxJQUFqQztBQUNBLFVBQUlDLFVBQVUsR0FBR25GLElBQUksQ0FBQ2lGLEtBQUwsQ0FBVzFPLFVBQVUsQ0FBQ3dPLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQkksS0FBdEIsQ0FBNEJILEtBQTVCLEVBQW1DSSxrQkFBbkMsQ0FBc0RDLEtBQXRELENBQTRELEdBQTVELEVBQWlFLENBQWpFLENBQUQsQ0FBVixHQUFnRixHQUEzRixDQUFqQjtBQUVBMU4sV0FBSyxDQUFDd0ksTUFBTixDQUFhO0FBQUNYLGVBQU8sRUFBQ2hNLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBaEMsT0FBYixFQUF1RDtBQUFDSCxZQUFJLEVBQUM7QUFDekRpRyxzQkFBWSxFQUFFekwsTUFEMkM7QUFFekQwTCxxQkFBVyxFQUFFUCxLQUY0QztBQUd6RFEsb0JBQVUsRUFBRVAsSUFINkM7QUFJekRDLG9CQUFVLEVBQUVBLFVBSjZDO0FBS3pEMUwseUJBQWUsRUFBRXNMLFNBQVMsQ0FBQ0MsV0FBVixDQUFzQnZNLFVBQXRCLENBQWlDK0wsUUFBakMsQ0FBMEMvUCxPQUxGO0FBTXpEaVIsa0JBQVEsRUFBRVgsU0FBUyxDQUFDQyxXQUFWLENBQXNCSSxLQUF0QixDQUE0QkgsS0FBNUIsRUFBbUNTLFFBTlk7QUFPekRsSSxvQkFBVSxFQUFFdUgsU0FBUyxDQUFDQyxXQUFWLENBQXNCSSxLQUF0QixDQUE0QkgsS0FBNUIsRUFBbUN6SDtBQVBVO0FBQU4sT0FBdkQ7QUFTSCxLQWxCRCxDQW1CQSxPQUFNbkosQ0FBTixFQUFRO0FBQ0pDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7QUFDSixHQTFCVTtBQTJCWCx3QkFBc0IsWUFBVTtBQUM1QixTQUFLSyxPQUFMO0FBQ0EsUUFBSVYsR0FBRyxHQUFHb0gsR0FBRyxHQUFDLFNBQWQ7O0FBQ0EsUUFBRztBQUNDLFVBQUl4RyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7QUFDQSxVQUFJcUgsTUFBTSxHQUFHeEcsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBYjtBQUNBc0csWUFBTSxHQUFHQSxNQUFNLENBQUNyRyxNQUFoQjtBQUNBLFVBQUkyUSxLQUFLLEdBQUcsRUFBWjtBQUNBQSxXQUFLLENBQUNsRyxPQUFOLEdBQWdCcEUsTUFBTSxDQUFDdUssU0FBUCxDQUFpQkMsT0FBakM7QUFDQUYsV0FBSyxDQUFDRyxpQkFBTixHQUEwQnpLLE1BQU0sQ0FBQ0MsU0FBUCxDQUFpQkMsbUJBQTNDO0FBQ0FvSyxXQUFLLENBQUNJLGVBQU4sR0FBd0IxSyxNQUFNLENBQUNDLFNBQVAsQ0FBaUIwSyxpQkFBekM7QUFFQSxVQUFJQyxXQUFXLEdBQUd4QixXQUFXLENBQUMzTyxPQUFaLENBQW9CLEVBQXBCLEVBQXdCO0FBQUMyRixZQUFJLEVBQUU7QUFBQzNCLGdCQUFNLEVBQUUsQ0FBQztBQUFWO0FBQVAsT0FBeEIsQ0FBbEI7O0FBQ0EsVUFBSW1NLFdBQVcsSUFBSUEsV0FBVyxDQUFDbk0sTUFBWixJQUFzQjZMLEtBQUssQ0FBQ0csaUJBQS9DLEVBQWtFO0FBQzlELG1EQUFvQ0gsS0FBSyxDQUFDRyxpQkFBMUMsdUJBQXdFRyxXQUFXLENBQUNuTSxNQUFwRjtBQUNIOztBQUVEOUYsU0FBRyxHQUFHb0gsR0FBRyxHQUFDLGFBQVY7QUFDQXhHLGNBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLFVBQUl5RSxVQUFVLEdBQUc1RCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFqQjtBQUNBMEQsZ0JBQVUsR0FBR0EsVUFBVSxDQUFDekQsTUFBWCxDQUFrQnlELFVBQS9CO0FBQ0FrTixXQUFLLENBQUNsTixVQUFOLEdBQW1CQSxVQUFVLENBQUN0QyxNQUE5QjtBQUNBLFVBQUkrUCxRQUFRLEdBQUcsQ0FBZjs7QUFDQSxXQUFLdFMsQ0FBTCxJQUFVNkUsVUFBVixFQUFxQjtBQUNqQnlOLGdCQUFRLElBQUkzSCxRQUFRLENBQUM5RixVQUFVLENBQUM3RSxDQUFELENBQVYsQ0FBY21MLFlBQWYsQ0FBcEI7QUFDSDs7QUFDRDRHLFdBQUssQ0FBQ1EsaUJBQU4sR0FBMEJELFFBQTFCO0FBR0F0TyxXQUFLLENBQUN3SSxNQUFOLENBQWE7QUFBQ1gsZUFBTyxFQUFDa0csS0FBSyxDQUFDbEc7QUFBZixPQUFiLEVBQXNDO0FBQUNILFlBQUksRUFBQ3FHO0FBQU4sT0FBdEMsRUFBb0Q7QUFBQ3ZHLGNBQU0sRUFBRTtBQUFULE9BQXBELEVBMUJELENBMkJDOztBQUNBLFVBQUliLFFBQVEsQ0FBQ29ILEtBQUssQ0FBQ0csaUJBQVAsQ0FBUixHQUFvQyxDQUF4QyxFQUEwQztBQUN0QyxZQUFJTSxXQUFXLEdBQUcsRUFBbEI7QUFDQUEsbUJBQVcsQ0FBQ3RNLE1BQVosR0FBcUJ5RSxRQUFRLENBQUNsRCxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLG1CQUFsQixDQUE3QjtBQUNBNkssbUJBQVcsQ0FBQ3ZQLElBQVosR0FBbUIsSUFBSUMsSUFBSixDQUFTdUUsTUFBTSxDQUFDQyxTQUFQLENBQWlCMEssaUJBQTFCLENBQW5CO0FBRUFoUyxXQUFHLEdBQUdHLEdBQUcsR0FBRyxlQUFaOztBQUNBLFlBQUc7QUFDQ1Msa0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGNBQUlxUyxPQUFPLEdBQUd4UixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBM0MsQ0FGRCxDQUdDO0FBQ0E7O0FBQ0FvUixxQkFBVyxDQUFDRSxZQUFaLEdBQTJCL0gsUUFBUSxDQUFDOEgsT0FBTyxDQUFDRSxhQUFULENBQW5DO0FBQ0FILHFCQUFXLENBQUNJLGVBQVosR0FBOEJqSSxRQUFRLENBQUM4SCxPQUFPLENBQUNJLGlCQUFULENBQXRDO0FBQ0gsU0FQRCxDQVFBLE9BQU1wUyxDQUFOLEVBQVE7QUFDSkMsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRUQsWUFBS3FRLElBQUksQ0FBQ2dDLFdBQUwsQ0FBaUJDLEtBQXRCLEVBQThCO0FBQzFCM1MsYUFBRyxHQUFHRyxHQUFHLEdBQUcsZ0JBQU4sR0FBd0J1USxJQUFJLENBQUNnQyxXQUFMLENBQWlCQyxLQUEvQzs7QUFDQSxjQUFHO0FBQ0MvUixvQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYO0FBQ0EsZ0JBQUk0UyxNQUFNLEdBQUcvUixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBMUM7QUFDQW9SLHVCQUFXLENBQUNTLFdBQVosR0FBMEJ0SSxRQUFRLENBQUNxSSxNQUFELENBQWxDO0FBQ0gsV0FKRCxDQUtBLE9BQU12UyxDQUFOLEVBQVE7QUFDSkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLGFBQUcsR0FBR0csR0FBRyxHQUFHLDhCQUFaOztBQUNBLGNBQUk7QUFDQVMsb0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGdCQUFJOFMsSUFBSSxHQUFHalMsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQXhDOztBQUNBLGdCQUFJOFIsSUFBSSxJQUFJQSxJQUFJLENBQUMzUSxNQUFMLEdBQWMsQ0FBMUIsRUFBNEI7QUFDeEJpUSx5QkFBVyxDQUFDVyxhQUFaLEdBQTRCLEVBQTVCO0FBQ0FELGtCQUFJLENBQUNwUSxPQUFMLENBQWEsQ0FBQ3NRLE1BQUQsRUFBUzVQLENBQVQsS0FBZTtBQUN4QmdQLDJCQUFXLENBQUNXLGFBQVosQ0FBMEJySixJQUExQixDQUErQjtBQUMzQmlKLHVCQUFLLEVBQUVLLE1BQU0sQ0FBQ0wsS0FEYTtBQUUzQkssd0JBQU0sRUFBRXpRLFVBQVUsQ0FBQ3lRLE1BQU0sQ0FBQ0EsTUFBUjtBQUZTLGlCQUEvQjtBQUlILGVBTEQ7QUFNSDtBQUNKLFdBWkQsQ0FhQSxPQUFPM1MsQ0FBUCxFQUFTO0FBQ0xDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIOztBQUVETCxhQUFHLEdBQUdHLEdBQUcsR0FBRyxvQkFBWjs7QUFDQSxjQUFHO0FBQ0NTLG9CQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQVg7QUFDQSxnQkFBSWlULFNBQVMsR0FBR3BTLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE3Qzs7QUFDQSxnQkFBSWlTLFNBQUosRUFBYztBQUNWYix5QkFBVyxDQUFDYSxTQUFaLEdBQXdCMVEsVUFBVSxDQUFDMFEsU0FBRCxDQUFsQztBQUNIO0FBQ0osV0FORCxDQU9BLE9BQU01UyxDQUFOLEVBQVE7QUFDSkMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZRixDQUFaO0FBQ0g7O0FBRURMLGFBQUcsR0FBR0csR0FBRyxHQUFHLDRCQUFaOztBQUNBLGNBQUc7QUFDQ1Msb0JBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBWDtBQUNBLGdCQUFJa1QsVUFBVSxHQUFHclMsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsQ0FBakI7O0FBQ0EsZ0JBQUltUyxVQUFKLEVBQWU7QUFDWGQseUJBQVcsQ0FBQ2UsZ0JBQVosR0FBK0I1USxVQUFVLENBQUMyUSxVQUFVLENBQUNsUyxNQUFaLENBQXpDO0FBQ0g7QUFDSixXQU5ELENBT0EsT0FBTVgsQ0FBTixFQUFRO0FBQ0pDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ047O0FBRUNvUSxtQkFBVyxDQUFDdkcsTUFBWixDQUFtQmtJLFdBQW5CO0FBQ0gsT0FyR0YsQ0F1R0M7QUFFQTtBQUNBOzs7QUFDQSxhQUFPVCxLQUFLLENBQUNHLGlCQUFiO0FBQ0gsS0E1R0QsQ0E2R0EsT0FBT3pSLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNBLGFBQU8sNkJBQVA7QUFDSDtBQUNKLEdBL0lVO0FBZ0pYLDJCQUF5QixZQUFVO0FBQy9CdUQsU0FBSyxDQUFDNEIsSUFBTixHQUFhaUMsSUFBYixDQUFrQjtBQUFDMkwsYUFBTyxFQUFDLENBQUM7QUFBVixLQUFsQixFQUFnQzFMLEtBQWhDLENBQXNDLENBQXRDO0FBQ0gsR0FsSlU7QUFtSlgsbUJBQWlCLFlBQVU7QUFDdkIsUUFBSWlLLEtBQUssR0FBRy9OLEtBQUssQ0FBQzlCLE9BQU4sQ0FBYztBQUFDMkosYUFBTyxFQUFFaE0sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFqQyxLQUFkLENBQVo7O0FBRUEsUUFBSWtHLEtBQUssSUFBSUEsS0FBSyxDQUFDMEIsV0FBbkIsRUFBK0I7QUFDM0IvUyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBWjtBQUNILEtBRkQsTUFHSyxJQUFJZCxNQUFNLENBQUNpSCxRQUFQLENBQWdCNE0sS0FBaEIsQ0FBc0JELFdBQTFCLEVBQXVDO0FBQ3hDL1MsYUFBTyxDQUFDQyxHQUFSLENBQVksdUNBQVo7QUFDQSxVQUFJSyxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTVCxNQUFNLENBQUNpSCxRQUFQLENBQWdCNk0sV0FBekIsQ0FBZjtBQUNBLFVBQUlDLE9BQU8sR0FBRzNTLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQWQ7QUFDQSxVQUFJMFMsS0FBSyxHQUFHRCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JELEtBQWxCLElBQTJCRCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JDLFlBQXpEO0FBQ0EsVUFBSUMsV0FBVyxHQUFHO0FBQ2RuSSxlQUFPLEVBQUUrSCxPQUFPLENBQUM5SCxRQURIO0FBRWRtSSxtQkFBVyxFQUFFTCxPQUFPLENBQUNNLFlBRlA7QUFHZEMsdUJBQWUsRUFBRVAsT0FBTyxDQUFDUSxnQkFIWDtBQUlkQyxZQUFJLEVBQUVULE9BQU8sQ0FBQ0UsU0FBUixDQUFrQk8sSUFKVjtBQUtkQyxZQUFJLEVBQUVWLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlEsSUFMVjtBQU1kQyxlQUFPLEVBQUU7QUFDTHJCLGNBQUksRUFBRVUsT0FBTyxDQUFDRSxTQUFSLENBQWtCUyxPQUFsQixDQUEwQnJCLElBRDNCO0FBRUxsTCxnQkFBTSxFQUFFNEwsT0FBTyxDQUFDRSxTQUFSLENBQWtCUyxPQUFsQixDQUEwQnZNO0FBRjdCLFNBTks7QUFVZHdNLFlBQUksRUFBRVosT0FBTyxDQUFDRSxTQUFSLENBQWtCVSxJQVZWO0FBV2RYLGFBQUssRUFBRTtBQUNIWSxzQkFBWSxFQUFFWixLQUFLLENBQUNhLGFBRGpCO0FBRUhDLDRCQUFrQixFQUFFZCxLQUFLLENBQUNlLG9CQUZ2QjtBQUdIQyw2QkFBbUIsRUFBRWhCLEtBQUssQ0FBQ2lCLHFCQUh4QjtBQUlIQyw2QkFBbUIsRUFBRWxCLEtBQUssQ0FBQ21CO0FBSnhCLFNBWE87QUFpQmRDLFdBQUcsRUFBRTtBQUNEQyw0QkFBa0IsRUFBRSxDQURuQjtBQUVEQyx1QkFBYSxFQUFFLEVBRmQ7QUFHREMsc0JBQVksRUFBRSxFQUhiO0FBSURDLHFCQUFXLEVBQUU7QUFKWixTQWpCUztBQXVCZEMsZ0JBQVEsRUFBQztBQUNMdE4sZ0JBQU0sRUFBRTRMLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQndCLFFBQWxCLENBQTJCdE47QUFEOUIsU0F2Qks7QUEwQmRnTCxjQUFNLEVBQUVZLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQmQsTUExQlo7QUEyQmR1QyxjQUFNLEVBQUUzQixPQUFPLENBQUNFLFNBQVIsQ0FBa0J5QjtBQTNCWixPQUFsQjs7QUE4QlAsVUFBSTNCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQm1CLEdBQXRCLEVBQTJCO0FBQ2hCakIsbUJBQVcsQ0FBQ2lCLEdBQVosR0FBa0I7QUFDZEMsNEJBQWtCLEVBQUV0QixPQUFPLENBQUNFLFNBQVIsQ0FBa0JtQixHQUFsQixDQUFzQk8sb0JBRDVCO0FBRWRMLHVCQUFhLEVBQUV2QixPQUFPLENBQUNFLFNBQVIsQ0FBa0JtQixHQUFsQixDQUFzQlEsY0FGdkI7QUFHZEwsc0JBQVksRUFBRXhCLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQm1CLEdBQWxCLENBQXNCUyxhQUh0QjtBQUlkTCxxQkFBVyxFQUFFekIsT0FBTyxDQUFDRSxTQUFSLENBQWtCbUIsR0FBbEIsQ0FBc0JVO0FBSnJCLFNBQWxCO0FBTVY7O0FBQ00sVUFBSXpGLGdCQUFnQixHQUFHLENBQXZCLENBM0N3QyxDQTZDeEM7O0FBQ0EsVUFBSTBELE9BQU8sQ0FBQ0UsU0FBUixDQUFrQjhCLE9BQWxCLElBQTZCaEMsT0FBTyxDQUFDRSxTQUFSLENBQWtCOEIsT0FBbEIsQ0FBMEJDLE1BQXZELElBQWtFakMsT0FBTyxDQUFDRSxTQUFSLENBQWtCOEIsT0FBbEIsQ0FBMEJDLE1BQTFCLENBQWlDdFQsTUFBakMsR0FBMEMsQ0FBaEgsRUFBbUg7QUFDL0csYUFBS2lCLENBQUwsSUFBVW9RLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQjhCLE9BQWxCLENBQTBCQyxNQUFwQyxFQUEyQztBQUN2QyxjQUFJQyxHQUFHLEdBQUdsQyxPQUFPLENBQUNFLFNBQVIsQ0FBa0I4QixPQUFsQixDQUEwQkMsTUFBMUIsQ0FBaUNyUyxDQUFqQyxFQUFvQ2pDLEtBQXBDLENBQTBDdVUsR0FBcEQsQ0FEdUMsQ0FFdkM7O0FBQ0EsZUFBS0MsQ0FBTCxJQUFVRCxHQUFWLEVBQWM7QUFDVixnQkFBSUEsR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT3pVLElBQVAsSUFBZSwrQkFBbkIsRUFBbUQ7QUFDL0NaLHFCQUFPLENBQUNDLEdBQVIsQ0FBWW1WLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU94VSxLQUFuQixFQUQrQyxDQUUvQzs7QUFDQSxrQkFBSVUsU0FBUyxHQUFHO0FBQ1pxRyxnQ0FBZ0IsRUFBRXdOLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU94VSxLQUFQLENBQWF5VSxNQURuQjtBQUVaNUksMkJBQVcsRUFBRTBJLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU94VSxLQUFQLENBQWE2TCxXQUZkO0FBR1o1SywwQkFBVSxFQUFFc1QsR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT3hVLEtBQVAsQ0FBYWlCLFVBSGI7QUFJWitLLG1DQUFtQixFQUFFdUksR0FBRyxDQUFDQyxDQUFELENBQUgsQ0FBT3hVLEtBQVAsQ0FBYWdNLG1CQUp0QjtBQUtabkwsZ0NBQWdCLEVBQUUwVCxHQUFHLENBQUNDLENBQUQsQ0FBSCxDQUFPeFUsS0FBUCxDQUFhd0ksaUJBTG5CO0FBTVoxSCxpQ0FBaUIsRUFBRXlULEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU94VSxLQUFQLENBQWFjLGlCQU5wQjtBQU9aOEksNEJBQVksRUFBRWlCLElBQUksQ0FBQzZKLEtBQUwsQ0FBV3RMLFFBQVEsQ0FBQ21MLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU94VSxLQUFQLENBQWFBLEtBQWIsQ0FBbUI2UixNQUFwQixDQUFSLEdBQXNDdEMsSUFBSSxDQUFDZ0MsV0FBTCxDQUFpQm9ELFFBQWxFLENBUEY7QUFRWjVJLHNCQUFNLEVBQUUsS0FSSTtBQVNaN0Ysc0JBQU0sRUFBRTtBQVRJLGVBQWhCO0FBWUF5SSw4QkFBZ0IsSUFBSWpPLFNBQVMsQ0FBQ2tKLFlBQTlCO0FBRUEsa0JBQUl3RCxVQUFVLEdBQUc5TyxNQUFNLENBQUNpSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjZILFNBQXZCLEdBQWlDLDRCQUFqQyxHQUE4RCwwQkFBL0U7QUFDQSxrQkFBSXVILFdBQVcsR0FBR3RXLE1BQU0sQ0FBQ3NJLElBQVAsQ0FBWSxnQkFBWixFQUE4QjJOLEdBQUcsQ0FBQ0MsQ0FBRCxDQUFILENBQU94VSxLQUFQLENBQWF5VSxNQUEzQyxFQUFtRHJILFVBQW5ELENBQWxCLENBbEIrQyxDQW1CL0M7O0FBRUExTSx1QkFBUyxDQUFDNEssT0FBVixHQUFvQjtBQUNoQix3QkFBTzhCLFVBRFM7QUFFaEIseUJBQVF3SDtBQUZRLGVBQXBCO0FBS0FsVSx1QkFBUyxDQUFDcEIsT0FBVixHQUFvQjRELFVBQVUsQ0FBQ3hDLFNBQVMsQ0FBQzRLLE9BQVgsQ0FBOUI7QUFDQTVLLHVCQUFTLENBQUM2SyxNQUFWLEdBQW1Cak4sTUFBTSxDQUFDc0ksSUFBUCxDQUFZLGdCQUFaLEVBQThCbEcsU0FBUyxDQUFDNEssT0FBeEMsRUFBaURoTixNQUFNLENBQUNpSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmdHLGtCQUF4RSxDQUFuQjtBQUNBOUssdUJBQVMsQ0FBQytLLGVBQVYsR0FBNEJuTixNQUFNLENBQUNzSSxJQUFQLENBQVksZ0JBQVosRUFBOEJsRyxTQUFTLENBQUM0SyxPQUF4QyxFQUFpRGhOLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCa0csa0JBQXhFLENBQTVCO0FBQ0E1SSxnQ0FBa0IsQ0FBQ2lHLE1BQW5CLENBQTBCO0FBQ3RCekosdUJBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BREc7QUFFdEJrTixpQ0FBaUIsRUFBRSxDQUZHO0FBR3RCNUMsNEJBQVksRUFBRWxKLFNBQVMsQ0FBQ2tKLFlBSEY7QUFJdEI3SixvQkFBSSxFQUFFLEtBSmdCO0FBS3RCNEUsc0JBQU0sRUFBRSxDQUxjO0FBTXRCOEgsMEJBQVUsRUFBRTRGLE9BQU8sQ0FBQ007QUFORSxlQUExQjtBQVNBaFUsd0JBQVUsQ0FBQ29LLE1BQVgsQ0FBa0JySSxTQUFsQjtBQUNIO0FBQ0o7QUFDSjtBQUNKLE9BN0Z1QyxDQStGeEM7OztBQUNBdkIsYUFBTyxDQUFDQyxHQUFSLENBQVkscUNBQVo7O0FBQ0EsVUFBSWlULE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEIxUCxVQUExQixJQUF3QytPLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEIxUCxVQUExQixDQUFxQ3RDLE1BQXJDLEdBQThDLENBQTFGLEVBQTRGO0FBQ3hGN0IsZUFBTyxDQUFDQyxHQUFSLENBQVlpVCxPQUFPLENBQUNFLFNBQVIsQ0FBa0JTLE9BQWxCLENBQTBCMVAsVUFBMUIsQ0FBcUN0QyxNQUFqRDtBQUNBLFlBQUk2VCxnQkFBZ0IsR0FBR3hDLE9BQU8sQ0FBQ0UsU0FBUixDQUFrQlMsT0FBbEIsQ0FBMEIxUCxVQUFqRDtBQUNBLFlBQUlvTSxhQUFhLEdBQUcyQyxPQUFPLENBQUMvTyxVQUE1Qjs7QUFDQSxhQUFLLElBQUk3RSxDQUFULElBQWNvVyxnQkFBZCxFQUErQjtBQUMzQjtBQUNBLGNBQUluVSxTQUFTLEdBQUdtVSxnQkFBZ0IsQ0FBQ3BXLENBQUQsQ0FBaEM7QUFDQWlDLG1CQUFTLENBQUNJLGlCQUFWLEdBQThCeEMsTUFBTSxDQUFDc0ksSUFBUCxDQUFZLGNBQVosRUFBNEJpTyxnQkFBZ0IsQ0FBQ3BXLENBQUQsQ0FBaEIsQ0FBb0JvQyxnQkFBaEQsQ0FBOUI7QUFFQSxjQUFJdU0sVUFBVSxHQUFHOU8sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI2SCxTQUF2QixHQUFpQyw0QkFBakMsR0FBOEQsMEJBQS9FO0FBQ0EsY0FBSXVILFdBQVcsR0FBR3RXLE1BQU0sQ0FBQ3NJLElBQVAsQ0FBWSxnQkFBWixFQUE4QmxHLFNBQVMsQ0FBQ3FHLGdCQUF4QyxFQUEwRHFHLFVBQTFELENBQWxCO0FBRUExTSxtQkFBUyxDQUFDNEssT0FBVixHQUFvQjtBQUNoQixvQkFBTzhCLFVBRFM7QUFFaEIscUJBQVF3SDtBQUZRLFdBQXBCO0FBS0FsVSxtQkFBUyxDQUFDcEIsT0FBVixHQUFvQjRELFVBQVUsQ0FBQ3hDLFNBQVMsQ0FBQzRLLE9BQVgsQ0FBOUI7QUFDQTVLLG1CQUFTLENBQUM0SyxPQUFWLEdBQW9CNUssU0FBUyxDQUFDNEssT0FBOUI7QUFDQTVLLG1CQUFTLENBQUM2SyxNQUFWLEdBQW1Cak4sTUFBTSxDQUFDc0ksSUFBUCxDQUFZLGdCQUFaLEVBQThCbEcsU0FBUyxDQUFDNEssT0FBeEMsRUFBaURoTixNQUFNLENBQUNpSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QmdHLGtCQUF4RSxDQUFuQjtBQUNBOUssbUJBQVMsQ0FBQytLLGVBQVYsR0FBNEJuTixNQUFNLENBQUNzSSxJQUFQLENBQVksZ0JBQVosRUFBOEJsRyxTQUFTLENBQUM0SyxPQUF4QyxFQUFpRGhOLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCa0csa0JBQXhFLENBQTVCO0FBRUFoTCxtQkFBUyxDQUFDa0osWUFBVixHQUF5QjZGLGVBQWUsQ0FBQy9PLFNBQUQsRUFBWWdQLGFBQVosQ0FBeEM7QUFDQWYsMEJBQWdCLElBQUlqTyxTQUFTLENBQUNrSixZQUE5QjtBQUVBakwsb0JBQVUsQ0FBQ3NMLE1BQVgsQ0FBa0I7QUFBQ2xELDRCQUFnQixFQUFDckcsU0FBUyxDQUFDcUc7QUFBNUIsV0FBbEIsRUFBZ0VyRyxTQUFoRTtBQUNBb0MsNEJBQWtCLENBQUNpRyxNQUFuQixDQUEwQjtBQUN0QnpKLG1CQUFPLEVBQUVvQixTQUFTLENBQUNwQixPQURHO0FBRXRCa04sNkJBQWlCLEVBQUUsQ0FGRztBQUd0QjVDLHdCQUFZLEVBQUVsSixTQUFTLENBQUNrSixZQUhGO0FBSXRCN0osZ0JBQUksRUFBRSxLQUpnQjtBQUt0QjRFLGtCQUFNLEVBQUUsQ0FMYztBQU10QjhILHNCQUFVLEVBQUU0RixPQUFPLENBQUNNO0FBTkUsV0FBMUI7QUFRSDtBQUNKOztBQUVERixpQkFBVyxDQUFDUCxXQUFaLEdBQTBCLElBQTFCO0FBQ0FPLGlCQUFXLENBQUN6QixpQkFBWixHQUFnQ3JDLGdCQUFoQztBQUNBLFVBQUk5TyxNQUFNLEdBQUc0QyxLQUFLLENBQUN3SCxNQUFOLENBQWE7QUFBQ0ssZUFBTyxFQUFDbUksV0FBVyxDQUFDbkk7QUFBckIsT0FBYixFQUE0QztBQUFDSCxZQUFJLEVBQUNzSTtBQUFOLE9BQTVDLENBQWI7QUFHQXRULGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDBDQUFaO0FBRUg7O0FBRUQsV0FBTyxJQUFQO0FBQ0g7QUF6U1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ2hCQSxJQUFJZCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlnRSxLQUFKLEVBQVU2TSxXQUFWO0FBQXNCL1EsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDaUUsT0FBSyxDQUFDaEUsQ0FBRCxFQUFHO0FBQUNnRSxTQUFLLEdBQUNoRSxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CNlEsYUFBVyxDQUFDN1EsQ0FBRCxFQUFHO0FBQUM2USxlQUFXLEdBQUM3USxDQUFaO0FBQWM7O0FBQWhELENBQTFCLEVBQTRFLENBQTVFO0FBQStFLElBQUlxVyxTQUFKO0FBQWN2VyxNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDc1csV0FBUyxDQUFDclcsQ0FBRCxFQUFHO0FBQUNxVyxhQUFTLEdBQUNyVyxDQUFWO0FBQVk7O0FBQTFCLENBQTdDLEVBQXlFLENBQXpFO0FBQTRFLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBSzlRSCxNQUFNLENBQUN5VyxPQUFQLENBQWUsb0JBQWYsRUFBcUMsWUFBWTtBQUM3QyxTQUFPLENBQ0h6RixXQUFXLENBQUNqTCxJQUFaLENBQWlCLEVBQWpCLEVBQW9CO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFrQjRCLFNBQUssRUFBQztBQUF4QixHQUFwQixDQURHLEVBRUh1TyxTQUFTLENBQUN6USxJQUFWLENBQWUsRUFBZixFQUFrQjtBQUFDaUMsUUFBSSxFQUFDO0FBQUMwTyxxQkFBZSxFQUFDLENBQUM7QUFBbEIsS0FBTjtBQUEyQnpPLFNBQUssRUFBQztBQUFqQyxHQUFsQixDQUZHLENBQVA7QUFJSCxDQUxEO0FBT0F3SSxnQkFBZ0IsQ0FBQyxjQUFELEVBQWlCLFlBQVU7QUFDdkMsU0FBTztBQUNIMUssUUFBSSxHQUFFO0FBQ0YsYUFBTzVCLEtBQUssQ0FBQzRCLElBQU4sQ0FBVztBQUFDaUcsZUFBTyxFQUFDaE0sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFoQyxPQUFYLENBQVA7QUFDSCxLQUhFOztBQUlIMEUsWUFBUSxFQUFFLENBQ047QUFDSTNLLFVBQUksQ0FBQ21NLEtBQUQsRUFBTztBQUNQLGVBQU83UixVQUFVLENBQUMwRixJQUFYLENBQ0gsRUFERyxFQUVIO0FBQUM0SSxnQkFBTSxFQUFDO0FBQ0ozTixtQkFBTyxFQUFDLENBREo7QUFFSnVNLHVCQUFXLEVBQUMsQ0FGUjtBQUdKaEwsNEJBQWdCLEVBQUMsQ0FIYjtBQUlKcUYsa0JBQU0sRUFBQyxDQUFDLENBSko7QUFLSjZGLGtCQUFNLEVBQUMsQ0FMSDtBQU1KRCx1QkFBVyxFQUFDO0FBTlI7QUFBUixTQUZHLENBQVA7QUFXSDs7QUFiTCxLQURNO0FBSlAsR0FBUDtBQXNCSCxDQXZCZSxDQUFoQixDOzs7Ozs7Ozs7OztBQ1pBdk4sTUFBTSxDQUFDMFEsTUFBUCxDQUFjO0FBQUN4TSxPQUFLLEVBQUMsTUFBSUEsS0FBWDtBQUFpQjZNLGFBQVcsRUFBQyxNQUFJQTtBQUFqQyxDQUFkO0FBQTZELElBQUlKLEtBQUo7QUFBVTNRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzBRLE9BQUssQ0FBQ3pRLENBQUQsRUFBRztBQUFDeVEsU0FBSyxHQUFDelEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUFrRCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDZCQUFaLEVBQTBDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUExQyxFQUF3RSxDQUF4RTtBQUdqSSxNQUFNZ0UsS0FBSyxHQUFHLElBQUl5TSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsT0FBckIsQ0FBZDtBQUNBLE1BQU1HLFdBQVcsR0FBRyxJQUFJSixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBcEI7QUFFUDFNLEtBQUssQ0FBQzJNLE9BQU4sQ0FBYztBQUNWQyxVQUFRLEdBQUU7QUFDTixXQUFPMVEsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDckIsYUFBTyxFQUFDLEtBQUtnRjtBQUFkLEtBQW5CLENBQVA7QUFDSDs7QUFIUyxDQUFkLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSWhHLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXFXLFNBQUo7QUFBY3ZXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtCQUFaLEVBQStCO0FBQUNzVyxXQUFTLENBQUNyVyxDQUFELEVBQUc7QUFBQ3FXLGFBQVMsR0FBQ3JXLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0IsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUlySkgsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw0QkFBMEIsWUFBVTtBQUNoQyxTQUFLRSxPQUFMO0FBQ0EsUUFBSTBWLE1BQU0sR0FBRzNXLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCMFAsV0FBcEM7O0FBQ0EsUUFBSUQsTUFBSixFQUFXO0FBQ1AsVUFBRztBQUNDLFlBQUlFLEdBQUcsR0FBRyxJQUFJeFQsSUFBSixFQUFWO0FBQ0F3VCxXQUFHLENBQUNDLFVBQUosQ0FBZSxDQUFmO0FBQ0EsWUFBSXZXLEdBQUcsR0FBRyx1REFBcURvVyxNQUFyRCxHQUE0RCx3SEFBdEU7QUFDQSxZQUFJeFYsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmOztBQUNBLFlBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQjtBQUNBLGNBQUlpQyxJQUFJLEdBQUd4QixJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixDQUFYO0FBQ0FzQixjQUFJLEdBQUdBLElBQUksQ0FBQytULE1BQUQsQ0FBWCxDQUgyQixDQUkzQjs7QUFDQSxpQkFBT0gsU0FBUyxDQUFDN0ssTUFBVixDQUFpQjtBQUFDK0ssMkJBQWUsRUFBQzlULElBQUksQ0FBQzhUO0FBQXRCLFdBQWpCLEVBQXlEO0FBQUM3SyxnQkFBSSxFQUFDako7QUFBTixXQUF6RCxDQUFQO0FBQ0g7QUFDSixPQVpELENBYUEsT0FBTWhDLENBQU4sRUFBUTtBQUNKQyxlQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osS0FqQkQsTUFrQkk7QUFDQSxhQUFPLDJCQUFQO0FBQ0g7QUFDSixHQXpCVTtBQTBCWCx3QkFBc0IsWUFBVTtBQUM1QixTQUFLSyxPQUFMO0FBQ0EsUUFBSTBWLE1BQU0sR0FBRzNXLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCMFAsV0FBcEM7O0FBQ0EsUUFBSUQsTUFBSixFQUFXO0FBQ1AsYUFBUUgsU0FBUyxDQUFDblUsT0FBVixDQUFrQixFQUFsQixFQUFxQjtBQUFDMkYsWUFBSSxFQUFDO0FBQUMwTyx5QkFBZSxFQUFDLENBQUM7QUFBbEI7QUFBTixPQUFyQixDQUFSO0FBQ0gsS0FGRCxNQUdJO0FBQ0EsYUFBTywyQkFBUDtBQUNIO0FBRUo7QUFwQ1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBelcsTUFBTSxDQUFDMFEsTUFBUCxDQUFjO0FBQUM2RixXQUFTLEVBQUMsTUFBSUE7QUFBZixDQUFkO0FBQXlDLElBQUk1RixLQUFKO0FBQVUzUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMwUSxPQUFLLENBQUN6USxDQUFELEVBQUc7QUFBQ3lRLFNBQUssR0FBQ3pRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFNUMsTUFBTXFXLFNBQVMsR0FBRyxJQUFJNUYsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFlBQXJCLENBQWxCLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSTdRLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTRXLFdBQUo7QUFBZ0I5VyxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWixFQUFnQztBQUFDNlcsYUFBVyxDQUFDNVcsQ0FBRCxFQUFHO0FBQUM0VyxlQUFXLEdBQUM1VyxDQUFaO0FBQWM7O0FBQTlCLENBQWhDLEVBQWdFLENBQWhFO0FBQW1FLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBSWxLSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLGdDQUE4QixZQUFVO0FBQ3BDLFNBQUtFLE9BQUw7QUFDQSxRQUFJK0QsVUFBVSxHQUFHM0UsVUFBVSxDQUFDMEYsSUFBWCxDQUFnQixFQUFoQixFQUFvQkUsS0FBcEIsRUFBakI7QUFDQSxRQUFJbEUsV0FBVyxHQUFHLEVBQWxCO0FBQ0FsQixXQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWjs7QUFDQSxTQUFLWCxDQUFMLElBQVU2RSxVQUFWLEVBQXFCO0FBQ2pCLFVBQUlBLFVBQVUsQ0FBQzdFLENBQUQsQ0FBVixDQUFjb0MsZ0JBQWxCLEVBQW1DO0FBQy9CLFlBQUloQyxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2QnNFLFVBQVUsQ0FBQzdFLENBQUQsQ0FBVixDQUFjb0MsZ0JBQTNDLEdBQTRELGNBQXRFOztBQUNBLFlBQUc7QUFDQyxjQUFJcEIsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmOztBQUNBLGNBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixnQkFBSStDLFVBQVUsR0FBR3RDLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE5QyxDQUQyQixDQUUzQjs7QUFDQVEsdUJBQVcsR0FBR0EsV0FBVyxDQUFDaVYsTUFBWixDQUFtQnRULFVBQW5CLENBQWQ7QUFDSCxXQUpELE1BS0k7QUFDQTdDLG1CQUFPLENBQUNDLEdBQVIsQ0FBWUssUUFBUSxDQUFDUixVQUFyQjtBQUNIO0FBQ0osU0FWRCxDQVdBLE9BQU9DLENBQVAsRUFBUztBQUNMQyxpQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDtBQUNKO0FBQ0o7O0FBRUQsU0FBSytDLENBQUwsSUFBVTVCLFdBQVYsRUFBc0I7QUFDbEIsVUFBSUEsV0FBVyxDQUFDNEIsQ0FBRCxDQUFYLElBQWtCNUIsV0FBVyxDQUFDNEIsQ0FBRCxDQUFYLENBQWVkLE1BQXJDLEVBQ0lkLFdBQVcsQ0FBQzRCLENBQUQsQ0FBWCxDQUFlZCxNQUFmLEdBQXdCQyxVQUFVLENBQUNmLFdBQVcsQ0FBQzRCLENBQUQsQ0FBWCxDQUFlZCxNQUFoQixDQUFsQztBQUNQLEtBNUJtQyxDQThCcEM7OztBQUNBLFFBQUlELElBQUksR0FBRztBQUNQYixpQkFBVyxFQUFFQSxXQUROO0FBRVBrVixlQUFTLEVBQUUsSUFBSTVULElBQUo7QUFGSixLQUFYO0FBS0EsV0FBTzBULFdBQVcsQ0FBQ3RNLE1BQVosQ0FBbUI3SCxJQUFuQixDQUFQO0FBQ0gsR0F0Q1UsQ0F1Q1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBcERXLENBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSkEzQyxNQUFNLENBQUMwUSxNQUFQLENBQWM7QUFBQ29HLGFBQVcsRUFBQyxNQUFJQTtBQUFqQixDQUFkO0FBQTZDLElBQUluRyxLQUFKO0FBQVUzUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMwUSxPQUFLLENBQUN6USxDQUFELEVBQUc7QUFBQ3lRLFNBQUssR0FBQ3pRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFaEQsTUFBTTRXLFdBQVcsR0FBRyxJQUFJbkcsS0FBSyxDQUFDQyxVQUFWLENBQXFCLGFBQXJCLENBQXBCLEM7Ozs7Ozs7Ozs7O0FDRlAsSUFBSXFHLGFBQUo7O0FBQWtCalgsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVosRUFBbUQ7QUFBQ2dSLFNBQU8sQ0FBQy9RLENBQUQsRUFBRztBQUFDK1csaUJBQWEsR0FBQy9XLENBQWQ7QUFBZ0I7O0FBQTVCLENBQW5ELEVBQWlGLENBQWpGO0FBQWxCLElBQUlDLElBQUo7QUFBU0gsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDRSxNQUFJLENBQUNELENBQUQsRUFBRztBQUFDQyxRQUFJLEdBQUNELENBQUw7QUFBTzs7QUFBaEIsQ0FBMUIsRUFBNEMsQ0FBNUM7QUFFVEgsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCx3QkFBc0IsVUFBU29XLE1BQVQsRUFBaUI7QUFDbkMsVUFBTTVXLEdBQUcsYUFBTUcsR0FBTixTQUFUO0FBQ0FrQyxRQUFJLEdBQUc7QUFDSCxZQUFNdVUsTUFBTSxDQUFDelYsS0FEVjtBQUVILGNBQVE7QUFGTCxLQUFQO0FBSUEsVUFBTTBWLFNBQVMsR0FBRyxJQUFJL1QsSUFBSixHQUFXb0osT0FBWCxFQUFsQjtBQUNBNUwsV0FBTyxDQUFDQyxHQUFSLGlDQUFxQ3NXLFNBQXJDLGNBQWtEN1csR0FBbEQsd0JBQW1FYSxJQUFJLENBQUNvRSxTQUFMLENBQWU1QyxJQUFmLENBQW5FO0FBRUEsUUFBSXpCLFFBQVEsR0FBR2YsSUFBSSxDQUFDaVgsSUFBTCxDQUFVOVcsR0FBVixFQUFlO0FBQUNxQztBQUFELEtBQWYsQ0FBZjtBQUNBL0IsV0FBTyxDQUFDQyxHQUFSLG1DQUF1Q3NXLFNBQXZDLGNBQW9EN1csR0FBcEQsZUFBNERhLElBQUksQ0FBQ29FLFNBQUwsQ0FBZXJFLFFBQWYsQ0FBNUQ7O0FBQ0EsUUFBSUEsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQWdDO0FBQzVCLFVBQUlpQyxJQUFJLEdBQUd6QixRQUFRLENBQUN5QixJQUFwQjtBQUNBLFVBQUlBLElBQUksQ0FBQzBVLElBQVQsRUFDSSxNQUFNLElBQUl0WCxNQUFNLENBQUN1WCxLQUFYLENBQWlCM1UsSUFBSSxDQUFDMFUsSUFBdEIsRUFBNEJsVyxJQUFJLENBQUNDLEtBQUwsQ0FBV3VCLElBQUksQ0FBQzRVLE9BQWhCLEVBQXlCQyxPQUFyRCxDQUFOO0FBQ0osYUFBT3RXLFFBQVEsQ0FBQ3lCLElBQVQsQ0FBYzhVLE1BQXJCO0FBQ0g7QUFDSixHQWxCVTtBQW1CWCx5QkFBdUIsVUFBU0MsSUFBVCxFQUFlQyxJQUFmLEVBQXFCO0FBQ3hDLFVBQU1yWCxHQUFHLGFBQU1HLEdBQU4sY0FBYWtYLElBQWIsQ0FBVDtBQUNBaFYsUUFBSSxHQUFHO0FBQ0gsb0NBQ08rVSxJQURQO0FBRUksb0JBQVkzWCxNQUFNLENBQUNpSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QjhFLE9BRnZDO0FBR0ksb0JBQVk7QUFIaEI7QUFERyxLQUFQO0FBT0EsUUFBSTdLLFFBQVEsR0FBR2YsSUFBSSxDQUFDaVgsSUFBTCxDQUFVOVcsR0FBVixFQUFlO0FBQUNxQztBQUFELEtBQWYsQ0FBZjs7QUFDQSxRQUFJekIsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQWdDO0FBQzVCLGFBQU9TLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLENBQVA7QUFDSDtBQUNKLEdBaENVO0FBaUNYLDBCQUF3QixVQUFTdVcsS0FBVCxFQUFnQnZOLElBQWhCLEVBQXNCc04sSUFBdEIsRUFBOEM7QUFBQSxRQUFsQkUsVUFBa0IsdUVBQVAsS0FBTztBQUNsRSxVQUFNdlgsR0FBRyxhQUFNRyxHQUFOLGNBQWFrWCxJQUFiLENBQVQ7QUFDQWhWLFFBQUkscUJBQU9pVixLQUFQO0FBQ0Esa0JBQVk7QUFDUixnQkFBUXZOLElBREE7QUFFUixvQkFBWXRLLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEUsT0FGM0I7QUFHUiwwQkFBa0I4TCxVQUhWO0FBSVIsb0JBQVk7QUFKSjtBQURaLE1BQUo7QUFRQSxRQUFJM1csUUFBUSxHQUFHZixJQUFJLENBQUNpWCxJQUFMLENBQVU5VyxHQUFWLEVBQWU7QUFBQ3FDO0FBQUQsS0FBZixDQUFmOztBQUNBLFFBQUl6QixRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBZ0M7QUFDNUIsYUFBT1MsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJ5VyxZQUFwQztBQUNIO0FBQ0o7QUEvQ1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ0ZBLElBQUliLGFBQUo7O0FBQWtCalgsTUFBTSxDQUFDQyxJQUFQLENBQVksc0NBQVosRUFBbUQ7QUFBQ2dSLFNBQU8sQ0FBQy9RLENBQUQsRUFBRztBQUFDK1csaUJBQWEsR0FBQy9XLENBQWQ7QUFBZ0I7O0FBQTVCLENBQW5ELEVBQWlGLENBQWpGO0FBQWxCLElBQUlILE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsSUFBSjtBQUFTSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNFLE1BQUksQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFFBQUksR0FBQ0QsQ0FBTDtBQUFPOztBQUFoQixDQUExQixFQUE0QyxDQUE1QztBQUErQyxJQUFJNlgsU0FBSjtBQUFjL1gsTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVosRUFBOEI7QUFBQzhYLFdBQVMsQ0FBQzdYLENBQUQsRUFBRztBQUFDNlgsYUFBUyxHQUFDN1gsQ0FBVjtBQUFZOztBQUExQixDQUE5QixFQUEwRCxDQUExRDtBQUE2RCxJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUlsTjtBQUVBSCxNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYLDRCQUEwQixZQUFVO0FBQ2hDLFNBQUtFLE9BQUw7O0FBQ0EsUUFBRztBQUNDLFVBQUlWLEdBQUcsR0FBR0csR0FBRyxHQUFHLGdCQUFoQjtBQUNBLFVBQUlTLFFBQVEsR0FBR2YsSUFBSSxDQUFDSyxHQUFMLENBQVNGLEdBQVQsQ0FBZjtBQUNBLFVBQUkwWCxTQUFTLEdBQUc3VyxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBN0MsQ0FIRCxDQUlDOztBQUVBLFVBQUkyVyxtQkFBbUIsR0FBRyxJQUFJQyxHQUFKLENBQVFILFNBQVMsQ0FBQ2pTLElBQVYsQ0FDOUI7QUFBQywyQkFBa0I7QUFBQ1EsYUFBRyxFQUFDLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsU0FBdkI7QUFBTDtBQUFuQixPQUQ4QixFQUVoQ04sS0FGZ0MsR0FFeEJFLEdBRndCLENBRW5CbEIsQ0FBRCxJQUFNQSxDQUFDLENBQUNtVCxVQUZZLENBQVIsQ0FBMUI7QUFJQSxVQUFJQyxXQUFXLEdBQUcsRUFBbEI7O0FBQ0EsVUFBSUosU0FBUyxDQUFDdlYsTUFBVixHQUFtQixDQUF2QixFQUF5QjtBQUNyQjtBQUNBLGNBQU00VixhQUFhLEdBQUdOLFNBQVMsQ0FBQ3BSLGFBQVYsR0FBMEJvQyx5QkFBMUIsRUFBdEI7O0FBQ0EsYUFBSyxJQUFJckYsQ0FBVCxJQUFjc1UsU0FBZCxFQUF3QjtBQUNwQixjQUFJTSxRQUFRLEdBQUdOLFNBQVMsQ0FBQ3RVLENBQUQsQ0FBeEI7QUFDQTRVLGtCQUFRLENBQUNILFVBQVQsR0FBc0J0TixRQUFRLENBQUN5TixRQUFRLENBQUNDLEVBQVYsQ0FBOUI7O0FBQ0EsY0FBSUQsUUFBUSxDQUFDSCxVQUFULEdBQXNCLENBQXRCLElBQTJCLENBQUNGLG1CQUFtQixDQUFDTyxHQUFwQixDQUF3QkYsUUFBUSxDQUFDSCxVQUFqQyxDQUFoQyxFQUE4RTtBQUMxRSxnQkFBRztBQUNDLGtCQUFJN1gsR0FBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQU4sR0FBd0I2WCxRQUFRLENBQUNILFVBQWpDLEdBQTRDLFdBQXREO0FBQ0Esa0JBQUlqWCxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7O0FBQ0Esa0JBQUlZLFFBQVEsQ0FBQ1IsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixvQkFBSW9RLFFBQVEsR0FBRzNQLElBQUksQ0FBQ0MsS0FBTCxDQUFXRixRQUFRLENBQUNHLE9BQXBCLEVBQTZCQyxNQUE1Qzs7QUFDQSxvQkFBSXdQLFFBQVEsQ0FBQzJILFdBQVQsSUFBeUIzSCxRQUFRLENBQUMySCxXQUFULElBQXdCSCxRQUFRLENBQUNDLEVBQTlELEVBQWtFO0FBQzlERCwwQkFBUSxDQUFDeEgsUUFBVCxHQUFvQkEsUUFBUSxDQUFDQSxRQUE3QjtBQUNIO0FBQ0o7O0FBQ0R1SCwyQkFBYSxDQUFDdlMsSUFBZCxDQUFtQjtBQUFDcVMsMEJBQVUsRUFBRUcsUUFBUSxDQUFDSDtBQUF0QixlQUFuQixFQUFzRHpNLE1BQXRELEdBQStEQyxTQUEvRCxDQUF5RTtBQUFDQyxvQkFBSSxFQUFDME07QUFBTixlQUF6RTtBQUNBRix5QkFBVyxDQUFDcE8sSUFBWixDQUFpQnNPLFFBQVEsQ0FBQ0gsVUFBMUI7QUFDSCxhQVhELENBWUEsT0FBTXhYLENBQU4sRUFBUTtBQUNKMFgsMkJBQWEsQ0FBQ3ZTLElBQWQsQ0FBbUI7QUFBQ3FTLDBCQUFVLEVBQUVHLFFBQVEsQ0FBQ0g7QUFBdEIsZUFBbkIsRUFBc0R6TSxNQUF0RCxHQUErREMsU0FBL0QsQ0FBeUU7QUFBQ0Msb0JBQUksRUFBQzBNO0FBQU4sZUFBekU7QUFDQUYseUJBQVcsQ0FBQ3BPLElBQVosQ0FBaUJzTyxRQUFRLENBQUNILFVBQTFCO0FBQ0F2WCxxQkFBTyxDQUFDQyxHQUFSLENBQVlGLENBQUMsQ0FBQ08sUUFBRixDQUFXRyxPQUF2QjtBQUNIO0FBQ0o7QUFDSjs7QUFDRGdYLHFCQUFhLENBQUN2UyxJQUFkLENBQW1CO0FBQUNxUyxvQkFBVSxFQUFDO0FBQUNPLGdCQUFJLEVBQUNOO0FBQU4sV0FBWjtBQUFnQ08seUJBQWUsRUFBQztBQUFDRCxnQkFBSSxFQUFDLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsU0FBdkI7QUFBTjtBQUFoRCxTQUFuQixFQUNLaE0sTUFETCxDQUNZO0FBQUNkLGNBQUksRUFBRTtBQUFDLCtCQUFtQjtBQUFwQjtBQUFQLFNBRFo7QUFFQXlNLHFCQUFhLENBQUNqSixPQUFkO0FBQ0g7O0FBQ0QsYUFBTyxJQUFQO0FBQ0gsS0ExQ0QsQ0EyQ0EsT0FBT3pPLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0osR0FqRFU7QUFrRFgsa0NBQWdDLFlBQVU7QUFDdEMsU0FBS0ssT0FBTDtBQUNBLFFBQUlnWCxTQUFTLEdBQUdELFNBQVMsQ0FBQ2pTLElBQVYsQ0FBZTtBQUFDLHlCQUFrQjtBQUFDNFMsWUFBSSxFQUFDLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsU0FBdkI7QUFBTjtBQUFuQixLQUFmLEVBQTZFMVMsS0FBN0UsRUFBaEI7O0FBRUEsUUFBSWdTLFNBQVMsSUFBS0EsU0FBUyxDQUFDdlYsTUFBVixHQUFtQixDQUFyQyxFQUF3QztBQUNwQyxXQUFLLElBQUlpQixDQUFULElBQWNzVSxTQUFkLEVBQXdCO0FBQ3BCLFlBQUluTixRQUFRLENBQUNtTixTQUFTLENBQUN0VSxDQUFELENBQVQsQ0FBYXlVLFVBQWQsQ0FBUixHQUFvQyxDQUF4QyxFQUEwQztBQUN0QyxjQUFHO0FBQ0M7QUFDQSxnQkFBSTdYLEdBQUcsR0FBR0csR0FBRyxHQUFHLGlCQUFOLEdBQXdCdVgsU0FBUyxDQUFDdFUsQ0FBRCxDQUFULENBQWF5VSxVQUFyQyxHQUFnRCxXQUExRDtBQUNBLGdCQUFJalgsUUFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFmO0FBQ0EsZ0JBQUlnWSxRQUFRLEdBQUc7QUFBQ0gsd0JBQVUsRUFBRUgsU0FBUyxDQUFDdFUsQ0FBRCxDQUFULENBQWF5VTtBQUExQixhQUFmOztBQUNBLGdCQUFJalgsUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCLGtCQUFJa1ksUUFBUSxHQUFHelgsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTVDO0FBQ0FnWCxzQkFBUSxDQUFDTSxRQUFULEdBQW9CQSxRQUFwQjtBQUNIOztBQUVEdFksZUFBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQU4sR0FBd0J1WCxTQUFTLENBQUN0VSxDQUFELENBQVQsQ0FBYXlVLFVBQXJDLEdBQWdELFFBQXREO0FBQ0FqWCxvQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYOztBQUNBLGdCQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0Isa0JBQUlnUixLQUFLLEdBQUd2USxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBekM7QUFDQWdYLHNCQUFRLENBQUM1RyxLQUFULEdBQWlCbUgsYUFBYSxDQUFDbkgsS0FBRCxDQUE5QjtBQUNIOztBQUVEcFIsZUFBRyxHQUFHRyxHQUFHLEdBQUcsaUJBQU4sR0FBd0J1WCxTQUFTLENBQUN0VSxDQUFELENBQVQsQ0FBYXlVLFVBQXJDLEdBQWdELFFBQXREO0FBQ0FqWCxvQkFBUSxHQUFHZixJQUFJLENBQUNLLEdBQUwsQ0FBU0YsR0FBVCxDQUFYOztBQUNBLGdCQUFJWSxRQUFRLENBQUNSLFVBQVQsSUFBdUIsR0FBM0IsRUFBK0I7QUFDM0Isa0JBQUlvWSxLQUFLLEdBQUczWCxJQUFJLENBQUNDLEtBQUwsQ0FBV0YsUUFBUSxDQUFDRyxPQUFwQixFQUE2QkMsTUFBekM7QUFDQWdYLHNCQUFRLENBQUNRLEtBQVQsR0FBaUJBLEtBQWpCO0FBQ0g7O0FBRURSLG9CQUFRLENBQUNTLFNBQVQsR0FBcUIsSUFBSTNWLElBQUosRUFBckI7QUFDQTJVLHFCQUFTLENBQUNyTCxNQUFWLENBQWlCO0FBQUN5TCx3QkFBVSxFQUFFSCxTQUFTLENBQUN0VSxDQUFELENBQVQsQ0FBYXlVO0FBQTFCLGFBQWpCLEVBQXdEO0FBQUN2TSxrQkFBSSxFQUFDME07QUFBTixhQUF4RDtBQUNILFdBMUJELENBMkJBLE9BQU0zWCxDQUFOLEVBQVEsQ0FFUDtBQUNKO0FBQ0o7QUFDSjs7QUFDRCxXQUFPLElBQVA7QUFDSDtBQTNGVSxDQUFmOztBQThGQSxNQUFNa1ksYUFBYSxHQUFJbkgsS0FBRCxJQUFXO0FBQzdCLE1BQUksQ0FBQ0EsS0FBTCxFQUFZO0FBQ1IsV0FBTyxFQUFQO0FBQ0g7O0FBRUQsTUFBSXNILE1BQU0sR0FBR3RILEtBQUssQ0FBQ3hMLEdBQU4sQ0FBVytTLElBQUQsSUFBVUEsSUFBSSxDQUFDQyxLQUF6QixDQUFiO0FBQ0EsTUFBSUMsY0FBYyxHQUFHLEVBQXJCO0FBQ0EsTUFBSUMsbUJBQW1CLEdBQUcsRUFBMUI7QUFDQWhaLFlBQVUsQ0FBQzBGLElBQVgsQ0FBZ0I7QUFBQ3ZELHFCQUFpQixFQUFFO0FBQUMrRCxTQUFHLEVBQUUwUztBQUFOO0FBQXBCLEdBQWhCLEVBQW9EaFcsT0FBcEQsQ0FBNkRiLFNBQUQsSUFBZTtBQUN2RWdYLGtCQUFjLENBQUNoWCxTQUFTLENBQUNJLGlCQUFYLENBQWQsR0FBOEM7QUFDMUM4VyxhQUFPLEVBQUVsWCxTQUFTLENBQUNtTCxXQUFWLENBQXNCK0wsT0FEVztBQUUxQ3RZLGFBQU8sRUFBRW9CLFNBQVMsQ0FBQ3BCLE9BRnVCO0FBRzFDMk0sWUFBTSxFQUFFN0ssVUFBVSxDQUFDVixTQUFTLENBQUN1TCxNQUFYLENBSHdCO0FBSTFDNEwscUJBQWUsRUFBRXpXLFVBQVUsQ0FBQ1YsU0FBUyxDQUFDd0wsZ0JBQVgsQ0FKZTtBQUsxQzRMLG9CQUFjLEVBQUUxVyxVQUFVLENBQUNWLFNBQVMsQ0FBQ3dMLGdCQUFYO0FBTGdCLEtBQTlDO0FBT0F5TCx1QkFBbUIsQ0FBQ2pYLFNBQVMsQ0FBQ0csZ0JBQVgsQ0FBbkIsR0FBa0RILFNBQVMsQ0FBQ0ksaUJBQTVEO0FBQ0gsR0FURDtBQVVBeVcsUUFBTSxDQUFDaFcsT0FBUCxDQUFnQmtXLEtBQUQsSUFBVztBQUN0QixRQUFJLENBQUNDLGNBQWMsQ0FBQ0QsS0FBRCxDQUFuQixFQUE0QjtBQUN4QjtBQUNBLFVBQUk1WSxHQUFHLGFBQU1HLEdBQU4saUNBQWdDeVksS0FBaEMsaUJBQVA7QUFDQSxVQUFJcFgsV0FBSjtBQUNBLFVBQUkwWCxXQUFXLEdBQUcsQ0FBbEI7O0FBQ0EsVUFBRztBQUNDLFlBQUl0WSxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWY7O0FBQ0EsWUFBSVksUUFBUSxDQUFDUixVQUFULElBQXVCLEdBQTNCLEVBQStCO0FBQzNCb0IscUJBQVcsR0FBR1gsSUFBSSxDQUFDQyxLQUFMLENBQVdGLFFBQVEsQ0FBQ0csT0FBcEIsRUFBNkJDLE1BQTNDOztBQUNBLGNBQUlRLFdBQVcsSUFBSUEsV0FBVyxDQUFDVyxNQUFaLEdBQXFCLENBQXhDLEVBQTJDO0FBQ3ZDWCx1QkFBVyxDQUFDa0IsT0FBWixDQUFxQlMsVUFBRCxJQUFnQjtBQUNoQyxrQkFBSWIsTUFBTSxHQUFHQyxVQUFVLENBQUNZLFVBQVUsQ0FBQ2IsTUFBWixDQUF2Qjs7QUFDQSxrQkFBSXdXLG1CQUFtQixDQUFDM1YsVUFBVSxDQUFDd0csaUJBQVosQ0FBdkIsRUFBdUQ7QUFDbkQ7QUFDQSxvQkFBSTlILFNBQVMsR0FBR2dYLGNBQWMsQ0FBQ0MsbUJBQW1CLENBQUMzVixVQUFVLENBQUN3RyxpQkFBWixDQUFwQixDQUE5QjtBQUNBOUgseUJBQVMsQ0FBQ29YLGNBQVYsSUFBNEIzVyxNQUE1Qjs7QUFDQSxvQkFBSVQsU0FBUyxDQUFDd0wsZ0JBQVYsSUFBOEIsQ0FBbEMsRUFBb0M7QUFBRTtBQUNsQzZMLDZCQUFXLElBQUs1VyxNQUFNLEdBQUNULFNBQVMsQ0FBQ21YLGVBQWxCLEdBQXFDblgsU0FBUyxDQUFDdUwsTUFBOUQ7QUFDSDtBQUVKLGVBUkQsTUFRTztBQUNILG9CQUFJdkwsU0FBUyxHQUFHL0IsVUFBVSxDQUFDZ0MsT0FBWCxDQUFtQjtBQUFDRSxrQ0FBZ0IsRUFBRW1CLFVBQVUsQ0FBQ3dHO0FBQTlCLGlCQUFuQixDQUFoQjs7QUFDQSxvQkFBSTlILFNBQVMsSUFBSUEsU0FBUyxDQUFDd0wsZ0JBQVYsSUFBOEIsQ0FBL0MsRUFBaUQ7QUFBRTtBQUMvQzZMLDZCQUFXLElBQUs1VyxNQUFNLEdBQUNDLFVBQVUsQ0FBQ1YsU0FBUyxDQUFDd0wsZ0JBQVgsQ0FBbEIsR0FBa0Q5SyxVQUFVLENBQUNWLFNBQVMsQ0FBQ3VMLE1BQVgsQ0FBM0U7QUFDSDtBQUNKO0FBQ0osYUFoQkQ7QUFpQkg7QUFDSjtBQUNKLE9BeEJELENBeUJBLE9BQU8vTSxDQUFQLEVBQVM7QUFDTEMsZUFBTyxDQUFDQyxHQUFSLENBQVlGLENBQVo7QUFDSDs7QUFDRHdZLG9CQUFjLENBQUNELEtBQUQsQ0FBZCxHQUF3QjtBQUFDTSxtQkFBVyxFQUFFQTtBQUFkLE9BQXhCO0FBQ0g7QUFDSixHQXBDRDtBQXFDQSxTQUFPOUgsS0FBSyxDQUFDeEwsR0FBTixDQUFXK1MsSUFBRCxJQUFVO0FBQ3ZCLFFBQUlDLEtBQUssR0FBR0MsY0FBYyxDQUFDRixJQUFJLENBQUNDLEtBQU4sQ0FBMUI7QUFDQSxRQUFJTSxXQUFXLEdBQUdOLEtBQUssQ0FBQ00sV0FBeEI7O0FBQ0EsUUFBSUEsV0FBVyxJQUFJNUssU0FBbkIsRUFBOEI7QUFDMUI7QUFDQTRLLGlCQUFXLEdBQUdOLEtBQUssQ0FBQ0ksZUFBTixHQUF3QkosS0FBSyxDQUFDSyxjQUFOLEdBQXFCTCxLQUFLLENBQUNJLGVBQTVCLEdBQStDSixLQUFLLENBQUN4TCxNQUE1RSxHQUFvRixDQUFsRztBQUNIOztBQUNELDZCQUFXdUwsSUFBWDtBQUFpQk87QUFBakI7QUFDSCxHQVJNLENBQVA7QUFTSCxDQWhFRCxDOzs7Ozs7Ozs7OztBQ3BHQSxJQUFJelosTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJNlgsU0FBSjtBQUFjL1gsTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVosRUFBOEI7QUFBQzhYLFdBQVMsQ0FBQzdYLENBQUQsRUFBRztBQUFDNlgsYUFBUyxHQUFDN1gsQ0FBVjtBQUFZOztBQUExQixDQUE5QixFQUEwRCxDQUExRDtBQUE2RCxJQUFJdVosS0FBSjtBQUFVelosTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDd1osT0FBSyxDQUFDdlosQ0FBRCxFQUFHO0FBQUN1WixTQUFLLEdBQUN2WixDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBSXJKSCxNQUFNLENBQUN5VyxPQUFQLENBQWUsZ0JBQWYsRUFBaUMsWUFBWTtBQUN6QyxTQUFPdUIsU0FBUyxDQUFDalMsSUFBVixDQUFlLEVBQWYsRUFBbUI7QUFBQ2lDLFFBQUksRUFBQztBQUFDb1EsZ0JBQVUsRUFBQyxDQUFDO0FBQWI7QUFBTixHQUFuQixDQUFQO0FBQ0gsQ0FGRDtBQUlBcFksTUFBTSxDQUFDeVcsT0FBUCxDQUFlLGVBQWYsRUFBZ0MsVUFBVStCLEVBQVYsRUFBYTtBQUN6Q2tCLE9BQUssQ0FBQ2xCLEVBQUQsRUFBS21CLE1BQUwsQ0FBTDtBQUNBLFNBQU8zQixTQUFTLENBQUNqUyxJQUFWLENBQWU7QUFBQ3FTLGNBQVUsRUFBQ0k7QUFBWixHQUFmLENBQVA7QUFDSCxDQUhELEU7Ozs7Ozs7Ozs7O0FDUkF2WSxNQUFNLENBQUMwUSxNQUFQLENBQWM7QUFBQ3FILFdBQVMsRUFBQyxNQUFJQTtBQUFmLENBQWQ7QUFBeUMsSUFBSXBILEtBQUo7QUFBVTNRLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzBRLE9BQUssQ0FBQ3pRLENBQUQsRUFBRztBQUFDeVEsU0FBSyxHQUFDelEsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUU1QyxNQUFNNlgsU0FBUyxHQUFHLElBQUlwSCxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsV0FBckIsQ0FBbEIsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJN1EsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJeVEsS0FBSjtBQUFVM1EsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDMFEsT0FBSyxDQUFDelEsQ0FBRCxFQUFHO0FBQUN5USxTQUFLLEdBQUN6USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlrRSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0JzVixXQUEvQixFQUEyQ0Msb0JBQTNDO0FBQWdFNVosTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDbUUsa0JBQWdCLENBQUNsRSxDQUFELEVBQUc7QUFBQ2tFLG9CQUFnQixHQUFDbEUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDbUUsV0FBUyxDQUFDbkUsQ0FBRCxFQUFHO0FBQUNtRSxhQUFTLEdBQUNuRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FeVosYUFBVyxDQUFDelosQ0FBRCxFQUFHO0FBQUN5WixlQUFXLEdBQUN6WixDQUFaO0FBQWMsR0FBaEc7O0FBQWlHMFosc0JBQW9CLENBQUMxWixDQUFELEVBQUc7QUFBQzBaLHdCQUFvQixHQUFDMVosQ0FBckI7QUFBdUI7O0FBQWhKLENBQTVCLEVBQThLLENBQTlLO0FBQWlMLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQTdDLEVBQTJFLENBQTNFO0FBQThFLElBQUlpRSxhQUFKO0FBQWtCbkUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVosRUFBNEQ7QUFBQ2tFLGVBQWEsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsaUJBQWEsR0FBQ2pFLENBQWQ7QUFBZ0I7O0FBQWxDLENBQTVELEVBQWdHLENBQWhHO0FBQW1HLElBQUkyWixNQUFKO0FBQVc3WixNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDNFosUUFBTSxDQUFDM1osQ0FBRCxFQUFHO0FBQUMyWixVQUFNLEdBQUMzWixDQUFQO0FBQVM7O0FBQXBCLENBQXJDLEVBQTJELENBQTNEO0FBQThELElBQUk0WixpQkFBSjtBQUFzQjlaLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQzZaLG1CQUFpQixDQUFDNVosQ0FBRCxFQUFHO0FBQUM0WixxQkFBaUIsR0FBQzVaLENBQWxCO0FBQW9COztBQUExQyxDQUE1QixFQUF3RSxDQUF4RTtBQUEyRSxJQUFJNlosWUFBSjtBQUFpQi9aLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQzhaLGNBQVksQ0FBQzdaLENBQUQsRUFBRztBQUFDNlosZ0JBQVksR0FBQzdaLENBQWI7QUFBZTs7QUFBaEMsQ0FBNUIsRUFBOEQsQ0FBOUQ7QUFBaUUsSUFBSStELFNBQUo7QUFBY2pFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUNnRSxXQUFTLENBQUMvRCxDQUFELEVBQUc7QUFBQytELGFBQVMsR0FBQy9ELENBQVY7QUFBWTs7QUFBMUIsQ0FBckMsRUFBaUUsQ0FBakU7QUFBb0UsSUFBSWdFLEtBQUo7QUFBVWxFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNpRSxPQUFLLENBQUNoRSxDQUFELEVBQUc7QUFBQ2dFLFNBQUssR0FBQ2hFLENBQU47QUFBUTs7QUFBbEIsQ0FBbkMsRUFBdUQsQ0FBdkQ7O0FBQTBELElBQUk4WixDQUFKOztBQUFNaGEsTUFBTSxDQUFDQyxJQUFQLENBQVksUUFBWixFQUFxQjtBQUFDZ1IsU0FBTyxDQUFDL1EsQ0FBRCxFQUFHO0FBQUM4WixLQUFDLEdBQUM5WixDQUFGO0FBQUk7O0FBQWhCLENBQXJCLEVBQXVDLEVBQXZDO0FBV3Y5QixNQUFNK1osaUJBQWlCLEdBQUcsSUFBMUI7O0FBRUEsTUFBTUMsYUFBYSxHQUFHLENBQUNqUyxXQUFELEVBQWNrUyxZQUFkLEtBQStCO0FBQ2pELE1BQUlDLFVBQVUsR0FBRyxFQUFqQjtBQUNBLFFBQU1DLElBQUksR0FBRztBQUFDQyxRQUFJLEVBQUUsQ0FDaEI7QUFBRWxVLFlBQU0sRUFBRTtBQUFFbVUsV0FBRyxFQUFFdFM7QUFBUDtBQUFWLEtBRGdCLEVBRWhCO0FBQUU3QixZQUFNLEVBQUU7QUFBRW9VLFlBQUksRUFBRUw7QUFBUjtBQUFWLEtBRmdCO0FBQVAsR0FBYjtBQUdBLFFBQU1NLE9BQU8sR0FBRztBQUFDMVMsUUFBSSxFQUFDO0FBQUMzQixZQUFNLEVBQUU7QUFBVDtBQUFOLEdBQWhCO0FBQ0FuQyxXQUFTLENBQUM2QixJQUFWLENBQWV1VSxJQUFmLEVBQXFCSSxPQUFyQixFQUE4QnpYLE9BQTlCLENBQXVDbUQsS0FBRCxJQUFXO0FBQzdDaVUsY0FBVSxDQUFDalUsS0FBSyxDQUFDQyxNQUFQLENBQVYsR0FBMkI7QUFDdkJBLFlBQU0sRUFBRUQsS0FBSyxDQUFDQyxNQURTO0FBRXZCTCxxQkFBZSxFQUFFSSxLQUFLLENBQUNKLGVBRkE7QUFHdkIwRSxxQkFBZSxFQUFFdEUsS0FBSyxDQUFDc0UsZUFIQTtBQUl2QksscUJBQWUsRUFBRTNFLEtBQUssQ0FBQzJFLGVBSkE7QUFLdkIvRixnQkFBVSxFQUFFb0IsS0FBSyxDQUFDcEIsVUFMSztBQU12QjVCLFVBQUksRUFBRWdELEtBQUssQ0FBQ2hEO0FBTlcsS0FBM0I7QUFRSCxHQVREO0FBV0FrQixXQUFTLENBQUN5QixJQUFWLENBQWV1VSxJQUFmLEVBQXFCSSxPQUFyQixFQUE4QnpYLE9BQTlCLENBQXVDbUQsS0FBRCxJQUFXO0FBQzdDLFFBQUksQ0FBQ2lVLFVBQVUsQ0FBQ2pVLEtBQUssQ0FBQ0MsTUFBUCxDQUFmLEVBQStCO0FBQzNCZ1UsZ0JBQVUsQ0FBQ2pVLEtBQUssQ0FBQ0MsTUFBUCxDQUFWLEdBQTJCO0FBQUVBLGNBQU0sRUFBRUQsS0FBSyxDQUFDQztBQUFoQixPQUEzQjtBQUNBeEYsYUFBTyxDQUFDQyxHQUFSLGlCQUFxQnNGLEtBQUssQ0FBQ0MsTUFBM0I7QUFDSDs7QUFDRDRULEtBQUMsQ0FBQ1UsTUFBRixDQUFTTixVQUFVLENBQUNqVSxLQUFLLENBQUNDLE1BQVAsQ0FBbkIsRUFBbUM7QUFDL0IwRCxnQkFBVSxFQUFFM0QsS0FBSyxDQUFDMkQsVUFEYTtBQUUvQjZDLHNCQUFnQixFQUFFeEcsS0FBSyxDQUFDd0csZ0JBRk87QUFHL0JsRyxjQUFRLEVBQUVOLEtBQUssQ0FBQ00sUUFIZTtBQUkvQjRFLGtCQUFZLEVBQUVsRixLQUFLLENBQUNrRjtBQUpXLEtBQW5DO0FBTUgsR0FYRDtBQVlBLFNBQU8rTyxVQUFQO0FBQ0gsQ0E5QkQ7O0FBZ0NBLE1BQU1PLGlCQUFpQixHQUFHLENBQUNDLFlBQUQsRUFBZTdVLGVBQWYsS0FBbUM7QUFDekQsTUFBSThVLGNBQWMsR0FBR2QsWUFBWSxDQUFDM1gsT0FBYixDQUNqQjtBQUFDOFcsU0FBSyxFQUFDMEIsWUFBUDtBQUFxQjlKLFlBQVEsRUFBQy9LLGVBQTlCO0FBQStDK1UsZUFBVyxFQUFFLENBQUM7QUFBN0QsR0FEaUIsQ0FBckI7QUFFQSxNQUFJQyxpQkFBaUIsR0FBR2hiLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QkQsV0FBL0M7QUFDQSxNQUFJK1MsU0FBUyxHQUFHLEVBQWhCOztBQUNBLE1BQUlILGNBQUosRUFBb0I7QUFDaEJHLGFBQVMsR0FBR2hCLENBQUMsQ0FBQ2lCLElBQUYsQ0FBT0osY0FBUCxFQUF1QixDQUFDLFdBQUQsRUFBYyxZQUFkLENBQXZCLENBQVo7QUFDSCxHQUZELE1BRU87QUFDSEcsYUFBUyxHQUFHO0FBQ1JFLGVBQVMsRUFBRSxDQURIO0FBRVJDLGdCQUFVLEVBQUU7QUFGSixLQUFaO0FBSUg7O0FBQ0QsU0FBT0gsU0FBUDtBQUNILENBZEQ7O0FBZ0JBamIsTUFBTSxDQUFDZSxPQUFQLENBQWU7QUFDWCw0Q0FBMEMsWUFBVTtBQUNoRCxRQUFJLENBQUNzYSxpQkFBTCxFQUF1QjtBQUNuQixVQUFJO0FBQ0EsWUFBSUMsU0FBUyxHQUFHalksSUFBSSxDQUFDd1QsR0FBTCxFQUFoQjtBQUNBd0UseUJBQWlCLEdBQUcsSUFBcEI7QUFDQXhhLGVBQU8sQ0FBQ0MsR0FBUixDQUFZLDhCQUFaO0FBQ0EsYUFBS0csT0FBTDtBQUNBLFlBQUkrRCxVQUFVLEdBQUczRSxVQUFVLENBQUMwRixJQUFYLENBQWdCLEVBQWhCLEVBQW9CRSxLQUFwQixFQUFqQjtBQUNBLFlBQUltVSxZQUFZLEdBQUdwYSxNQUFNLENBQUNzSSxJQUFQLENBQVkseUJBQVosQ0FBbkI7QUFDQSxZQUFJaVQsY0FBYyxHQUFHekIsTUFBTSxDQUFDelgsT0FBUCxDQUFlO0FBQUMySixpQkFBTyxFQUFFaE0sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFqQyxTQUFmLENBQXJCO0FBQ0EsWUFBSTlELFdBQVcsR0FBSXFULGNBQWMsSUFBRUEsY0FBYyxDQUFDQyw4QkFBaEMsR0FBZ0VELGNBQWMsQ0FBQ0MsOEJBQS9FLEdBQThHeGIsTUFBTSxDQUFDaUgsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUF2SjtBQUNBa1Msb0JBQVksR0FBRzdOLElBQUksQ0FBQ2tQLEdBQUwsQ0FBU3ZULFdBQVcsR0FBR2dTLGlCQUF2QixFQUEwQ0UsWUFBMUMsQ0FBZjtBQUNBLGNBQU1zQixlQUFlLEdBQUcxQixZQUFZLENBQUNwVCxhQUFiLEdBQTZCK1UsdUJBQTdCLEVBQXhCO0FBRUEsWUFBSUMsYUFBYSxHQUFHLEVBQXBCO0FBQ0E1VyxrQkFBVSxDQUFDL0IsT0FBWCxDQUFvQmIsU0FBRCxJQUFld1osYUFBYSxDQUFDeFosU0FBUyxDQUFDcEIsT0FBWCxDQUFiLEdBQW1Db0IsU0FBckUsRUFiQSxDQWVBOztBQUNBLFlBQUlpWSxVQUFVLEdBQUdGLGFBQWEsQ0FBQ2pTLFdBQUQsRUFBY2tTLFlBQWQsQ0FBOUIsQ0FoQkEsQ0FrQkE7O0FBQ0EsWUFBSXlCLGtCQUFrQixHQUFHLEVBQXpCOztBQUVBNUIsU0FBQyxDQUFDaFgsT0FBRixDQUFVb1gsVUFBVixFQUFzQixDQUFDalUsS0FBRCxFQUFRMlUsV0FBUixLQUF3QjtBQUMxQyxjQUFJL1UsZUFBZSxHQUFHSSxLQUFLLENBQUNKLGVBQTVCO0FBQ0EsY0FBSThWLGVBQWUsR0FBRyxJQUFJM0QsR0FBSixDQUFRL1IsS0FBSyxDQUFDcEIsVUFBZCxDQUF0QjtBQUNBLGNBQUkrVyxhQUFhLEdBQUczWCxhQUFhLENBQUMvQixPQUFkLENBQXNCO0FBQUN3SSx3QkFBWSxFQUFDekUsS0FBSyxDQUFDQztBQUFwQixXQUF0QixDQUFwQjtBQUNBLGNBQUkyVixnQkFBZ0IsR0FBRyxDQUF2QjtBQUVBRCx1QkFBYSxDQUFDL1csVUFBZCxDQUF5Qi9CLE9BQXpCLENBQWtDZ1osZUFBRCxJQUFxQjtBQUNsRCxnQkFBSUgsZUFBZSxDQUFDckQsR0FBaEIsQ0FBb0J3RCxlQUFlLENBQUNqYixPQUFwQyxDQUFKLEVBQ0lnYixnQkFBZ0IsSUFBSWxaLFVBQVUsQ0FBQ21aLGVBQWUsQ0FBQzNRLFlBQWpCLENBQTlCO0FBQ1AsV0FIRDtBQUtBeVEsdUJBQWEsQ0FBQy9XLFVBQWQsQ0FBeUIvQixPQUF6QixDQUFrQ2daLGVBQUQsSUFBcUI7QUFDbEQsZ0JBQUlDLGdCQUFnQixHQUFHRCxlQUFlLENBQUNqYixPQUF2Qzs7QUFDQSxnQkFBSSxDQUFDaVosQ0FBQyxDQUFDeEIsR0FBRixDQUFNb0Qsa0JBQU4sRUFBMEIsQ0FBQzdWLGVBQUQsRUFBa0JrVyxnQkFBbEIsQ0FBMUIsQ0FBTCxFQUFxRTtBQUNqRSxrQkFBSWpCLFNBQVMsR0FBR0wsaUJBQWlCLENBQUNzQixnQkFBRCxFQUFtQmxXLGVBQW5CLENBQWpDOztBQUNBaVUsZUFBQyxDQUFDa0MsR0FBRixDQUFNTixrQkFBTixFQUEwQixDQUFDN1YsZUFBRCxFQUFrQmtXLGdCQUFsQixDQUExQixFQUErRGpCLFNBQS9EO0FBQ0g7O0FBRURoQixhQUFDLENBQUN0TixNQUFGLENBQVNrUCxrQkFBVCxFQUE2QixDQUFDN1YsZUFBRCxFQUFrQmtXLGdCQUFsQixFQUFvQyxZQUFwQyxDQUE3QixFQUFpRkUsQ0FBRCxJQUFPQSxDQUFDLEdBQUMsQ0FBekY7O0FBQ0EsZ0JBQUksQ0FBQ04sZUFBZSxDQUFDckQsR0FBaEIsQ0FBb0J5RCxnQkFBcEIsQ0FBTCxFQUE0QztBQUN4Q2pDLGVBQUMsQ0FBQ3ROLE1BQUYsQ0FBU2tQLGtCQUFULEVBQTZCLENBQUM3VixlQUFELEVBQWtCa1csZ0JBQWxCLEVBQW9DLFdBQXBDLENBQTdCLEVBQWdGRSxDQUFELElBQU9BLENBQUMsR0FBQyxDQUF4Rjs7QUFDQVYsNkJBQWUsQ0FBQ2pSLE1BQWhCLENBQXVCO0FBQ25CME8scUJBQUssRUFBRStDLGdCQURZO0FBRW5CbkIsMkJBQVcsRUFBRTNVLEtBQUssQ0FBQ0MsTUFGQTtBQUduQjBLLHdCQUFRLEVBQUUvSyxlQUhTO0FBSW5CMEUsK0JBQWUsRUFBRXRFLEtBQUssQ0FBQ3NFLGVBSko7QUFLbkJLLCtCQUFlLEVBQUUzRSxLQUFLLENBQUMyRSxlQUxKO0FBTW5CM0gsb0JBQUksRUFBRWdELEtBQUssQ0FBQ2hELElBTk87QUFPbkIyRywwQkFBVSxFQUFFM0QsS0FBSyxDQUFDMkQsVUFQQztBQVFuQjZDLGdDQUFnQixFQUFFeEcsS0FBSyxDQUFDd0csZ0JBUkw7QUFTbkJsRyx3QkFBUSxFQUFFTixLQUFLLENBQUNNLFFBVEc7QUFVbkIrUywyQkFBVyxFQUFFclQsS0FBSyxDQUFDa0YsWUFWQTtBQVduQjBRLGdDQVhtQjtBQVluQmhELHlCQUFTLEVBQUVvQixZQVpRO0FBYW5CZSx5QkFBUyxFQUFFbEIsQ0FBQyxDQUFDeFosR0FBRixDQUFNb2Isa0JBQU4sRUFBMEIsQ0FBQzdWLGVBQUQsRUFBa0JrVyxnQkFBbEIsRUFBb0MsV0FBcEMsQ0FBMUIsQ0FiUTtBQWNuQmQsMEJBQVUsRUFBRW5CLENBQUMsQ0FBQ3haLEdBQUYsQ0FBTW9iLGtCQUFOLEVBQTBCLENBQUM3VixlQUFELEVBQWtCa1csZ0JBQWxCLEVBQW9DLFlBQXBDLENBQTFCO0FBZE8sZUFBdkI7QUFnQkg7QUFDSixXQTNCRDtBQTRCSCxTQXZDRDs7QUF5Q0FqQyxTQUFDLENBQUNoWCxPQUFGLENBQVU0WSxrQkFBVixFQUE4QixDQUFDNUMsTUFBRCxFQUFTalQsZUFBVCxLQUE2QjtBQUN2RGlVLFdBQUMsQ0FBQ2hYLE9BQUYsQ0FBVWdXLE1BQVYsRUFBa0IsQ0FBQ29ELEtBQUQsRUFBUXhCLFlBQVIsS0FBeUI7QUFDdkNhLDJCQUFlLENBQUMzVixJQUFoQixDQUFxQjtBQUNqQm9ULG1CQUFLLEVBQUUwQixZQURVO0FBRWpCOUosc0JBQVEsRUFBRS9LLGVBRk87QUFHakIrVSx5QkFBVyxFQUFFLENBQUM7QUFIRyxhQUFyQixFQUlHcFAsTUFKSCxHQUlZQyxTQUpaLENBSXNCO0FBQUNDLGtCQUFJLEVBQUU7QUFDekJzTixxQkFBSyxFQUFFMEIsWUFEa0I7QUFFekI5Six3QkFBUSxFQUFFL0ssZUFGZTtBQUd6QitVLDJCQUFXLEVBQUUsQ0FBQyxDQUhXO0FBSXpCL0IseUJBQVMsRUFBRW9CLFlBSmM7QUFLekJlLHlCQUFTLEVBQUVsQixDQUFDLENBQUN4WixHQUFGLENBQU00YixLQUFOLEVBQWEsV0FBYixDQUxjO0FBTXpCakIsMEJBQVUsRUFBRW5CLENBQUMsQ0FBQ3haLEdBQUYsQ0FBTTRiLEtBQU4sRUFBYSxZQUFiO0FBTmE7QUFBUCxhQUp0QjtBQVlILFdBYkQ7QUFjSCxTQWZEOztBQWlCQSxZQUFJNUUsT0FBTyxHQUFHLEVBQWQ7O0FBQ0EsWUFBSWlFLGVBQWUsQ0FBQ2haLE1BQWhCLEdBQXlCLENBQTdCLEVBQStCO0FBQzNCLGdCQUFNNFosTUFBTSxHQUFHdEMsWUFBWSxDQUFDdUMsT0FBYixDQUFxQkMsS0FBckIsQ0FBMkJGLE1BQTFDLENBRDJCLENBRTNCO0FBQ0E7QUFDQTs7QUFDQSxjQUFJRyxXQUFXLEdBQUdmLGVBQWUsQ0FBQ3JNLE9BQWhCLENBQXdCO0FBQUk7QUFBNUIsWUFBNkNxTixJQUE3QyxDQUNkMWMsTUFBTSxDQUFDMmMsZUFBUCxDQUF1QixDQUFDcGIsTUFBRCxFQUFTZ0osR0FBVCxLQUFpQjtBQUNwQyxnQkFBSUEsR0FBSixFQUFRO0FBQ0o4USwrQkFBaUIsR0FBRyxLQUFwQixDQURJLENBRUo7O0FBQ0Esb0JBQU05USxHQUFOO0FBQ0g7O0FBQ0QsZ0JBQUloSixNQUFKLEVBQVc7QUFDUDtBQUNBa1cscUJBQU8sR0FBRyxXQUFJbFcsTUFBTSxDQUFDQSxNQUFQLENBQWNxYixTQUFsQiw2QkFDSXJiLE1BQU0sQ0FBQ0EsTUFBUCxDQUFjc2IsU0FEbEIsNkJBRUl0YixNQUFNLENBQUNBLE1BQVAsQ0FBY3ViLFNBRmxCLGVBQVY7QUFHSDtBQUNKLFdBWkQsQ0FEYyxDQUFsQjtBQWVBN1ksaUJBQU8sQ0FBQ3VELEtBQVIsQ0FBY2lWLFdBQWQ7QUFDSDs7QUFFRHBCLHlCQUFpQixHQUFHLEtBQXBCO0FBQ0F2QixjQUFNLENBQUNuTyxNQUFQLENBQWM7QUFBQ0ssaUJBQU8sRUFBRWhNLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBakMsU0FBZCxFQUF5RDtBQUFDSCxjQUFJLEVBQUM7QUFBQzJQLDBDQUE4QixFQUFDcEIsWUFBaEM7QUFBOEMyQyx3Q0FBNEIsRUFBRSxJQUFJMVosSUFBSjtBQUE1RTtBQUFOLFNBQXpEO0FBQ0EsaUNBQWtCQSxJQUFJLENBQUN3VCxHQUFMLEtBQWF5RSxTQUEvQixnQkFBOEM3RCxPQUE5QztBQUNILE9BMUdELENBMEdFLE9BQU83VyxDQUFQLEVBQVU7QUFDUnlhLHlCQUFpQixHQUFHLEtBQXBCO0FBQ0EsY0FBTXphLENBQU47QUFDSDtBQUNKLEtBL0dELE1BZ0hJO0FBQ0EsYUFBTyxhQUFQO0FBQ0g7QUFDSixHQXJIVTtBQXNIWCxpREFBK0MsWUFBVTtBQUNyRDtBQUNBO0FBQ0EsUUFBSSxDQUFDb2Msc0JBQUwsRUFBNEI7QUFDeEJBLDRCQUFzQixHQUFHLElBQXpCO0FBQ0FuYyxhQUFPLENBQUNDLEdBQVIsQ0FBWSw4QkFBWjtBQUNBLFdBQUtHLE9BQUw7QUFDQSxVQUFJK0QsVUFBVSxHQUFHM0UsVUFBVSxDQUFDMEYsSUFBWCxDQUFnQixFQUFoQixFQUFvQkUsS0FBcEIsRUFBakI7QUFDQSxVQUFJbVUsWUFBWSxHQUFHcGEsTUFBTSxDQUFDc0ksSUFBUCxDQUFZLHlCQUFaLENBQW5CO0FBQ0EsVUFBSWlULGNBQWMsR0FBR3pCLE1BQU0sQ0FBQ3pYLE9BQVAsQ0FBZTtBQUFDMkosZUFBTyxFQUFFaE0sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFqQyxPQUFmLENBQXJCO0FBQ0EsVUFBSTlELFdBQVcsR0FBSXFULGNBQWMsSUFBRUEsY0FBYyxDQUFDMEIscUJBQWhDLEdBQXVEMUIsY0FBYyxDQUFDMEIscUJBQXRFLEdBQTRGamQsTUFBTSxDQUFDaUgsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCRCxXQUFySSxDQVB3QixDQVF4QjtBQUNBOztBQUNBLFlBQU13VCxlQUFlLEdBQUczQixpQkFBaUIsQ0FBQ25ULGFBQWxCLEdBQWtDb0MseUJBQWxDLEVBQXhCOztBQUNBLFdBQUtyRixDQUFMLElBQVVxQixVQUFWLEVBQXFCO0FBQ2pCO0FBQ0EsWUFBSTZWLFlBQVksR0FBRzdWLFVBQVUsQ0FBQ3JCLENBQUQsQ0FBVixDQUFjM0MsT0FBakM7QUFDQSxZQUFJa2MsYUFBYSxHQUFHN1ksZ0JBQWdCLENBQUMwQixJQUFqQixDQUFzQjtBQUN0Qy9FLGlCQUFPLEVBQUM2WixZQUQ4QjtBQUV0Q3hQLGdCQUFNLEVBQUMsS0FGK0I7QUFHdENrUCxjQUFJLEVBQUUsQ0FBRTtBQUFFbFUsa0JBQU0sRUFBRTtBQUFFbVUsaUJBQUcsRUFBRXRTO0FBQVA7QUFBVixXQUFGLEVBQW9DO0FBQUU3QixrQkFBTSxFQUFFO0FBQUVvVSxrQkFBSSxFQUFFTDtBQUFSO0FBQVYsV0FBcEM7QUFIZ0MsU0FBdEIsRUFJakJuVSxLQUppQixFQUFwQjtBQU1BLFlBQUlrWCxNQUFNLEdBQUcsRUFBYixDQVRpQixDQVdqQjs7QUFDQSxhQUFLMVcsQ0FBTCxJQUFVeVcsYUFBVixFQUF3QjtBQUNwQixjQUFJOVcsS0FBSyxHQUFHbEMsU0FBUyxDQUFDN0IsT0FBVixDQUFrQjtBQUFDZ0Usa0JBQU0sRUFBQzZXLGFBQWEsQ0FBQ3pXLENBQUQsQ0FBYixDQUFpQko7QUFBekIsV0FBbEIsQ0FBWjtBQUNBLGNBQUkrVyxjQUFjLEdBQUdyRCxpQkFBaUIsQ0FBQzFYLE9BQWxCLENBQTBCO0FBQUM4VyxpQkFBSyxFQUFDMEIsWUFBUDtBQUFxQjlKLG9CQUFRLEVBQUMzSyxLQUFLLENBQUNKO0FBQXBDLFdBQTFCLENBQXJCOztBQUVBLGNBQUksT0FBT21YLE1BQU0sQ0FBQy9XLEtBQUssQ0FBQ0osZUFBUCxDQUFiLEtBQXlDLFdBQTdDLEVBQXlEO0FBQ3JELGdCQUFJb1gsY0FBSixFQUFtQjtBQUNmRCxvQkFBTSxDQUFDL1csS0FBSyxDQUFDSixlQUFQLENBQU4sR0FBZ0NvWCxjQUFjLENBQUNwWixLQUFmLEdBQXFCLENBQXJEO0FBQ0gsYUFGRCxNQUdJO0FBQ0FtWixvQkFBTSxDQUFDL1csS0FBSyxDQUFDSixlQUFQLENBQU4sR0FBZ0MsQ0FBaEM7QUFDSDtBQUNKLFdBUEQsTUFRSTtBQUNBbVgsa0JBQU0sQ0FBQy9XLEtBQUssQ0FBQ0osZUFBUCxDQUFOO0FBQ0g7QUFDSjs7QUFFRCxhQUFLaEYsT0FBTCxJQUFnQm1jLE1BQWhCLEVBQXVCO0FBQ25CLGNBQUl2YSxJQUFJLEdBQUc7QUFDUHVXLGlCQUFLLEVBQUUwQixZQURBO0FBRVA5SixvQkFBUSxFQUFDL1AsT0FGRjtBQUdQZ0QsaUJBQUssRUFBRW1aLE1BQU0sQ0FBQ25jLE9BQUQ7QUFITixXQUFYO0FBTUEwYSx5QkFBZSxDQUFDM1YsSUFBaEIsQ0FBcUI7QUFBQ29ULGlCQUFLLEVBQUMwQixZQUFQO0FBQXFCOUosb0JBQVEsRUFBQy9QO0FBQTlCLFdBQXJCLEVBQTZEMkssTUFBN0QsR0FBc0VDLFNBQXRFLENBQWdGO0FBQUNDLGdCQUFJLEVBQUNqSjtBQUFOLFdBQWhGO0FBQ0gsU0FyQ2dCLENBc0NqQjs7QUFFSDs7QUFFRCxVQUFJOFksZUFBZSxDQUFDaFosTUFBaEIsR0FBeUIsQ0FBN0IsRUFBK0I7QUFDM0JnWix1QkFBZSxDQUFDck0sT0FBaEIsQ0FBd0JyUCxNQUFNLENBQUMyYyxlQUFQLENBQXVCLENBQUNwUyxHQUFELEVBQU1oSixNQUFOLEtBQWlCO0FBQzVELGNBQUlnSixHQUFKLEVBQVE7QUFDSnlTLGtDQUFzQixHQUFHLEtBQXpCO0FBQ0FuYyxtQkFBTyxDQUFDQyxHQUFSLENBQVl5SixHQUFaO0FBQ0g7O0FBQ0QsY0FBSWhKLE1BQUosRUFBVztBQUNQdVksa0JBQU0sQ0FBQ25PLE1BQVAsQ0FBYztBQUFDSyxxQkFBTyxFQUFFaE0sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFqQyxhQUFkLEVBQXlEO0FBQUNILGtCQUFJLEVBQUM7QUFBQ29SLHFDQUFxQixFQUFDN0MsWUFBdkI7QUFBcUNpRCxtQ0FBbUIsRUFBRSxJQUFJaGEsSUFBSjtBQUExRDtBQUFOLGFBQXpEO0FBQ0EyWixrQ0FBc0IsR0FBRyxLQUF6QjtBQUNBbmMsbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDSDtBQUNKLFNBVnVCLENBQXhCO0FBV0gsT0FaRCxNQWFJO0FBQ0FrYyw4QkFBc0IsR0FBRyxLQUF6QjtBQUNIOztBQUVELGFBQU8sSUFBUDtBQUNILEtBdkVELE1Bd0VJO0FBQ0EsYUFBTyxhQUFQO0FBQ0g7QUFDSixHQXBNVTtBQXFNWCxnREFBOEMsVUFBUzVaLElBQVQsRUFBYztBQUN4RCxTQUFLbkMsT0FBTDtBQUNBLFFBQUk0VixHQUFHLEdBQUcsSUFBSXhULElBQUosRUFBVjs7QUFFQSxRQUFJRCxJQUFJLElBQUksR0FBWixFQUFnQjtBQUNaLFVBQUl3SixnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLFVBQUkwUSxrQkFBa0IsR0FBRyxDQUF6QjtBQUVBLFVBQUlDLFNBQVMsR0FBR2paLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZTtBQUFFLGdCQUFRO0FBQUV5VSxhQUFHLEVBQUUsSUFBSW5YLElBQUosQ0FBU0EsSUFBSSxDQUFDd1QsR0FBTCxLQUFhLEtBQUssSUFBM0I7QUFBUDtBQUFWLE9BQWYsRUFBc0U1USxLQUF0RSxFQUFoQjs7QUFDQSxVQUFJc1gsU0FBUyxDQUFDN2EsTUFBVixHQUFtQixDQUF2QixFQUF5QjtBQUNyQixhQUFLaUIsQ0FBTCxJQUFVNFosU0FBVixFQUFvQjtBQUNoQjNRLDBCQUFnQixJQUFJMlEsU0FBUyxDQUFDNVosQ0FBRCxDQUFULENBQWErQyxRQUFqQztBQUNBNFcsNEJBQWtCLElBQUlDLFNBQVMsQ0FBQzVaLENBQUQsQ0FBVCxDQUFhMkgsWUFBbkM7QUFDSDs7QUFDRHNCLHdCQUFnQixHQUFHQSxnQkFBZ0IsR0FBRzJRLFNBQVMsQ0FBQzdhLE1BQWhEO0FBQ0E0YSwwQkFBa0IsR0FBR0Esa0JBQWtCLEdBQUdDLFNBQVMsQ0FBQzdhLE1BQXBEO0FBRUF5QixhQUFLLENBQUN3SSxNQUFOLENBQWE7QUFBQ1gsaUJBQU8sRUFBQ2hNLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBaEMsU0FBYixFQUFzRDtBQUFDSCxjQUFJLEVBQUM7QUFBQzJSLGlDQUFxQixFQUFDRixrQkFBdkI7QUFBMkNHLCtCQUFtQixFQUFDN1E7QUFBL0Q7QUFBTixTQUF0RDtBQUNBZ04sbUJBQVcsQ0FBQ25QLE1BQVosQ0FBbUI7QUFDZm1DLDBCQUFnQixFQUFFQSxnQkFESDtBQUVmMFEsNEJBQWtCLEVBQUVBLGtCQUZMO0FBR2Y3YixjQUFJLEVBQUUyQixJQUhTO0FBSWY2VCxtQkFBUyxFQUFFSjtBQUpJLFNBQW5CO0FBTUg7QUFDSjs7QUFDRCxRQUFJelQsSUFBSSxJQUFJLEdBQVosRUFBZ0I7QUFDWixVQUFJd0osZ0JBQWdCLEdBQUcsQ0FBdkI7QUFDQSxVQUFJMFEsa0JBQWtCLEdBQUcsQ0FBekI7QUFDQSxVQUFJQyxTQUFTLEdBQUdqWixTQUFTLENBQUN5QixJQUFWLENBQWU7QUFBRSxnQkFBUTtBQUFFeVUsYUFBRyxFQUFFLElBQUluWCxJQUFKLENBQVNBLElBQUksQ0FBQ3dULEdBQUwsS0FBYSxLQUFHLEVBQUgsR0FBUSxJQUE5QjtBQUFQO0FBQVYsT0FBZixFQUF5RTVRLEtBQXpFLEVBQWhCOztBQUNBLFVBQUlzWCxTQUFTLENBQUM3YSxNQUFWLEdBQW1CLENBQXZCLEVBQXlCO0FBQ3JCLGFBQUtpQixDQUFMLElBQVU0WixTQUFWLEVBQW9CO0FBQ2hCM1EsMEJBQWdCLElBQUkyUSxTQUFTLENBQUM1WixDQUFELENBQVQsQ0FBYStDLFFBQWpDO0FBQ0E0Vyw0QkFBa0IsSUFBSUMsU0FBUyxDQUFDNVosQ0FBRCxDQUFULENBQWEySCxZQUFuQztBQUNIOztBQUNEc0Isd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHMlEsU0FBUyxDQUFDN2EsTUFBaEQ7QUFDQTRhLDBCQUFrQixHQUFHQSxrQkFBa0IsR0FBR0MsU0FBUyxDQUFDN2EsTUFBcEQ7QUFFQXlCLGFBQUssQ0FBQ3dJLE1BQU4sQ0FBYTtBQUFDWCxpQkFBTyxFQUFDaE0sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFoQyxTQUFiLEVBQXNEO0FBQUNILGNBQUksRUFBQztBQUFDNlIsK0JBQW1CLEVBQUNKLGtCQUFyQjtBQUF5Q0ssNkJBQWlCLEVBQUMvUTtBQUEzRDtBQUFOLFNBQXREO0FBQ0FnTixtQkFBVyxDQUFDblAsTUFBWixDQUFtQjtBQUNmbUMsMEJBQWdCLEVBQUVBLGdCQURIO0FBRWYwUSw0QkFBa0IsRUFBRUEsa0JBRkw7QUFHZjdiLGNBQUksRUFBRTJCLElBSFM7QUFJZjZULG1CQUFTLEVBQUVKO0FBSkksU0FBbkI7QUFNSDtBQUNKOztBQUVELFFBQUl6VCxJQUFJLElBQUksR0FBWixFQUFnQjtBQUNaLFVBQUl3SixnQkFBZ0IsR0FBRyxDQUF2QjtBQUNBLFVBQUkwUSxrQkFBa0IsR0FBRyxDQUF6QjtBQUNBLFVBQUlDLFNBQVMsR0FBR2paLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZTtBQUFFLGdCQUFRO0FBQUV5VSxhQUFHLEVBQUUsSUFBSW5YLElBQUosQ0FBU0EsSUFBSSxDQUFDd1QsR0FBTCxLQUFhLEtBQUcsRUFBSCxHQUFNLEVBQU4sR0FBVyxJQUFqQztBQUFQO0FBQVYsT0FBZixFQUE0RTVRLEtBQTVFLEVBQWhCOztBQUNBLFVBQUlzWCxTQUFTLENBQUM3YSxNQUFWLEdBQW1CLENBQXZCLEVBQXlCO0FBQ3JCLGFBQUtpQixDQUFMLElBQVU0WixTQUFWLEVBQW9CO0FBQ2hCM1EsMEJBQWdCLElBQUkyUSxTQUFTLENBQUM1WixDQUFELENBQVQsQ0FBYStDLFFBQWpDO0FBQ0E0Vyw0QkFBa0IsSUFBSUMsU0FBUyxDQUFDNVosQ0FBRCxDQUFULENBQWEySCxZQUFuQztBQUNIOztBQUNEc0Isd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHMlEsU0FBUyxDQUFDN2EsTUFBaEQ7QUFDQTRhLDBCQUFrQixHQUFHQSxrQkFBa0IsR0FBR0MsU0FBUyxDQUFDN2EsTUFBcEQ7QUFFQXlCLGFBQUssQ0FBQ3dJLE1BQU4sQ0FBYTtBQUFDWCxpQkFBTyxFQUFDaE0sTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUI4RTtBQUFoQyxTQUFiLEVBQXNEO0FBQUNILGNBQUksRUFBQztBQUFDK1IsOEJBQWtCLEVBQUNOLGtCQUFwQjtBQUF3Q08sNEJBQWdCLEVBQUNqUjtBQUF6RDtBQUFOLFNBQXREO0FBQ0FnTixtQkFBVyxDQUFDblAsTUFBWixDQUFtQjtBQUNmbUMsMEJBQWdCLEVBQUVBLGdCQURIO0FBRWYwUSw0QkFBa0IsRUFBRUEsa0JBRkw7QUFHZjdiLGNBQUksRUFBRTJCLElBSFM7QUFJZjZULG1CQUFTLEVBQUVKO0FBSkksU0FBbkI7QUFNSDtBQUNKLEtBcEV1RCxDQXNFeEQ7O0FBQ0gsR0E1UVU7QUE2UVgsZ0RBQThDLFlBQVU7QUFDcEQsU0FBSzVWLE9BQUw7QUFDQSxRQUFJK0QsVUFBVSxHQUFHM0UsVUFBVSxDQUFDMEYsSUFBWCxDQUFnQixFQUFoQixFQUFvQkUsS0FBcEIsRUFBakI7QUFDQSxRQUFJNFEsR0FBRyxHQUFHLElBQUl4VCxJQUFKLEVBQVY7O0FBQ0EsU0FBS00sQ0FBTCxJQUFVcUIsVUFBVixFQUFxQjtBQUNqQixVQUFJNEgsZ0JBQWdCLEdBQUcsQ0FBdkI7QUFFQSxVQUFJOUcsTUFBTSxHQUFHNUIsU0FBUyxDQUFDNkIsSUFBVixDQUFlO0FBQUNDLHVCQUFlLEVBQUNoQixVQUFVLENBQUNyQixDQUFELENBQVYsQ0FBYzNDLE9BQS9CO0FBQXdDLGdCQUFRO0FBQUV3WixhQUFHLEVBQUUsSUFBSW5YLElBQUosQ0FBU0EsSUFBSSxDQUFDd1QsR0FBTCxLQUFhLEtBQUcsRUFBSCxHQUFNLEVBQU4sR0FBVyxJQUFqQztBQUFQO0FBQWhELE9BQWYsRUFBaUg7QUFBQ2xJLGNBQU0sRUFBQztBQUFDdEksZ0JBQU0sRUFBQztBQUFSO0FBQVIsT0FBakgsRUFBc0lKLEtBQXRJLEVBQWI7O0FBRUEsVUFBSUgsTUFBTSxDQUFDcEQsTUFBUCxHQUFnQixDQUFwQixFQUFzQjtBQUNsQixZQUFJb2IsWUFBWSxHQUFHLEVBQW5COztBQUNBLGFBQUtyWCxDQUFMLElBQVVYLE1BQVYsRUFBaUI7QUFDYmdZLHNCQUFZLENBQUM3VCxJQUFiLENBQWtCbkUsTUFBTSxDQUFDVyxDQUFELENBQU4sQ0FBVUosTUFBNUI7QUFDSDs7QUFFRCxZQUFJa1gsU0FBUyxHQUFHalosU0FBUyxDQUFDeUIsSUFBVixDQUFlO0FBQUNNLGdCQUFNLEVBQUU7QUFBQ0UsZUFBRyxFQUFDdVg7QUFBTDtBQUFULFNBQWYsRUFBNkM7QUFBQ25QLGdCQUFNLEVBQUM7QUFBQ3RJLGtCQUFNLEVBQUMsQ0FBUjtBQUFVSyxvQkFBUSxFQUFDO0FBQW5CO0FBQVIsU0FBN0MsRUFBNkVULEtBQTdFLEVBQWhCOztBQUdBLGFBQUs4WCxDQUFMLElBQVVSLFNBQVYsRUFBb0I7QUFDaEIzUSwwQkFBZ0IsSUFBSTJRLFNBQVMsQ0FBQ1EsQ0FBRCxDQUFULENBQWFyWCxRQUFqQztBQUNIOztBQUVEa0csd0JBQWdCLEdBQUdBLGdCQUFnQixHQUFHMlEsU0FBUyxDQUFDN2EsTUFBaEQ7QUFDSDs7QUFFRG1YLDBCQUFvQixDQUFDcFAsTUFBckIsQ0FBNEI7QUFDeEJ6RSx1QkFBZSxFQUFFaEIsVUFBVSxDQUFDckIsQ0FBRCxDQUFWLENBQWMzQyxPQURQO0FBRXhCNEwsd0JBQWdCLEVBQUVBLGdCQUZNO0FBR3hCbkwsWUFBSSxFQUFFLGdDQUhrQjtBQUl4QndWLGlCQUFTLEVBQUVKO0FBSmEsT0FBNUI7QUFNSDs7QUFFRCxXQUFPLElBQVA7QUFDSDtBQS9TVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDN0RBLElBQUk3VyxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlrRSxnQkFBSixFQUFxQkMsU0FBckIsRUFBK0IwVixZQUEvQixFQUE0Q0QsaUJBQTVDLEVBQThEeFYsZUFBOUQ7QUFBOEV0RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNtRSxrQkFBZ0IsQ0FBQ2xFLENBQUQsRUFBRztBQUFDa0Usb0JBQWdCLEdBQUNsRSxDQUFqQjtBQUFtQixHQUF4Qzs7QUFBeUNtRSxXQUFTLENBQUNuRSxDQUFELEVBQUc7QUFBQ21FLGFBQVMsR0FBQ25FLENBQVY7QUFBWSxHQUFsRTs7QUFBbUU2WixjQUFZLENBQUM3WixDQUFELEVBQUc7QUFBQzZaLGdCQUFZLEdBQUM3WixDQUFiO0FBQWUsR0FBbEc7O0FBQW1HNFosbUJBQWlCLENBQUM1WixDQUFELEVBQUc7QUFBQzRaLHFCQUFpQixHQUFDNVosQ0FBbEI7QUFBb0IsR0FBNUk7O0FBQTZJb0UsaUJBQWUsQ0FBQ3BFLENBQUQsRUFBRztBQUFDb0UsbUJBQWUsR0FBQ3BFLENBQWhCO0FBQWtCOztBQUFsTCxDQUE1QixFQUFnTixDQUFoTjtBQUFtTixJQUFJRSxVQUFKO0FBQWVKLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGdDQUFaLEVBQTZDO0FBQUNHLFlBQVUsQ0FBQ0YsQ0FBRCxFQUFHO0FBQUNFLGNBQVUsR0FBQ0YsQ0FBWDtBQUFhOztBQUE1QixDQUE3QyxFQUEyRSxDQUEzRTtBQUloWEgsTUFBTSxDQUFDeVcsT0FBUCxDQUFlLHVCQUFmLEVBQXdDLFlBQVk7QUFDaEQsU0FBT3BTLGdCQUFnQixDQUFDMEIsSUFBakIsRUFBUDtBQUNILENBRkQ7QUFJQS9GLE1BQU0sQ0FBQ3lXLE9BQVAsQ0FBZSwwQkFBZixFQUEyQyxVQUFTelYsT0FBVCxFQUFrQmdkLEdBQWxCLEVBQXNCO0FBQzdELFNBQU8zWixnQkFBZ0IsQ0FBQzBCLElBQWpCLENBQXNCO0FBQUMvRSxXQUFPLEVBQUNBO0FBQVQsR0FBdEIsRUFBd0M7QUFBQ2lILFNBQUssRUFBQytWLEdBQVA7QUFBWWhXLFFBQUksRUFBQztBQUFDM0IsWUFBTSxFQUFDLENBQUM7QUFBVDtBQUFqQixHQUF4QyxDQUFQO0FBQ0gsQ0FGRDtBQUlBckcsTUFBTSxDQUFDeVcsT0FBUCxDQUFlLG1CQUFmLEVBQW9DLFlBQVU7QUFDMUMsU0FBT25TLFNBQVMsQ0FBQ3lCLElBQVYsQ0FBZSxFQUFmLEVBQWtCO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFrQjRCLFNBQUssRUFBQztBQUF4QixHQUFsQixDQUFQO0FBQ0gsQ0FGRDtBQUlBakksTUFBTSxDQUFDeVcsT0FBUCxDQUFlLHVCQUFmLEVBQXdDLFlBQVU7QUFDOUMsU0FBT2xTLGVBQWUsQ0FBQ3dCLElBQWhCLENBQXFCLEVBQXJCLEVBQXdCO0FBQUNpQyxRQUFJLEVBQUM7QUFBQzNCLFlBQU0sRUFBQyxDQUFDO0FBQVQsS0FBTjtBQUFtQjRCLFNBQUssRUFBQztBQUF6QixHQUF4QixDQUFQO0FBQ0gsQ0FGRDtBQUlBd0ksZ0JBQWdCLENBQUMsd0JBQUQsRUFBMkIsVUFBU3pQLE9BQVQsRUFBa0JTLElBQWxCLEVBQXVCO0FBQzlELE1BQUl3YyxVQUFVLEdBQUcsRUFBakI7O0FBQ0EsTUFBSXhjLElBQUksSUFBSSxPQUFaLEVBQW9CO0FBQ2hCd2MsY0FBVSxHQUFHO0FBQ1Q5RSxXQUFLLEVBQUVuWTtBQURFLEtBQWI7QUFHSCxHQUpELE1BS0k7QUFDQWlkLGNBQVUsR0FBRztBQUNUbE4sY0FBUSxFQUFFL1A7QUFERCxLQUFiO0FBR0g7O0FBQ0QsU0FBTztBQUNIK0UsUUFBSSxHQUFFO0FBQ0YsYUFBT2dVLGlCQUFpQixDQUFDaFUsSUFBbEIsQ0FBdUJrWSxVQUF2QixDQUFQO0FBQ0gsS0FIRTs7QUFJSHZOLFlBQVEsRUFBRSxDQUNOO0FBQ0kzSyxVQUFJLENBQUNzVyxLQUFELEVBQU87QUFDUCxlQUFPaGMsVUFBVSxDQUFDMEYsSUFBWCxDQUNILEVBREcsRUFFSDtBQUFDNEksZ0JBQU0sRUFBQztBQUFDM04sbUJBQU8sRUFBQyxDQUFUO0FBQVl1TSx1QkFBVyxFQUFDLENBQXhCO0FBQTJCQyx1QkFBVyxFQUFDO0FBQXZDO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQTNCZSxDQUFoQjtBQTZCQWlELGdCQUFnQixDQUFDLHlCQUFELEVBQTRCLFVBQVN6UCxPQUFULEVBQWtCUyxJQUFsQixFQUF1QjtBQUMvRCxTQUFPO0FBQ0hzRSxRQUFJLEdBQUU7QUFDRixhQUFPaVUsWUFBWSxDQUFDalUsSUFBYixDQUNIO0FBQUMsU0FBQ3RFLElBQUQsR0FBUVQ7QUFBVCxPQURHLEVBRUg7QUFBQ2dILFlBQUksRUFBRTtBQUFDZ1IsbUJBQVMsRUFBRSxDQUFDO0FBQWI7QUFBUCxPQUZHLENBQVA7QUFJSCxLQU5FOztBQU9IdEksWUFBUSxFQUFFLENBQ047QUFDSTNLLFVBQUksR0FBRTtBQUNGLGVBQU8xRixVQUFVLENBQUMwRixJQUFYLENBQ0gsRUFERyxFQUVIO0FBQUM0SSxnQkFBTSxFQUFDO0FBQUMzTixtQkFBTyxFQUFDLENBQVQ7QUFBWXVNLHVCQUFXLEVBQUMsQ0FBeEI7QUFBMkJoTCw0QkFBZ0IsRUFBQztBQUE1QztBQUFSLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE07QUFQUCxHQUFQO0FBa0JILENBbkJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDakRBdEMsTUFBTSxDQUFDMFEsTUFBUCxDQUFjO0FBQUN0TSxrQkFBZ0IsRUFBQyxNQUFJQSxnQkFBdEI7QUFBdUNDLFdBQVMsRUFBQyxNQUFJQSxTQUFyRDtBQUErRHlWLG1CQUFpQixFQUFDLE1BQUlBLGlCQUFyRjtBQUF1R0MsY0FBWSxFQUFDLE1BQUlBLFlBQXhIO0FBQXFJelYsaUJBQWUsRUFBQyxNQUFJQSxlQUF6SjtBQUF5S3FWLGFBQVcsRUFBQyxNQUFJQSxXQUF6TDtBQUFxTUMsc0JBQW9CLEVBQUMsTUFBSUE7QUFBOU4sQ0FBZDtBQUFtUSxJQUFJakosS0FBSjtBQUFVM1EsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDMFEsT0FBSyxDQUFDelEsQ0FBRCxFQUFHO0FBQUN5USxTQUFLLEdBQUN6USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQXZDLEVBQXFFLENBQXJFO0FBR3ZVLE1BQU1rRSxnQkFBZ0IsR0FBRyxJQUFJdU0sS0FBSyxDQUFDQyxVQUFWLENBQXFCLG1CQUFyQixDQUF6QjtBQUNBLE1BQU12TSxTQUFTLEdBQUcsSUFBSXNNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixXQUFyQixDQUFsQjtBQUNBLE1BQU1rSixpQkFBaUIsR0FBRyxJQUFJbkosS0FBSyxDQUFDQyxVQUFWLENBQXFCLHFCQUFyQixDQUExQjtBQUNBLE1BQU1tSixZQUFZLEdBQUcsSUFBS3BKLEtBQUssQ0FBQ0MsVUFBWCxDQUFzQixlQUF0QixDQUFyQjtBQUNBLE1BQU10TSxlQUFlLEdBQUcsSUFBSXFNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQiw0QkFBckIsQ0FBeEI7QUFDQSxNQUFNK0ksV0FBVyxHQUFHLElBQUloSixLQUFLLENBQUNDLFVBQVYsQ0FBcUIsY0FBckIsQ0FBcEI7QUFDQSxNQUFNZ0osb0JBQW9CLEdBQUcsSUFBSWpKLEtBQUssQ0FBQ0MsVUFBVixDQUFxQix3QkFBckIsQ0FBN0I7QUFFUGtKLGlCQUFpQixDQUFDakosT0FBbEIsQ0FBMEI7QUFDdEJvTixpQkFBZSxHQUFFO0FBQ2IsUUFBSTliLFNBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBbUI7QUFBQ3JCLGFBQU8sRUFBQyxLQUFLK1A7QUFBZCxLQUFuQixDQUFoQjtBQUNBLFdBQVEzTyxTQUFTLENBQUNtTCxXQUFYLEdBQXdCbkwsU0FBUyxDQUFDbUwsV0FBVixDQUFzQitMLE9BQTlDLEdBQXNELEtBQUt2SSxRQUFsRTtBQUNILEdBSnFCOztBQUt0Qm9OLGNBQVksR0FBRTtBQUNWLFFBQUkvYixTQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQW1CO0FBQUNyQixhQUFPLEVBQUMsS0FBS21ZO0FBQWQsS0FBbkIsQ0FBaEI7QUFDQSxXQUFRL1csU0FBUyxDQUFDbUwsV0FBWCxHQUF3Qm5MLFNBQVMsQ0FBQ21MLFdBQVYsQ0FBc0IrTCxPQUE5QyxHQUFzRCxLQUFLSCxLQUFsRTtBQUNIOztBQVJxQixDQUExQixFOzs7Ozs7Ozs7OztBQ1hBLElBQUluWixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUl1WixLQUFKO0FBQVV6WixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUN3WixPQUFLLENBQUN2WixDQUFELEVBQUc7QUFBQ3VaLFNBQUssR0FBQ3ZaLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSTJaLE1BQUo7QUFBVzdaLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzRaLFFBQU0sQ0FBQzNaLENBQUQsRUFBRztBQUFDMlosVUFBTSxHQUFDM1osQ0FBUDtBQUFTOztBQUFwQixDQUEzQixFQUFpRCxDQUFqRDtBQUl2SUgsTUFBTSxDQUFDeVcsT0FBUCxDQUFnQixlQUFoQixFQUFpQyxZQUFZO0FBQ3pDLFNBQU9xRCxNQUFNLENBQUMvVCxJQUFQLENBQWE7QUFBRWlHLFdBQU8sRUFBR2hNLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOEU7QUFBbkMsR0FBYixDQUFQO0FBQ0gsQ0FGRCxFOzs7Ozs7Ozs7OztBQ0pBL0wsTUFBTSxDQUFDMFEsTUFBUCxDQUFjO0FBQUNtSixRQUFNLEVBQUMsTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUlsSixLQUFKO0FBQVUzUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMwUSxPQUFLLENBQUN6USxDQUFELEVBQUc7QUFBQ3lRLFNBQUssR0FBQ3pRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFdEMsTUFBTTJaLE1BQU0sR0FBRyxJQUFJbEosS0FBSyxDQUFDQyxVQUFWLENBQXFCLFFBQXJCLENBQWYsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJN1EsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUlzRSxZQUFKO0FBQWlCeEUsTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ3VFLGNBQVksQ0FBQ3RFLENBQUQsRUFBRztBQUFDc0UsZ0JBQVksR0FBQ3RFLENBQWI7QUFBZTs7QUFBaEMsQ0FBakQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSUUsVUFBSjtBQUFlSixNQUFNLENBQUNDLElBQVAsQ0FBWSxnQ0FBWixFQUE2QztBQUFDRyxZQUFVLENBQUNGLENBQUQsRUFBRztBQUFDRSxjQUFVLEdBQUNGLENBQVg7QUFBYTs7QUFBNUIsQ0FBN0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSXFFLGtCQUFKO0FBQXVCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ3NFLG9CQUFrQixDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxzQkFBa0IsR0FBQ3JFLENBQW5CO0FBQXFCOztBQUE1QyxDQUE1QyxFQUEwRixDQUExRjtBQU1uVixNQUFNaWUsYUFBYSxHQUFHLEVBQXRCO0FBRUFwZSxNQUFNLENBQUNlLE9BQVAsQ0FBZ0I7QUFDWix3QkFBdUIsVUFBVXVJLElBQVYsRUFBZ0I2QyxTQUFoQixFQUEyQjtBQUM5QyxTQUFLbEwsT0FBTDtBQUNBcUksUUFBSSxHQUFHQSxJQUFJLENBQUMrVSxXQUFMLEVBQVA7QUFDQXhkLFdBQU8sQ0FBQ0MsR0FBUixDQUFhLGFBQWF3SSxJQUExQjs7QUFDQSxRQUFJO0FBQ0EsVUFBSS9JLEdBQUcsR0FBR0csR0FBRyxHQUFHLE9BQU4sR0FBZ0I0SSxJQUExQjtBQUNBLFVBQUluSSxRQUFRLEdBQUdmLElBQUksQ0FBQ0ssR0FBTCxDQUFVRixHQUFWLENBQWY7QUFDQSxVQUFJK2QsRUFBRSxHQUFHbGQsSUFBSSxDQUFDQyxLQUFMLENBQVlGLFFBQVEsQ0FBQ0csT0FBckIsQ0FBVDtBQUNBVCxhQUFPLENBQUNDLEdBQVIsQ0FBYXdJLElBQWI7QUFDQWdWLFFBQUUsQ0FBQ2pZLE1BQUgsR0FBWXlFLFFBQVEsQ0FBRXdULEVBQUUsQ0FBQ2pZLE1BQUwsQ0FBcEI7QUFDQSxVQUFJa1ksSUFBSSxHQUFHOVosWUFBWSxDQUFDZ0csTUFBYixDQUFxQjZULEVBQXJCLENBQVg7O0FBQ0EsVUFBSUMsSUFBSixFQUFVO0FBQ04sZUFBT0EsSUFBUDtBQUNILE9BRkQsTUFHSyxPQUFPLEtBQVA7QUFFUixLQVpELENBYUEsT0FBTzNkLENBQVAsRUFBVTtBQUNOQyxhQUFPLENBQUNDLEdBQVIsQ0FBYUYsQ0FBYjtBQUNIO0FBQ0osR0FyQlc7QUFzQlosaUNBQWdDLFVBQVVJLE9BQVYsRUFBbUJxRixNQUFuQixFQUEyQjtBQUN2RDtBQUNBLFdBQU81QixZQUFZLENBQUNzQixJQUFiLENBQW1CO0FBQ2xCekQsU0FBRyxFQUFHLENBQUM7QUFDSGlZLFlBQUksRUFBRyxDQUNIO0FBQUUseUJBQWdCO0FBQWxCLFNBREcsRUFFSDtBQUFFLG1DQUEwQjtBQUE1QixTQUZHLEVBR0g7QUFBRSxxQ0FBNEJ2WjtBQUE5QixTQUhHO0FBREosT0FBRCxFQU1IO0FBQ0N1WixZQUFJLEVBQUcsQ0FDSDtBQUFFLG1DQUEwQjtBQUE1QixTQURHLEVBRUg7QUFBRSxxQ0FBNEI7QUFBOUIsU0FGRyxFQUdIO0FBQUUsbUNBQTBCO0FBQTVCLFNBSEcsRUFJSDtBQUFFLHFDQUE0QnZaO0FBQTlCLFNBSkc7QUFEUixPQU5HLEVBYUg7QUFDQ3VaLFlBQUksRUFBRyxDQUNIO0FBQUUseUJBQWdCO0FBQWxCLFNBREcsRUFFSDtBQUFFLG1DQUEwQjtBQUE1QixTQUZHLEVBR0g7QUFBRSxxQ0FBNEJ2WjtBQUE5QixTQUhHO0FBRFIsT0FiRyxFQW1CSDtBQUNDdVosWUFBSSxFQUFHLENBQ0g7QUFBRSx5QkFBZ0I7QUFBbEIsU0FERyxFQUVIO0FBQUUsbUNBQTBCO0FBQTVCLFNBRkcsRUFHSDtBQUFFLHFDQUE0QnZaO0FBQTlCLFNBSEc7QUFEUixPQW5CRyxFQXlCSDtBQUNDdVosWUFBSSxFQUFHLENBQ0g7QUFBRSx5QkFBZ0I7QUFBbEIsU0FERyxFQUVIO0FBQUUsbUNBQTBCO0FBQTVCLFNBRkcsRUFHSDtBQUFFLHFDQUE0QnZaO0FBQTlCLFNBSEc7QUFEUixPQXpCRyxDQURZO0FBaUNsQixjQUFTO0FBQUVtSyxlQUFPLEVBQUc7QUFBWixPQWpDUztBQWtDbEI5RSxZQUFNLEVBQUc7QUFBRW1ZLFdBQUcsRUFBR25ZO0FBQVI7QUFsQ1MsS0FBbkIsRUFvQ0g7QUFDSTJCLFVBQUksRUFBRztBQUFFM0IsY0FBTSxFQUFHLENBQUM7QUFBWixPQURYO0FBRUk0QixXQUFLLEVBQUc7QUFGWixLQXBDRyxFQXdDTGhDLEtBeENLLEVBQVA7QUF5Q0gsR0FqRVc7QUFrRVosMkJBQTBCLFVBQVVqRixPQUFWLEVBQWtDO0FBQUEsUUFBZjJOLE1BQWUsdUVBQU4sSUFBTTtBQUN4RDtBQUNBLFFBQUl2TSxTQUFKO0FBQ0EsUUFBSSxDQUFDdU0sTUFBTCxFQUNJQSxNQUFNLEdBQUc7QUFBRTNOLGFBQU8sRUFBRyxDQUFaO0FBQWV1TSxpQkFBVyxFQUFHLENBQTdCO0FBQWdDaEwsc0JBQWdCLEVBQUcsQ0FBbkQ7QUFBc0RDLHVCQUFpQixFQUFHO0FBQTFFLEtBQVQ7O0FBQ0osUUFBSXhCLE9BQU8sQ0FBQ3lkLFFBQVIsQ0FBa0J6ZSxNQUFNLENBQUNpSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QndYLG1CQUF6QyxDQUFKLEVBQW1FO0FBQy9EO0FBQ0F0YyxlQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQW9CO0FBQUVFLHdCQUFnQixFQUFHdkI7QUFBckIsT0FBcEIsRUFBb0Q7QUFBRTJOO0FBQUYsT0FBcEQsQ0FBWjtBQUNILEtBSEQsTUFJSyxJQUFJM04sT0FBTyxDQUFDeWQsUUFBUixDQUFrQnplLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCeVgsbUJBQXpDLENBQUosRUFBbUU7QUFDcEU7QUFDQXZjLGVBQVMsR0FBRy9CLFVBQVUsQ0FBQ2dDLE9BQVgsQ0FBb0I7QUFBRUcseUJBQWlCLEVBQUd4QjtBQUF0QixPQUFwQixFQUFxRDtBQUFFMk47QUFBRixPQUFyRCxDQUFaO0FBQ0gsS0FISSxNQUlBLElBQUkzTixPQUFPLENBQUMwQixNQUFSLEtBQW1CMGIsYUFBdkIsRUFBc0M7QUFDdkNoYyxlQUFTLEdBQUcvQixVQUFVLENBQUNnQyxPQUFYLENBQW9CO0FBQUVyQixlQUFPLEVBQUdBO0FBQVosT0FBcEIsRUFBMkM7QUFBRTJOO0FBQUYsT0FBM0MsQ0FBWjtBQUNIOztBQUNELFFBQUl2TSxTQUFKLEVBQWU7QUFDWCxhQUFPQSxTQUFQO0FBQ0g7O0FBQ0QsV0FBTyxLQUFQO0FBRUg7QUF2RlcsQ0FBaEIsRTs7Ozs7Ozs7Ozs7QUNSQSxJQUFJcEMsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJc0UsWUFBSjtBQUFpQnhFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9CQUFaLEVBQWlDO0FBQUN1RSxjQUFZLENBQUN0RSxDQUFELEVBQUc7QUFBQ3NFLGdCQUFZLEdBQUN0RSxDQUFiO0FBQWU7O0FBQWhDLENBQWpDLEVBQW1FLENBQW5FO0FBQXNFLElBQUkrRCxTQUFKO0FBQWNqRSxNQUFNLENBQUNDLElBQVAsQ0FBWSx3QkFBWixFQUFxQztBQUFDZ0UsV0FBUyxDQUFDL0QsQ0FBRCxFQUFHO0FBQUMrRCxhQUFTLEdBQUMvRCxDQUFWO0FBQVk7O0FBQTFCLENBQXJDLEVBQWlFLENBQWpFO0FBS3JLc1EsZ0JBQWdCLENBQUMsbUJBQUQsRUFBc0IsWUFBb0I7QUFBQSxNQUFYeEksS0FBVyx1RUFBSCxFQUFHO0FBQ3RELFNBQU87QUFDSGxDLFFBQUksR0FBRTtBQUNGLGFBQU90QixZQUFZLENBQUNzQixJQUFiLENBQWtCLEVBQWxCLEVBQXFCO0FBQUNpQyxZQUFJLEVBQUM7QUFBQzNCLGdCQUFNLEVBQUMsQ0FBQztBQUFULFNBQU47QUFBbUI0QixhQUFLLEVBQUNBO0FBQXpCLE9BQXJCLENBQVA7QUFDSCxLQUhFOztBQUlIeUksWUFBUSxFQUFFLENBQ047QUFDSTNLLFVBQUksQ0FBQ3VZLEVBQUQsRUFBSTtBQUNKLGVBQU9wYSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQ2lZLEVBQUUsQ0FBQ2pZO0FBQVgsU0FERyxFQUVIO0FBQUNzSSxnQkFBTSxFQUFDO0FBQUN2TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCO0FBa0JBb0ssZ0JBQWdCLENBQUMsd0JBQUQsRUFBMkIsVUFBU21PLGdCQUFULEVBQTJCQyxnQkFBM0IsRUFBdUQ7QUFBQSxNQUFWNVcsS0FBVSx1RUFBSixHQUFJO0FBQzlGLE1BQUk2VyxLQUFLLEdBQUcsRUFBWjs7QUFDQSxNQUFJRixnQkFBZ0IsSUFBSUMsZ0JBQXhCLEVBQXlDO0FBQ3JDQyxTQUFLLEdBQUc7QUFBQ3hjLFNBQUcsRUFBQyxDQUFDO0FBQUMsbUNBQTBCc2M7QUFBM0IsT0FBRCxFQUErQztBQUFDLG1DQUEwQkM7QUFBM0IsT0FBL0M7QUFBTCxLQUFSO0FBQ0g7O0FBRUQsTUFBSSxDQUFDRCxnQkFBRCxJQUFxQkMsZ0JBQXpCLEVBQTBDO0FBQ3RDQyxTQUFLLEdBQUc7QUFBQyxpQ0FBMEJEO0FBQTNCLEtBQVI7QUFDSDs7QUFFRCxTQUFPO0FBQ0g5WSxRQUFJLEdBQUU7QUFDRixhQUFPdEIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQitZLEtBQWxCLEVBQXlCO0FBQUM5VyxZQUFJLEVBQUM7QUFBQzNCLGdCQUFNLEVBQUMsQ0FBQztBQUFULFNBQU47QUFBbUI0QixhQUFLLEVBQUNBO0FBQXpCLE9BQXpCLENBQVA7QUFDSCxLQUhFOztBQUlIeUksWUFBUSxFQUFDLENBQ0w7QUFDSTNLLFVBQUksQ0FBQ3VZLEVBQUQsRUFBSTtBQUNKLGVBQU9wYSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQ2lZLEVBQUUsQ0FBQ2pZO0FBQVgsU0FERyxFQUVIO0FBQUNzSSxnQkFBTSxFQUFDO0FBQUN2TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURLO0FBSk4sR0FBUDtBQWVILENBekJlLENBQWhCO0FBMkJBb0ssZ0JBQWdCLENBQUMsc0JBQUQsRUFBeUIsVUFBU25ILElBQVQsRUFBYztBQUNuRCxTQUFPO0FBQ0h2RCxRQUFJLEdBQUU7QUFDRixhQUFPdEIsWUFBWSxDQUFDc0IsSUFBYixDQUFrQjtBQUFDMlIsY0FBTSxFQUFDcE87QUFBUixPQUFsQixDQUFQO0FBQ0gsS0FIRTs7QUFJSG9ILFlBQVEsRUFBRSxDQUNOO0FBQ0kzSyxVQUFJLENBQUN1WSxFQUFELEVBQUk7QUFDSixlQUFPcGEsU0FBUyxDQUFDNkIsSUFBVixDQUNIO0FBQUNNLGdCQUFNLEVBQUNpWSxFQUFFLENBQUNqWTtBQUFYLFNBREcsRUFFSDtBQUFDc0ksZ0JBQU0sRUFBQztBQUFDdkwsZ0JBQUksRUFBQyxDQUFOO0FBQVNpRCxrQkFBTSxFQUFDO0FBQWhCO0FBQVIsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FETTtBQUpQLEdBQVA7QUFlSCxDQWhCZSxDQUFoQjtBQWtCQW9LLGdCQUFnQixDQUFDLHFCQUFELEVBQXdCLFVBQVNwSyxNQUFULEVBQWdCO0FBQ3BELFNBQU87QUFDSE4sUUFBSSxHQUFFO0FBQ0YsYUFBT3RCLFlBQVksQ0FBQ3NCLElBQWIsQ0FBa0I7QUFBQ00sY0FBTSxFQUFDQTtBQUFSLE9BQWxCLENBQVA7QUFDSCxLQUhFOztBQUlIcUssWUFBUSxFQUFFLENBQ047QUFDSTNLLFVBQUksQ0FBQ3VZLEVBQUQsRUFBSTtBQUNKLGVBQU9wYSxTQUFTLENBQUM2QixJQUFWLENBQ0g7QUFBQ00sZ0JBQU0sRUFBQ2lZLEVBQUUsQ0FBQ2pZO0FBQVgsU0FERyxFQUVIO0FBQUNzSSxnQkFBTSxFQUFDO0FBQUN2TCxnQkFBSSxFQUFDLENBQU47QUFBU2lELGtCQUFNLEVBQUM7QUFBaEI7QUFBUixTQUZHLENBQVA7QUFJSDs7QUFOTCxLQURNO0FBSlAsR0FBUDtBQWVILENBaEJlLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDcEVBcEcsTUFBTSxDQUFDMFEsTUFBUCxDQUFjO0FBQUNsTSxjQUFZLEVBQUMsTUFBSUE7QUFBbEIsQ0FBZDtBQUErQyxJQUFJbU0sS0FBSjtBQUFVM1EsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDMFEsT0FBSyxDQUFDelEsQ0FBRCxFQUFHO0FBQUN5USxTQUFLLEdBQUN6USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUkrRCxTQUFKO0FBQWNqRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxxQkFBWixFQUFrQztBQUFDZ0UsV0FBUyxDQUFDL0QsQ0FBRCxFQUFHO0FBQUMrRCxhQUFTLEdBQUMvRCxDQUFWO0FBQVk7O0FBQTFCLENBQWxDLEVBQThELENBQTlEO0FBQWlFLElBQUk0ZSxNQUFKO0FBQVc5ZSxNQUFNLENBQUNDLElBQVAsQ0FBWSwrQkFBWixFQUE0QztBQUFDNmUsUUFBTSxDQUFDNWUsQ0FBRCxFQUFHO0FBQUM0ZSxVQUFNLEdBQUM1ZSxDQUFQO0FBQVM7O0FBQXBCLENBQTVDLEVBQWtFLENBQWxFO0FBSTlMLE1BQU1zRSxZQUFZLEdBQUcsSUFBSW1NLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixjQUFyQixDQUFyQjtBQUVQcE0sWUFBWSxDQUFDcU0sT0FBYixDQUFxQjtBQUNqQjFLLE9BQUssR0FBRTtBQUNILFdBQU9sQyxTQUFTLENBQUM3QixPQUFWLENBQWtCO0FBQUNnRSxZQUFNLEVBQUMsS0FBS0E7QUFBYixLQUFsQixDQUFQO0FBQ0g7O0FBSGdCLENBQXJCLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSXJHLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXNFLFlBQUo7QUFBaUJ4RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWixFQUFpRDtBQUFDdUUsY0FBWSxDQUFDdEUsQ0FBRCxFQUFHO0FBQUNzRSxnQkFBWSxHQUFDdEUsQ0FBYjtBQUFlOztBQUFoQyxDQUFqRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJK0QsU0FBSjtBQUFjakUsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQ2dFLFdBQVMsQ0FBQy9ELENBQUQsRUFBRztBQUFDK0QsYUFBUyxHQUFDL0QsQ0FBVjtBQUFZOztBQUExQixDQUFyQyxFQUFpRSxDQUFqRTtBQUFvRSxJQUFJNFcsV0FBSjtBQUFnQjlXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUM2VyxhQUFXLENBQUM1VyxDQUFELEVBQUc7QUFBQzRXLGVBQVcsR0FBQzVXLENBQVo7QUFBYzs7QUFBOUIsQ0FBL0MsRUFBK0UsQ0FBL0U7QUFLelFILE1BQU0sQ0FBQ2UsT0FBUCxDQUFlO0FBQ1gsd0NBQXNDLFVBQVNDLE9BQVQsRUFBaUI7QUFDbkQ7QUFDQSxRQUFJc2QsRUFBRSxHQUFHN1osWUFBWSxDQUFDcEMsT0FBYixDQUFxQjtBQUFDa1ksVUFBSSxFQUFDLENBQ2hDO0FBQUMsZ0RBQXVDdlo7QUFBeEMsT0FEZ0MsRUFFaEM7QUFBQyw2QkFBb0I7QUFBckIsT0FGZ0MsRUFHaEM7QUFBQ3NXLFlBQUksRUFBQztBQUFDbk0saUJBQU8sRUFBQztBQUFUO0FBQU4sT0FIZ0M7QUFBTixLQUFyQixDQUFUOztBQU1BLFFBQUltVCxFQUFKLEVBQU87QUFDSCxVQUFJbFksS0FBSyxHQUFHbEMsU0FBUyxDQUFDN0IsT0FBVixDQUFrQjtBQUFDZ0UsY0FBTSxFQUFDaVksRUFBRSxDQUFDalk7QUFBWCxPQUFsQixDQUFaOztBQUNBLFVBQUlELEtBQUosRUFBVTtBQUNOLGVBQU9BLEtBQUssQ0FBQ2hELElBQWI7QUFDSDtBQUNKLEtBTEQsTUFNSTtBQUNBO0FBQ0EsYUFBTyxLQUFQO0FBQ0g7QUFDSixHQW5CVTs7QUFvQlg7QUFDQSxpQ0FBK0JwQyxPQUEvQixFQUF1QztBQUNuQyxRQUFJVCxHQUFHLEdBQUdHLEdBQUcsR0FBRyxzQkFBTixHQUE2Qk0sT0FBN0IsR0FBcUMsY0FBL0M7O0FBRUEsUUFBRztBQUNDLFVBQUllLFdBQVcsR0FBRzNCLElBQUksQ0FBQ0ssR0FBTCxDQUFTRixHQUFULENBQWxCOztBQUNBLFVBQUl3QixXQUFXLENBQUNwQixVQUFaLElBQTBCLEdBQTlCLEVBQWtDO0FBQzlCb0IsbUJBQVcsR0FBR1gsSUFBSSxDQUFDQyxLQUFMLENBQVdVLFdBQVcsQ0FBQ1QsT0FBdkIsRUFBZ0NDLE1BQTlDO0FBQ0FRLG1CQUFXLENBQUNrQixPQUFaLENBQW9CLENBQUNTLFVBQUQsRUFBYUMsQ0FBYixLQUFtQjtBQUNuQyxjQUFJNUIsV0FBVyxDQUFDNEIsQ0FBRCxDQUFYLElBQWtCNUIsV0FBVyxDQUFDNEIsQ0FBRCxDQUFYLENBQWVkLE1BQXJDLEVBQ0lkLFdBQVcsQ0FBQzRCLENBQUQsQ0FBWCxDQUFlZCxNQUFmLEdBQXdCQyxVQUFVLENBQUNmLFdBQVcsQ0FBQzRCLENBQUQsQ0FBWCxDQUFlZCxNQUFoQixDQUFsQztBQUNQLFNBSEQ7QUFLQSxlQUFPZCxXQUFQO0FBQ0g7O0FBQUE7QUFDSixLQVhELENBWUEsT0FBT25CLENBQVAsRUFBUztBQUNMQyxhQUFPLENBQUNDLEdBQVIsQ0FBWUYsQ0FBWjtBQUNIO0FBQ0o7O0FBdkNVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQSxJQUFJWixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksa0JBQVosRUFBK0I7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQS9CLEVBQTZELENBQTdEO0FBQWdFLElBQUlrRSxnQkFBSjtBQUFxQnBFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaLEVBQXVDO0FBQUNtRSxrQkFBZ0IsQ0FBQ2xFLENBQUQsRUFBRztBQUFDa0Usb0JBQWdCLEdBQUNsRSxDQUFqQjtBQUFtQjs7QUFBeEMsQ0FBdkMsRUFBaUYsQ0FBakY7QUFBb0YsSUFBSXFFLGtCQUFKO0FBQXVCdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQ3NFLG9CQUFrQixDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxzQkFBa0IsR0FBQ3JFLENBQW5CO0FBQXFCOztBQUE1QyxDQUE1QyxFQUEwRixDQUExRjtBQUsvUUgsTUFBTSxDQUFDeVcsT0FBUCxDQUFlLGdCQUFmLEVBQWlDLFlBQW1FO0FBQUEsTUFBekR6TyxJQUF5RCx1RUFBbEQscUJBQWtEO0FBQUEsTUFBM0JnWCxTQUEyQix1RUFBZixDQUFDLENBQWM7QUFBQSxNQUFYclEsTUFBVyx1RUFBSixFQUFJO0FBQ2hHLFNBQU90TyxVQUFVLENBQUMwRixJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQUNpQyxRQUFJLEVBQUU7QUFBQyxPQUFDQSxJQUFELEdBQVFnWDtBQUFULEtBQVA7QUFBNEJyUSxVQUFNLEVBQUVBO0FBQXBDLEdBQXBCLENBQVA7QUFDSCxDQUZEO0FBSUE4QixnQkFBZ0IsQ0FBQyxzQkFBRCxFQUF3QjtBQUNwQzFLLE1BQUksR0FBRztBQUNILFdBQU8xRixVQUFVLENBQUMwRixJQUFYLENBQWdCLEVBQWhCLENBQVA7QUFDSCxHQUhtQzs7QUFJcEMySyxVQUFRLEVBQUUsQ0FDTjtBQUNJM0ssUUFBSSxDQUFDa1osR0FBRCxFQUFNO0FBQ04sYUFBTzVhLGdCQUFnQixDQUFDMEIsSUFBakIsQ0FDSDtBQUFFL0UsZUFBTyxFQUFFaWUsR0FBRyxDQUFDamU7QUFBZixPQURHLEVBRUg7QUFBRWdILFlBQUksRUFBRTtBQUFDM0IsZ0JBQU0sRUFBRTtBQUFULFNBQVI7QUFBcUI0QixhQUFLLEVBQUU7QUFBNUIsT0FGRyxDQUFQO0FBSUg7O0FBTkwsR0FETTtBQUowQixDQUF4QixDQUFoQjtBQWdCQWpJLE1BQU0sQ0FBQ3lXLE9BQVAsQ0FBZSx5QkFBZixFQUEwQyxZQUFVO0FBQ2hELFNBQU9wVyxVQUFVLENBQUMwRixJQUFYLENBQWdCO0FBQ25CNkIsVUFBTSxFQUFFLENBRFc7QUFFbkI2RixVQUFNLEVBQUM7QUFGWSxHQUFoQixFQUdMO0FBQ0V6RixRQUFJLEVBQUM7QUFDRHNELGtCQUFZLEVBQUMsQ0FBQztBQURiLEtBRFA7QUFJRXFELFVBQU0sRUFBQztBQUNIM04sYUFBTyxFQUFFLENBRE47QUFFSHVNLGlCQUFXLEVBQUMsQ0FGVDtBQUdIakMsa0JBQVksRUFBQyxDQUhWO0FBSUhrQyxpQkFBVyxFQUFDO0FBSlQ7QUFKVCxHQUhLLENBQVA7QUFlSCxDQWhCRDtBQWtCQWlELGdCQUFnQixDQUFDLG1CQUFELEVBQXNCLFVBQVN6UCxPQUFULEVBQWlCO0FBQ25ELE1BQUkwWixPQUFPLEdBQUc7QUFBQzFaLFdBQU8sRUFBQ0E7QUFBVCxHQUFkOztBQUNBLE1BQUlBLE9BQU8sQ0FBQ3lFLE9BQVIsQ0FBZ0J6RixNQUFNLENBQUNpSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QndYLG1CQUF2QyxLQUErRCxDQUFDLENBQXBFLEVBQXNFO0FBQ2xFaEUsV0FBTyxHQUFHO0FBQUNuWSxzQkFBZ0IsRUFBQ3ZCO0FBQWxCLEtBQVY7QUFDSDs7QUFDRCxTQUFPO0FBQ0grRSxRQUFJLEdBQUU7QUFDRixhQUFPMUYsVUFBVSxDQUFDMEYsSUFBWCxDQUFnQjJVLE9BQWhCLENBQVA7QUFDSCxLQUhFOztBQUlIaEssWUFBUSxFQUFFLENBQ047QUFDSTNLLFVBQUksQ0FBQ2taLEdBQUQsRUFBSztBQUNMLGVBQU96YSxrQkFBa0IsQ0FBQ3VCLElBQW5CLENBQ0g7QUFBQy9FLGlCQUFPLEVBQUNpZSxHQUFHLENBQUNqZTtBQUFiLFNBREcsRUFFSDtBQUFDZ0gsY0FBSSxFQUFDO0FBQUMzQixrQkFBTSxFQUFDLENBQUM7QUFBVCxXQUFOO0FBQW1CNEIsZUFBSyxFQUFDO0FBQXpCLFNBRkcsQ0FBUDtBQUlIOztBQU5MLEtBRE0sRUFTTjtBQUNJbEMsVUFBSSxDQUFDa1osR0FBRCxFQUFNO0FBQ04sZUFBTzVhLGdCQUFnQixDQUFDMEIsSUFBakIsQ0FDSDtBQUFFL0UsaUJBQU8sRUFBRWllLEdBQUcsQ0FBQ2plO0FBQWYsU0FERyxFQUVIO0FBQUVnSCxjQUFJLEVBQUU7QUFBQzNCLGtCQUFNLEVBQUUsQ0FBQztBQUFWLFdBQVI7QUFBc0I0QixlQUFLLEVBQUVqSSxNQUFNLENBQUNpSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QkM7QUFBcEQsU0FGRyxDQUFQO0FBSUg7O0FBTkwsS0FUTTtBQUpQLEdBQVA7QUF1QkgsQ0E1QmUsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUMzQ0FsSCxNQUFNLENBQUMwUSxNQUFQLENBQWM7QUFBQ3RRLFlBQVUsRUFBQyxNQUFJQTtBQUFoQixDQUFkO0FBQTJDLElBQUl1USxLQUFKO0FBQVUzUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMwUSxPQUFLLENBQUN6USxDQUFELEVBQUc7QUFBQ3lRLFNBQUssR0FBQ3pRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSWtFLGdCQUFKO0FBQXFCcEUsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQ21FLGtCQUFnQixDQUFDbEUsQ0FBRCxFQUFHO0FBQUNrRSxvQkFBZ0IsR0FBQ2xFLENBQWpCO0FBQW1COztBQUF4QyxDQUFwQyxFQUE4RSxDQUE5RTtBQUFpRixJQUFJcUUsa0JBQUo7QUFBdUJ2RSxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWixFQUF5QztBQUFDc0Usb0JBQWtCLENBQUNyRSxDQUFELEVBQUc7QUFBQ3FFLHNCQUFrQixHQUFDckUsQ0FBbkI7QUFBcUI7O0FBQTVDLENBQXpDLEVBQXVGLENBQXZGO0FBSTdOLE1BQU1FLFVBQVUsR0FBRyxJQUFJdVEsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFlBQXJCLENBQW5CO0FBRVB4USxVQUFVLENBQUN5USxPQUFYLENBQW1CO0FBQ2ZvTyxXQUFTLEdBQUU7QUFDUCxXQUFPN2EsZ0JBQWdCLENBQUNoQyxPQUFqQixDQUF5QjtBQUFDckIsYUFBTyxFQUFDLEtBQUtBO0FBQWQsS0FBekIsQ0FBUDtBQUNILEdBSGM7O0FBSWZtZSxTQUFPLEdBQUU7QUFDTCxXQUFPM2Esa0JBQWtCLENBQUN1QixJQUFuQixDQUF3QjtBQUFDL0UsYUFBTyxFQUFDLEtBQUtBO0FBQWQsS0FBeEIsRUFBZ0Q7QUFBQ2dILFVBQUksRUFBQztBQUFDM0IsY0FBTSxFQUFDLENBQUM7QUFBVCxPQUFOO0FBQW1CNEIsV0FBSyxFQUFDO0FBQXpCLEtBQWhELEVBQThFaEMsS0FBOUUsRUFBUDtBQUNIOztBQU5jLENBQW5CLEUsQ0FRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNCQWhHLE1BQU0sQ0FBQzBRLE1BQVAsQ0FBYztBQUFDbk0sb0JBQWtCLEVBQUMsTUFBSUE7QUFBeEIsQ0FBZDtBQUEyRCxJQUFJb00sS0FBSjtBQUFVM1EsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDMFEsT0FBSyxDQUFDelEsQ0FBRCxFQUFHO0FBQUN5USxTQUFLLEdBQUN6USxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBRTlELE1BQU1xRSxrQkFBa0IsR0FBRyxJQUFJb00sS0FBSyxDQUFDQyxVQUFWLENBQXFCLHNCQUFyQixDQUEzQixDOzs7Ozs7Ozs7OztBQ0ZQNVEsTUFBTSxDQUFDMFEsTUFBUCxDQUFjO0FBQUNqTSxXQUFTLEVBQUMsTUFBSUE7QUFBZixDQUFkO0FBQXlDLElBQUlrTSxLQUFKO0FBQVUzUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMwUSxPQUFLLENBQUN6USxDQUFELEVBQUc7QUFBQ3lRLFNBQUssR0FBQ3pRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFNUMsTUFBTXVFLFNBQVMsR0FBRyxJQUFJa00sS0FBSyxDQUFDQyxVQUFWLENBQXFCLFdBQXJCLENBQWxCLEM7Ozs7Ozs7Ozs7O0FDRlA1USxNQUFNLENBQUMwUSxNQUFQLENBQWM7QUFBQ3ZNLGVBQWEsRUFBQyxNQUFJQTtBQUFuQixDQUFkO0FBQWlELElBQUl3TSxLQUFKO0FBQVUzUSxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUMwUSxPQUFLLENBQUN6USxDQUFELEVBQUc7QUFBQ3lRLFNBQUssR0FBQ3pRLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFcEQsTUFBTWlFLGFBQWEsR0FBRyxJQUFJd00sS0FBSyxDQUFDQyxVQUFWLENBQXFCLGdCQUFyQixDQUF0QixDOzs7Ozs7Ozs7OztBQ0ZQO0FBQ0Esd0M7Ozs7Ozs7Ozs7O0FDREEsSUFBSTNNLFNBQUo7QUFBY2pFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRCQUFaLEVBQXlDO0FBQUNnRSxXQUFTLENBQUMvRCxDQUFELEVBQUc7QUFBQytELGFBQVMsR0FBQy9ELENBQVY7QUFBWTs7QUFBMUIsQ0FBekMsRUFBcUUsQ0FBckU7QUFBd0UsSUFBSTZYLFNBQUo7QUFBYy9YLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUM4WCxXQUFTLENBQUM3WCxDQUFELEVBQUc7QUFBQzZYLGFBQVMsR0FBQzdYLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSWtFLGdCQUFKLEVBQXFCQyxTQUFyQixFQUErQnlWLGlCQUEvQixFQUFpREMsWUFBakQsRUFBOERKLFdBQTlELEVBQTBFQyxvQkFBMUU7QUFBK0Y1WixNQUFNLENBQUNDLElBQVAsQ0FBWSw4QkFBWixFQUEyQztBQUFDbUUsa0JBQWdCLENBQUNsRSxDQUFELEVBQUc7QUFBQ2tFLG9CQUFnQixHQUFDbEUsQ0FBakI7QUFBbUIsR0FBeEM7O0FBQXlDbUUsV0FBUyxDQUFDbkUsQ0FBRCxFQUFHO0FBQUNtRSxhQUFTLEdBQUNuRSxDQUFWO0FBQVksR0FBbEU7O0FBQW1FNFosbUJBQWlCLENBQUM1WixDQUFELEVBQUc7QUFBQzRaLHFCQUFpQixHQUFDNVosQ0FBbEI7QUFBb0IsR0FBNUc7O0FBQTZHNlosY0FBWSxDQUFDN1osQ0FBRCxFQUFHO0FBQUM2WixnQkFBWSxHQUFDN1osQ0FBYjtBQUFlLEdBQTVJOztBQUE2SXlaLGFBQVcsQ0FBQ3paLENBQUQsRUFBRztBQUFDeVosZUFBVyxHQUFDelosQ0FBWjtBQUFjLEdBQTFLOztBQUEySzBaLHNCQUFvQixDQUFDMVosQ0FBRCxFQUFHO0FBQUMwWix3QkFBb0IsR0FBQzFaLENBQXJCO0FBQXVCOztBQUExTixDQUEzQyxFQUF1USxDQUF2UTtBQUEwUSxJQUFJc0UsWUFBSjtBQUFpQnhFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaLEVBQXFEO0FBQUN1RSxjQUFZLENBQUN0RSxDQUFELEVBQUc7QUFBQ3NFLGdCQUFZLEdBQUN0RSxDQUFiO0FBQWU7O0FBQWhDLENBQXJELEVBQXVGLENBQXZGO0FBQTBGLElBQUlpRSxhQUFKO0FBQWtCbkUsTUFBTSxDQUFDQyxJQUFQLENBQVksNENBQVosRUFBeUQ7QUFBQ2tFLGVBQWEsQ0FBQ2pFLENBQUQsRUFBRztBQUFDaUUsaUJBQWEsR0FBQ2pFLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXpELEVBQTZGLENBQTdGO0FBQWdHLElBQUlFLFVBQUo7QUFBZUosTUFBTSxDQUFDQyxJQUFQLENBQVksb0NBQVosRUFBaUQ7QUFBQ0csWUFBVSxDQUFDRixDQUFELEVBQUc7QUFBQ0UsY0FBVSxHQUFDRixDQUFYO0FBQWE7O0FBQTVCLENBQWpELEVBQStFLENBQS9FO0FBQWtGLElBQUlxRSxrQkFBSjtBQUF1QnZFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1DQUFaLEVBQWdEO0FBQUNzRSxvQkFBa0IsQ0FBQ3JFLENBQUQsRUFBRztBQUFDcUUsc0JBQWtCLEdBQUNyRSxDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBaEQsRUFBOEYsQ0FBOUY7QUFBaUcsSUFBSXVFLFNBQUo7QUFBY3pFLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGtDQUFaLEVBQStDO0FBQUN3RSxXQUFTLENBQUN2RSxDQUFELEVBQUc7QUFBQ3VFLGFBQVMsR0FBQ3ZFLENBQVY7QUFBWTs7QUFBMUIsQ0FBL0MsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSXFXLFNBQUo7QUFBY3ZXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG9DQUFaLEVBQWlEO0FBQUNzVyxXQUFTLENBQUNyVyxDQUFELEVBQUc7QUFBQ3FXLGFBQVMsR0FBQ3JXLENBQVY7QUFBWTs7QUFBMUIsQ0FBakQsRUFBNkUsQ0FBN0U7QUFBZ0YsSUFBSTZRLFdBQUo7QUFBZ0IvUSxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQkFBWixFQUF1QztBQUFDOFEsYUFBVyxDQUFDN1EsQ0FBRCxFQUFHO0FBQUM2USxlQUFXLEdBQUM3USxDQUFaO0FBQWM7O0FBQTlCLENBQXZDLEVBQXVFLENBQXZFO0FBWTNwQzZRLFdBQVcsQ0FBQ3BLLGFBQVosR0FBNEJ3WSxXQUE1QixDQUF3QztBQUFDL1ksUUFBTSxFQUFFLENBQUM7QUFBVixDQUF4QyxFQUFxRDtBQUFDZ1osUUFBTSxFQUFDO0FBQVIsQ0FBckQ7QUFFQW5iLFNBQVMsQ0FBQzBDLGFBQVYsR0FBMEJ3WSxXQUExQixDQUFzQztBQUFDL1ksUUFBTSxFQUFFLENBQUM7QUFBVixDQUF0QyxFQUFtRDtBQUFDZ1osUUFBTSxFQUFDO0FBQVIsQ0FBbkQ7QUFDQW5iLFNBQVMsQ0FBQzBDLGFBQVYsR0FBMEJ3WSxXQUExQixDQUFzQztBQUFDcFosaUJBQWUsRUFBQztBQUFqQixDQUF0QztBQUVBdEIsU0FBUyxDQUFDa0MsYUFBVixHQUEwQndZLFdBQTFCLENBQXNDO0FBQUMvWSxRQUFNLEVBQUUsQ0FBQztBQUFWLENBQXRDO0FBRUEyUixTQUFTLENBQUNwUixhQUFWLEdBQTBCd1ksV0FBMUIsQ0FBc0M7QUFBQ2hILFlBQVUsRUFBRTtBQUFiLENBQXRDLEVBQXVEO0FBQUNpSCxRQUFNLEVBQUM7QUFBUixDQUF2RDtBQUVBaGIsZ0JBQWdCLENBQUN1QyxhQUFqQixHQUFpQ3dZLFdBQWpDLENBQTZDO0FBQUNwZSxTQUFPLEVBQUMsQ0FBVDtBQUFXcUYsUUFBTSxFQUFFLENBQUM7QUFBcEIsQ0FBN0MsRUFBcUU7QUFBQ2daLFFBQU0sRUFBQztBQUFSLENBQXJFO0FBQ0FoYixnQkFBZ0IsQ0FBQ3VDLGFBQWpCLEdBQWlDd1ksV0FBakMsQ0FBNkM7QUFBQ3BlLFNBQU8sRUFBQyxDQUFUO0FBQVdxSyxRQUFNLEVBQUMsQ0FBbEI7QUFBcUJoRixRQUFNLEVBQUUsQ0FBQztBQUE5QixDQUE3QztBQUVBL0IsU0FBUyxDQUFDc0MsYUFBVixHQUEwQndZLFdBQTFCLENBQXNDO0FBQUMvWSxRQUFNLEVBQUUsQ0FBQztBQUFWLENBQXRDLEVBQW9EO0FBQUNnWixRQUFNLEVBQUM7QUFBUixDQUFwRDtBQUVBckYsWUFBWSxDQUFDcFQsYUFBYixHQUE2QndZLFdBQTdCLENBQXlDO0FBQUNyTyxVQUFRLEVBQUMsQ0FBVjtBQUFhb0ksT0FBSyxFQUFDLENBQW5CO0FBQXNCSCxXQUFTLEVBQUUsQ0FBQztBQUFsQyxDQUF6QztBQUNBZ0IsWUFBWSxDQUFDcFQsYUFBYixHQUE2QndZLFdBQTdCLENBQXlDO0FBQUNyTyxVQUFRLEVBQUMsQ0FBVjtBQUFhZ0ssYUFBVyxFQUFDLENBQUM7QUFBMUIsQ0FBekM7QUFDQWYsWUFBWSxDQUFDcFQsYUFBYixHQUE2QndZLFdBQTdCLENBQXlDO0FBQUNqRyxPQUFLLEVBQUMsQ0FBUDtBQUFVNEIsYUFBVyxFQUFDLENBQUM7QUFBdkIsQ0FBekM7QUFDQWYsWUFBWSxDQUFDcFQsYUFBYixHQUE2QndZLFdBQTdCLENBQXlDO0FBQUNqRyxPQUFLLEVBQUMsQ0FBUDtBQUFVcEksVUFBUSxFQUFDLENBQW5CO0FBQXNCZ0ssYUFBVyxFQUFDLENBQUM7QUFBbkMsQ0FBekMsRUFBZ0Y7QUFBQ3NFLFFBQU0sRUFBQztBQUFSLENBQWhGO0FBRUF0RixpQkFBaUIsQ0FBQ25ULGFBQWxCLEdBQWtDd1ksV0FBbEMsQ0FBOEM7QUFBQ3JPLFVBQVEsRUFBQztBQUFWLENBQTlDO0FBQ0FnSixpQkFBaUIsQ0FBQ25ULGFBQWxCLEdBQWtDd1ksV0FBbEMsQ0FBOEM7QUFBQ2pHLE9BQUssRUFBQztBQUFQLENBQTlDO0FBQ0FZLGlCQUFpQixDQUFDblQsYUFBbEIsR0FBa0N3WSxXQUFsQyxDQUE4QztBQUFDck8sVUFBUSxFQUFDLENBQVY7QUFBYW9JLE9BQUssRUFBQztBQUFuQixDQUE5QyxFQUFvRTtBQUFDa0csUUFBTSxFQUFDO0FBQVIsQ0FBcEU7QUFFQXpGLFdBQVcsQ0FBQ2hULGFBQVosR0FBNEJ3WSxXQUE1QixDQUF3QztBQUFDM2QsTUFBSSxFQUFDLENBQU47QUFBU3dWLFdBQVMsRUFBQyxDQUFDO0FBQXBCLENBQXhDLEVBQStEO0FBQUNvSSxRQUFNLEVBQUM7QUFBUixDQUEvRDtBQUNBeEYsb0JBQW9CLENBQUNqVCxhQUFyQixHQUFxQ3dZLFdBQXJDLENBQWlEO0FBQUNwWixpQkFBZSxFQUFDLENBQWpCO0FBQW1CaVIsV0FBUyxFQUFDLENBQUM7QUFBOUIsQ0FBakQsRUFBa0Y7QUFBQ29JLFFBQU0sRUFBQztBQUFSLENBQWxGLEUsQ0FDQTs7QUFFQTVhLFlBQVksQ0FBQ21DLGFBQWIsR0FBNkJ3WSxXQUE3QixDQUF5QztBQUFDMUgsUUFBTSxFQUFDO0FBQVIsQ0FBekMsRUFBb0Q7QUFBQzJILFFBQU0sRUFBQztBQUFSLENBQXBEO0FBQ0E1YSxZQUFZLENBQUNtQyxhQUFiLEdBQTZCd1ksV0FBN0IsQ0FBeUM7QUFBQy9ZLFFBQU0sRUFBQyxDQUFDO0FBQVQsQ0FBekMsRSxDQUNBOztBQUNBNUIsWUFBWSxDQUFDbUMsYUFBYixHQUE2QndZLFdBQTdCLENBQXlDO0FBQUMsMkJBQXdCO0FBQXpCLENBQXpDO0FBQ0EzYSxZQUFZLENBQUNtQyxhQUFiLEdBQTZCd1ksV0FBN0IsQ0FBeUM7QUFBQyw2QkFBMEI7QUFBM0IsQ0FBekM7QUFFQWhiLGFBQWEsQ0FBQ3dDLGFBQWQsR0FBOEJ3WSxXQUE5QixDQUEwQztBQUFDdlUsY0FBWSxFQUFDLENBQUM7QUFBZixDQUExQztBQUVBeEssVUFBVSxDQUFDdUcsYUFBWCxHQUEyQndZLFdBQTNCLENBQXVDO0FBQUNwZSxTQUFPLEVBQUM7QUFBVCxDQUF2QyxFQUFtRDtBQUFDcWUsUUFBTSxFQUFDLElBQVI7QUFBY0MseUJBQXVCLEVBQUU7QUFBRXRlLFdBQU8sRUFBRTtBQUFFbUssYUFBTyxFQUFFO0FBQVg7QUFBWDtBQUF2QyxDQUFuRDtBQUNBOUssVUFBVSxDQUFDdUcsYUFBWCxHQUEyQndZLFdBQTNCLENBQXVDO0FBQUMzVyxrQkFBZ0IsRUFBQztBQUFsQixDQUF2QyxFQUE0RDtBQUFDNFcsUUFBTSxFQUFDO0FBQVIsQ0FBNUQ7QUFDQWhmLFVBQVUsQ0FBQ3VHLGFBQVgsR0FBMkJ3WSxXQUEzQixDQUF1QztBQUFDLG1CQUFnQjtBQUFqQixDQUF2QyxFQUEyRDtBQUFDQyxRQUFNLEVBQUMsSUFBUjtBQUFjQyx5QkFBdUIsRUFBRTtBQUFFLHFCQUFpQjtBQUFFblUsYUFBTyxFQUFFO0FBQVg7QUFBbkI7QUFBdkMsQ0FBM0Q7QUFFQTNHLGtCQUFrQixDQUFDb0MsYUFBbkIsR0FBbUN3WSxXQUFuQyxDQUErQztBQUFDcGUsU0FBTyxFQUFDLENBQVQ7QUFBV3FGLFFBQU0sRUFBQyxDQUFDO0FBQW5CLENBQS9DO0FBQ0E3QixrQkFBa0IsQ0FBQ29DLGFBQW5CLEdBQW1Dd1ksV0FBbkMsQ0FBK0M7QUFBQzNkLE1BQUksRUFBQztBQUFOLENBQS9DO0FBRUErVSxTQUFTLENBQUM1UCxhQUFWLEdBQTBCd1ksV0FBMUIsQ0FBc0M7QUFBQzFJLGlCQUFlLEVBQUMsQ0FBQztBQUFsQixDQUF0QyxFQUEyRDtBQUFDMkksUUFBTSxFQUFDO0FBQVIsQ0FBM0QsRTs7Ozs7Ozs7Ozs7QUN0REFwZixNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaO0FBQXlCRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxtQkFBWjtBQUFpQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVo7QUFBbUMsSUFBSXFmLFVBQUo7QUFBZXRmLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUNxZixZQUFVLENBQUNwZixDQUFELEVBQUc7QUFBQ29mLGNBQVUsR0FBQ3BmLENBQVg7QUFBYTs7QUFBNUIsQ0FBbkMsRUFBaUUsQ0FBakU7QUFBb0UsSUFBSXFmLE1BQUo7QUFBV3ZmLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ3NmLFFBQU0sQ0FBQ3JmLENBQUQsRUFBRztBQUFDcWYsVUFBTSxHQUFDcmYsQ0FBUDtBQUFTOztBQUFwQixDQUEzQixFQUFpRCxDQUFqRDtBQWMzTDtBQUVBb2YsVUFBVSxDQUFDRSxJQUFJLElBQUk7QUFDZjtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUEsUUFBTUMsTUFBTSxHQUFHRixNQUFNLENBQUNHLFlBQVAsRUFBZjtBQUNBRixNQUFJLENBQUNHLFlBQUwsQ0FBa0JGLE1BQU0sQ0FBQ0csSUFBUCxDQUFZQyxRQUFaLEVBQWxCO0FBQ0FMLE1BQUksQ0FBQ0csWUFBTCxDQUFrQkYsTUFBTSxDQUFDSyxLQUFQLENBQWFELFFBQWIsRUFBbEIsRUFkZSxDQWdCZjtBQUNILENBakJTLENBQVYsQzs7Ozs7Ozs7Ozs7QUNoQkE3ZixNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWjtBQUFrREQsTUFBTSxDQUFDQyxJQUFQLENBQVksbUNBQVo7QUFBaURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaO0FBQXNERCxNQUFNLENBQUNDLElBQVAsQ0FBWSxvQ0FBWjtBQUFrREQsTUFBTSxDQUFDQyxJQUFQLENBQVkseUNBQVo7QUFBdURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdDQUFaO0FBQXNERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw2Q0FBWjtBQUEyREQsTUFBTSxDQUFDQyxJQUFQLENBQVkscUNBQVo7QUFBbURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBDQUFaO0FBQXdERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx1Q0FBWjtBQUFxREQsTUFBTSxDQUFDQyxJQUFQLENBQVksNENBQVo7QUFBMERELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLCtDQUFaO0FBQTZERCxNQUFNLENBQUNDLElBQVAsQ0FBWSwwQ0FBWjtBQUF3REQsTUFBTSxDQUFDQyxJQUFQLENBQVksK0NBQVo7QUFBNkRELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHlDQUFaO0FBQXVERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw4Q0FBWjtBQUE0REQsTUFBTSxDQUFDQyxJQUFQLENBQVkseUNBQVo7QUFBdURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNDQUFaO0FBQW9ERCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWixFOzs7Ozs7Ozs7OztBQ0E3OUIsSUFBSThmLE1BQUo7QUFBVy9mLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ2dSLFNBQU8sQ0FBQy9RLENBQUQsRUFBRztBQUFDNmYsVUFBTSxHQUFDN2YsQ0FBUDtBQUFTOztBQUFyQixDQUFyQixFQUE0QyxDQUE1QztBQUErQyxJQUFJQyxJQUFKO0FBQVNILE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ0UsTUFBSSxDQUFDRCxDQUFELEVBQUc7QUFBQ0MsUUFBSSxHQUFDRCxDQUFMO0FBQU87O0FBQWhCLENBQTFCLEVBQTRDLENBQTVDO0FBQStDLElBQUkwRSxPQUFKO0FBQVk1RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxTQUFaLEVBQXNCO0FBQUMsTUFBSUMsQ0FBSixFQUFNO0FBQUMwRSxXQUFPLEdBQUMxRSxDQUFSO0FBQVU7O0FBQWxCLENBQXRCLEVBQTBDLENBQTFDOztBQUk5SDtBQUNBLElBQUk4ZixNQUFNLEdBQUdDLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLGVBQVosQ0FBYixDLENBQ0E7OztBQUNBLElBQUlDLElBQUksR0FBR0YsR0FBRyxDQUFDQyxPQUFKLENBQVksZUFBWixFQUE2QkMsSUFBeEM7O0FBRUEsU0FBU0MsV0FBVCxDQUFxQkMsU0FBckIsRUFBZ0M7QUFDNUIsU0FBT0EsU0FBUyxDQUFDbmEsR0FBVixDQUFjLFVBQVNvYSxJQUFULEVBQWU7QUFDaEMsV0FBTyxDQUFDLE1BQU0sQ0FBQ0EsSUFBSSxHQUFHLElBQVIsRUFBY1QsUUFBZCxDQUF1QixFQUF2QixDQUFQLEVBQW1DVSxLQUFuQyxDQUF5QyxDQUFDLENBQTFDLENBQVA7QUFDSCxHQUZNLEVBRUpDLElBRkksQ0FFQyxFQUZELENBQVA7QUFHSDs7QUFFRHpnQixNQUFNLENBQUNlLE9BQVAsQ0FBZTtBQUNYMmYsZ0JBQWMsRUFBRSxVQUFTdkssTUFBVCxFQUFpQndLLE1BQWpCLEVBQXlCO0FBQ3JDLFFBQUlDLE1BQUo7O0FBRUEsUUFBSXpLLE1BQU0sQ0FBQzFVLElBQVAsQ0FBWWdFLE9BQVosQ0FBb0IsZUFBcEIsSUFBdUMsQ0FBM0MsRUFBNkM7QUFDekM7QUFDQSxVQUFJb2IsaUJBQWlCLEdBQUd4VyxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLEtBQTFCLENBQXhCO0FBQ0FzVyxZQUFNLEdBQUd2VyxNQUFNLENBQUN5VyxLQUFQLENBQWEsRUFBYixDQUFUO0FBRUFELHVCQUFpQixDQUFDRSxJQUFsQixDQUF1QkgsTUFBdkIsRUFBK0IsQ0FBL0I7QUFDQXZXLFlBQU0sQ0FBQ0MsSUFBUCxDQUFZNkwsTUFBTSxDQUFDelUsS0FBbkIsRUFBMEIsUUFBMUIsRUFBb0NxZixJQUFwQyxDQUF5Q0gsTUFBekMsRUFBaURDLGlCQUFpQixDQUFDbmUsTUFBbkU7QUFDSCxLQVBELE1BUUssSUFBSXlULE1BQU0sQ0FBQzFVLElBQVAsQ0FBWWdFLE9BQVosQ0FBb0IsaUJBQXBCLElBQXlDLENBQTdDLEVBQStDO0FBQ2hEO0FBQ0EsVUFBSW9iLGlCQUFpQixHQUFHeFcsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUEwQixLQUExQixDQUF4QjtBQUNBc1csWUFBTSxHQUFHdlcsTUFBTSxDQUFDeVcsS0FBUCxDQUFhLEVBQWIsQ0FBVDtBQUVBRCx1QkFBaUIsQ0FBQ0UsSUFBbEIsQ0FBdUJILE1BQXZCLEVBQStCLENBQS9CO0FBQ0F2VyxZQUFNLENBQUNDLElBQVAsQ0FBWTZMLE1BQU0sQ0FBQ3pVLEtBQW5CLEVBQTBCLFFBQTFCLEVBQW9DcWYsSUFBcEMsQ0FBeUNILE1BQXpDLEVBQWlEQyxpQkFBaUIsQ0FBQ25lLE1BQW5FO0FBQ0gsS0FQSSxNQVFBO0FBQ0Q3QixhQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBWjtBQUNBLGFBQU8sS0FBUDtBQUNIOztBQUVELFdBQU9rZixNQUFNLENBQUNnQixNQUFQLENBQWNMLE1BQWQsRUFBc0JYLE1BQU0sQ0FBQ2lCLE9BQVAsQ0FBZUwsTUFBZixDQUF0QixDQUFQO0FBQ0gsR0ExQlU7QUEyQlhNLGdCQUFjLEVBQUUsVUFBUy9LLE1BQVQsRUFBaUIxVSxJQUFqQixFQUF1QjtBQUNuQztBQUNBLFFBQUlvZixpQkFBSixFQUF1QkQsTUFBdkI7O0FBRUEsUUFBSW5mLElBQUksQ0FBQ2dFLE9BQUwsQ0FBYSxlQUFiLElBQWdDLENBQXBDLEVBQXNDO0FBQ2xDO0FBQ0FvYix1QkFBaUIsR0FBR3hXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBMEIsS0FBMUIsQ0FBcEI7QUFDQXNXLFlBQU0sR0FBR3ZXLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZMFYsTUFBTSxDQUFDbUIsU0FBUCxDQUFpQm5CLE1BQU0sQ0FBQ29CLE1BQVAsQ0FBY2pMLE1BQWQsRUFBc0JrTCxLQUF2QyxDQUFaLENBQVQ7QUFDSCxLQUpELE1BS0ssSUFBSTVmLElBQUksQ0FBQ2dFLE9BQUwsQ0FBYSxpQkFBYixJQUFrQyxDQUF0QyxFQUF3QztBQUN6QztBQUNBb2IsdUJBQWlCLEdBQUd4VyxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQTBCLEtBQTFCLENBQXBCO0FBQ0FzVyxZQUFNLEdBQUd2VyxNQUFNLENBQUNDLElBQVAsQ0FBWTBWLE1BQU0sQ0FBQ21CLFNBQVAsQ0FBaUJuQixNQUFNLENBQUNvQixNQUFQLENBQWNqTCxNQUFkLEVBQXNCa0wsS0FBdkMsQ0FBWixDQUFUO0FBQ0gsS0FKSSxNQUtBO0FBQ0R4Z0IsYUFBTyxDQUFDQyxHQUFSLENBQVksNEJBQVo7QUFDQSxhQUFPLEtBQVA7QUFDSDs7QUFFRCxXQUFPOGYsTUFBTSxDQUFDSixLQUFQLENBQWFLLGlCQUFpQixDQUFDbmUsTUFBL0IsRUFBdUNvZCxRQUF2QyxDQUFnRCxRQUFoRCxDQUFQO0FBQ0gsR0EvQ1U7QUFnRFh3QixjQUFZLEVBQUUsVUFBU0MsWUFBVCxFQUFzQjtBQUNoQyxRQUFJdmdCLE9BQU8sR0FBR2dmLE1BQU0sQ0FBQ29CLE1BQVAsQ0FBY0csWUFBZCxDQUFkO0FBQ0EsV0FBT3ZCLE1BQU0sQ0FBQ2dCLE1BQVAsQ0FBY2hoQixNQUFNLENBQUNpSCxRQUFQLENBQWdCQyxNQUFoQixDQUF1QnlYLG1CQUFyQyxFQUEwRDNkLE9BQU8sQ0FBQ3FnQixLQUFsRSxDQUFQO0FBQ0gsR0FuRFU7QUFvRFhHLG1CQUFpQixFQUFFLFVBQVNDLFVBQVQsRUFBb0I7QUFDbkMsUUFBSS9iLFFBQVEsR0FBR3RGLElBQUksQ0FBQ0ssR0FBTCxDQUFTZ2hCLFVBQVQsQ0FBZjs7QUFDQSxRQUFJL2IsUUFBUSxDQUFDL0UsVUFBVCxJQUF1QixHQUEzQixFQUErQjtBQUMzQixVQUFJZ0YsSUFBSSxHQUFHZCxPQUFPLENBQUNlLElBQVIsQ0FBYUYsUUFBUSxDQUFDcEUsT0FBdEIsQ0FBWDtBQUNBLGFBQU9xRSxJQUFJLENBQUMsbUJBQUQsQ0FBSixDQUEwQkUsSUFBMUIsQ0FBK0IsS0FBL0IsQ0FBUDtBQUNIO0FBQ0o7QUExRFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBNUYsTUFBTSxDQUFDMFEsTUFBUCxDQUFjO0FBQUMrUSxhQUFXLEVBQUMsTUFBSUEsV0FBakI7QUFBNkJDLG9CQUFrQixFQUFDLE1BQUlBLGtCQUFwRDtBQUF1RUMsVUFBUSxFQUFDLE1BQUlBLFFBQXBGO0FBQTZGN0MsUUFBTSxFQUFDLE1BQUlBLE1BQXhHO0FBQStHOEMsVUFBUSxFQUFDLE1BQUlBO0FBQTVILENBQWQ7QUFBcUosSUFBSUMsS0FBSjtBQUFVN2hCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLE9BQVosRUFBb0I7QUFBQ2dSLFNBQU8sQ0FBQy9RLENBQUQsRUFBRztBQUFDMmhCLFNBQUssR0FBQzNoQixDQUFOO0FBQVE7O0FBQXBCLENBQXBCLEVBQTBDLENBQTFDO0FBQTZDLElBQUk0aEIsbUJBQUo7QUFBd0I5aEIsTUFBTSxDQUFDQyxJQUFQLENBQVksWUFBWixFQUF5QjtBQUFDNmhCLHFCQUFtQixDQUFDNWhCLENBQUQsRUFBRztBQUFDNGhCLHVCQUFtQixHQUFDNWhCLENBQXBCO0FBQXNCOztBQUE5QyxDQUF6QixFQUF5RSxDQUF6RTs7QUFHN04sTUFBTXVoQixXQUFXLEdBQUlNLEtBQUQsSUFBVztBQUNsQyxVQUFRQSxLQUFLLENBQUM5TyxLQUFkO0FBQ0EsU0FBSyxPQUFMO0FBQ0ksYUFBTyxJQUFQOztBQUNKO0FBQ0ksYUFBTyxJQUFQO0FBSko7QUFNSCxDQVBNOztBQVVBLE1BQU15TyxrQkFBa0IsR0FBSUssS0FBRCxJQUFXO0FBQ3pDLFVBQVFBLEtBQUssQ0FBQ3BhLE1BQWQ7QUFDQSxTQUFLLFFBQUw7QUFDSSwwQkFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssVUFBTDtBQUNJLDBCQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxTQUFMO0FBQ0ksMEJBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLGVBQUw7QUFDSSwwQkFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssY0FBTDtBQUNJLDBCQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0o7QUFDSSwwQkFBTyw4QkFBUDtBQVpKO0FBY0gsQ0FmTTs7QUFpQkEsTUFBTWdhLFFBQVEsR0FBSUksS0FBRCxJQUFXO0FBQy9CLFVBQVFBLEtBQUssQ0FBQzlJLElBQWQ7QUFDQSxTQUFLLEtBQUw7QUFDSSwwQkFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKLFNBQUssSUFBTDtBQUNJLDBCQUFPO0FBQUcsaUJBQVMsRUFBQztBQUFiLFFBQVA7O0FBQ0osU0FBSyxTQUFMO0FBQ0ksMEJBQU87QUFBRyxpQkFBUyxFQUFDO0FBQWIsUUFBUDs7QUFDSixTQUFLLGNBQUw7QUFDSSwwQkFBTztBQUFHLGlCQUFTLEVBQUM7QUFBYixRQUFQOztBQUNKO0FBQ0ksMEJBQU8sOEJBQVA7QUFWSjtBQVlILENBYk07O0FBZUEsTUFBTTZGLE1BQU0sR0FBSWlELEtBQUQsSUFBVztBQUM3QixNQUFJQSxLQUFLLENBQUNDLEtBQVYsRUFBZ0I7QUFDWix3QkFBTztBQUFNLGVBQVMsRUFBQztBQUFoQixvQkFBMkM7QUFBRyxlQUFTLEVBQUM7QUFBYixNQUEzQyxDQUFQO0FBQ0gsR0FGRCxNQUdJO0FBQ0Esd0JBQU87QUFBTSxlQUFTLEVBQUM7QUFBaEIsb0JBQTBDO0FBQUcsZUFBUyxFQUFDO0FBQWIsTUFBMUMsQ0FBUDtBQUNIO0FBQ0osQ0FQTTs7QUFTQSxNQUFNSixRQUFOLFNBQXVCQyxLQUFLLENBQUNJLFNBQTdCLENBQXVDO0FBQzFDQyxhQUFXLENBQUNILEtBQUQsRUFBUTtBQUNmLFVBQU1BLEtBQU47QUFDQSxTQUFLSSxHQUFMLEdBQVdOLEtBQUssQ0FBQ08sU0FBTixFQUFYO0FBQ0g7O0FBRURDLFFBQU0sR0FBRztBQUNMLFdBQU8sY0FDSDtBQUFHLFNBQUcsRUFBQyxNQUFQO0FBQWMsZUFBUyxFQUFDLDBCQUF4QjtBQUFtRCxTQUFHLEVBQUUsS0FBS0Y7QUFBN0QsY0FERyxlQUVILG9CQUFDLG1CQUFEO0FBQXFCLFNBQUcsRUFBQyxTQUF6QjtBQUFtQyxlQUFTLEVBQUMsT0FBN0M7QUFBcUQsWUFBTSxFQUFFLEtBQUtBO0FBQWxFLE9BQ0ssS0FBS0osS0FBTCxDQUFXdFIsUUFBWCxHQUFvQixLQUFLc1IsS0FBTCxDQUFXdFIsUUFBL0IsR0FBd0MsS0FBS3NSLEtBQUwsQ0FBV08sV0FEeEQsQ0FGRyxDQUFQO0FBTUg7O0FBYnlDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0RDlDdGlCLE1BQU0sQ0FBQzBRLE1BQVAsQ0FBYztBQUFDTyxTQUFPLEVBQUMsTUFBSUQ7QUFBYixDQUFkO0FBQWtDLElBQUlqUixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlxaUIsTUFBSjtBQUFXdmlCLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFFBQVosRUFBcUI7QUFBQ2dSLFNBQU8sQ0FBQy9RLENBQUQsRUFBRztBQUFDcWlCLFVBQU0sR0FBQ3JpQixDQUFQO0FBQVM7O0FBQXJCLENBQXJCLEVBQTRDLENBQTVDOztBQUc3R3NpQixVQUFVLEdBQUkvZ0IsS0FBRCxJQUFXO0FBQ3BCLE1BQUlnaEIsU0FBUyxHQUFHLFVBQWhCO0FBQ0FoaEIsT0FBSyxHQUFHNkssSUFBSSxDQUFDaUYsS0FBTCxDQUFZOVAsS0FBSyxHQUFHLElBQXBCLElBQTRCLElBQXBDO0FBQ0EsTUFBSTZLLElBQUksQ0FBQ2lGLEtBQUwsQ0FBWTlQLEtBQVosTUFBdUJBLEtBQTNCLEVBQ0lnaEIsU0FBUyxHQUFHLEtBQVosQ0FESixLQUVLLElBQUluVyxJQUFJLENBQUNpRixLQUFMLENBQVk5UCxLQUFLLEdBQUcsRUFBcEIsTUFBNEJBLEtBQUssR0FBRyxFQUF4QyxFQUNEZ2hCLFNBQVMsR0FBRyxPQUFaLENBREMsS0FFQSxJQUFJblcsSUFBSSxDQUFDaUYsS0FBTCxDQUFZOVAsS0FBSyxHQUFHLEdBQXBCLE1BQTZCQSxLQUFLLEdBQUcsR0FBekMsRUFDRGdoQixTQUFTLEdBQUcsUUFBWixDQURDLEtBRUEsSUFBSW5XLElBQUksQ0FBQ2lGLEtBQUwsQ0FBWTlQLEtBQUssR0FBRyxJQUFwQixNQUE4QkEsS0FBSyxHQUFHLElBQTFDLEVBQ0RnaEIsU0FBUyxHQUFHLFNBQVo7QUFDSixTQUFPRixNQUFNLENBQUU5Z0IsS0FBRixDQUFOLENBQWVpaEIsTUFBZixDQUF1QkQsU0FBdkIsQ0FBUDtBQUNILENBWkQ7O0FBY0EsTUFBTUUsUUFBUSxHQUFHNWlCLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCMmIsS0FBeEM7QUFDQWhpQixPQUFPLENBQUNDLEdBQVIsQ0FBYSxhQUFiLEVBQTRCOGhCLFFBQTVCOztBQUNBLEtBQUssSUFBSWpmLENBQVQsSUFBY2lmLFFBQWQsRUFBd0I7QUFDcEIsUUFBTUUsSUFBSSxHQUFHRixRQUFRLENBQUNqZixDQUFELENBQXJCOztBQUNBLE1BQUksQ0FBQ21mLElBQUksQ0FBQ0MsaUJBQVYsRUFBNkI7QUFDekJELFFBQUksQ0FBQ0MsaUJBQUwsR0FBeUJELElBQUksQ0FBQ0UsV0FBTCxHQUFtQixHQUE1QztBQUNIO0FBQ0o7O0FBRWMsTUFBTS9SLElBQU4sQ0FBVztBQUl0QmtSLGFBQVcsQ0FBRTVPLE1BQUYsRUFBb0Q7QUFBQSxRQUExQ0wsS0FBMEMsdUVBQWxDbFQsTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIrYixTQUFXO0FBQzNELFVBQU1DLFVBQVUsR0FBR2hRLEtBQUssQ0FBQ2lRLFdBQU4sRUFBbkI7QUFDQSxTQUFLQyxLQUFMLEdBQWFSLFFBQVEsQ0FBQzdjLElBQVQsQ0FBZStjLElBQUksSUFDNUJBLElBQUksQ0FBQzVQLEtBQUwsQ0FBV2lRLFdBQVgsT0FBOEJELFVBQTlCLElBQTRDSixJQUFJLENBQUNFLFdBQUwsQ0FBaUJHLFdBQWpCLE9BQW9DRCxVQUR2RSxDQUFiOztBQUlBLFFBQUksS0FBS0UsS0FBVCxFQUFnQjtBQUNaLFVBQUlGLFVBQVUsS0FBSyxLQUFLRSxLQUFMLENBQVdsUSxLQUFYLENBQWlCaVEsV0FBakIsRUFBbkIsRUFBb0Q7QUFDaEQsYUFBS0UsT0FBTCxHQUFlMUosTUFBTSxDQUFFcEcsTUFBRixDQUFyQjtBQUNILE9BRkQsTUFFTyxJQUFJMlAsVUFBVSxLQUFLLEtBQUtFLEtBQUwsQ0FBV0osV0FBWCxDQUF1QkcsV0FBdkIsRUFBbkIsRUFBMEQ7QUFDN0QsYUFBS0UsT0FBTCxHQUFlMUosTUFBTSxDQUFFcEcsTUFBRixDQUFOLEdBQWtCLEtBQUs2UCxLQUFMLENBQVcvTSxRQUE1QztBQUNIO0FBQ0osS0FORCxNQU9LO0FBQ0QsV0FBSytNLEtBQUwsR0FBYSxFQUFiO0FBQ0EsV0FBS0MsT0FBTCxHQUFlMUosTUFBTSxDQUFFcEcsTUFBRixDQUFyQjtBQUNIO0FBQ0o7O0FBRUQsTUFBSUEsTUFBSixHQUFjO0FBQ1YsV0FBTyxLQUFLOFAsT0FBWjtBQUNIOztBQUVELE1BQUlDLGFBQUosR0FBcUI7QUFDakIsV0FBUSxLQUFLRixLQUFOLEdBQWUsS0FBS0MsT0FBTCxHQUFlLEtBQUtELEtBQUwsQ0FBVy9NLFFBQXpDLEdBQW9ELEtBQUtnTixPQUFoRTtBQUNIOztBQUVEdkQsVUFBUSxDQUFFeUQsU0FBRixFQUFhO0FBQ2pCO0FBQ0EsUUFBSUMsUUFBUSxHQUFHdlMsSUFBSSxDQUFDZ0MsV0FBTCxDQUFpQm9ELFFBQWpCLElBQTZCa04sU0FBUyxHQUFHaFgsSUFBSSxDQUFDa1gsR0FBTCxDQUFVLEVBQVYsRUFBY0YsU0FBZCxDQUFILEdBQThCLEtBQXBFLENBQWY7O0FBQ0EsUUFBSSxLQUFLaFEsTUFBTCxHQUFjaVEsUUFBbEIsRUFBNEI7QUFDeEIsdUJBQVVoQixNQUFNLENBQUUsS0FBS2pQLE1BQVAsQ0FBTixDQUFxQm9QLE1BQXJCLENBQTZCLFVBQTdCLENBQVYsY0FBc0QsS0FBS1MsS0FBTCxDQUFXbFEsS0FBakU7QUFDSCxLQUZELE1BRU87QUFDSCx1QkFBVXFRLFNBQVMsR0FBR2YsTUFBTSxDQUFFLEtBQUtjLGFBQVAsQ0FBTixDQUE0QlgsTUFBNUIsQ0FBb0MsU0FBUyxJQUFJZSxNQUFKLENBQVlILFNBQVosQ0FBN0MsQ0FBSCxHQUEwRWQsVUFBVSxDQUFFLEtBQUthLGFBQVAsQ0FBdkcsY0FBZ0ksS0FBS0YsS0FBTCxDQUFXSixXQUEzSTtBQUNIO0FBQ0o7O0FBRURXLFlBQVUsQ0FBRWpCLFNBQUYsRUFBYTtBQUNuQixRQUFJblAsTUFBTSxHQUFHLEtBQUtBLE1BQWxCOztBQUNBLFFBQUltUCxTQUFKLEVBQWU7QUFDWG5QLFlBQU0sR0FBR2lQLE1BQU0sQ0FBRWpQLE1BQUYsQ0FBTixDQUFnQm9QLE1BQWhCLENBQXdCRCxTQUF4QixDQUFUO0FBQ0g7O0FBRUQsUUFBSXhQLEtBQUssR0FBSSxLQUFLa1EsS0FBTCxJQUFjLEVBQWYsR0FBcUJuUyxJQUFJLENBQUNnQyxXQUFMLENBQWlCK1AsV0FBdEMsR0FBb0QsS0FBS0ksS0FBTCxDQUFXbFEsS0FBM0U7QUFDQSxxQkFBVUssTUFBVixjQUFvQkwsS0FBcEI7QUFDSDs7QUFFRDBRLGFBQVcsQ0FBRWxCLFNBQUYsRUFBYTtBQUNwQixRQUFJblAsTUFBTSxHQUFHLEtBQUsrUCxhQUFsQjs7QUFDQSxRQUFJWixTQUFKLEVBQWU7QUFDWG5QLFlBQU0sR0FBR2lQLE1BQU0sQ0FBRWpQLE1BQUYsQ0FBTixDQUFnQm9QLE1BQWhCLENBQXdCRCxTQUF4QixDQUFUO0FBQ0g7O0FBQ0QscUJBQVVuUCxNQUFWLGNBQW9CdEMsSUFBSSxDQUFDZ0MsV0FBTCxDQUFpQitQLFdBQXJDO0FBQ0g7O0FBekRxQjs7QUFBTC9SLEksQ0FDVmdDLFcsR0FBYzJQLFFBQVEsQ0FBQzdjLElBQVQsQ0FBZStjLElBQUksSUFBSUEsSUFBSSxDQUFDNVAsS0FBTCxLQUFlbFQsTUFBTSxDQUFDaUgsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUIrYixTQUE3RCxDO0FBREpoUyxJLENBRVY0UyxRLEdBQVcsSUFBSWxLLE1BQU0sQ0FBRTFJLElBQUksQ0FBQ2dDLFdBQUwsQ0FBaUJvRCxRQUFuQixDOzs7Ozs7Ozs7OztBQzVCaENwVyxNQUFNLENBQUNDLElBQVAsQ0FBWSx5QkFBWjtBQUF1Q0QsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVo7QUFJdkM7QUFDQTtBQUVBa0ksT0FBTyxHQUFHLEtBQVY7QUFDQWlULGlCQUFpQixHQUFHLEtBQXBCO0FBQ0EyQixzQkFBc0IsR0FBRyxLQUF6QjtBQUNBclYsR0FBRyxHQUFHM0gsTUFBTSxDQUFDaUgsUUFBUCxDQUFnQjZjLE1BQWhCLENBQXVCQyxHQUE3QjtBQUNBcmpCLEdBQUcsR0FBR1YsTUFBTSxDQUFDaUgsUUFBUCxDQUFnQjZjLE1BQWhCLENBQXVCRSxHQUE3QjtBQUNBQyxXQUFXLEdBQUcsQ0FBZDtBQUNBQyxVQUFVLEdBQUcsQ0FBYjtBQUNBQyxjQUFjLEdBQUcsQ0FBakI7QUFDQUMsYUFBYSxHQUFHLENBQWhCO0FBQ0FDLHFCQUFxQixHQUFHLENBQXhCO0FBQ0FDLGdCQUFnQixHQUFHLENBQW5CO0FBQ0FDLGVBQWUsR0FBRyxDQUFsQjtBQUNBQyxjQUFjLEdBQUcsQ0FBakI7QUFFQSxNQUFNQyxlQUFlLEdBQUcsd0JBQXhCOztBQUVBQyxpQkFBaUIsR0FBRyxNQUFNO0FBQ3RCMWtCLFFBQU0sQ0FBQ3NJLElBQVAsQ0FBYSxvQkFBYixFQUFtQyxDQUFDcWMsS0FBRCxFQUFRcGpCLE1BQVIsS0FBbUI7QUFDbEQsUUFBSW9qQixLQUFKLEVBQVc7QUFDUDlqQixhQUFPLENBQUNDLEdBQVIsQ0FBYSxtQkFBbUI2akIsS0FBaEM7QUFDSCxLQUZELE1BRU87QUFDSDlqQixhQUFPLENBQUNDLEdBQVIsQ0FBYSxtQkFBbUJTLE1BQWhDO0FBQ0g7QUFDSixHQU5EO0FBT0gsQ0FSRDs7QUFVQXFqQixXQUFXLEdBQUcsTUFBTTtBQUNoQjVrQixRQUFNLENBQUNzSSxJQUFQLENBQWEscUJBQWIsRUFBb0MsQ0FBQ3FjLEtBQUQsRUFBUXBqQixNQUFSLEtBQW1CO0FBQ25ELFFBQUlvakIsS0FBSixFQUFXO0FBQ1A5akIsYUFBTyxDQUFDQyxHQUFSLENBQWEsbUJBQW1CNmpCLEtBQWhDO0FBQ0gsS0FGRCxNQUVPO0FBQ0g5akIsYUFBTyxDQUFDQyxHQUFSLENBQWEsbUJBQW1CUyxNQUFoQztBQUNIO0FBQ0osR0FORDtBQU9ILENBUkQ7O0FBVUFzakIsaUJBQWlCLEdBQUcsTUFBTTtBQUN0QjdrQixRQUFNLENBQUNzSSxJQUFQLENBQWEseUJBQWIsRUFBd0MsQ0FBQ3FjLEtBQUQsRUFBUXBqQixNQUFSLEtBQW1CO0FBQ3ZELFFBQUlvakIsS0FBSixFQUFXO0FBQ1A5akIsYUFBTyxDQUFDQyxHQUFSLENBQWEsb0JBQW9CNmpCLEtBQWpDO0FBQ0g7QUFDSixHQUpEO0FBS0gsQ0FORDs7QUFRQUcsWUFBWSxHQUFHLE1BQU07QUFDakI5a0IsUUFBTSxDQUFDc0ksSUFBUCxDQUFhLHdCQUFiLEVBQXVDLENBQUNxYyxLQUFELEVBQVFwakIsTUFBUixLQUFtQjtBQUN0RCxRQUFJb2pCLEtBQUosRUFBVztBQUNQOWpCLGFBQU8sQ0FBQ0MsR0FBUixDQUFhLG1CQUFtQjZqQixLQUFoQztBQUNIOztBQUNELFFBQUlwakIsTUFBSixFQUFZO0FBQ1JWLGFBQU8sQ0FBQ0MsR0FBUixDQUFhLG1CQUFtQlMsTUFBaEM7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVREOztBQVdBd2pCLG1CQUFtQixHQUFHLE1BQU07QUFDeEIva0IsUUFBTSxDQUFDc0ksSUFBUCxDQUFhLDhCQUFiLEVBQTZDLENBQUNxYyxLQUFELEVBQVFwakIsTUFBUixLQUFtQjtBQUM1RCxRQUFJb2pCLEtBQUosRUFBVztBQUNQOWpCLGFBQU8sQ0FBQ0MsR0FBUixDQUFhLDJCQUEyQjZqQixLQUF4QztBQUNIOztBQUNELFFBQUlwakIsTUFBSixFQUFZO0FBQ1JWLGFBQU8sQ0FBQ0MsR0FBUixDQUFhLDJCQUEyQlMsTUFBeEM7QUFDSDtBQUNKLEdBUEQ7QUFRSCxDQVREOztBQVdBeWpCLGtCQUFrQixHQUFHLE1BQU07QUFDdkJobEIsUUFBTSxDQUFDc0ksSUFBUCxDQUFhLHdDQUFiLEVBQXVELENBQUNxYyxLQUFELEVBQVFwakIsTUFBUixLQUFtQjtBQUN0RSxRQUFJb2pCLEtBQUosRUFBVztBQUNQOWpCLGFBQU8sQ0FBQ0MsR0FBUixDQUFhLDBCQUEwQjZqQixLQUF2QztBQUNIOztBQUNELFFBQUlwakIsTUFBSixFQUFZO0FBQ1JWLGFBQU8sQ0FBQ0MsR0FBUixDQUFhLHNCQUFzQlMsTUFBbkM7QUFDSDtBQUNKLEdBUEQ7QUFRQTs7Ozs7Ozs7OztBQVVILENBbkJEOztBQXFCQTBqQixjQUFjLEdBQUcsTUFBTTtBQUNuQmpsQixRQUFNLENBQUNzSSxJQUFQLENBQWEsNEJBQWIsRUFBMkMsQ0FBQ3FjLEtBQUQsRUFBUXBqQixNQUFSLEtBQW1CO0FBQzFELFFBQUlvakIsS0FBSixFQUFXO0FBQ1A5akIsYUFBTyxDQUFDQyxHQUFSLENBQWEsNEJBQTRCNmpCLEtBQXpDO0FBQ0gsS0FGRCxNQUdLO0FBQ0Q5akIsYUFBTyxDQUFDQyxHQUFSLENBQWEseUJBQXlCUyxNQUF0QztBQUNIO0FBQ0osR0FQRDtBQVFILENBVEQ7O0FBV0EyakIsaUJBQWlCLEdBQUcsTUFBTTtBQUN0QjtBQUNBbGxCLFFBQU0sQ0FBQ3NJLElBQVAsQ0FBYSw0Q0FBYixFQUEyRCxHQUEzRCxFQUFnRSxDQUFDcWMsS0FBRCxFQUFRcGpCLE1BQVIsS0FBbUI7QUFDL0UsUUFBSW9qQixLQUFKLEVBQVc7QUFDUDlqQixhQUFPLENBQUNDLEdBQVIsQ0FBYSwwQ0FBMEM2akIsS0FBdkQ7QUFDSCxLQUZELE1BRU87QUFDSDlqQixhQUFPLENBQUNDLEdBQVIsQ0FBYSx1Q0FBdUNTLE1BQXBEO0FBQ0g7QUFDSixHQU5EO0FBUUF2QixRQUFNLENBQUNzSSxJQUFQLENBQWEsd0JBQWIsRUFBdUMsQ0FBQ3FjLEtBQUQsRUFBUXBqQixNQUFSLEtBQW1CO0FBQ3RELFFBQUlvakIsS0FBSixFQUFXO0FBQ1A5akIsYUFBTyxDQUFDQyxHQUFSLENBQWEsMkJBQTJCNmpCLEtBQXhDO0FBQ0gsS0FGRCxNQUVPO0FBQ0g5akIsYUFBTyxDQUFDQyxHQUFSLENBQWEsd0JBQXdCUyxNQUFyQztBQUNIO0FBQ0osR0FORDtBQU9ILENBakJEOztBQW1CQTRqQixlQUFlLEdBQUcsTUFBTTtBQUNwQjtBQUNBbmxCLFFBQU0sQ0FBQ3NJLElBQVAsQ0FBYSw0Q0FBYixFQUEyRCxHQUEzRCxFQUFnRSxDQUFDcWMsS0FBRCxFQUFRcGpCLE1BQVIsS0FBbUI7QUFDL0UsUUFBSW9qQixLQUFKLEVBQVc7QUFDUDlqQixhQUFPLENBQUNDLEdBQVIsQ0FBYSx3Q0FBd0M2akIsS0FBckQ7QUFDSCxLQUZELE1BR0s7QUFDRDlqQixhQUFPLENBQUNDLEdBQVIsQ0FBYSxxQ0FBcUNTLE1BQWxEO0FBQ0g7QUFDSixHQVBEO0FBUUgsQ0FWRDs7QUFZQTZqQixjQUFjLEdBQUcsTUFBTTtBQUNuQjtBQUNBcGxCLFFBQU0sQ0FBQ3NJLElBQVAsQ0FBYSw0Q0FBYixFQUEyRCxHQUEzRCxFQUFnRSxDQUFDcWMsS0FBRCxFQUFRcGpCLE1BQVIsS0FBbUI7QUFDL0UsUUFBSW9qQixLQUFKLEVBQVc7QUFDUDlqQixhQUFPLENBQUNDLEdBQVIsQ0FBYSx1Q0FBdUM2akIsS0FBcEQ7QUFDSCxLQUZELE1BR0s7QUFDRDlqQixhQUFPLENBQUNDLEdBQVIsQ0FBYSxvQ0FBb0NTLE1BQWpEO0FBQ0g7QUFDSixHQVBEO0FBU0F2QixRQUFNLENBQUNzSSxJQUFQLENBQWEsNENBQWIsRUFBMkQsQ0FBQ3FjLEtBQUQsRUFBUXBqQixNQUFSLEtBQW1CO0FBQzFFLFFBQUlvakIsS0FBSixFQUFXO0FBQ1A5akIsYUFBTyxDQUFDQyxHQUFSLENBQWEsMkNBQTJDNmpCLEtBQXhEO0FBQ0gsS0FGRCxNQUdLO0FBQ0Q5akIsYUFBTyxDQUFDQyxHQUFSLENBQWEsd0NBQXdDUyxNQUFyRDtBQUNIO0FBQ0osR0FQRDtBQVFILENBbkJEOztBQXNCQXZCLE1BQU0sQ0FBQ3FsQixPQUFQLENBQWdCLFlBQVk7QUFDeEIsTUFBSXJsQixNQUFNLENBQUNzbEIsYUFBWCxFQUEwQjtBQS9KOUIsUUFBSUMsbUJBQUo7QUFBd0J0bEIsVUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ2dSLGFBQU8sQ0FBQy9RLENBQUQsRUFBRztBQUFDb2xCLDJCQUFtQixHQUFDcGxCLENBQXBCO0FBQXNCOztBQUFsQyxLQUF2QyxFQUEyRSxDQUEzRTtBQWdLaEJxbEIsV0FBTyxDQUFDQyxHQUFSLENBQVlDLDRCQUFaLEdBQTJDLENBQTNDO0FBRUEvYyxVQUFNLENBQUNDLElBQVAsQ0FBYTJjLG1CQUFiLEVBQWtDdGlCLE9BQWxDLENBQTRDMGlCLEdBQUQsSUFBUztBQUNoRCxVQUFJM2xCLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0IwZSxHQUFoQixLQUF3QjlXLFNBQTVCLEVBQXVDO0FBQ25DaE8sZUFBTyxDQUFDK2tCLElBQVIsZ0NBQXNDRCxHQUF0QztBQUNBM2xCLGNBQU0sQ0FBQ2lILFFBQVAsQ0FBZ0IwZSxHQUFoQixJQUF1QixFQUF2QjtBQUNIOztBQUNEaGQsWUFBTSxDQUFDQyxJQUFQLENBQWEyYyxtQkFBbUIsQ0FBQ0ksR0FBRCxDQUFoQyxFQUF1QzFpQixPQUF2QyxDQUFpRDRpQixLQUFELElBQVc7QUFDdkQsWUFBSTdsQixNQUFNLENBQUNpSCxRQUFQLENBQWdCMGUsR0FBaEIsRUFBcUJFLEtBQXJCLEtBQStCaFgsU0FBbkMsRUFBOEM7QUFDMUNoTyxpQkFBTyxDQUFDK2tCLElBQVIsZ0NBQXNDRCxHQUF0QyxjQUE2Q0UsS0FBN0M7QUFDQTdsQixnQkFBTSxDQUFDaUgsUUFBUCxDQUFnQjBlLEdBQWhCLEVBQXFCRSxLQUFyQixJQUE4Qk4sbUJBQW1CLENBQUNJLEdBQUQsQ0FBbkIsQ0FBeUJFLEtBQXpCLENBQTlCO0FBQ0g7QUFDSixPQUxEO0FBTUgsS0FYRDtBQVlIOztBQUVEN2xCLFFBQU0sQ0FBQ3NJLElBQVAsQ0FBYSxlQUFiLEVBQThCLENBQUNpQyxHQUFELEVBQU1oSixNQUFOLEtBQWlCO0FBQzNDLFFBQUlnSixHQUFKLEVBQVM7QUFDTDFKLGFBQU8sQ0FBQ0MsR0FBUixDQUFheUosR0FBYjtBQUNIOztBQUNELFFBQUloSixNQUFKLEVBQVk7QUFDUixVQUFJdkIsTUFBTSxDQUFDaUgsUUFBUCxDQUFnQjRNLEtBQWhCLENBQXNCaVMsVUFBMUIsRUFBc0M7QUFDbEMzQixzQkFBYyxHQUFHbmtCLE1BQU0sQ0FBQytsQixXQUFQLENBQW9CLFlBQVk7QUFDN0NsQiwyQkFBaUI7QUFDcEIsU0FGZ0IsRUFFZDdrQixNQUFNLENBQUNpSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUI2ZCxpQkFGVCxDQUFqQjtBQUlBL0IsbUJBQVcsR0FBR2prQixNQUFNLENBQUMrbEIsV0FBUCxDQUFvQixZQUFZO0FBQzFDbkIscUJBQVc7QUFDZCxTQUZhLEVBRVg1a0IsTUFBTSxDQUFDaUgsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCOGQsYUFGWixDQUFkO0FBSUEvQixrQkFBVSxHQUFHbGtCLE1BQU0sQ0FBQytsQixXQUFQLENBQW9CLFlBQVk7QUFDekNyQiwyQkFBaUI7QUFDcEIsU0FGWSxFQUVWMWtCLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QitkLGNBRmIsQ0FBYjs7QUFJQSxZQUFJbG1CLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QmdlLGdCQUF2QixJQUEyQyxDQUEvQyxFQUFrRDtBQUM5Qy9CLHVCQUFhLEdBQUdwa0IsTUFBTSxDQUFDK2xCLFdBQVAsQ0FBb0IsWUFBWTtBQUM1Q2pCLHdCQUFZO0FBQ2YsV0FGZSxFQUViOWtCLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QmdlLGdCQUZWLENBQWhCO0FBSUE5QiwrQkFBcUIsR0FBR3JrQixNQUFNLENBQUMrbEIsV0FBUCxDQUFvQixZQUFZO0FBQ3BEaEIsK0JBQW1CO0FBQ3RCLFdBRnVCLEVBRXJCL2tCLE1BQU0sQ0FBQ2lILFFBQVAsQ0FBZ0JrQixNQUFoQixDQUF1QmdlLGdCQUZGLENBQXhCO0FBR0g7O0FBRUQ3Qix3QkFBZ0IsR0FBR3RrQixNQUFNLENBQUMrbEIsV0FBUCxDQUFvQixZQUFZO0FBQy9DZiw0QkFBa0I7QUFDckIsU0FGa0IsRUFFaEJobEIsTUFBTSxDQUFDaUgsUUFBUCxDQUFnQmtCLE1BQWhCLENBQXVCaWUsb0JBRlAsQ0FBbkI7QUFJQTdCLHVCQUFlLEdBQUd2a0IsTUFBTSxDQUFDK2xCLFdBQVAsQ0FBb0IsWUFBWTtBQUM5Q2Qsd0JBQWM7QUFDakIsU0FGaUIsRUFFZmpsQixNQUFNLENBQUNpSCxRQUFQLENBQWdCa0IsTUFBaEIsQ0FBdUJrZSxrQkFGUixDQUFsQjtBQUlBN0Isc0JBQWMsR0FBR3hrQixNQUFNLENBQUMrbEIsV0FBUCxDQUFvQixZQUFZO0FBQzdDLGNBQUlsUCxHQUFHLEdBQUcsSUFBSXhULElBQUosRUFBVjs7QUFDQSxjQUFLd1QsR0FBRyxDQUFDeVAsYUFBSixNQUF3QixDQUE3QixFQUFpQztBQUM3QnBCLDZCQUFpQjtBQUNwQjs7QUFFRCxjQUFLck8sR0FBRyxDQUFDMFAsYUFBSixNQUF3QixDQUF6QixJQUFnQzFQLEdBQUcsQ0FBQ3lQLGFBQUosTUFBd0IsQ0FBNUQsRUFBZ0U7QUFDNURuQiwyQkFBZTtBQUNsQjs7QUFFRCxjQUFLdE8sR0FBRyxDQUFDMlAsV0FBSixNQUFzQixDQUF2QixJQUE4QjNQLEdBQUcsQ0FBQzBQLGFBQUosTUFBd0IsQ0FBdEQsSUFBNkQxUCxHQUFHLENBQUN5UCxhQUFKLE1BQXdCLENBQXpGLEVBQTZGO0FBQ3pGbEIsMEJBQWM7QUFDakI7QUFDSixTQWJnQixFQWFkLElBYmMsQ0FBakI7QUFjSDtBQUNKO0FBQ0osR0FwREQ7QUFzREgsQ0F4RUQsRSIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuY29uc3QgZmV0Y2hGcm9tVXJsID0gKHVybCkgPT4ge1xuICAgIHRyeXtcbiAgICAgICAgbGV0IHJlcyA9IEhUVFAuZ2V0KExDRCArIHVybCk7XG4gICAgICAgIGlmIChyZXMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgcmV0dXJuIHJlc1xuICAgICAgICB9O1xuICAgIH1cbiAgICBjYXRjaCAoZSl7XG4gICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgIH1cbn1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdhY2NvdW50cy5nZXRBY2NvdW50RGV0YWlsJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9hdXRoL2FjY291bnRzLycrIGFkZHJlc3M7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBhdmFpbGFibGUgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGF2YWlsYWJsZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSlNPTi5wYXJzZShhdmFpbGFibGUuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgIGxldCBhY2NvdW50O1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS50eXBlID09PSAnY29zbW9zLXNkay9BY2NvdW50JylcbiAgICAgICAgICAgICAgICAgICAgYWNjb3VudCA9IHJlc3BvbnNlLnZhbHVlO1xuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHJlc3BvbnNlLnR5cGUgPT09ICdjb3Ntb3Mtc2RrL0RlbGF5ZWRWZXN0aW5nQWNjb3VudCcgfHwgcmVzcG9uc2UudHlwZSA9PT0gJ2Nvc21vcy1zZGsvQ29udGludW91c1Zlc3RpbmdBY2NvdW50JylcbiAgICAgICAgICAgICAgICAgICAgYWNjb3VudCA9IHJlc3BvbnNlLnZhbHVlLkJhc2VWZXN0aW5nQWNjb3VudC5CYXNlQWNjb3VudFxuICAgICAgICAgICAgICAgIGlmIChhY2NvdW50ICYmIGFjY291bnQuYWNjb3VudF9udW1iZXIgIT0gbnVsbClcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFjY291bnRcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbFxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgIH1cbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRCYWxhbmNlJzogZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgYmFsYW5jZSA9IHt9XG5cbiAgICAgICAgLy8gZ2V0IGF2YWlsYWJsZSBhdG9tc1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9iYW5rL2JhbGFuY2VzLycrIGFkZHJlc3M7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBhdmFpbGFibGUgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKGF2YWlsYWJsZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgYmFsYW5jZS5hdmFpbGFibGUgPSBKU09OLnBhcnNlKGF2YWlsYWJsZS5jb250ZW50KS5yZXN1bHQ7XG5cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gZ2V0IGRlbGVnYXRlZCBhbW5vdW50c1xuICAgICAgICB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy9kZWxlZ2F0aW9ucyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGJhbGFuY2UuZGVsZWdhdGlvbnMgPSBKU09OLnBhcnNlKGRlbGVnYXRpb25zLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBnZXQgdW5ib25kaW5nXG4gICAgICAgIHVybCA9IExDRCArICcvc3Rha2luZy9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL3VuYm9uZGluZ19kZWxlZ2F0aW9ucyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCB1bmJvbmRpbmcgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgaWYgKHVuYm9uZGluZy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgYmFsYW5jZS51bmJvbmRpbmcgPSBKU09OLnBhcnNlKHVuYm9uZGluZy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBnZXQgcmV3YXJkc1xuICAgICAgICB1cmwgPSBMQ0QgKyAnL2Rpc3RyaWJ1dGlvbi9kZWxlZ2F0b3JzLycrYWRkcmVzcysnL3Jld2FyZHMnO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgcmV3YXJkcyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAocmV3YXJkcy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgLy9nZXQgc2VwZXJhdGUgcmV3YXJkcyB2YWx1ZVxuICAgICAgICAgICAgICAgIGJhbGFuY2UucmV3YXJkcyA9IEpTT04ucGFyc2UocmV3YXJkcy5jb250ZW50KS5yZXN1bHQucmV3YXJkcztcbiAgICAgICAgICAgICAgICAvL2dldCB0b3RhbCByZXdhcmRzIHZhbHVlXG4gICAgICAgICAgICAgICAgYmFsYW5jZS50b3RhbF9yZXdhcmRzPSBKU09OLnBhcnNlKHJld2FyZHMuY29udGVudCkucmVzdWx0LnRvdGFsO1xuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gZ2V0IGNvbW1pc3Npb25cbiAgICAgICAgbGV0IHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZShcbiAgICAgICAgICAgIHskb3I6IFt7b3BlcmF0b3JfYWRkcmVzczphZGRyZXNzfSwge2RlbGVnYXRvcl9hZGRyZXNzOmFkZHJlc3N9LCB7YWRkcmVzczphZGRyZXNzfV19KVxuICAgICAgICBpZiAodmFsaWRhdG9yKSB7XG4gICAgICAgICAgICBsZXQgdXJsID0gTENEICsgJy9kaXN0cmlidXRpb24vdmFsaWRhdG9ycy8nICsgdmFsaWRhdG9yLm9wZXJhdG9yX2FkZHJlc3M7XG4gICAgICAgICAgICBiYWxhbmNlLm9wZXJhdG9yX2FkZHJlc3MgPSB2YWxpZGF0b3Iub3BlcmF0b3JfYWRkcmVzcztcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgbGV0IHJld2FyZHMgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIGlmIChyZXdhcmRzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGNvbnRlbnQgPSBKU09OLnBhcnNlKHJld2FyZHMuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICBpZiAoY29udGVudC52YWxfY29tbWlzc2lvbiAmJiBjb250ZW50LnZhbF9jb21taXNzaW9uLmxlbmd0aCA+IDApXG4gICAgICAgICAgICAgICAgICAgICAgICBiYWxhbmNlLmNvbW1pc3Npb24gPSBjb250ZW50LnZhbF9jb21taXNzaW9uO1xuXG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBiYWxhbmNlO1xuICAgIH0sXG4gICAgJ2FjY291bnRzLmdldERlbGVnYXRpb24nKGFkZHJlc3MsIHZhbGlkYXRvcil7XG4gICAgICAgIGxldCB1cmwgPSBgL3N0YWtpbmcvZGVsZWdhdG9ycy8ke2FkZHJlc3N9L2RlbGVnYXRpb25zLyR7dmFsaWRhdG9yfWA7XG4gICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICBkZWxlZ2F0aW9ucyA9IGRlbGVnYXRpb25zICYmIGRlbGVnYXRpb25zLmRhdGEucmVzdWx0O1xuICAgICAgICBpZiAoZGVsZWdhdGlvbnMgJiYgZGVsZWdhdGlvbnMuc2hhcmVzKVxuICAgICAgICAgICAgZGVsZWdhdGlvbnMuc2hhcmVzID0gcGFyc2VGbG9hdChkZWxlZ2F0aW9ucy5zaGFyZXMpO1xuXG4gICAgICAgIHVybCA9IGAvc3Rha2luZy9yZWRlbGVnYXRpb25zP2RlbGVnYXRvcj0ke2FkZHJlc3N9JnZhbGlkYXRvcl90bz0ke3ZhbGlkYXRvcn1gO1xuICAgICAgICBsZXQgcmVsZWdhdGlvbnMgPSBmZXRjaEZyb21VcmwodXJsKTtcbiAgICAgICAgcmVsZWdhdGlvbnMgPSByZWxlZ2F0aW9ucyAmJiByZWxlZ2F0aW9ucy5kYXRhLnJlc3VsdDtcbiAgICAgICAgbGV0IGNvbXBsZXRpb25UaW1lO1xuICAgICAgICBpZiAocmVsZWdhdGlvbnMpIHtcbiAgICAgICAgICAgIHJlbGVnYXRpb25zLmZvckVhY2goKHJlbGVnYXRpb24pID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgZW50cmllcyA9IHJlbGVnYXRpb24uZW50cmllc1xuICAgICAgICAgICAgICAgIGxldCB0aW1lID0gbmV3IERhdGUoZW50cmllc1tlbnRyaWVzLmxlbmd0aC0xXS5jb21wbGV0aW9uX3RpbWUpXG4gICAgICAgICAgICAgICAgaWYgKCFjb21wbGV0aW9uVGltZSB8fCB0aW1lID4gY29tcGxldGlvblRpbWUpXG4gICAgICAgICAgICAgICAgICAgIGNvbXBsZXRpb25UaW1lID0gdGltZVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnJlZGVsZWdhdGlvbkNvbXBsZXRpb25UaW1lID0gY29tcGxldGlvblRpbWU7XG4gICAgICAgIH1cblxuICAgICAgICB1cmwgPSBgL3N0YWtpbmcvZGVsZWdhdG9ycy8ke2FkZHJlc3N9L3VuYm9uZGluZ19kZWxlZ2F0aW9ucy8ke3ZhbGlkYXRvcn1gO1xuICAgICAgICBsZXQgdW5kZWxlZ2F0aW9ucyA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICB1bmRlbGVnYXRpb25zID0gdW5kZWxlZ2F0aW9ucyAmJiB1bmRlbGVnYXRpb25zLmRhdGEucmVzdWx0O1xuICAgICAgICBpZiAodW5kZWxlZ2F0aW9ucykge1xuICAgICAgICAgICAgZGVsZWdhdGlvbnMudW5ib25kaW5nID0gdW5kZWxlZ2F0aW9ucy5lbnRyaWVzLmxlbmd0aDtcbiAgICAgICAgICAgIGRlbGVnYXRpb25zLnVuYm9uZGluZ0NvbXBsZXRpb25UaW1lID0gdW5kZWxlZ2F0aW9ucy5lbnRyaWVzWzBdLmNvbXBsZXRpb25fdGltZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZGVsZWdhdGlvbnM7XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QWxsRGVsZWdhdGlvbnMnKGFkZHJlc3Mpe1xuICAgICAgICBsZXQgdXJsID0gTENEICsgJy9zdGFraW5nL2RlbGVnYXRvcnMvJythZGRyZXNzKycvZGVsZWdhdGlvbnMnO1xuXG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCBkZWxlZ2F0aW9ucyA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnMuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zID0gSlNPTi5wYXJzZShkZWxlZ2F0aW9ucy5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zICYmIGRlbGVnYXRpb25zLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucy5mb3JFYWNoKChkZWxlZ2F0aW9uLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGVsZWdhdGlvbnNbaV0gJiYgZGVsZWdhdGlvbnNbaV0uc2hhcmVzKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zW2ldLnNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbnNbaV0uc2hhcmVzKTtcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZGVsZWdhdGlvbnM7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnYWNjb3VudHMuZ2V0QWxsVW5ib25kaW5ncycoYWRkcmVzcyl7XG4gICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvZGVsZWdhdG9ycy8nK2FkZHJlc3MrJy91bmJvbmRpbmdfZGVsZWdhdGlvbnMnO1xuXG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCB1bmJvbmRpbmdzID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmICh1bmJvbmRpbmdzLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICB1bmJvbmRpbmdzID0gSlNPTi5wYXJzZSh1bmJvbmRpbmdzLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICByZXR1cm4gdW5ib25kaW5ncztcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdhY2NvdW50cy5nZXRBbGxSZWRlbGVnYXRpb25zJyhhZGRyZXNzLCB2YWxpZGF0b3Ipe1xuICAgICAgICBsZXQgdXJsID0gYC9zdGFraW5nL3JlZGVsZWdhdGlvbnM/ZGVsZWdhdG9yPSR7YWRkcmVzc30mdmFsaWRhdG9yX2Zyb209JHt2YWxpZGF0b3J9YDtcbiAgICAgICAgbGV0IHJlc3VsdCA9IGZldGNoRnJvbVVybCh1cmwpO1xuICAgICAgICBpZiAocmVzdWx0ICYmIHJlc3VsdC5kYXRhKSB7XG4gICAgICAgICAgICBsZXQgcmVkZWxlZ2F0aW9ucyA9IHt9XG4gICAgICAgICAgICByZXN1bHQuZGF0YS5mb3JFYWNoKChyZWRlbGVnYXRpb24pID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgZW50cmllcyA9IHJlZGVsZWdhdGlvbi5lbnRyaWVzO1xuICAgICAgICAgICAgICAgIHJlZGVsZWdhdGlvbnNbcmVkZWxlZ2F0aW9uLnZhbGlkYXRvcl9kc3RfYWRkcmVzc10gPSB7XG4gICAgICAgICAgICAgICAgICAgIGNvdW50OiBlbnRyaWVzLmxlbmd0aCxcbiAgICAgICAgICAgICAgICAgICAgY29tcGxldGlvblRpbWU6IGVudHJpZXNbMF0uY29tcGxldGlvbl90aW1lXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIHJldHVybiByZWRlbGVnYXRpb25zXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgICAgICBcbn0pIFxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuaW1wb3J0IHsgUHJvbWlzZSB9IGZyb20gXCJtZXRlb3IvcHJvbWlzZVwiO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnL2ltcG9ydHMvYXBpL2Jsb2Nrcy9ibG9ja3MuanMnO1xuaW1wb3J0IHsgQ2hhaW4gfSBmcm9tICcvaW1wb3J0cy9hcGkvY2hhaW4vY2hhaW4uanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9yU2V0cyB9IGZyb20gJy9pbXBvcnRzL2FwaS92YWxpZGF0b3Itc2V0cy92YWxpZGF0b3Itc2V0cy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzLCBBbmFseXRpY3MsIFZQRGlzdHJpYnV0aW9uc30gZnJvbSAnL2ltcG9ydHMvYXBpL3JlY29yZHMvcmVjb3Jkcy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcvaW1wb3J0cy9hcGkvdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zIH0gZnJvbSAnLi4vLi4vdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyc7XG5pbXBvcnQgeyBFdmlkZW5jZXMgfSBmcm9tICcuLi8uLi9ldmlkZW5jZXMvZXZpZGVuY2VzLmpzJztcbmltcG9ydCB7IHNoYTI1NiB9IGZyb20gJ2pzLXNoYTI1Nic7XG5pbXBvcnQgeyBnZXRBZGRyZXNzIH0gZnJvbSAndGVuZGVybWludC9saWIvcHVia2V5JztcbmltcG9ydCAqIGFzIGNoZWVyaW8gZnJvbSAnY2hlZXJpbyc7XG5cbi8vIGltcG9ydCBCbG9jayBmcm9tICcuLi8uLi8uLi91aS9jb21wb25lbnRzL0Jsb2NrJztcblxuLy8gZ2V0VmFsaWRhdG9yVm90aW5nUG93ZXIgPSAodmFsaWRhdG9ycywgYWRkcmVzcykgPT4ge1xuLy8gICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbi8vICAgICAgICAgaWYgKHZhbGlkYXRvcnNbdl0uYWRkcmVzcyA9PSBhZGRyZXNzKXtcbi8vICAgICAgICAgICAgIHJldHVybiBwYXJzZUludCh2YWxpZGF0b3JzW3ZdLnZvdGluZ19wb3dlcik7XG4vLyAgICAgICAgIH1cbi8vICAgICB9XG4vLyB9XG5cbmdldFJlbW92ZWRWYWxpZGF0b3JzID0gKHByZXZWYWxpZGF0b3JzLCB2YWxpZGF0b3JzKSA9PiB7XG4gICAgLy8gbGV0IHJlbW92ZVZhbGlkYXRvcnMgPSBbXTtcbiAgICBmb3IgKHAgaW4gcHJldlZhbGlkYXRvcnMpe1xuICAgICAgICBmb3IgKHYgaW4gdmFsaWRhdG9ycyl7XG4gICAgICAgICAgICBpZiAocHJldlZhbGlkYXRvcnNbcF0uYWRkcmVzcyA9PSB2YWxpZGF0b3JzW3ZdLmFkZHJlc3Mpe1xuICAgICAgICAgICAgICAgIHByZXZWYWxpZGF0b3JzLnNwbGljZShwLDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHByZXZWYWxpZGF0b3JzO1xufVxuXG5nZXRWYWxpZGF0b3JQcm9maWxlVXJsID0gKGlkZW50aXR5KSA9PiB7XG4gICAgaWYgKGlkZW50aXR5Lmxlbmd0aCA9PSAxNil7XG4gICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KGBodHRwczovL2tleWJhc2UuaW8vXy9hcGkvMS4wL3VzZXIvbG9va3VwLmpzb24/a2V5X3N1ZmZpeD0ke2lkZW50aXR5fSZmaWVsZHM9cGljdHVyZXNgKVxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgIGxldCB0aGVtID0gcmVzcG9uc2UuZGF0YS50aGVtXG4gICAgICAgICAgICByZXR1cm4gdGhlbSAmJiB0aGVtLmxlbmd0aCAmJiB0aGVtWzBdLnBpY3R1cmVzICYmIHRoZW1bMF0ucGljdHVyZXMucHJpbWFyeSAmJiB0aGVtWzBdLnBpY3R1cmVzLnByaW1hcnkudXJsO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkocmVzcG9uc2UpKVxuICAgICAgICB9XG4gICAgfSBlbHNlIGlmIChpZGVudGl0eS5pbmRleE9mKFwia2V5YmFzZS5pby90ZWFtL1wiKT4wKXtcbiAgICAgICAgbGV0IHRlYW1QYWdlID0gSFRUUC5nZXQoaWRlbnRpdHkpO1xuICAgICAgICBpZiAodGVhbVBhZ2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgbGV0IHBhZ2UgPSBjaGVlcmlvLmxvYWQodGVhbVBhZ2UuY29udGVudCk7XG4gICAgICAgICAgICByZXR1cm4gcGFnZShcIi5rYi1tYWluLWNhcmQgaW1nXCIpLmF0dHIoJ3NyYycpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkodGVhbVBhZ2UpKVxuICAgICAgICB9XG4gICAgfVxufVxuXG4vLyB2YXIgZmlsdGVyZWQgPSBbMSwgMiwgMywgNCwgNV0uZmlsdGVyKG5vdENvbnRhaW5lZEluKFsxLCAyLCAzLCA1XSkpO1xuLy8gY29uc29sZS5sb2coZmlsdGVyZWQpOyAvLyBbNF1cblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdibG9ja3MuYXZlcmFnZUJsb2NrVGltZScoYWRkcmVzcyl7XG4gICAgICAgIGxldCBibG9ja3MgPSBCbG9ja3Njb24uZmluZCh7cHJvcG9zZXJBZGRyZXNzOmFkZHJlc3N9KS5mZXRjaCgpO1xuICAgICAgICBsZXQgaGVpZ2h0cyA9IGJsb2Nrcy5tYXAoKGJsb2NrLCBpKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gYmxvY2suaGVpZ2h0O1xuICAgICAgICB9KTtcbiAgICAgICAgbGV0IGJsb2Nrc1N0YXRzID0gQW5hbHl0aWNzLmZpbmQoe2hlaWdodDp7JGluOmhlaWdodHN9fSkuZmV0Y2goKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coYmxvY2tzU3RhdHMpO1xuXG4gICAgICAgIGxldCB0b3RhbEJsb2NrRGlmZiA9IDA7XG4gICAgICAgIGZvciAoYiBpbiBibG9ja3NTdGF0cyl7XG4gICAgICAgICAgICB0b3RhbEJsb2NrRGlmZiArPSBibG9ja3NTdGF0c1tiXS50aW1lRGlmZjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdG90YWxCbG9ja0RpZmYvaGVpZ2h0cy5sZW5ndGg7XG4gICAgfSxcbiAgICAnYmxvY2tzLmZpbmRVcFRpbWUnKGFkZHJlc3Mpe1xuICAgICAgICBsZXQgY29sbGVjdGlvbiA9IFZhbGlkYXRvclJlY29yZHMucmF3Q29sbGVjdGlvbigpO1xuICAgICAgICAvLyBsZXQgYWdncmVnYXRlUXVlcnkgPSBNZXRlb3Iud3JhcEFzeW5jKGNvbGxlY3Rpb24uYWdncmVnYXRlLCBjb2xsZWN0aW9uKTtcbiAgICAgICAgdmFyIHBpcGVsaW5lID0gW1xuICAgICAgICAgICAgeyRtYXRjaDp7XCJhZGRyZXNzXCI6YWRkcmVzc319LFxuICAgICAgICAgICAgLy8geyRwcm9qZWN0OnthZGRyZXNzOjEsaGVpZ2h0OjEsZXhpc3RzOjF9fSxcbiAgICAgICAgICAgIHskc29ydDp7XCJoZWlnaHRcIjotMX19LFxuICAgICAgICAgICAgeyRsaW1pdDooTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy51cHRpbWVXaW5kb3ctMSl9LFxuICAgICAgICAgICAgeyR1bndpbmQ6IFwiJF9pZFwifSxcbiAgICAgICAgICAgIHskZ3JvdXA6e1xuICAgICAgICAgICAgICAgIFwiX2lkXCI6IFwiJGFkZHJlc3NcIixcbiAgICAgICAgICAgICAgICBcInVwdGltZVwiOiB7XG4gICAgICAgICAgICAgICAgICAgIFwiJHN1bVwiOntcbiAgICAgICAgICAgICAgICAgICAgICAgICRjb25kOiBbeyRlcTogWyckZXhpc3RzJywgdHJ1ZV19LCAxLCAwXVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgfV07XG4gICAgICAgIC8vIGxldCByZXN1bHQgPSBhZ2dyZWdhdGVRdWVyeShwaXBlbGluZSwgeyBjdXJzb3I6IHt9IH0pO1xuXG4gICAgICAgIHJldHVybiBQcm9taXNlLmF3YWl0KGNvbGxlY3Rpb24uYWdncmVnYXRlKHBpcGVsaW5lKS50b0FycmF5KCkpO1xuICAgICAgICAvLyByZXR1cm4gLmFnZ3JlZ2F0ZSgpXG4gICAgfSxcbiAgICAnYmxvY2tzLmdldExhdGVzdEhlaWdodCc6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IHVybCA9IFJQQysnL3N0YXR1cyc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgc3RhdHVzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIHJldHVybiAoc3RhdHVzLnJlc3VsdC5zeW5jX2luZm8ubGF0ZXN0X2Jsb2NrX2hlaWdodCk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdibG9ja3MuZ2V0Q3VycmVudEhlaWdodCc6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgbGV0IGN1cnJIZWlnaHQgPSBCbG9ja3Njb24uZmluZCh7fSx7c29ydDp7aGVpZ2h0Oi0xfSxsaW1pdDoxfSkuZmV0Y2goKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCJjdXJyZW50SGVpZ2h0OlwiK2N1cnJIZWlnaHQpO1xuICAgICAgICBsZXQgc3RhcnRIZWlnaHQgPSBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnN0YXJ0SGVpZ2h0O1xuICAgICAgICBpZiAoY3VyckhlaWdodCAmJiBjdXJySGVpZ2h0Lmxlbmd0aCA9PSAxKSB7XG4gICAgICAgICAgICBsZXQgaGVpZ2h0ID0gY3VyckhlaWdodFswXS5oZWlnaHQ7XG4gICAgICAgICAgICBpZiAoaGVpZ2h0ID4gc3RhcnRIZWlnaHQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGhlaWdodFxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzdGFydEhlaWdodFxuICAgIH0sXG4gICAgJ2Jsb2Nrcy5ibG9ja3NVcGRhdGUnOiBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKFNZTkNJTkcpXG4gICAgICAgICAgICByZXR1cm4gXCJTeW5jaW5nLi4uXCI7XG4gICAgICAgIGVsc2UgY29uc29sZS5sb2coXCJzdGFydCB0byBzeW5jXCIpO1xuICAgICAgICAvLyBNZXRlb3IuY2xlYXJJbnRlcnZhbChNZXRlb3IudGltZXJIYW5kbGUpO1xuICAgICAgICAvLyBnZXQgdGhlIGxhdGVzdCBoZWlnaHRcbiAgICAgICAgbGV0IHVudGlsID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRMYXRlc3RIZWlnaHQnKTtcbiAgICAgICAgLy8gY29uc29sZS5sb2codW50aWwpO1xuICAgICAgICAvLyBnZXQgdGhlIGN1cnJlbnQgaGVpZ2h0IGluIGRiXG4gICAgICAgIGxldCBjdXJyID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0Jyk7XG4gICAgICAgIGNvbnNvbGUubG9nKGN1cnIpO1xuICAgICAgICAvLyBsb29wIGlmIHRoZXJlJ3MgdXBkYXRlIGluIGRiXG4gICAgICAgIGlmICh1bnRpbCA+IGN1cnIpIHtcbiAgICAgICAgICAgIFNZTkNJTkcgPSB0cnVlO1xuXG4gICAgICAgICAgICBsZXQgdmFsaWRhdG9yU2V0ID0ge31cbiAgICAgICAgICAgIC8vIGdldCBsYXRlc3QgdmFsaWRhdG9yIGNhbmRpZGF0ZSBpbmZvcm1hdGlvblxuICAgICAgICAgICAgdXJsID0gTENEKycvc3Rha2luZy92YWxpZGF0b3JzJztcblxuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdC5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvclNldFt2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleV0gPSB2YWxpZGF0b3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHVybCA9IExDRCsnL3N0YWtpbmcvdmFsaWRhdG9ycz9zdGF0dXM9dW5ib25kaW5nJztcblxuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdC5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHZhbGlkYXRvclNldFt2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleV0gPSB2YWxpZGF0b3IpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdXJsID0gTENEKycvc3Rha2luZy92YWxpZGF0b3JzP3N0YXR1cz11bmJvbmRlZCc7XG5cbiAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB2YWxpZGF0b3JTZXRbdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXldID0gdmFsaWRhdG9yKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXQgdG90YWxWYWxpZGF0b3JzID0gT2JqZWN0LmtleXModmFsaWRhdG9yU2V0KS5sZW5ndGg7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImFsbCB2YWxpZGF0b3JzOiBcIisgdG90YWxWYWxpZGF0b3JzKTtcbiAgICAgICAgICAgIGZvciAobGV0IGhlaWdodCA9IGN1cnIrMSA7IGhlaWdodCA8PSB1bnRpbCA7IGhlaWdodCsrKSB7XG4gICAgICAgICAgICAgICAgbGV0IHN0YXJ0QmxvY2tUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAvLyBhZGQgdGltZW91dCBoZXJlPyBhbmQgb3V0c2lkZSB0aGlzIGxvb3AgKGZvciBjYXRjaGVkIHVwIGFuZCBrZWVwIGZldGNoaW5nKT9cbiAgICAgICAgICAgICAgICB0aGlzLnVuYmxvY2soKTtcbiAgICAgICAgICAgICAgICBsZXQgdXJsID0gUlBDKycvYmxvY2s/aGVpZ2h0PScgKyBoZWlnaHQ7XG4gICAgICAgICAgICAgICAgbGV0IGFuYWx5dGljc0RhdGEgPSB7fTtcblxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHVybCk7XG4gICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBidWxrVmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYnVsa1ZhbGlkYXRvclJlY29yZHMgPSBWYWxpZGF0b3JSZWNvcmRzLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtWUEhpc3RvcnkgPSBWb3RpbmdQb3dlckhpc3RvcnkucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYnVsa1RyYW5zYXRpb25zID0gVHJhbnNhY3Rpb25zLnJhd0NvbGxlY3Rpb24oKS5pbml0aWFsaXplVW5vcmRlcmVkQnVsa09wKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0R2V0SGVpZ2h0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgYmxvY2sgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2sgPSBibG9jay5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzdG9yZSBoZWlnaHQsIGhhc2gsIG51bXRyYW5zYWN0aW9uIGFuZCB0aW1lIGluIGRiXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgYmxvY2tEYXRhID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLmhhc2ggPSBibG9jay5ibG9ja19tZXRhLmJsb2NrX2lkLmhhc2g7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudHJhbnNOdW0gPSBibG9jay5ibG9ja19tZXRhLmhlYWRlci5udW1fdHhzO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnRpbWUgPSBuZXcgRGF0ZShibG9jay5ibG9jay5oZWFkZXIudGltZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEubGFzdEJsb2NrSGFzaCA9IGJsb2NrLmJsb2NrLmhlYWRlci5sYXN0X2Jsb2NrX2lkLmhhc2g7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEucHJvcG9zZXJBZGRyZXNzID0gYmxvY2suYmxvY2suaGVhZGVyLnByb3Bvc2VyX2FkZHJlc3M7XG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudmFsaWRhdG9ycyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZWNvbW1pdHMgPSBibG9jay5ibG9jay5sYXN0X2NvbW1pdC5wcmVjb21taXRzO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZWNvbW1pdHMgIT0gbnVsbCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cocHJlY29tbWl0cy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGk9MDsgaTxwcmVjb21taXRzLmxlbmd0aDsgaSsrKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZWNvbW1pdHNbaV0gIT0gbnVsbCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0RhdGEudmFsaWRhdG9ycy5wdXNoKHByZWNvbW1pdHNbaV0udmFsaWRhdG9yX2FkZHJlc3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS5wcmVjb21taXRzID0gcHJlY29tbWl0cy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmVjb3JkIGZvciBhbmFseXRpY3NcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBQcmVjb21taXRSZWNvcmRzLmluc2VydCh7aGVpZ2h0OmhlaWdodCwgcHJlY29tbWl0czpwcmVjb21taXRzLmxlbmd0aH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzYXZlIHR4cyBpbiBkYXRhYmFzZVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGJsb2NrLmJsb2NrLmRhdGEudHhzICYmIGJsb2NrLmJsb2NrLmRhdGEudHhzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodCBpbiBibG9jay5ibG9jay5kYXRhLnR4cyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1ldGVvci5jYWxsKCdUcmFuc2FjdGlvbnMuaW5kZXgnLCBzaGEyNTYoQnVmZmVyLmZyb20oYmxvY2suYmxvY2suZGF0YS50eHNbdF0sICdiYXNlNjQnKSksIGJsb2NrRGF0YS50aW1lLCAoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc2F2ZSBkb3VibGUgc2lnbiBldmlkZW5jZXNcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChibG9jay5ibG9jay5ldmlkZW5jZS5ldmlkZW5jZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRXZpZGVuY2VzLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBldmlkZW5jZTogYmxvY2suYmxvY2suZXZpZGVuY2UuZXZpZGVuY2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tEYXRhLnByZWNvbW1pdHNDb3VudCA9IGJsb2NrRGF0YS52YWxpZGF0b3JzLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS5oZWlnaHQgPSBoZWlnaHQ7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRHZXRIZWlnaHRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0IGhlaWdodCB0aW1lOiBcIisoKGVuZEdldEhlaWdodFRpbWUtc3RhcnRHZXRIZWlnaHRUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydEdldFZhbGlkYXRvcnNUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHVwZGF0ZSBjaGFpbiBzdGF0dXNcbiAgICAgICAgICAgICAgICAgICAgICAgIHVybCA9IFJQQysnL3ZhbGlkYXRvcnM/aGVpZ2h0PScraGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvcnMucmVzdWx0LmJsb2NrX2hlaWdodCA9IHBhcnNlSW50KHZhbGlkYXRvcnMucmVzdWx0LmJsb2NrX2hlaWdodCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBWYWxpZGF0b3JTZXRzLmluc2VydCh2YWxpZGF0b3JzLnJlc3VsdCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrRGF0YS52YWxpZGF0b3JzQ291bnQgPSB2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydEJsb2NrSW5zZXJ0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBCbG9ja3Njb24uaW5zZXJ0KGJsb2NrRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kQmxvY2tJbnNlcnRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQmxvY2sgaW5zZXJ0IHRpbWU6IFwiKygoZW5kQmxvY2tJbnNlcnRUaW1lLXN0YXJ0QmxvY2tJbnNlcnRUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzdG9yZSB2YWxkaWF0b3JzIGV4aXN0IHJlY29yZHNcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBleGlzdGluZ1ZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe2FkZHJlc3M6eyRleGlzdHM6dHJ1ZX19KS5mZXRjaCgpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ID4gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmVjb3JkIHByZWNvbW1pdHMgYW5kIGNhbGN1bGF0ZSB1cHRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBvbmx5IHJlY29yZCBmcm9tIGJsb2NrIDJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGkgaW4gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBhZGRyZXNzID0gdmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9yc1tpXS5hZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVjb3JkID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBoZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiBhZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhpc3RzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogcGFyc2VJbnQodmFsaWRhdG9ycy5yZXN1bHQudmFsaWRhdG9yc1tpXS52b3RpbmdfcG93ZXIpLy9nZXRWYWxpZGF0b3JWb3RpbmdQb3dlcihleGlzdGluZ1ZhbGlkYXRvcnMsIGFkZHJlc3MpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKGogaW4gcHJlY29tbWl0cyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJlY29tbWl0c1tqXSAhPSBudWxsKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYWRkcmVzcyA9PSBwcmVjb21taXRzW2pdLnZhbGlkYXRvcl9hZGRyZXNzKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVjb3JkLmV4aXN0cyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWNvbW1pdHMuc3BsaWNlKGosMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNhbGN1bGF0ZSB0aGUgdXB0aW1lIGJhc2VkIG9uIHRoZSByZWNvcmRzIHN0b3JlZCBpbiBwcmV2aW91cyBibG9ja3NcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gb25seSBkbyB0aGlzIGV2ZXJ5IDE1IGJsb2NrcyB+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKChoZWlnaHQgJSAxNSkgPT0gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBsZXQgc3RhcnRBZ2dUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1CbG9ja3MgPSBNZXRlb3IuY2FsbCgnYmxvY2tzLmZpbmRVcFRpbWUnLCBhZGRyZXNzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB1cHRpbWUgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IGVuZEFnZ1RpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJHZXQgYWdncmVnYXRlZCB1cHRpbWUgZm9yIFwiK2V4aXN0aW5nVmFsaWRhdG9yc1tpXS5hZGRyZXNzK1wiOiBcIisoKGVuZEFnZ1RpbWUtc3RhcnRBZ2dUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKChudW1CbG9ja3NbMF0gIT0gbnVsbCkgJiYgKG51bUJsb2Nrc1swXS51cHRpbWUgIT0gbnVsbCkpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwdGltZSA9IG51bUJsb2Nrc1swXS51cHRpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBiYXNlID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy51cHRpbWVXaW5kb3c7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0IDwgYmFzZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFzZSA9IGhlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlY29yZC5leGlzdHMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh1cHRpbWUgPCBiYXNlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXB0aW1lKys7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwdGltZSA9ICh1cHRpbWUgLyBiYXNlKSoxMDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7YWRkcmVzczphZGRyZXNzfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0Ont1cHRpbWU6dXB0aW1lLCBsYXN0U2VlbjpibG9ja0RhdGEudGltZX19KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXB0aW1lID0gKHVwdGltZSAvIGJhc2UpKjEwMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHthZGRyZXNzOmFkZHJlc3N9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6e3VwdGltZTp1cHRpbWV9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9yUmVjb3Jkcy5pbnNlcnQocmVjb3JkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVmFsaWRhdG9yUmVjb3Jkcy51cGRhdGUoe2hlaWdodDpoZWlnaHQsYWRkcmVzczpyZWNvcmQuYWRkcmVzc30scmVjb3JkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBjaGFpblN0YXR1cyA9IENoYWluLmZpbmRPbmUoe2NoYWluSWQ6YmxvY2suYmxvY2tfbWV0YS5oZWFkZXIuY2hhaW5faWR9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBsYXN0U3luY2VkVGltZSA9IGNoYWluU3RhdHVzP2NoYWluU3RhdHVzLmxhc3RTeW5jZWRUaW1lOjA7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGltZURpZmY7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgYmxvY2tUaW1lID0gTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5kZWZhdWx0QmxvY2tUaW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGxhc3RTeW5jZWRUaW1lKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZGF0ZUxhdGVzdCA9IGJsb2NrRGF0YS50aW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkYXRlTGFzdCA9IG5ldyBEYXRlKGxhc3RTeW5jZWRUaW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lRGlmZiA9IE1hdGguYWJzKGRhdGVMYXRlc3QuZ2V0VGltZSgpIC0gZGF0ZUxhc3QuZ2V0VGltZSgpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja1RpbWUgPSAoY2hhaW5TdGF0dXMuYmxvY2tUaW1lICogKGJsb2NrRGF0YS5oZWlnaHQgLSAxKSArIHRpbWVEaWZmKSAvIGJsb2NrRGF0YS5oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRHZXRWYWxpZGF0b3JzVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkdldCBoZWlnaHQgdmFsaWRhdG9ycyB0aW1lOiBcIisoKGVuZEdldFZhbGlkYXRvcnNUaW1lLXN0YXJ0R2V0VmFsaWRhdG9yc1RpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpibG9jay5ibG9ja19tZXRhLmhlYWRlci5jaGFpbl9pZH0sIHskc2V0OntsYXN0U3luY2VkVGltZTpibG9ja0RhdGEudGltZSwgYmxvY2tUaW1lOmJsb2NrVGltZX19KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS5hdmVyYWdlQmxvY2tUaW1lID0gYmxvY2tUaW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS50aW1lRGlmZiA9IHRpbWVEaWZmO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBhbmFseXRpY3NEYXRhLnRpbWUgPSBibG9ja0RhdGEudGltZTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaW5pdGlhbGl6ZSB2YWxpZGF0b3IgZGF0YSBhdCBmaXJzdCBibG9ja1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgKGhlaWdodCA9PSAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBWYWxpZGF0b3JzLnJlbW92ZSh7fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGFuYWx5dGljc0RhdGEudm90aW5nX3Bvd2VyID0gMDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0RmluZFZhbGlkYXRvcnNOYW1lVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9ycy5yZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvcnMgYXJlIGFsbCB0aGUgdmFsaWRhdG9ycyBpbiB0aGUgY3VycmVudCBoZWlnaHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInZhbGlkYXRvclNldCBzaXplOiBcIit2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBWYWxpZGF0b3JzLmluc2VydCh2YWxpZGF0b3JzLnJlc3VsdC52YWxpZGF0b3JzW3ZdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvciA9IHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnNbdl07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci52b3RpbmdfcG93ZXIgPSBwYXJzZUludCh2YWxpZGF0b3Iudm90aW5nX3Bvd2VyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnByb3Bvc2VyX3ByaW9yaXR5ID0gcGFyc2VJbnQodmFsaWRhdG9yLnByb3Bvc2VyX3ByaW9yaXR5KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsRXhpc3QgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe1wicHViX2tleS52YWx1ZVwiOnZhbGlkYXRvci5wdWJfa2V5LnZhbHVlfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghdmFsRXhpc3Qpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYHZhbGlkYXRvciBwdWJfa2V5ICR7dmFsaWRhdG9yLmFkZHJlc3N9ICR7dmFsaWRhdG9yLnB1Yl9rZXkudmFsdWV9IG5vdCBpbiBkYmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IGNvbW1hbmQgPSBNZXRlb3Iuc2V0dGluZ3MuYmluLmdhaWFkZWJ1ZytcIiBwdWJrZXkgXCIrdmFsaWRhdG9yLnB1Yl9rZXkudmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjb21tYW5kKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGxldCB0ZW1wVmFsID0gdmFsaWRhdG9yO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYWRkcmVzcyA9IGdldEFkZHJlc3ModmFsaWRhdG9yLnB1Yl9rZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFjY3B1YiA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4Q29uc1B1Yik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JEYXRhID0gdmFsaWRhdG9yU2V0W3ZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5XVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvckRhdGEpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHJvZmlsZV91cmwgPSAgZ2V0VmFsaWRhdG9yUHJvZmlsZVVybCh2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5vcGVyYXRvcl9hZGRyZXNzID0gdmFsaWRhdG9yRGF0YS5vcGVyYXRvcl9hZGRyZXNzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWxlZ2F0b3JfYWRkcmVzcyA9IE1ldGVvci5jYWxsKCdnZXREZWxlZ2F0b3InLCB2YWxpZGF0b3JEYXRhLm9wZXJhdG9yX2FkZHJlc3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5qYWlsZWQgPSB2YWxpZGF0b3JEYXRhLmphaWxlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc3RhdHVzID0gdmFsaWRhdG9yRGF0YS5zdGF0dXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm1pbl9zZWxmX2RlbGVnYXRpb24gPSB2YWxpZGF0b3JEYXRhLm1pbl9zZWxmX2RlbGVnYXRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnRva2VucyA9IHZhbGlkYXRvckRhdGEudG9rZW5zO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzID0gdmFsaWRhdG9yRGF0YS5kZWxlZ2F0b3Jfc2hhcmVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZXNjcmlwdGlvbiA9IHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmJvbmRfaGVpZ2h0ID0gdmFsaWRhdG9yRGF0YS5ib25kX2hlaWdodDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuYm9uZF9pbnRyYV90eF9jb3VudGVyID0gdmFsaWRhdG9yRGF0YS5ib25kX2ludHJhX3R4X2NvdW50ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnVuYm9uZGluZ19oZWlnaHQgPSB2YWxpZGF0b3JEYXRhLnVuYm9uZGluZ19oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnVuYm9uZGluZ190aW1lID0gdmFsaWRhdG9yRGF0YS51bmJvbmRpbmdfdGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuY29tbWlzc2lvbiA9IHZhbGlkYXRvckRhdGEuY29tbWlzc2lvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc2VsZl9kZWxlZ2F0aW9uID0gdmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLnJlbW92ZWQgPSBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IucmVtb3ZlZEF0ID0gMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvclNldC5zcGxpY2UodmFsLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ25vIGNvbiBwdWIga2V5PycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGJ1bGtWYWxpZGF0b3JzLmluc2VydCh2YWxpZGF0b3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7YWRkcmVzczogdmFsaWRhdG9yLmFkZHJlc3N9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6dmFsaWRhdG9yfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcInZhbGlkYXRvciBmaXJzdCBhcHBlYXJzOiBcIitidWxrVmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZQSGlzdG9yeS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogdmFsaWRhdG9yLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYWRkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGJsb2NrRGF0YS5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tEYXRhLnRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBNZXRlb3IuY2FsbCgncnVuQ29kZScsIGNvbW1hbmQsIGZ1bmN0aW9uKGVycm9yLCByZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmFkZHJlc3MgPSByZXN1bHQubWF0Y2goL1xcc1swLTlBLUZdezQwfSQvaWdtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvci5hZGRyZXNzID0gdmFsaWRhdG9yLmFkZHJlc3NbMF0udHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmhleCA9IHJlc3VsdC5tYXRjaCgvXFxzWzAtOUEtRl17NjR9JC9pZ20pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmhleCA9IHZhbGlkYXRvci5oZXhbMF0udHJpbSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmNvc21vc2FjY3B1YiA9IHJlc3VsdC5tYXRjaCgvY29zbW9zcHViLiokL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuY29zbW9zYWNjcHViID0gdmFsaWRhdG9yLmNvc21vc2FjY3B1YlswXS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gcmVzdWx0Lm1hdGNoKC9jb3Ntb3N2YWxvcGVycHViLiokL2lnbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleVswXS50cmltKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleSA9IHJlc3VsdC5tYXRjaCgvY29zbW9zdmFsY29uc3B1Yi4qJC9pZ20pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdmFsaWRhdG9yLmNvbnNlbnN1c19wdWJrZXkgPSB2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleVswXS50cmltKCk7XG5cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvckRhdGEgPSB2YWxpZGF0b3JTZXRbdmFsRXhpc3QuY29uc2Vuc3VzX3B1YmtleV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JEYXRhKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbiAmJiAoIXZhbEV4aXN0LmRlc2NyaXB0aW9uIHx8IHZhbGlkYXRvckRhdGEuZGVzY3JpcHRpb24uaWRlbnRpdHkgIT09IHZhbEV4aXN0LmRlc2NyaXB0aW9uLmlkZW50aXR5KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnByb2ZpbGVfdXJsID0gIGdldFZhbGlkYXRvclByb2ZpbGVVcmwodmFsaWRhdG9yRGF0YS5kZXNjcmlwdGlvbi5pZGVudGl0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuamFpbGVkID0gdmFsaWRhdG9yRGF0YS5qYWlsZWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnN0YXR1cyA9IHZhbGlkYXRvckRhdGEuc3RhdHVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci50b2tlbnMgPSB2YWxpZGF0b3JEYXRhLnRva2VucztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVsZWdhdG9yX3NoYXJlcyA9IHZhbGlkYXRvckRhdGEuZGVsZWdhdG9yX3NoYXJlcztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVzY3JpcHRpb24gPSB2YWxpZGF0b3JEYXRhLmRlc2NyaXB0aW9uO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5ib25kX2hlaWdodCA9IHZhbGlkYXRvckRhdGEuYm9uZF9oZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmJvbmRfaW50cmFfdHhfY291bnRlciA9IHZhbGlkYXRvckRhdGEuYm9uZF9pbnRyYV90eF9jb3VudGVyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci51bmJvbmRpbmdfaGVpZ2h0ID0gdmFsaWRhdG9yRGF0YS51bmJvbmRpbmdfaGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci51bmJvbmRpbmdfdGltZSA9IHZhbGlkYXRvckRhdGEudW5ib25kaW5nX3RpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmNvbW1pc3Npb24gPSB2YWxpZGF0b3JEYXRhLmNvbW1pc3Npb247XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjYWxjdWxhdGUgc2VsZiBkZWxlZ2F0aW9uIHBlcmNlbnRhZ2UgZXZlcnkgMzAgYmxvY2tzXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ICUgMzAgPT0gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KExDRCArICcvc3Rha2luZy9kZWxlZ2F0b3JzLycrdmFsRXhpc3QuZGVsZWdhdG9yX2FkZHJlc3MrJy9kZWxlZ2F0aW9ucy8nK3ZhbEV4aXN0Lm9wZXJhdG9yX2FkZHJlc3MpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzZWxmRGVsZWdhdGlvbiA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZWxmRGVsZWdhdGlvbi5zaGFyZXMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iuc2VsZl9kZWxlZ2F0aW9uID0gcGFyc2VGbG9hdChzZWxmRGVsZWdhdGlvbi5zaGFyZXMpL3BhcnNlRmxvYXQodmFsaWRhdG9yLmRlbGVnYXRvcl9zaGFyZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7Y29uc2Vuc3VzX3B1YmtleTogdmFsRXhpc3QuY29uc2Vuc3VzX3B1YmtleX0pLnVwZGF0ZU9uZSh7JHNldDp2YWxpZGF0b3J9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcInZhbGlkYXRvciBleGlzaXRzOiBcIitidWxrVmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHZhbGlkYXRvclNldC5zcGxpY2UodmFsLCAxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdubyBjb24gcHViIGtleT8nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZWb3RpbmdQb3dlciA9IFZvdGluZ1Bvd2VySGlzdG9yeS5maW5kT25lKHthZGRyZXNzOnZhbGlkYXRvci5hZGRyZXNzfSwge2hlaWdodDotMSwgbGltaXQ6MX0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldlZvdGluZ1Bvd2VyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocHJldlZvdGluZ1Bvd2VyLnZvdGluZ19wb3dlciAhPSB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNoYW5nZVR5cGUgPSAocHJldlZvdGluZ1Bvd2VyLnZvdGluZ19wb3dlciA+IHZhbGlkYXRvci52b3RpbmdfcG93ZXIpPydkb3duJzondXAnO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY2hhbmdlRGF0YSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldl92b3RpbmdfcG93ZXI6IHByZXZWb3RpbmdQb3dlci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3RpbmdfcG93ZXI6IHZhbGlkYXRvci52b3RpbmdfcG93ZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBjaGFuZ2VUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBibG9ja0RhdGEuaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tEYXRhLnRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ3ZvdGluZyBwb3dlciBjaGFuZ2VkLicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhjaGFuZ2VEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZQSGlzdG9yeS5pbnNlcnQoY2hhbmdlRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHZhbGlkYXRvcik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW5hbHl0aWNzRGF0YS52b3RpbmdfcG93ZXIgKz0gdmFsaWRhdG9yLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGVyZSBpcyB2YWxpZGF0b3IgcmVtb3ZlZFxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByZXZWYWxpZGF0b3JzID0gVmFsaWRhdG9yU2V0cy5maW5kT25lKHtibG9ja19oZWlnaHQ6aGVpZ2h0LTF9KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcmV2VmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZW1vdmVkVmFsaWRhdG9ycyA9IGdldFJlbW92ZWRWYWxpZGF0b3JzKHByZXZWYWxpZGF0b3JzLnZhbGlkYXRvcnMsIHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnMpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAociBpbiByZW1vdmVkVmFsaWRhdG9ycyl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVlBIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkcmVzczogcmVtb3ZlZFZhbGlkYXRvcnNbcl0uYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2X3ZvdGluZ19wb3dlcjogcmVtb3ZlZFZhbGlkYXRvcnNbcl0udm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGluZ19wb3dlcjogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAncmVtb3ZlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IGJsb2NrRGF0YS5oZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tfdGltZTogYmxvY2tEYXRhLnRpbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gY2hlY2sgaWYgdGhlcmUncyBhbnkgdmFsaWRhdG9yIG5vdCBpbiBkYiAxNDQwMCBibG9ja3MofjEgZGF5KVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGhlaWdodCAlIDE0NDAwID09IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdDaGVja2luZyBhbGwgdmFsaWRhdG9ycyBhZ2FpbnN0IGRiLi4uJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRiVmFsaWRhdG9ycyA9IHt9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZhbGlkYXRvcnMuZmluZCh7fSwge2ZpZWxkczoge2NvbnNlbnN1c19wdWJrZXk6IDEsIHN0YXR1czogMX19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLmZvckVhY2goKHYpID0+IGRiVmFsaWRhdG9yc1t2LmNvbnNlbnN1c19wdWJrZXldID0gdi5zdGF0dXMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE9iamVjdC5rZXlzKHZhbGlkYXRvclNldCkuZm9yRWFjaCgoY29uUHViS2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yRGF0YSA9IHZhbGlkYXRvclNldFtjb25QdWJLZXldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQWN0aXZlIHZhbGlkYXRvcnMgc2hvdWxkIGhhdmUgYmVlbiB1cGRhdGVkIGluIHByZXZpb3VzIHN0ZXBzXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsaWRhdG9yRGF0YS5zdGF0dXMgPT09IDIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChkYlZhbGlkYXRvcnNbY29uUHViS2V5XSA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgdmFsaWRhdG9yIHdpdGggY29uc2Vuc3VzX3B1YmtleSAke2NvblB1YktleX0gbm90IGluIGRiYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHB1YmtleVR5cGUgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnNlY3AyNTZrMT8ndGVuZGVybWludC9QdWJLZXlTZWNwMjU2azEnOid0ZW5kZXJtaW50L1B1YktleUVkMjU1MTknO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEucHViX2tleSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ0eXBlXCIgOiBwdWJrZXlUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6IE1ldGVvci5jYWxsKCdiZWNoMzJUb1B1YmtleScsIGNvblB1YktleSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yRGF0YS5hZGRyZXNzID0gZ2V0QWRkcmVzcyh2YWxpZGF0b3JEYXRhLnB1Yl9rZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEuZGVsZWdhdG9yX2FkZHJlc3MgPSBNZXRlb3IuY2FsbCgnZ2V0RGVsZWdhdG9yJywgdmFsaWRhdG9yRGF0YS5vcGVyYXRvcl9hZGRyZXNzKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvckRhdGEuYWNjcHViID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yRGF0YS5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yRGF0YS5vcGVyYXRvcl9wdWJrZXkgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3JEYXRhLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeSh2YWxpZGF0b3JEYXRhKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHtjb25zZW5zdXNfcHVia2V5OiBjb25QdWJLZXl9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6dmFsaWRhdG9yRGF0YX0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChkYlZhbGlkYXRvcnNbY29uUHViS2V5XSA9PSAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvcnMuZmluZCh7Y29uc2Vuc3VzX3B1YmtleTogY29uUHViS2V5fSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnZhbGlkYXRvckRhdGF9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGZldGNoaW5nIGtleWJhc2UgZXZlcnkgMTQ0MDAgYmxvY2tzKH4xIGRheSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChoZWlnaHQgJSAxNDQwMCA9PSAxKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnRmV0Y2hpbmcga2V5YmFzZS4uLicpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmFsaWRhdG9ycy5maW5kKHt9KS5mb3JFYWNoKCh2YWxpZGF0b3IpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcm9maWxlVXJsID0gIGdldFZhbGlkYXRvclByb2ZpbGVVcmwodmFsaWRhdG9yLmRlc2NyaXB0aW9uLmlkZW50aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByb2ZpbGVVcmwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBidWxrVmFsaWRhdG9ycy5maW5kKHthZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6eydwcm9maWxlX3VybCc6cHJvZmlsZVVybH19KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRGaW5kVmFsaWRhdG9yc05hbWVUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0IHZhbGlkYXRvcnMgbmFtZSB0aW1lOiBcIisoKGVuZEZpbmRWYWxpZGF0b3JzTmFtZVRpbWUtc3RhcnRGaW5kVmFsaWRhdG9yc05hbWVUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyByZWNvcmQgZm9yIGFuYWx5dGljc1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN0YXJ0QW5heXRpY3NJbnNlcnRUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIEFuYWx5dGljcy5pbnNlcnQoYW5hbHl0aWNzRGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZW5kQW5hbHl0aWNzSW5zZXJ0VGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFuYWx5dGljcyBpbnNlcnQgdGltZTogXCIrKChlbmRBbmFseXRpY3NJbnNlcnRUaW1lLXN0YXJ0QW5heXRpY3NJbnNlcnRUaW1lKS8xMDAwKStcInNlY29uZHMuXCIpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhcnRWVXBUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWxrVmFsaWRhdG9ycy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhidWxrVmFsaWRhdG9ycy5sZW5ndGgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWYWxpZGF0b3JzLmV4ZWN1dGUoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGVuZFZVcFRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0b3IgdXBkYXRlIHRpbWU6IFwiKygoZW5kVlVwVGltZS1zdGFydFZVcFRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGFydFZSVGltZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnVsa1ZhbGlkYXRvclJlY29yZHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1ZhbGlkYXRvclJlY29yZHMuZXhlY3V0ZSgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBlbmRWUlRpbWUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJWYWxpZGF0b3IgcmVjb3JkcyB1cGRhdGUgdGltZTogXCIrKChlbmRWUlRpbWUtc3RhcnRWUlRpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWxrVlBIaXN0b3J5Lmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtWUEhpc3RvcnkuZXhlY3V0ZSgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChidWxrVHJhbnNhdGlvbnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1RyYW5zYXRpb25zLmV4ZWN1dGUoKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlcnIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXJyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjYWxjdWxhdGUgdm90aW5nIHBvd2VyIGRpc3RyaWJ1dGlvbiBldmVyeSA2MCBibG9ja3MgfiA1bWluc1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaGVpZ2h0ICUgNjAgPT0gMSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCI9PT09PSBjYWxjdWxhdGUgdm90aW5nIHBvd2VyIGRpc3RyaWJ1dGlvbiA9PT09PVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgYWN0aXZlVmFsaWRhdG9ycyA9IFZhbGlkYXRvcnMuZmluZCh7c3RhdHVzOjIsamFpbGVkOmZhbHNlfSx7c29ydDp7dm90aW5nX3Bvd2VyOi0xfX0pLmZldGNoKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IG51bVRvcFR3ZW50eSA9IE1hdGguY2VpbChhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCowLjIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1Cb3R0b21FaWdodHkgPSBhY3RpdmVWYWxpZGF0b3JzLmxlbmd0aCAtIG51bVRvcFR3ZW50eTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0b3BUd2VudHlQb3dlciA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJvdHRvbUVpZ2h0eVBvd2VyID0gMDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBudW1Ub3BUaGlydHlGb3VyID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbnVtQm90dG9tU2l4dHlTaXggPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0b3BUaGlydHlGb3VyUGVyY2VudCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGJvdHRvbVNpeHR5U2l4UGVyY2VudCA9IDA7XG5cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2IGluIGFjdGl2ZVZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodiA8IG51bVRvcFR3ZW50eSl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3BUd2VudHlQb3dlciArPSBhY3RpdmVWYWxpZGF0b3JzW3ZdLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tRWlnaHR5UG93ZXIgKz0gYWN0aXZlVmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0b3BUaGlydHlGb3VyUGVyY2VudCA8IDAuMzQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wVGhpcnR5Rm91clBlcmNlbnQgKz0gYWN0aXZlVmFsaWRhdG9yc1t2XS52b3RpbmdfcG93ZXIgLyBhbmFseXRpY3NEYXRhLnZvdGluZ19wb3dlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bVRvcFRoaXJ0eUZvdXIrKztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvdHRvbVNpeHR5U2l4UGVyY2VudCA9IDEgLSB0b3BUaGlydHlGb3VyUGVyY2VudDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Cb3R0b21TaXh0eVNpeCA9IGFjdGl2ZVZhbGlkYXRvcnMubGVuZ3RoIC0gbnVtVG9wVGhpcnR5Rm91cjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2cERpc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Ub3BUd2VudHk6IG51bVRvcFR3ZW50eSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wVHdlbnR5UG93ZXI6IHRvcFR3ZW50eVBvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Cb3R0b21FaWdodHk6IG51bUJvdHRvbUVpZ2h0eSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tRWlnaHR5UG93ZXI6IGJvdHRvbUVpZ2h0eVBvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudW1Ub3BUaGlydHlGb3VyOiBudW1Ub3BUaGlydHlGb3VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3BUaGlydHlGb3VyUGVyY2VudDogdG9wVGhpcnR5Rm91clBlcmNlbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bUJvdHRvbVNpeHR5U2l4OiBudW1Cb3R0b21TaXh0eVNpeCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm90dG9tU2l4dHlTaXhQZXJjZW50OiBib3R0b21TaXh0eVNpeFBlcmNlbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bVZhbGlkYXRvcnM6IGFjdGl2ZVZhbGlkYXRvcnMubGVuZ3RoLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbFZvdGluZ1Bvd2VyOiBhbmFseXRpY3NEYXRhLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tUaW1lOiBibG9ja0RhdGEudGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3JlYXRlQXQ6IG5ldyBEYXRlKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyh2cERpc3QpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVlBEaXN0cmlidXRpb25zLmluc2VydCh2cERpc3QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgICAgIFNZTkNJTkcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiU3RvcHBlZFwiO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBsZXQgZW5kQmxvY2tUaW1lID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlRoaXMgYmxvY2sgdXNlZDogXCIrKChlbmRCbG9ja1RpbWUtc3RhcnRCbG9ja1RpbWUpLzEwMDApK1wic2Vjb25kcy5cIik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBTWU5DSU5HID0gZmFsc2U7XG4gICAgICAgICAgICBDaGFpbi51cGRhdGUoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSwgeyRzZXQ6e2xhc3RCbG9ja3NTeW5jZWRUaW1lOm5ldyBEYXRlKCksIHRvdGFsVmFsaWRhdG9yczp0b3RhbFZhbGlkYXRvcnN9fSk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdW50aWw7XG4gICAgfSxcbiAgICAnYWRkTGltaXQnOiBmdW5jdGlvbihsaW1pdCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhsaW1pdCsxMClcbiAgICAgICAgcmV0dXJuIChsaW1pdCsxMCk7XG4gICAgfSxcbiAgICAnaGFzTW9yZSc6IGZ1bmN0aW9uKGxpbWl0KSB7XG4gICAgICAgIGlmIChsaW1pdCA+IE1ldGVvci5jYWxsKCdnZXRDdXJyZW50SGVpZ2h0JykpIHtcbiAgICAgICAgICAgIHJldHVybiAoZmFsc2UpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuICh0cnVlKTtcbiAgICAgICAgfVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBCbG9ja3Njb24gfSBmcm9tICcuLi9ibG9ja3MuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcblxucHVibGlzaENvbXBvc2l0ZSgnYmxvY2tzLmhlaWdodCcsIGZ1bmN0aW9uKGxpbWl0KXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoe30sIHtsaW1pdDogbGltaXQsIHNvcnQ6IHtoZWlnaHQ6IC0xfX0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChibG9jayl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRkcmVzczpibG9jay5wcm9wb3NlckFkZHJlc3N9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2xpbWl0OjF9XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnYmxvY2tzLmZpbmRPbmUnLCBmdW5jdGlvbihoZWlnaHQpe1xuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZCh7aGVpZ2h0OmhlaWdodH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChibG9jayl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBUcmFuc2FjdGlvbnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6YmxvY2suaGVpZ2h0fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKGJsb2NrKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHthZGRyZXNzOmJsb2NrLnByb3Bvc2VyQWRkcmVzc30sXG4gICAgICAgICAgICAgICAgICAgICAgICB7bGltaXQ6MX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbmV4cG9ydCBjb25zdCBCbG9ja3Njb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignYmxvY2tzJyk7XG5cbkJsb2Nrc2Nvbi5oZWxwZXJzKHtcbiAgICBwcm9wb3Nlcigpe1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMucHJvcG9zZXJBZGRyZXNzfSk7XG4gICAgfVxufSk7XG5cbi8vIEJsb2Nrc2Nvbi5oZWxwZXJzKHtcbi8vICAgICBzb3J0ZWQobGltaXQpIHtcbi8vICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKHt9LCB7c29ydDoge2hlaWdodDotMX0sIGxpbWl0OiBsaW1pdH0pO1xuLy8gICAgIH1cbi8vIH0pO1xuXG5cbi8vIE1ldGVvci5zZXRJbnRlcnZhbChmdW5jdGlvbigpIHtcbi8vICAgICBNZXRlb3IuY2FsbCgnYmxvY2tzVXBkYXRlJywgKGVycm9yLCByZXN1bHQpID0+IHtcbi8vICAgICAgICAgY29uc29sZS5sb2cocmVzdWx0KTtcbi8vICAgICB9KVxuLy8gfSwgMzAwMDAwMDApOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IGdldEFkZHJlc3MgfSBmcm9tICd0ZW5kZXJtaW50L2xpYi9wdWJrZXkuanMnO1xuaW1wb3J0IHsgQ2hhaW4sIENoYWluU3RhdGVzIH0gZnJvbSAnLi4vY2hhaW4uanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWb3RpbmdQb3dlckhpc3RvcnkgfSBmcm9tICcuLi8uLi92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5pbXBvcnQgQ29pbiBmcm9tICcuLi8uLi8uLi8uLi9ib3RoL3V0aWxzL2NvaW5zLmpzJztcblxuZmluZFZvdGluZ1Bvd2VyID0gKHZhbGlkYXRvciwgZ2VuVmFsaWRhdG9ycykgPT4ge1xuICAgIGZvciAobGV0IHYgaW4gZ2VuVmFsaWRhdG9ycyl7XG4gICAgICAgIGlmICh2YWxpZGF0b3IucHViX2tleS52YWx1ZSA9PSBnZW5WYWxpZGF0b3JzW3ZdLnB1Yl9rZXkudmFsdWUpe1xuICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KGdlblZhbGlkYXRvcnNbdl0ucG93ZXIpO1xuICAgICAgICB9XG4gICAgfVxufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2NoYWluLmdldENvbnNlbnN1c1N0YXRlJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB1cmwgPSBSUEMrJy9kdW1wX2NvbnNlbnN1c19zdGF0ZSc7XG4gICAgICAgIHRyeXtcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgY29uc2Vuc3VzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIGNvbnNlbnN1cyA9IGNvbnNlbnN1cy5yZXN1bHQ7XG4gICAgICAgICAgICBsZXQgaGVpZ2h0ID0gY29uc2Vuc3VzLnJvdW5kX3N0YXRlLmhlaWdodDtcbiAgICAgICAgICAgIGxldCByb3VuZCA9IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS5yb3VuZDtcbiAgICAgICAgICAgIGxldCBzdGVwID0gY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnN0ZXA7XG4gICAgICAgICAgICBsZXQgdm90ZWRQb3dlciA9IE1hdGgucm91bmQocGFyc2VGbG9hdChjb25zZW5zdXMucm91bmRfc3RhdGUudm90ZXNbcm91bmRdLnByZXZvdGVzX2JpdF9hcnJheS5zcGxpdChcIiBcIilbM10pKjEwMCk7XG5cbiAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LCB7JHNldDp7XG4gICAgICAgICAgICAgICAgdm90aW5nSGVpZ2h0OiBoZWlnaHQsXG4gICAgICAgICAgICAgICAgdm90aW5nUm91bmQ6IHJvdW5kLFxuICAgICAgICAgICAgICAgIHZvdGluZ1N0ZXA6IHN0ZXAsXG4gICAgICAgICAgICAgICAgdm90ZWRQb3dlcjogdm90ZWRQb3dlcixcbiAgICAgICAgICAgICAgICBwcm9wb3NlckFkZHJlc3M6IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS52YWxpZGF0b3JzLnByb3Bvc2VyLmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgcHJldm90ZXM6IGNvbnNlbnN1cy5yb3VuZF9zdGF0ZS52b3Rlc1tyb3VuZF0ucHJldm90ZXMsXG4gICAgICAgICAgICAgICAgcHJlY29tbWl0czogY29uc2Vuc3VzLnJvdW5kX3N0YXRlLnZvdGVzW3JvdW5kXS5wcmVjb21taXRzXG4gICAgICAgICAgICB9fSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgJ2NoYWluLnVwZGF0ZVN0YXR1cyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICBsZXQgdXJsID0gUlBDKycvc3RhdHVzJztcbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGxldCBzdGF0dXMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgc3RhdHVzID0gc3RhdHVzLnJlc3VsdDtcbiAgICAgICAgICAgIGxldCBjaGFpbiA9IHt9O1xuICAgICAgICAgICAgY2hhaW4uY2hhaW5JZCA9IHN0YXR1cy5ub2RlX2luZm8ubmV0d29yaztcbiAgICAgICAgICAgIGNoYWluLmxhdGVzdEJsb2NrSGVpZ2h0ID0gc3RhdHVzLnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfaGVpZ2h0O1xuICAgICAgICAgICAgY2hhaW4ubGF0ZXN0QmxvY2tUaW1lID0gc3RhdHVzLnN5bmNfaW5mby5sYXRlc3RfYmxvY2tfdGltZTtcblxuICAgICAgICAgICAgbGV0IGxhdGVzdFN0YXRlID0gQ2hhaW5TdGF0ZXMuZmluZE9uZSh7fSwge3NvcnQ6IHtoZWlnaHQ6IC0xfX0pXG4gICAgICAgICAgICBpZiAobGF0ZXN0U3RhdGUgJiYgbGF0ZXN0U3RhdGUuaGVpZ2h0ID49IGNoYWluLmxhdGVzdEJsb2NrSGVpZ2h0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGBubyB1cGRhdGVzIChnZXR0aW5nIGJsb2NrICR7Y2hhaW4ubGF0ZXN0QmxvY2tIZWlnaHR9IGF0IGJsb2NrICR7bGF0ZXN0U3RhdGUuaGVpZ2h0fSlgXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHVybCA9IFJQQysnL3ZhbGlkYXRvcnMnO1xuICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICAgICAgdmFsaWRhdG9ycyA9IHZhbGlkYXRvcnMucmVzdWx0LnZhbGlkYXRvcnM7XG4gICAgICAgICAgICBjaGFpbi52YWxpZGF0b3JzID0gdmFsaWRhdG9ycy5sZW5ndGg7XG4gICAgICAgICAgICBsZXQgYWN0aXZlVlAgPSAwO1xuICAgICAgICAgICAgZm9yICh2IGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgICAgIGFjdGl2ZVZQICs9IHBhcnNlSW50KHZhbGlkYXRvcnNbdl0udm90aW5nX3Bvd2VyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNoYWluLmFjdGl2ZVZvdGluZ1Bvd2VyID0gYWN0aXZlVlA7XG5cblxuICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOmNoYWluLmNoYWluSWR9LCB7JHNldDpjaGFpbn0sIHt1cHNlcnQ6IHRydWV9KTtcbiAgICAgICAgICAgIC8vIEdldCBjaGFpbiBzdGF0ZXNcbiAgICAgICAgICAgIGlmIChwYXJzZUludChjaGFpbi5sYXRlc3RCbG9ja0hlaWdodCkgPiAwKXtcbiAgICAgICAgICAgICAgICBsZXQgY2hhaW5TdGF0ZXMgPSB7fTtcbiAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5oZWlnaHQgPSBwYXJzZUludChzdGF0dXMuc3luY19pbmZvLmxhdGVzdF9ibG9ja19oZWlnaHQpO1xuICAgICAgICAgICAgICAgIGNoYWluU3RhdGVzLnRpbWUgPSBuZXcgRGF0ZShzdGF0dXMuc3luY19pbmZvLmxhdGVzdF9ibG9ja190aW1lKTtcblxuICAgICAgICAgICAgICAgIHVybCA9IExDRCArICcvc3Rha2luZy9wb29sJztcbiAgICAgICAgICAgICAgICB0cnl7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGJvbmRpbmcgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgLy8gY2hhaW4uYm9uZGVkVG9rZW5zID0gYm9uZGluZy5ib25kZWRfdG9rZW5zO1xuICAgICAgICAgICAgICAgICAgICAvLyBjaGFpbi5ub3RCb25kZWRUb2tlbnMgPSBib25kaW5nLm5vdF9ib25kZWRfdG9rZW5zO1xuICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5ib25kZWRUb2tlbnMgPSBwYXJzZUludChib25kaW5nLmJvbmRlZF90b2tlbnMpO1xuICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5ub3RCb25kZWRUb2tlbnMgPSBwYXJzZUludChib25kaW5nLm5vdF9ib25kZWRfdG9rZW5zKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmICggQ29pbi5TdGFraW5nQ29pbi5kZW5vbSApIHtcbiAgICAgICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9zdXBwbHkvdG90YWwvJysgQ29pbi5TdGFraW5nQ29pbi5kZW5vbTtcbiAgICAgICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHN1cHBseSA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMudG90YWxTdXBwbHkgPSBwYXJzZUludChzdXBwbHkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL2Rpc3RyaWJ1dGlvbi9jb21tdW5pdHlfcG9vbCc7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcG9vbCA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHBvb2wgJiYgcG9vbC5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5jb21tdW5pdHlQb29sID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9vbC5mb3JFYWNoKChhbW91bnQsIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuY29tbXVuaXR5UG9vbC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbm9tOiBhbW91bnQuZGVub20sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IHBhcnNlRmxvYXQoYW1vdW50LmFtb3VudClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICB1cmwgPSBMQ0QgKyAnL21pbnRpbmcvaW5mbGF0aW9uJztcbiAgICAgICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGluZmxhdGlvbiA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGluZmxhdGlvbil7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hhaW5TdGF0ZXMuaW5mbGF0aW9uID0gcGFyc2VGbG9hdChpbmZsYXRpb24pXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHVybCA9IExDRCArICcvbWludGluZy9hbm51YWwtcHJvdmlzaW9ucyc7XG4gICAgICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcm92aXNpb25zID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcm92aXNpb25zKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGFpblN0YXRlcy5hbm51YWxQcm92aXNpb25zID0gcGFyc2VGbG9hdChwcm92aXNpb25zLnJlc3VsdClcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjYXRjaChlKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBcdFx0fVxuXG4gICAgICAgICAgICAgICAgQ2hhaW5TdGF0ZXMuaW5zZXJ0KGNoYWluU3RhdGVzKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gY2hhaW4udG90YWxWb3RpbmdQb3dlciA9IHRvdGFsVlA7XG5cbiAgICAgICAgICAgIC8vIHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyh2YWxpZGF0b3JzKTtcbiAgICAgICAgICAgIHJldHVybiBjaGFpbi5sYXRlc3RCbG9ja0hlaWdodDtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlKTtcbiAgICAgICAgICAgIHJldHVybiBcIkVycm9yIGdldHRpbmcgY2hhaW4gc3RhdHVzLlwiO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAnY2hhaW4uZ2V0TGF0ZXN0U3RhdHVzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgQ2hhaW4uZmluZCgpLnNvcnQoe2NyZWF0ZWQ6LTF9KS5saW1pdCgxKTtcbiAgICB9LFxuICAgICdjaGFpbi5nZW5lc2lzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgbGV0IGNoYWluID0gQ2hhaW4uZmluZE9uZSh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG5cbiAgICAgICAgaWYgKGNoYWluICYmIGNoYWluLnJlYWRHZW5lc2lzKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdHZW5lc2lzIGZpbGUgaGFzIGJlZW4gcHJvY2Vzc2VkJyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoTWV0ZW9yLnNldHRpbmdzLmRlYnVnLnJlYWRHZW5lc2lzKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnPT09IFN0YXJ0IHByb2Nlc3NpbmcgZ2VuZXNpcyBmaWxlID09PScpO1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQoTWV0ZW9yLnNldHRpbmdzLmdlbmVzaXNGaWxlKTtcbiAgICAgICAgICAgIGxldCBnZW5lc2lzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIGxldCBkaXN0ciA9IGdlbmVzaXMuYXBwX3N0YXRlLmRpc3RyIHx8IGdlbmVzaXMuYXBwX3N0YXRlLmRpc3RyaWJ1dGlvblxuICAgICAgICAgICAgbGV0IGNoYWluUGFyYW1zID0ge1xuICAgICAgICAgICAgICAgIGNoYWluSWQ6IGdlbmVzaXMuY2hhaW5faWQsXG4gICAgICAgICAgICAgICAgZ2VuZXNpc1RpbWU6IGdlbmVzaXMuZ2VuZXNpc190aW1lLFxuICAgICAgICAgICAgICAgIGNvbnNlbnN1c1BhcmFtczogZ2VuZXNpcy5jb25zZW5zdXNfcGFyYW1zLFxuICAgICAgICAgICAgICAgIGF1dGg6IGdlbmVzaXMuYXBwX3N0YXRlLmF1dGgsXG4gICAgICAgICAgICAgICAgYmFuazogZ2VuZXNpcy5hcHBfc3RhdGUuYmFuayxcbiAgICAgICAgICAgICAgICBzdGFraW5nOiB7XG4gICAgICAgICAgICAgICAgICAgIHBvb2w6IGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcucG9vbCxcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zOiBnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnBhcmFtc1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgbWludDogZ2VuZXNpcy5hcHBfc3RhdGUubWludCxcbiAgICAgICAgICAgICAgICBkaXN0cjoge1xuICAgICAgICAgICAgICAgICAgICBjb21tdW5pdHlUYXg6IGRpc3RyLmNvbW11bml0eV90YXgsXG4gICAgICAgICAgICAgICAgICAgIGJhc2VQcm9wb3NlclJld2FyZDogZGlzdHIuYmFzZV9wcm9wb3Nlcl9yZXdhcmQsXG4gICAgICAgICAgICAgICAgICAgIGJvbnVzUHJvcG9zZXJSZXdhcmQ6IGRpc3RyLmJvbnVzX3Byb3Bvc2VyX3Jld2FyZCxcbiAgICAgICAgICAgICAgICAgICAgd2l0aGRyYXdBZGRyRW5hYmxlZDogZGlzdHIud2l0aGRyYXdfYWRkcl9lbmFibGVkXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBnb3Y6IHtcbiAgICAgICAgICAgICAgICAgICAgc3RhcnRpbmdQcm9wb3NhbElkOiAwLFxuICAgICAgICAgICAgICAgICAgICBkZXBvc2l0UGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICAgICAgdm90aW5nUGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICAgICAgdGFsbHlQYXJhbXM6IHt9XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzbGFzaGluZzp7XG4gICAgICAgICAgICAgICAgICAgIHBhcmFtczogZ2VuZXNpcy5hcHBfc3RhdGUuc2xhc2hpbmcucGFyYW1zXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzdXBwbHk6IGdlbmVzaXMuYXBwX3N0YXRlLnN1cHBseSxcbiAgICAgICAgICAgICAgICBjcmlzaXM6IGdlbmVzaXMuYXBwX3N0YXRlLmNyaXNpc1xuICAgICAgICAgICAgfVxuXG5cdCAgICBpZiAoZ2VuZXNpcy5hcHBfc3RhdGUuZ292KSB7XG4gICAgICAgICAgICAgICAgY2hhaW5QYXJhbXMuZ292ID0ge1xuICAgICAgICAgICAgICAgICAgICBzdGFydGluZ1Byb3Bvc2FsSWQ6IGdlbmVzaXMuYXBwX3N0YXRlLmdvdi5zdGFydGluZ19wcm9wb3NhbF9pZCxcbiAgICAgICAgICAgICAgICAgICAgZGVwb3NpdFBhcmFtczogZ2VuZXNpcy5hcHBfc3RhdGUuZ292LmRlcG9zaXRfcGFyYW1zLFxuICAgICAgICAgICAgICAgICAgICB2b3RpbmdQYXJhbXM6IGdlbmVzaXMuYXBwX3N0YXRlLmdvdi52b3RpbmdfcGFyYW1zLFxuICAgICAgICAgICAgICAgICAgICB0YWxseVBhcmFtczogZ2VuZXNpcy5hcHBfc3RhdGUuZ292LnRhbGx5X3BhcmFtc1xuICAgICAgICAgICAgICAgIH07XG5cdCAgICB9XG4gICAgICAgICAgICBsZXQgdG90YWxWb3RpbmdQb3dlciA9IDA7XG5cbiAgICAgICAgICAgIC8vIHJlYWQgZ2VudHhcbiAgICAgICAgICAgIGlmIChnZW5lc2lzLmFwcF9zdGF0ZS5nZW51dGlsICYmIGdlbmVzaXMuYXBwX3N0YXRlLmdlbnV0aWwuZ2VudHhzICYmIChnZW5lc2lzLmFwcF9zdGF0ZS5nZW51dGlsLmdlbnR4cy5sZW5ndGggPiAwKSl7XG4gICAgICAgICAgICAgICAgZm9yIChpIGluIGdlbmVzaXMuYXBwX3N0YXRlLmdlbnV0aWwuZ2VudHhzKXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IG1zZyA9IGdlbmVzaXMuYXBwX3N0YXRlLmdlbnV0aWwuZ2VudHhzW2ldLnZhbHVlLm1zZztcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2cobXNnLnR5cGUpO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKG0gaW4gbXNnKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtc2dbbV0udHlwZSA9PSBcImNvc21vcy1zZGsvTXNnQ3JlYXRlVmFsaWRhdG9yXCIpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKG1zZ1ttXS52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbGV0IGNvbW1hbmQgPSBNZXRlb3Iuc2V0dGluZ3MuYmluLmdhaWFkZWJ1ZytcIiBwdWJrZXkgXCIrbXNnW21dLnZhbHVlLnB1YmtleTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zZW5zdXNfcHVia2V5OiBtc2dbbV0udmFsdWUucHVia2V5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogbXNnW21dLnZhbHVlLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uOiBtc2dbbV0udmFsdWUuY29tbWlzc2lvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluX3NlbGZfZGVsZWdhdGlvbjogbXNnW21dLnZhbHVlLm1pbl9zZWxmX2RlbGVnYXRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wZXJhdG9yX2FkZHJlc3M6IG1zZ1ttXS52YWx1ZS52YWxpZGF0b3JfYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZWdhdG9yX2FkZHJlc3M6IG1zZ1ttXS52YWx1ZS5kZWxlZ2F0b3JfYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiBNYXRoLmZsb29yKHBhcnNlSW50KG1zZ1ttXS52YWx1ZS52YWx1ZS5hbW91bnQpIC8gQ29pbi5TdGFraW5nQ29pbi5mcmFjdGlvbiksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGphaWxlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogMlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsVm90aW5nUG93ZXIgKz0gdmFsaWRhdG9yLnZvdGluZ19wb3dlcjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwdWJrZXlUeXBlID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5zZWNwMjU2azE/J3RlbmRlcm1pbnQvUHViS2V5U2VjcDI1NmsxJzondGVuZGVybWludC9QdWJLZXlFZDI1NTE5JztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcHVia2V5VmFsdWUgPSBNZXRlb3IuY2FsbCgnYmVjaDMyVG9QdWJrZXknLCBtc2dbbV0udmFsdWUucHVia2V5LCBwdWJrZXlUeXBlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBWYWxpZGF0b3JzLnVwc2VydCh7Y29uc2Vuc3VzX3B1YmtleTptc2dbbV0udmFsdWUucHVia2V5fSx2YWxpZGF0b3IpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLnB1Yl9rZXkgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOnB1YmtleVR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwidmFsdWVcIjpwdWJrZXlWYWx1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hZGRyZXNzID0gZ2V0QWRkcmVzcyh2YWxpZGF0b3IucHViX2tleSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLmFjY3B1YiA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY1B1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yLm9wZXJhdG9yX3B1YmtleSA9IE1ldGVvci5jYWxsKCdwdWJrZXlUb0JlY2gzMicsIHZhbGlkYXRvci5wdWJfa2V5LCBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbFB1Yik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVm90aW5nUG93ZXJIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV2X3ZvdGluZ19wb3dlcjogMCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYWRkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBnZW5lc2lzLmdlbmVzaXNfdGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmFsaWRhdG9ycy5pbnNlcnQodmFsaWRhdG9yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gcmVhZCB2YWxpZGF0b3JzIGZyb20gcHJldmlvdXMgY2hhaW5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdyZWFkIHZhbGlkYXRvcnMgZnJvbSBwcmV2aW91cyBjaGFpbicpO1xuICAgICAgICAgICAgaWYgKGdlbmVzaXMuYXBwX3N0YXRlLnN0YWtpbmcudmFsaWRhdG9ycyAmJiBnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnZhbGlkYXRvcnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZ2VuZXNpcy5hcHBfc3RhdGUuc3Rha2luZy52YWxpZGF0b3JzLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgbGV0IGdlblZhbGlkYXRvcnNTZXQgPSBnZW5lc2lzLmFwcF9zdGF0ZS5zdGFraW5nLnZhbGlkYXRvcnM7XG4gICAgICAgICAgICAgICAgbGV0IGdlblZhbGlkYXRvcnMgPSBnZW5lc2lzLnZhbGlkYXRvcnM7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgdiBpbiBnZW5WYWxpZGF0b3JzU2V0KXtcbiAgICAgICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coZ2VuVmFsaWRhdG9yc1t2XSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSBnZW5WYWxpZGF0b3JzU2V0W3ZdO1xuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IuZGVsZWdhdG9yX2FkZHJlc3MgPSBNZXRlb3IuY2FsbCgnZ2V0RGVsZWdhdG9yJywgZ2VuVmFsaWRhdG9yc1NldFt2XS5vcGVyYXRvcl9hZGRyZXNzKTtcblxuICAgICAgICAgICAgICAgICAgICBsZXQgcHVia2V5VHlwZSA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuc2VjcDI1NmsxPyd0ZW5kZXJtaW50L1B1YktleVNlY3AyNTZrMSc6J3RlbmRlcm1pbnQvUHViS2V5RWQyNTUxOSc7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwdWJrZXlWYWx1ZSA9IE1ldGVvci5jYWxsKCdiZWNoMzJUb1B1YmtleScsIHZhbGlkYXRvci5jb25zZW5zdXNfcHVia2V5LCBwdWJrZXlUeXBlKTtcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3IucHViX2tleSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIFwidHlwZVwiOnB1YmtleVR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICBcInZhbHVlXCI6cHVia2V5VmFsdWVcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hZGRyZXNzID0gZ2V0QWRkcmVzcyh2YWxpZGF0b3IucHViX2tleSk7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5wdWJfa2V5ID0gdmFsaWRhdG9yLnB1Yl9rZXk7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5hY2NwdWIgPSBNZXRlb3IuY2FsbCgncHVia2V5VG9CZWNoMzInLCB2YWxpZGF0b3IucHViX2tleSwgTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5iZWNoMzJQcmVmaXhBY2NQdWIpO1xuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iub3BlcmF0b3JfcHVia2V5ID0gTWV0ZW9yLmNhbGwoJ3B1YmtleVRvQmVjaDMyJywgdmFsaWRhdG9yLnB1Yl9rZXksIE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsUHViKTtcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyID0gZmluZFZvdGluZ1Bvd2VyKHZhbGlkYXRvciwgZ2VuVmFsaWRhdG9ycyk7XG4gICAgICAgICAgICAgICAgICAgIHRvdGFsVm90aW5nUG93ZXIgKz0gdmFsaWRhdG9yLnZvdGluZ19wb3dlcjtcblxuICAgICAgICAgICAgICAgICAgICBWYWxpZGF0b3JzLnVwc2VydCh7Y29uc2Vuc3VzX3B1YmtleTp2YWxpZGF0b3IuY29uc2Vuc3VzX3B1YmtleX0sdmFsaWRhdG9yKTtcbiAgICAgICAgICAgICAgICAgICAgVm90aW5nUG93ZXJIaXN0b3J5Lmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOiB2YWxpZGF0b3IuYWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByZXZfdm90aW5nX3Bvd2VyOiAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nX3Bvd2VyOiB2YWxpZGF0b3Iudm90aW5nX3Bvd2VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2FkZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDAsXG4gICAgICAgICAgICAgICAgICAgICAgICBibG9ja190aW1lOiBnZW5lc2lzLmdlbmVzaXNfdGltZVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNoYWluUGFyYW1zLnJlYWRHZW5lc2lzID0gdHJ1ZTtcbiAgICAgICAgICAgIGNoYWluUGFyYW1zLmFjdGl2ZVZvdGluZ1Bvd2VyID0gdG90YWxWb3RpbmdQb3dlcjtcbiAgICAgICAgICAgIGxldCByZXN1bHQgPSBDaGFpbi51cHNlcnQoe2NoYWluSWQ6Y2hhaW5QYXJhbXMuY2hhaW5JZH0sIHskc2V0OmNoYWluUGFyYW1zfSk7XG5cblxuICAgICAgICAgICAgY29uc29sZS5sb2coJz09PSBGaW5pc2hlZCBwcm9jZXNzaW5nIGdlbmVzaXMgZmlsZSA9PT0nKTtcblxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxufSlcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQ2hhaW4sIENoYWluU3RhdGVzIH0gZnJvbSAnLi4vY2hhaW4uanMnO1xuaW1wb3J0IHsgQ29pblN0YXRzIH0gZnJvbSAnLi4vLi4vY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5NZXRlb3IucHVibGlzaCgnY2hhaW5TdGF0ZXMubGF0ZXN0JywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBbXG4gICAgICAgIENoYWluU3RhdGVzLmZpbmQoe30se3NvcnQ6e2hlaWdodDotMX0sbGltaXQ6MX0pLFxuICAgICAgICBDb2luU3RhdHMuZmluZCh7fSx7c29ydDp7bGFzdF91cGRhdGVkX2F0Oi0xfSxsaW1pdDoxfSlcbiAgICBdO1xufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ2NoYWluLnN0YXR1cycsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIENoYWluLmZpbmQoe2NoYWluSWQ6TWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChjaGFpbil7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZHJlc3M6MSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjoxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wZXJhdG9yX2FkZHJlc3M6MSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6LTEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgamFpbGVkOjEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvZmlsZV91cmw6MVxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pOyIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5leHBvcnQgY29uc3QgQ2hhaW4gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY2hhaW4nKTtcbmV4cG9ydCBjb25zdCBDaGFpblN0YXRlcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjaGFpbl9zdGF0ZXMnKVxuXG5DaGFpbi5oZWxwZXJzKHtcbiAgICBwcm9wb3Nlcigpe1xuICAgICAgICByZXR1cm4gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMucHJvcG9zZXJBZGRyZXNzfSk7XG4gICAgfVxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IENvaW5TdGF0cyB9IGZyb20gJy4uL2NvaW4tc3RhdHMuanMnO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuICAgICdjb2luU3RhdHMuZ2V0Q29pblN0YXRzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBjb2luSWQgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNvaW5nZWNrb0lkO1xuICAgICAgICBpZiAoY29pbklkKXtcbiAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgICAgICAgICBub3cuc2V0TWludXRlcygwKTtcbiAgICAgICAgICAgICAgICBsZXQgdXJsID0gXCJodHRwczovL2FwaS5jb2luZ2Vja28uY29tL2FwaS92My9zaW1wbGUvcHJpY2U/aWRzPVwiK2NvaW5JZCtcIiZ2c19jdXJyZW5jaWVzPXVzZCZpbmNsdWRlX21hcmtldF9jYXA9dHJ1ZSZpbmNsdWRlXzI0aHJfdm9sPXRydWUmaW5jbHVkZV8yNGhyX2NoYW5nZT10cnVlJmluY2x1ZGVfbGFzdF91cGRhdGVkX2F0PXRydWVcIjtcbiAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgZGF0YSA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCk7XG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPSBkYXRhW2NvaW5JZF07XG4gICAgICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGNvaW5TdGF0cyk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBDb2luU3RhdHMudXBzZXJ0KHtsYXN0X3VwZGF0ZWRfYXQ6ZGF0YS5sYXN0X3VwZGF0ZWRfYXR9LCB7JHNldDpkYXRhfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2goZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcIk5vIGNvaW5nZWNrbyBJZCBwcm92aWRlZC5cIlxuICAgICAgICB9XG4gICAgfSxcbiAgICAnY29pblN0YXRzLmdldFN0YXRzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBjb2luSWQgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNvaW5nZWNrb0lkO1xuICAgICAgICBpZiAoY29pbklkKXtcbiAgICAgICAgICAgIHJldHVybiAoQ29pblN0YXRzLmZpbmRPbmUoe30se3NvcnQ6e2xhc3RfdXBkYXRlZF9hdDotMX19KSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcIk5vIGNvaW5nZWNrbyBJZCBwcm92aWRlZC5cIjtcbiAgICAgICAgfVxuXG4gICAgfVxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBjb25zdCBDb2luU3RhdHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29pbl9zdGF0cycpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBEZWxlZ2F0aW9ucyB9IGZyb20gJy4uL2RlbGVnYXRpb25zLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ2RlbGVnYXRpb25zLmdldERlbGVnYXRpb25zJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB2YWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHt9KS5mZXRjaCgpO1xuICAgICAgICBsZXQgZGVsZWdhdGlvbnMgPSBbXTtcbiAgICAgICAgY29uc29sZS5sb2coXCI9PT0gR2V0dGluZyBkZWxlZ2F0aW9ucyA9PT1cIik7XG4gICAgICAgIGZvciAodiBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgIGlmICh2YWxpZGF0b3JzW3ZdLm9wZXJhdG9yX2FkZHJlc3Mpe1xuICAgICAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvdmFsaWRhdG9ycy8nK3ZhbGlkYXRvcnNbdl0ub3BlcmF0b3JfYWRkcmVzcytcIi9kZWxlZ2F0aW9uc1wiO1xuICAgICAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkZWxlZ2F0aW9uID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhkZWxlZ2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zID0gZGVsZWdhdGlvbnMuY29uY2F0KGRlbGVnYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXNwb25zZS5zdGF0dXNDb2RlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICAgICAgICAgIH0gICAgXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBmb3IgKGkgaW4gZGVsZWdhdGlvbnMpe1xuICAgICAgICAgICAgaWYgKGRlbGVnYXRpb25zW2ldICYmIGRlbGVnYXRpb25zW2ldLnNoYXJlcylcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMgPSBwYXJzZUZsb2F0KGRlbGVnYXRpb25zW2ldLnNoYXJlcyk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBjb25zb2xlLmxvZyhkZWxlZ2F0aW9ucyk7XG4gICAgICAgIGxldCBkYXRhID0ge1xuICAgICAgICAgICAgZGVsZWdhdGlvbnM6IGRlbGVnYXRpb25zLFxuICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIERlbGVnYXRpb25zLmluc2VydChkYXRhKTtcbiAgICB9XG4gICAgLy8gJ2Jsb2Nrcy5hdmVyYWdlQmxvY2tUaW1lJyhhZGRyZXNzKXtcbiAgICAvLyAgICAgbGV0IGJsb2NrcyA9IEJsb2Nrc2Nvbi5maW5kKHtwcm9wb3NlckFkZHJlc3M6YWRkcmVzc30pLmZldGNoKCk7XG4gICAgLy8gICAgIGxldCBoZWlnaHRzID0gYmxvY2tzLm1hcCgoYmxvY2ssIGkpID0+IHtcbiAgICAvLyAgICAgICAgIHJldHVybiBibG9jay5oZWlnaHQ7XG4gICAgLy8gICAgIH0pO1xuICAgIC8vICAgICBsZXQgYmxvY2tzU3RhdHMgPSBBbmFseXRpY3MuZmluZCh7aGVpZ2h0OnskaW46aGVpZ2h0c319KS5mZXRjaCgpO1xuICAgIC8vICAgICAvLyBjb25zb2xlLmxvZyhibG9ja3NTdGF0cyk7XG5cbiAgICAvLyAgICAgbGV0IHRvdGFsQmxvY2tEaWZmID0gMDtcbiAgICAvLyAgICAgZm9yIChiIGluIGJsb2Nrc1N0YXRzKXtcbiAgICAvLyAgICAgICAgIHRvdGFsQmxvY2tEaWZmICs9IGJsb2Nrc1N0YXRzW2JdLnRpbWVEaWZmO1xuICAgIC8vICAgICB9XG4gICAgLy8gICAgIHJldHVybiB0b3RhbEJsb2NrRGlmZi9oZWlnaHRzLmxlbmd0aDtcbiAgICAvLyB9XG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IERlbGVnYXRpb25zID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2RlbGVnYXRpb25zJyk7XG4iLCJpbXBvcnQgeyBIVFRQIH0gZnJvbSAnbWV0ZW9yL2h0dHAnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgJ3RyYW5zYWN0aW9uLnN1Ym1pdCc6IGZ1bmN0aW9uKHR4SW5mbykge1xuICAgICAgICBjb25zdCB1cmwgPSBgJHtMQ0R9L3R4c2A7XG4gICAgICAgIGRhdGEgPSB7XG4gICAgICAgICAgICBcInR4XCI6IHR4SW5mby52YWx1ZSxcbiAgICAgICAgICAgIFwibW9kZVwiOiBcInN5bmNcIlxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHRpbWVzdGFtcCA9IG5ldyBEYXRlKCkuZ2V0VGltZSgpO1xuICAgICAgICBjb25zb2xlLmxvZyhgc3VibWl0dGluZyB0cmFuc2FjdGlvbiR7dGltZXN0YW1wfSAke3VybH0gd2l0aCBkYXRhICR7SlNPTi5zdHJpbmdpZnkoZGF0YSl9YClcblxuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLnBvc3QodXJsLCB7ZGF0YX0pO1xuICAgICAgICBjb25zb2xlLmxvZyhgcmVzcG9uc2UgZm9yIHRyYW5zYWN0aW9uJHt0aW1lc3RhbXB9ICR7dXJsfTogJHtKU09OLnN0cmluZ2lmeShyZXNwb25zZSl9YClcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKSB7XG4gICAgICAgICAgICBsZXQgZGF0YSA9IHJlc3BvbnNlLmRhdGFcbiAgICAgICAgICAgIGlmIChkYXRhLmNvZGUpXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihkYXRhLmNvZGUsIEpTT04ucGFyc2UoZGF0YS5yYXdfbG9nKS5tZXNzYWdlKVxuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGEudHhoYXNoO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAndHJhbnNhY3Rpb24uZXhlY3V0ZSc6IGZ1bmN0aW9uKGJvZHksIHBhdGgpIHtcbiAgICAgICAgY29uc3QgdXJsID0gYCR7TENEfS8ke3BhdGh9YDtcbiAgICAgICAgZGF0YSA9IHtcbiAgICAgICAgICAgIFwiYmFzZV9yZXFcIjoge1xuICAgICAgICAgICAgICAgIC4uLmJvZHksXG4gICAgICAgICAgICAgICAgXCJjaGFpbl9pZFwiOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWQsXG4gICAgICAgICAgICAgICAgXCJzaW11bGF0ZVwiOiBmYWxzZVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLnBvc3QodXJsLCB7ZGF0YX0pO1xuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpO1xuICAgICAgICB9XG4gICAgfSxcbiAgICAndHJhbnNhY3Rpb24uc2ltdWxhdGUnOiBmdW5jdGlvbih0eE1zZywgZnJvbSwgcGF0aCwgYWRqdXN0bWVudD0nMS4yJykge1xuICAgICAgICBjb25zdCB1cmwgPSBgJHtMQ0R9LyR7cGF0aH1gO1xuICAgICAgICBkYXRhID0gey4uLnR4TXNnLFxuICAgICAgICAgICAgXCJiYXNlX3JlcVwiOiB7XG4gICAgICAgICAgICAgICAgXCJmcm9tXCI6IGZyb20sXG4gICAgICAgICAgICAgICAgXCJjaGFpbl9pZFwiOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWQsXG4gICAgICAgICAgICAgICAgXCJnYXNfYWRqdXN0bWVudFwiOiBhZGp1c3RtZW50LFxuICAgICAgICAgICAgICAgIFwic2ltdWxhdGVcIjogdHJ1ZVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLnBvc3QodXJsLCB7ZGF0YX0pO1xuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApIHtcbiAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLmdhc19lc3RpbWF0ZTtcbiAgICAgICAgfVxuICAgIH0sXG59KSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCB7IFByb3Bvc2FscyB9IGZyb20gJy4uL3Byb3Bvc2Fscy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vLi4vdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbi8vIGltcG9ydCB7IFByb21pc2UgfSBmcm9tICdtZXRlb3IvcHJvbWlzZSc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAncHJvcG9zYWxzLmdldFByb3Bvc2Fscyc6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICB0cnl7XG4gICAgICAgICAgICBsZXQgdXJsID0gTENEICsgJy9nb3YvcHJvcG9zYWxzJztcbiAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICBsZXQgcHJvcG9zYWxzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhwcm9wb3NhbHMpO1xuXG4gICAgICAgICAgICBsZXQgZmluaXNoZWRQcm9wb3NhbElkcyA9IG5ldyBTZXQoUHJvcG9zYWxzLmZpbmQoXG4gICAgICAgICAgICAgICAge1wicHJvcG9zYWxfc3RhdHVzXCI6eyRpbjpbXCJQYXNzZWRcIiwgXCJSZWplY3RlZFwiLCBcIlJlbW92ZWRcIl19fVxuICAgICAgICAgICAgKS5mZXRjaCgpLm1hcCgocCk9PiBwLnByb3Bvc2FsSWQpKTtcblxuICAgICAgICAgICAgbGV0IHByb3Bvc2FsSWRzID0gW107XG4gICAgICAgICAgICBpZiAocHJvcG9zYWxzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIC8vIFByb3Bvc2Fscy51cHNlcnQoKVxuICAgICAgICAgICAgICAgIGNvbnN0IGJ1bGtQcm9wb3NhbHMgPSBQcm9wb3NhbHMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpIGluIHByb3Bvc2Fscyl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBwcm9wb3NhbCA9IHByb3Bvc2Fsc1tpXTtcbiAgICAgICAgICAgICAgICAgICAgcHJvcG9zYWwucHJvcG9zYWxJZCA9IHBhcnNlSW50KHByb3Bvc2FsLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb3Bvc2FsLnByb3Bvc2FsSWQgPiAwICYmICFmaW5pc2hlZFByb3Bvc2FsSWRzLmhhcyhwcm9wb3NhbC5wcm9wb3NhbElkKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL2dvdi9wcm9wb3NhbHMvJytwcm9wb3NhbC5wcm9wb3NhbElkKycvcHJvcG9zZXInO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByb3Bvc2VyID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwcm9wb3Nlci5wcm9wb3NhbF9pZCAmJiAocHJvcG9zZXIucHJvcG9zYWxfaWQgPT0gcHJvcG9zYWwuaWQpKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsLnByb3Bvc2VyID0gcHJvcG9zZXIucHJvcG9zZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa1Byb3Bvc2Fscy5maW5kKHtwcm9wb3NhbElkOiBwcm9wb3NhbC5wcm9wb3NhbElkfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OnByb3Bvc2FsfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zYWxJZHMucHVzaChwcm9wb3NhbC5wcm9wb3NhbElkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtQcm9wb3NhbHMuZmluZCh7cHJvcG9zYWxJZDogcHJvcG9zYWwucHJvcG9zYWxJZH0pLnVwc2VydCgpLnVwZGF0ZU9uZSh7JHNldDpwcm9wb3NhbH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsSWRzLnB1c2gocHJvcG9zYWwucHJvcG9zYWxJZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5yZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBidWxrUHJvcG9zYWxzLmZpbmQoe3Byb3Bvc2FsSWQ6eyRuaW46cHJvcG9zYWxJZHN9LCBwcm9wb3NhbF9zdGF0dXM6eyRuaW46W1wiUGFzc2VkXCIsIFwiUmVqZWN0ZWRcIiwgXCJSZW1vdmVkXCJdfX0pXG4gICAgICAgICAgICAgICAgICAgIC51cGRhdGUoeyRzZXQ6IHtcInByb3Bvc2FsX3N0YXR1c1wiOiBcIlJlbW92ZWRcIn19KTtcbiAgICAgICAgICAgICAgICBidWxrUHJvcG9zYWxzLmV4ZWN1dGUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0cnVlXG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpe1xuICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdwcm9wb3NhbHMuZ2V0UHJvcG9zYWxSZXN1bHRzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBwcm9wb3NhbHMgPSBQcm9wb3NhbHMuZmluZCh7XCJwcm9wb3NhbF9zdGF0dXNcIjp7JG5pbjpbXCJQYXNzZWRcIiwgXCJSZWplY3RlZFwiLCBcIlJlbW92ZWRcIl19fSkuZmV0Y2goKTtcblxuICAgICAgICBpZiAocHJvcG9zYWxzICYmIChwcm9wb3NhbHMubGVuZ3RoID4gMCkpe1xuICAgICAgICAgICAgZm9yIChsZXQgaSBpbiBwcm9wb3NhbHMpe1xuICAgICAgICAgICAgICAgIGlmIChwYXJzZUludChwcm9wb3NhbHNbaV0ucHJvcG9zYWxJZCkgPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZ2V0IHByb3Bvc2FsIGRlcG9zaXRzXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdXJsID0gTENEICsgJy9nb3YvcHJvcG9zYWxzLycrcHJvcG9zYWxzW2ldLnByb3Bvc2FsSWQrJy9kZXBvc2l0cyc7XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHByb3Bvc2FsID0ge3Byb3Bvc2FsSWQ6IHByb3Bvc2Fsc1tpXS5wcm9wb3NhbElkfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGRlcG9zaXRzID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvcG9zYWwuZGVwb3NpdHMgPSBkZXBvc2l0cztcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgdXJsID0gTENEICsgJy9nb3YvcHJvcG9zYWxzLycrcHJvcG9zYWxzW2ldLnByb3Bvc2FsSWQrJy92b3Rlcyc7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZSA9IEhUVFAuZ2V0KHVybCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzQ29kZSA9PSAyMDApe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2b3RlcyA9IEpTT04ucGFyc2UocmVzcG9uc2UuY29udGVudCkucmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2FsLnZvdGVzID0gZ2V0Vm90ZURldGFpbCh2b3Rlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHVybCA9IExDRCArICcvZ292L3Byb3Bvc2Fscy8nK3Byb3Bvc2Fsc1tpXS5wcm9wb3NhbElkKycvdGFsbHknO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGFsbHkgPSBKU09OLnBhcnNlKHJlc3BvbnNlLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NhbC50YWxseSA9IHRhbGx5O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NhbC51cGRhdGVkQXQgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgUHJvcG9zYWxzLnVwZGF0ZSh7cHJvcG9zYWxJZDogcHJvcG9zYWxzW2ldLnByb3Bvc2FsSWR9LCB7JHNldDpwcm9wb3NhbH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNhdGNoKGUpe1xuXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICB9XG59KVxuXG5jb25zdCBnZXRWb3RlRGV0YWlsID0gKHZvdGVzKSA9PiB7XG4gICAgaWYgKCF2b3Rlcykge1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxuXG4gICAgbGV0IHZvdGVycyA9IHZvdGVzLm1hcCgodm90ZSkgPT4gdm90ZS52b3Rlcik7XG4gICAgbGV0IHZvdGluZ1Bvd2VyTWFwID0ge307XG4gICAgbGV0IHZhbGlkYXRvckFkZHJlc3NNYXAgPSB7fTtcbiAgICBWYWxpZGF0b3JzLmZpbmQoe2RlbGVnYXRvcl9hZGRyZXNzOiB7JGluOiB2b3RlcnN9fSkuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB7XG4gICAgICAgIHZvdGluZ1Bvd2VyTWFwW3ZhbGlkYXRvci5kZWxlZ2F0b3JfYWRkcmVzc10gPSB7XG4gICAgICAgICAgICBtb25pa2VyOiB2YWxpZGF0b3IuZGVzY3JpcHRpb24ubW9uaWtlcixcbiAgICAgICAgICAgIGFkZHJlc3M6IHZhbGlkYXRvci5hZGRyZXNzLFxuICAgICAgICAgICAgdG9rZW5zOiBwYXJzZUZsb2F0KHZhbGlkYXRvci50b2tlbnMpLFxuICAgICAgICAgICAgZGVsZWdhdG9yU2hhcmVzOiBwYXJzZUZsb2F0KHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzKSxcbiAgICAgICAgICAgIGRlZHVjdGVkU2hhcmVzOiBwYXJzZUZsb2F0KHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzKVxuICAgICAgICB9XG4gICAgICAgIHZhbGlkYXRvckFkZHJlc3NNYXBbdmFsaWRhdG9yLm9wZXJhdG9yX2FkZHJlc3NdID0gdmFsaWRhdG9yLmRlbGVnYXRvcl9hZGRyZXNzO1xuICAgIH0pO1xuICAgIHZvdGVycy5mb3JFYWNoKCh2b3RlcikgPT4ge1xuICAgICAgICBpZiAoIXZvdGluZ1Bvd2VyTWFwW3ZvdGVyXSkge1xuICAgICAgICAgICAgLy8gdm90ZXIgaXMgbm90IGEgdmFsaWRhdG9yXG4gICAgICAgICAgICBsZXQgdXJsID0gYCR7TENEfS9zdGFraW5nL2RlbGVnYXRvcnMvJHt2b3Rlcn0vZGVsZWdhdGlvbnNgO1xuICAgICAgICAgICAgbGV0IGRlbGVnYXRpb25zO1xuICAgICAgICAgICAgbGV0IHZvdGluZ1Bvd2VyID0gMDtcbiAgICAgICAgICAgIHRyeXtcbiAgICAgICAgICAgICAgICBsZXQgcmVzcG9uc2UgPSBIVFRQLmdldCh1cmwpO1xuICAgICAgICAgICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgICAgIGRlbGVnYXRpb25zID0gSlNPTi5wYXJzZShyZXNwb25zZS5jb250ZW50KS5yZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucyAmJiBkZWxlZ2F0aW9ucy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucy5mb3JFYWNoKChkZWxlZ2F0aW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHNoYXJlcyA9IHBhcnNlRmxvYXQoZGVsZWdhdGlvbi5zaGFyZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3JBZGRyZXNzTWFwW2RlbGVnYXRpb24udmFsaWRhdG9yX2FkZHJlc3NdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRlZHVjdCBkZWxlZ2F0ZWQgc2hhcmVkcyBmcm9tIHZhbGlkYXRvciBpZiBhIGRlbGVnYXRvciB2b3Rlc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yID0gdm90aW5nUG93ZXJNYXBbdmFsaWRhdG9yQWRkcmVzc01hcFtkZWxlZ2F0aW9uLnZhbGlkYXRvcl9hZGRyZXNzXV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbGlkYXRvci5kZWR1Y3RlZFNoYXJlcyAtPSBzaGFyZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0b3IuZGVsZWdhdG9yX3NoYXJlcyAhPSAwKXsgLy8gYXZvaWRpbmcgZGl2aXNpb24gYnkgemVyb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nUG93ZXIgKz0gKHNoYXJlcy92YWxpZGF0b3IuZGVsZWdhdG9yU2hhcmVzKSAqIHZhbGlkYXRvci50b2tlbnM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUoe29wZXJhdG9yX2FkZHJlc3M6IGRlbGVnYXRpb24udmFsaWRhdG9yX2FkZHJlc3N9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRvciAmJiB2YWxpZGF0b3IuZGVsZWdhdG9yX3NoYXJlcyAhPSAwKXsgLy8gYXZvaWRpbmcgZGl2aXNpb24gYnkgemVyb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nUG93ZXIgKz0gKHNoYXJlcy9wYXJzZUZsb2F0KHZhbGlkYXRvci5kZWxlZ2F0b3Jfc2hhcmVzKSkgKiBwYXJzZUZsb2F0KHZhbGlkYXRvci50b2tlbnMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSl7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2b3RpbmdQb3dlck1hcFt2b3Rlcl0gPSB7dm90aW5nUG93ZXI6IHZvdGluZ1Bvd2VyfTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiB2b3Rlcy5tYXAoKHZvdGUpID0+IHtcbiAgICAgICAgbGV0IHZvdGVyID0gdm90aW5nUG93ZXJNYXBbdm90ZS52b3Rlcl07XG4gICAgICAgIGxldCB2b3RpbmdQb3dlciA9IHZvdGVyLnZvdGluZ1Bvd2VyO1xuICAgICAgICBpZiAodm90aW5nUG93ZXIgPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAvLyB2b3RlciBpcyBhIHZhbGlkYXRvclxuICAgICAgICAgICAgdm90aW5nUG93ZXIgPSB2b3Rlci5kZWxlZ2F0b3JTaGFyZXM/KCh2b3Rlci5kZWR1Y3RlZFNoYXJlcy92b3Rlci5kZWxlZ2F0b3JTaGFyZXMpICogdm90ZXIudG9rZW5zKTowO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7Li4udm90ZSwgdm90aW5nUG93ZXJ9O1xuICAgIH0pO1xufVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBQcm9wb3NhbHMgfSBmcm9tICcuLi9wcm9wb3NhbHMuanMnO1xuaW1wb3J0IHsgY2hlY2sgfSBmcm9tICdtZXRlb3IvY2hlY2snXG5cbk1ldGVvci5wdWJsaXNoKCdwcm9wb3NhbHMubGlzdCcsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gUHJvcG9zYWxzLmZpbmQoe30sIHtzb3J0Ontwcm9wb3NhbElkOi0xfX0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdwcm9wb3NhbHMub25lJywgZnVuY3Rpb24gKGlkKXtcbiAgICBjaGVjayhpZCwgTnVtYmVyKTtcbiAgICByZXR1cm4gUHJvcG9zYWxzLmZpbmQoe3Byb3Bvc2FsSWQ6aWR9KTtcbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgUHJvcG9zYWxzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3Byb3Bvc2FscycpO1xuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzLCBBbmFseXRpY3MsIEF2ZXJhZ2VEYXRhLCBBdmVyYWdlVmFsaWRhdG9yRGF0YSB9IGZyb20gJy4uL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JTZXRzIH0gZnJvbSAnL2ltcG9ydHMvYXBpL3ZhbGlkYXRvci1zZXRzL3ZhbGlkYXRvci1zZXRzLmpzJztcbmltcG9ydCB7IFN0YXR1cyB9IGZyb20gJy4uLy4uL3N0YXR1cy9zdGF0dXMuanMnO1xuaW1wb3J0IHsgTWlzc2VkQmxvY2tzU3RhdHMgfSBmcm9tICcuLi9yZWNvcmRzLmpzJztcbmltcG9ydCB7IE1pc3NlZEJsb2NrcyB9IGZyb20gJy4uL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBDaGFpbiB9IGZyb20gJy4uLy4uL2NoYWluL2NoYWluLmpzJztcbmltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XG5jb25zdCBCVUxLVVBEQVRFTUFYU0laRSA9IDEwMDA7XG5cbmNvbnN0IGdldEJsb2NrU3RhdHMgPSAoc3RhcnRIZWlnaHQsIGxhdGVzdEhlaWdodCkgPT4ge1xuICAgIGxldCBibG9ja1N0YXRzID0ge307XG4gICAgY29uc3QgY29uZCA9IHskYW5kOiBbXG4gICAgICAgIHsgaGVpZ2h0OiB7ICRndDogc3RhcnRIZWlnaHQgfSB9LFxuICAgICAgICB7IGhlaWdodDogeyAkbHRlOiBsYXRlc3RIZWlnaHQgfSB9IF19O1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7c29ydDp7aGVpZ2h0OiAxfX07XG4gICAgQmxvY2tzY29uLmZpbmQoY29uZCwgb3B0aW9ucykuZm9yRWFjaCgoYmxvY2spID0+IHtcbiAgICAgICAgYmxvY2tTdGF0c1tibG9jay5oZWlnaHRdID0ge1xuICAgICAgICAgICAgaGVpZ2h0OiBibG9jay5oZWlnaHQsXG4gICAgICAgICAgICBwcm9wb3NlckFkZHJlc3M6IGJsb2NrLnByb3Bvc2VyQWRkcmVzcyxcbiAgICAgICAgICAgIHByZWNvbW1pdHNDb3VudDogYmxvY2sucHJlY29tbWl0c0NvdW50LFxuICAgICAgICAgICAgdmFsaWRhdG9yc0NvdW50OiBibG9jay52YWxpZGF0b3JzQ291bnQsXG4gICAgICAgICAgICB2YWxpZGF0b3JzOiBibG9jay52YWxpZGF0b3JzLFxuICAgICAgICAgICAgdGltZTogYmxvY2sudGltZVxuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICBBbmFseXRpY3MuZmluZChjb25kLCBvcHRpb25zKS5mb3JFYWNoKChibG9jaykgPT4ge1xuICAgICAgICBpZiAoIWJsb2NrU3RhdHNbYmxvY2suaGVpZ2h0XSkge1xuICAgICAgICAgICAgYmxvY2tTdGF0c1tibG9jay5oZWlnaHRdID0geyBoZWlnaHQ6IGJsb2NrLmhlaWdodCB9O1xuICAgICAgICAgICAgY29uc29sZS5sb2coYGJsb2NrICR7YmxvY2suaGVpZ2h0fSBkb2VzIG5vdCBoYXZlIGFuIGVudHJ5YCk7XG4gICAgICAgIH1cbiAgICAgICAgXy5hc3NpZ24oYmxvY2tTdGF0c1tibG9jay5oZWlnaHRdLCB7XG4gICAgICAgICAgICBwcmVjb21taXRzOiBibG9jay5wcmVjb21taXRzLFxuICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZTogYmxvY2suYXZlcmFnZUJsb2NrVGltZSxcbiAgICAgICAgICAgIHRpbWVEaWZmOiBibG9jay50aW1lRGlmZixcbiAgICAgICAgICAgIHZvdGluZ19wb3dlcjogYmxvY2sudm90aW5nX3Bvd2VyXG4gICAgICAgIH0pO1xuICAgIH0pO1xuICAgIHJldHVybiBibG9ja1N0YXRzO1xufVxuXG5jb25zdCBnZXRQcmV2aW91c1JlY29yZCA9ICh2b3RlckFkZHJlc3MsIHByb3Bvc2VyQWRkcmVzcykgPT4ge1xuICAgIGxldCBwcmV2aW91c1JlY29yZCA9IE1pc3NlZEJsb2Nrcy5maW5kT25lKFxuICAgICAgICB7dm90ZXI6dm90ZXJBZGRyZXNzLCBwcm9wb3Nlcjpwcm9wb3NlckFkZHJlc3MsIGJsb2NrSGVpZ2h0OiAtMX0pO1xuICAgIGxldCBsYXN0VXBkYXRlZEhlaWdodCA9IE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQ7XG4gICAgbGV0IHByZXZTdGF0cyA9IHt9O1xuICAgIGlmIChwcmV2aW91c1JlY29yZCkge1xuICAgICAgICBwcmV2U3RhdHMgPSBfLnBpY2socHJldmlvdXNSZWNvcmQsIFsnbWlzc0NvdW50JywgJ3RvdGFsQ291bnQnXSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcHJldlN0YXRzID0ge1xuICAgICAgICAgICAgbWlzc0NvdW50OiAwLFxuICAgICAgICAgICAgdG90YWxDb3VudDogMFxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBwcmV2U3RhdHM7XG59XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3MnOiBmdW5jdGlvbigpe1xuICAgICAgICBpZiAoIUNPVU5UTUlTU0VEQkxPQ0tTKXtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgbGV0IHN0YXJ0VGltZSA9IERhdGUubm93KCk7XG4gICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1MgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdjYWx1bGF0ZSBtaXNzZWQgYmxvY2tzIGNvdW50Jyk7XG4gICAgICAgICAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgICAgICAgICAgbGV0IGxhdGVzdEhlaWdodCA9IE1ldGVvci5jYWxsKCdibG9ja3MuZ2V0Q3VycmVudEhlaWdodCcpO1xuICAgICAgICAgICAgICAgIGxldCBleHBsb3JlclN0YXR1cyA9IFN0YXR1cy5maW5kT25lKHtjaGFpbklkOiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9KTtcbiAgICAgICAgICAgICAgICBsZXQgc3RhcnRIZWlnaHQgPSAoZXhwbG9yZXJTdGF0dXMmJmV4cGxvcmVyU3RhdHVzLmxhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja0hlaWdodCk/ZXhwbG9yZXJTdGF0dXMubGFzdFByb2Nlc3NlZE1pc3NlZEJsb2NrSGVpZ2h0Ok1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQ7XG4gICAgICAgICAgICAgICAgbGF0ZXN0SGVpZ2h0ID0gTWF0aC5taW4oc3RhcnRIZWlnaHQgKyBCVUxLVVBEQVRFTUFYU0laRSwgbGF0ZXN0SGVpZ2h0KTtcbiAgICAgICAgICAgICAgICBjb25zdCBidWxrTWlzc2VkU3RhdHMgPSBNaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVPcmRlcmVkQnVsa09wKCk7XG5cbiAgICAgICAgICAgICAgICBsZXQgdmFsaWRhdG9yc01hcCA9IHt9O1xuICAgICAgICAgICAgICAgIHZhbGlkYXRvcnMuZm9yRWFjaCgodmFsaWRhdG9yKSA9PiB2YWxpZGF0b3JzTWFwW3ZhbGlkYXRvci5hZGRyZXNzXSA9IHZhbGlkYXRvcik7XG5cbiAgICAgICAgICAgICAgICAvLyBhIG1hcCBvZiBibG9jayBoZWlnaHQgdG8gYmxvY2sgc3RhdHNcbiAgICAgICAgICAgICAgICBsZXQgYmxvY2tTdGF0cyA9IGdldEJsb2NrU3RhdHMoc3RhcnRIZWlnaHQsIGxhdGVzdEhlaWdodCk7XG5cbiAgICAgICAgICAgICAgICAvLyBwcm9wb3NlclZvdGVyU3RhdHMgaXMgYSBwcm9wb3Nlci12b3RlciBtYXAgY291bnRpbmcgbnVtYmVycyBvZiBwcm9wb3NlZCBibG9ja3Mgb2Ygd2hpY2ggdm90ZXIgaXMgYW4gYWN0aXZlIHZhbGlkYXRvclxuICAgICAgICAgICAgICAgIGxldCBwcm9wb3NlclZvdGVyU3RhdHMgPSB7fVxuXG4gICAgICAgICAgICAgICAgXy5mb3JFYWNoKGJsb2NrU3RhdHMsIChibG9jaywgYmxvY2tIZWlnaHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgbGV0IHByb3Bvc2VyQWRkcmVzcyA9IGJsb2NrLnByb3Bvc2VyQWRkcmVzcztcbiAgICAgICAgICAgICAgICAgICAgbGV0IHZvdGVkVmFsaWRhdG9ycyA9IG5ldyBTZXQoYmxvY2sudmFsaWRhdG9ycyk7XG4gICAgICAgICAgICAgICAgICAgIGxldCB2YWxpZGF0b3JTZXRzID0gVmFsaWRhdG9yU2V0cy5maW5kT25lKHtibG9ja19oZWlnaHQ6YmxvY2suaGVpZ2h0fSk7XG4gICAgICAgICAgICAgICAgICAgIGxldCB2b3RlZFZvdGluZ1Bvd2VyID0gMDtcblxuICAgICAgICAgICAgICAgICAgICB2YWxpZGF0b3JTZXRzLnZhbGlkYXRvcnMuZm9yRWFjaCgoYWN0aXZlVmFsaWRhdG9yKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodm90ZWRWYWxpZGF0b3JzLmhhcyhhY3RpdmVWYWxpZGF0b3IuYWRkcmVzcykpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90ZWRWb3RpbmdQb3dlciArPSBwYXJzZUZsb2F0KGFjdGl2ZVZhbGlkYXRvci52b3RpbmdfcG93ZXIpXG4gICAgICAgICAgICAgICAgICAgIH0pXG5cbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yU2V0cy52YWxpZGF0b3JzLmZvckVhY2goKGFjdGl2ZVZhbGlkYXRvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGN1cnJlbnRWYWxpZGF0b3IgPSBhY3RpdmVWYWxpZGF0b3IuYWRkcmVzc1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmhhcyhwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3JdKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBwcmV2U3RhdHMgPSBnZXRQcmV2aW91c1JlY29yZChjdXJyZW50VmFsaWRhdG9yLCBwcm9wb3NlckFkZHJlc3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF8uc2V0KHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvcl0sIHByZXZTdGF0cyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIF8udXBkYXRlKHByb3Bvc2VyVm90ZXJTdGF0cywgW3Byb3Bvc2VyQWRkcmVzcywgY3VycmVudFZhbGlkYXRvciwgJ3RvdGFsQ291bnQnXSwgKG4pID0+IG4rMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXZvdGVkVmFsaWRhdG9ycy5oYXMoY3VycmVudFZhbGlkYXRvcikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfLnVwZGF0ZShwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3IsICdtaXNzQ291bnQnXSwgKG4pID0+IG4rMSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnVsa01pc3NlZFN0YXRzLmluc2VydCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvdGVyOiBjdXJyZW50VmFsaWRhdG9yLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodDogYmxvY2suaGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9wb3NlcjogcHJvcG9zZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmVjb21taXRzQ291bnQ6IGJsb2NrLnByZWNvbW1pdHNDb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsaWRhdG9yc0NvdW50OiBibG9jay52YWxpZGF0b3JzQ291bnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWU6IGJsb2NrLnRpbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByZWNvbW1pdHM6IGJsb2NrLnByZWNvbW1pdHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGJsb2NrLmF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWVEaWZmOiBibG9jay50aW1lRGlmZixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90aW5nUG93ZXI6IGJsb2NrLnZvdGluZ19wb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdm90ZWRWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZEF0OiBsYXRlc3RIZWlnaHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pc3NDb3VudDogXy5nZXQocHJvcG9zZXJWb3RlclN0YXRzLCBbcHJvcG9zZXJBZGRyZXNzLCBjdXJyZW50VmFsaWRhdG9yLCAnbWlzc0NvdW50J10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbENvdW50OiBfLmdldChwcm9wb3NlclZvdGVyU3RhdHMsIFtwcm9wb3NlckFkZHJlc3MsIGN1cnJlbnRWYWxpZGF0b3IsICd0b3RhbENvdW50J10pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICBfLmZvckVhY2gocHJvcG9zZXJWb3RlclN0YXRzLCAodm90ZXJzLCBwcm9wb3NlckFkZHJlc3MpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgXy5mb3JFYWNoKHZvdGVycywgKHN0YXRzLCB2b3RlckFkZHJlc3MpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJ1bGtNaXNzZWRTdGF0cy5maW5kKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3Rlcjogdm90ZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOiBwcm9wb3NlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tIZWlnaHQ6IC0xXG4gICAgICAgICAgICAgICAgICAgICAgICB9KS51cHNlcnQoKS51cGRhdGVPbmUoeyRzZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b3Rlcjogdm90ZXJBZGRyZXNzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOiBwcm9wb3NlckFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tIZWlnaHQ6IC0xLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWRBdDogbGF0ZXN0SGVpZ2h0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pc3NDb3VudDogXy5nZXQoc3RhdHMsICdtaXNzQ291bnQnKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbENvdW50OiBfLmdldChzdGF0cywgJ3RvdGFsQ291bnQnKVxuICAgICAgICAgICAgICAgICAgICAgICAgfX0pO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIGxldCBtZXNzYWdlID0gJyc7XG4gICAgICAgICAgICAgICAgaWYgKGJ1bGtNaXNzZWRTdGF0cy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2xpZW50ID0gTWlzc2VkQmxvY2tzLl9kcml2ZXIubW9uZ28uY2xpZW50O1xuICAgICAgICAgICAgICAgICAgICAvLyBUT0RPOiBhZGQgdHJhbnNhY3Rpb24gYmFjayBhZnRlciByZXBsaWNhIHNldCgjMTQ2KSBpcyBzZXQgdXBcbiAgICAgICAgICAgICAgICAgICAgLy8gbGV0IHNlc3Npb24gPSBjbGllbnQuc3RhcnRTZXNzaW9uKCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIHNlc3Npb24uc3RhcnRUcmFuc2FjdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICBsZXQgYnVsa1Byb21pc2UgPSBidWxrTWlzc2VkU3RhdHMuZXhlY3V0ZShudWxsLyosIHtzZXNzaW9ufSovKS50aGVuKFxuICAgICAgICAgICAgICAgICAgICAgICAgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgocmVzdWx0LCBlcnIpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXJyKXtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ09VTlRNSVNTRURCTE9DS1MgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUHJvbWlzZS5hd2FpdChzZXNzaW9uLmFib3J0VHJhbnNhY3Rpb24oKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc3VsdCl7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFByb21pc2UuYXdhaXQoc2Vzc2lvbi5jb21taXRUcmFuc2FjdGlvbigpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZSA9IGAoJHtyZXN1bHQucmVzdWx0Lm5JbnNlcnRlZH0gaW5zZXJ0ZWQsIGAgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAke3Jlc3VsdC5yZXN1bHQublVwc2VydGVkfSB1cHNlcnRlZCwgYCArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYCR7cmVzdWx0LnJlc3VsdC5uTW9kaWZpZWR9IG1vZGlmaWVkKWA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgICAgICAgICAgIFByb21pc2UuYXdhaXQoYnVsa1Byb21pc2UpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgU3RhdHVzLnVwc2VydCh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSwgeyRzZXQ6e2xhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja0hlaWdodDpsYXRlc3RIZWlnaHQsIGxhc3RQcm9jZXNzZWRNaXNzZWRCbG9ja1RpbWU6IG5ldyBEYXRlKCl9fSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGBkb25lIGluICR7RGF0ZS5ub3coKSAtIHN0YXJ0VGltZX1tcyAke21lc3NhZ2V9YDtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLUyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcInVwZGF0aW5nLi4uXCI7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdWYWxpZGF0b3JSZWNvcmRzLmNhbGN1bGF0ZU1pc3NlZEJsb2Nrc1N0YXRzJzogZnVuY3Rpb24oKXtcbiAgICAgICAgLy8gVE9ETzogZGVwcmVjYXRlIHRoaXMgbWV0aG9kIGFuZCBNaXNzZWRCbG9ja3NTdGF0cyBjb2xsZWN0aW9uXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3M6IFwiK0NPVU5UTUlTU0VEQkxPQ0tTKTtcbiAgICAgICAgaWYgKCFDT1VOVE1JU1NFREJMT0NLU1NUQVRTKXtcbiAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSB0cnVlO1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ2NhbHVsYXRlIG1pc3NlZCBibG9ja3Mgc3RhdHMnKTtcbiAgICAgICAgICAgIHRoaXMudW5ibG9jaygpO1xuICAgICAgICAgICAgbGV0IHZhbGlkYXRvcnMgPSBWYWxpZGF0b3JzLmZpbmQoe30pLmZldGNoKCk7XG4gICAgICAgICAgICBsZXQgbGF0ZXN0SGVpZ2h0ID0gTWV0ZW9yLmNhbGwoJ2Jsb2Nrcy5nZXRDdXJyZW50SGVpZ2h0Jyk7XG4gICAgICAgICAgICBsZXQgZXhwbG9yZXJTdGF0dXMgPSBTdGF0dXMuZmluZE9uZSh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSk7XG4gICAgICAgICAgICBsZXQgc3RhcnRIZWlnaHQgPSAoZXhwbG9yZXJTdGF0dXMmJmV4cGxvcmVyU3RhdHVzLmxhc3RNaXNzZWRCbG9ja0hlaWdodCk/ZXhwbG9yZXJTdGF0dXMubGFzdE1pc3NlZEJsb2NrSGVpZ2h0Ok1ldGVvci5zZXR0aW5ncy5wYXJhbXMuc3RhcnRIZWlnaHQ7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhsYXRlc3RIZWlnaHQpO1xuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coc3RhcnRIZWlnaHQpO1xuICAgICAgICAgICAgY29uc3QgYnVsa01pc3NlZFN0YXRzID0gTWlzc2VkQmxvY2tzU3RhdHMucmF3Q29sbGVjdGlvbigpLmluaXRpYWxpemVVbm9yZGVyZWRCdWxrT3AoKTtcbiAgICAgICAgICAgIGZvciAoaSBpbiB2YWxpZGF0b3JzKXtcbiAgICAgICAgICAgICAgICAvLyBpZiAoKHZhbGlkYXRvcnNbaV0uYWRkcmVzcyA9PSBcIkI4NTUyRUFDMEQxMjNBNkJGNjA5MTIzMDQ3QTUxODFENDVFRTkwQjVcIikgfHwgKHZhbGlkYXRvcnNbaV0uYWRkcmVzcyA9PSBcIjY5RDk5QjJDNjYwNDNBQ0JFQUE4NDQ3NTI1QzM1NkFGQzY0MDhFMENcIikgfHwgKHZhbGlkYXRvcnNbaV0uYWRkcmVzcyA9PSBcIjM1QUQ3QTJDRDJGQzcxNzExQTY3NTgzMEVDMTE1ODA4MjI3M0Q0NTdcIikpe1xuICAgICAgICAgICAgICAgIGxldCB2b3RlckFkZHJlc3MgPSB2YWxpZGF0b3JzW2ldLmFkZHJlc3M7XG4gICAgICAgICAgICAgICAgbGV0IG1pc3NlZFJlY29yZHMgPSBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoe1xuICAgICAgICAgICAgICAgICAgICBhZGRyZXNzOnZvdGVyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgZXhpc3RzOmZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAkYW5kOiBbIHsgaGVpZ2h0OiB7ICRndDogc3RhcnRIZWlnaHQgfSB9LCB7IGhlaWdodDogeyAkbHRlOiBsYXRlc3RIZWlnaHQgfSB9IF1cbiAgICAgICAgICAgICAgICB9KS5mZXRjaCgpO1xuXG4gICAgICAgICAgICAgICAgbGV0IGNvdW50cyA9IHt9O1xuXG4gICAgICAgICAgICAgICAgLy8gY29uc29sZS5sb2coXCJtaXNzZWRSZWNvcmRzIHRvIHByb2Nlc3M6IFwiK21pc3NlZFJlY29yZHMubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICBmb3IgKGIgaW4gbWlzc2VkUmVjb3Jkcyl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBibG9jayA9IEJsb2Nrc2Nvbi5maW5kT25lKHtoZWlnaHQ6bWlzc2VkUmVjb3Jkc1tiXS5oZWlnaHR9KTtcbiAgICAgICAgICAgICAgICAgICAgbGV0IGV4aXN0aW5nUmVjb3JkID0gTWlzc2VkQmxvY2tzU3RhdHMuZmluZE9uZSh7dm90ZXI6dm90ZXJBZGRyZXNzLCBwcm9wb3NlcjpibG9jay5wcm9wb3NlckFkZHJlc3N9KTtcblxuICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvdW50c1tibG9jay5wcm9wb3NlckFkZHJlc3NdID09PSAndW5kZWZpbmVkJyl7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdSZWNvcmQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvdW50c1tibG9jay5wcm9wb3NlckFkZHJlc3NdID0gZXhpc3RpbmdSZWNvcmQuY291bnQrMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY291bnRzW2Jsb2NrLnByb3Bvc2VyQWRkcmVzc10gPSAxO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2V7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudHNbYmxvY2sucHJvcG9zZXJBZGRyZXNzXSsrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgZm9yIChhZGRyZXNzIGluIGNvdW50cyl7XG4gICAgICAgICAgICAgICAgICAgIGxldCBkYXRhID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgdm90ZXI6IHZvdGVyQWRkcmVzcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3Bvc2VyOmFkZHJlc3MsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb3VudDogY291bnRzW2FkZHJlc3NdXG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBidWxrTWlzc2VkU3RhdHMuZmluZCh7dm90ZXI6dm90ZXJBZGRyZXNzLCBwcm9wb3NlcjphZGRyZXNzfSkudXBzZXJ0KCkudXBkYXRlT25lKHskc2V0OmRhdGF9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gfVxuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChidWxrTWlzc2VkU3RhdHMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgYnVsa01pc3NlZFN0YXRzLmV4ZWN1dGUoTWV0ZW9yLmJpbmRFbnZpcm9ubWVudCgoZXJyLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycil7XG4gICAgICAgICAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlcnIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpe1xuICAgICAgICAgICAgICAgICAgICAgICAgU3RhdHVzLnVwc2VydCh7Y2hhaW5JZDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkfSwgeyRzZXQ6e2xhc3RNaXNzZWRCbG9ja0hlaWdodDpsYXRlc3RIZWlnaHQsIGxhc3RNaXNzZWRCbG9ja1RpbWU6IG5ldyBEYXRlKCl9fSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBDT1VOVE1JU1NFREJMT0NLU1NUQVRTID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImRvbmVcIik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNle1xuICAgICAgICAgICAgICAgIENPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZXtcbiAgICAgICAgICAgIHJldHVybiBcInVwZGF0aW5nLi4uXCI7XG4gICAgICAgIH1cbiAgICB9LFxuICAgICdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInOiBmdW5jdGlvbih0aW1lKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCBub3cgPSBuZXcgRGF0ZSgpO1xuXG4gICAgICAgIGlmICh0aW1lID09ICdtJyl7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZUJsb2NrVGltZSA9IDA7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZVZvdGluZ1Bvd2VyID0gMDtcblxuICAgICAgICAgICAgbGV0IGFuYWx5dGljcyA9IEFuYWx5dGljcy5maW5kKHsgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNjAgKiAxMDAwKSB9IH0pLmZldGNoKCk7XG4gICAgICAgICAgICBpZiAoYW5hbHl0aWNzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1tpXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyICs9IGFuYWx5dGljc1tpXS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgPSBhdmVyYWdlQmxvY2tUaW1lIC8gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgPSBhdmVyYWdlVm90aW5nUG93ZXIgLyBhbmFseXRpY3MubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0seyRzZXQ6e2xhc3RNaW51dGVWb3RpbmdQb3dlcjphdmVyYWdlVm90aW5nUG93ZXIsIGxhc3RNaW51dGVCbG9ja1RpbWU6YXZlcmFnZUJsb2NrVGltZX19KTtcbiAgICAgICAgICAgICAgICBBdmVyYWdlRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBhdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXI6IGF2ZXJhZ2VWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogdGltZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICh0aW1lID09ICdoJyl7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZUJsb2NrVGltZSA9IDA7XG4gICAgICAgICAgICBsZXQgYXZlcmFnZVZvdGluZ1Bvd2VyID0gMDtcbiAgICAgICAgICAgIGxldCBhbmFseXRpY3MgPSBBbmFseXRpY3MuZmluZCh7IFwidGltZVwiOiB7ICRndDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDYwKjYwICogMTAwMCkgfSB9KS5mZXRjaCgpO1xuICAgICAgICAgICAgaWYgKGFuYWx5dGljcy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICBmb3IgKGkgaW4gYW5hbHl0aWNzKXtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSArPSBhbmFseXRpY3NbaV0udGltZURpZmY7XG4gICAgICAgICAgICAgICAgICAgIGF2ZXJhZ2VWb3RpbmdQb3dlciArPSBhbmFseXRpY3NbaV0udm90aW5nX3Bvd2VyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lID0gYXZlcmFnZUJsb2NrVGltZSAvIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyID0gYXZlcmFnZVZvdGluZ1Bvd2VyIC8gYW5hbHl0aWNzLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgIENoYWluLnVwZGF0ZSh7Y2hhaW5JZDpNZXRlb3Iuc2V0dGluZ3MucHVibGljLmNoYWluSWR9LHskc2V0OntsYXN0SG91clZvdGluZ1Bvd2VyOmF2ZXJhZ2VWb3RpbmdQb3dlciwgbGFzdEhvdXJCbG9ja1RpbWU6YXZlcmFnZUJsb2NrVGltZX19KTtcbiAgICAgICAgICAgICAgICBBdmVyYWdlRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBhdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXI6IGF2ZXJhZ2VWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogdGltZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHRpbWUgPT0gJ2QnKXtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlQmxvY2tUaW1lID0gMDtcbiAgICAgICAgICAgIGxldCBhdmVyYWdlVm90aW5nUG93ZXIgPSAwO1xuICAgICAgICAgICAgbGV0IGFuYWx5dGljcyA9IEFuYWx5dGljcy5maW5kKHsgXCJ0aW1lXCI6IHsgJGd0OiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gMjQqNjAqNjAgKiAxMDAwKSB9IH0pLmZldGNoKCk7XG4gICAgICAgICAgICBpZiAoYW5hbHl0aWNzLmxlbmd0aCA+IDApe1xuICAgICAgICAgICAgICAgIGZvciAoaSBpbiBhbmFseXRpY3Mpe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lICs9IGFuYWx5dGljc1tpXS50aW1lRGlmZjtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZVZvdGluZ1Bvd2VyICs9IGFuYWx5dGljc1tpXS52b3RpbmdfcG93ZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWUgPSBhdmVyYWdlQmxvY2tUaW1lIC8gYW5hbHl0aWNzLmxlbmd0aDtcbiAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXIgPSBhdmVyYWdlVm90aW5nUG93ZXIgLyBhbmFseXRpY3MubGVuZ3RoO1xuXG4gICAgICAgICAgICAgICAgQ2hhaW4udXBkYXRlKHtjaGFpbklkOk1ldGVvci5zZXR0aW5ncy5wdWJsaWMuY2hhaW5JZH0seyRzZXQ6e2xhc3REYXlWb3RpbmdQb3dlcjphdmVyYWdlVm90aW5nUG93ZXIsIGxhc3REYXlCbG9ja1RpbWU6YXZlcmFnZUJsb2NrVGltZX19KTtcbiAgICAgICAgICAgICAgICBBdmVyYWdlRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlQmxvY2tUaW1lOiBhdmVyYWdlQmxvY2tUaW1lLFxuICAgICAgICAgICAgICAgICAgICBhdmVyYWdlVm90aW5nUG93ZXI6IGF2ZXJhZ2VWb3RpbmdQb3dlcixcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogdGltZSxcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gcmV0dXJuIGFuYWx5dGljcy5sZW5ndGg7XG4gICAgfSxcbiAgICAnQW5hbHl0aWNzLmFnZ3JlZ2F0ZVZhbGlkYXRvckRhaWx5QmxvY2tUaW1lJzogZnVuY3Rpb24oKXtcbiAgICAgICAgdGhpcy51bmJsb2NrKCk7XG4gICAgICAgIGxldCB2YWxpZGF0b3JzID0gVmFsaWRhdG9ycy5maW5kKHt9KS5mZXRjaCgpO1xuICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUoKTtcbiAgICAgICAgZm9yIChpIGluIHZhbGlkYXRvcnMpe1xuICAgICAgICAgICAgbGV0IGF2ZXJhZ2VCbG9ja1RpbWUgPSAwO1xuXG4gICAgICAgICAgICBsZXQgYmxvY2tzID0gQmxvY2tzY29uLmZpbmQoe3Byb3Bvc2VyQWRkcmVzczp2YWxpZGF0b3JzW2ldLmFkZHJlc3MsIFwidGltZVwiOiB7ICRndDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDI0KjYwKjYwICogMTAwMCkgfX0sIHtmaWVsZHM6e2hlaWdodDoxfX0pLmZldGNoKCk7XG5cbiAgICAgICAgICAgIGlmIChibG9ja3MubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgbGV0IGJsb2NrSGVpZ2h0cyA9IFtdO1xuICAgICAgICAgICAgICAgIGZvciAoYiBpbiBibG9ja3Mpe1xuICAgICAgICAgICAgICAgICAgICBibG9ja0hlaWdodHMucHVzaChibG9ja3NbYl0uaGVpZ2h0KTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBsZXQgYW5hbHl0aWNzID0gQW5hbHl0aWNzLmZpbmQoe2hlaWdodDogeyRpbjpibG9ja0hlaWdodHN9fSwge2ZpZWxkczp7aGVpZ2h0OjEsdGltZURpZmY6MX19KS5mZXRjaCgpO1xuXG5cbiAgICAgICAgICAgICAgICBmb3IgKGEgaW4gYW5hbHl0aWNzKXtcbiAgICAgICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSArPSBhbmFseXRpY3NbYV0udGltZURpZmY7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgYXZlcmFnZUJsb2NrVGltZSA9IGF2ZXJhZ2VCbG9ja1RpbWUgLyBhbmFseXRpY3MubGVuZ3RoO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBBdmVyYWdlVmFsaWRhdG9yRGF0YS5pbnNlcnQoe1xuICAgICAgICAgICAgICAgIHByb3Bvc2VyQWRkcmVzczogdmFsaWRhdG9yc1tpXS5hZGRyZXNzLFxuICAgICAgICAgICAgICAgIGF2ZXJhZ2VCbG9ja1RpbWU6IGF2ZXJhZ2VCbG9ja1RpbWUsXG4gICAgICAgICAgICAgICAgdHlwZTogJ1ZhbGlkYXRvckRhaWx5QXZlcmFnZUJsb2NrVGltZScsXG4gICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBub3dcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG59KVxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzLCBBbmFseXRpY3MsIE1pc3NlZEJsb2NrcywgTWlzc2VkQmxvY2tzU3RhdHMsIFZQRGlzdHJpYnV0aW9ucyB9IGZyb20gJy4uL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uLy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycy5qcyc7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JfcmVjb3Jkcy5hbGwnLCBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIFZhbGlkYXRvclJlY29yZHMuZmluZCgpO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCd2YWxpZGF0b3JfcmVjb3Jkcy51cHRpbWUnLCBmdW5jdGlvbihhZGRyZXNzLCBudW0pe1xuICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoe2FkZHJlc3M6YWRkcmVzc30se2xpbWl0Om51bSwgc29ydDp7aGVpZ2h0Oi0xfX0pO1xufSk7XG5cbk1ldGVvci5wdWJsaXNoKCdhbmFseXRpY3MuaGlzdG9yeScsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIEFuYWx5dGljcy5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LGxpbWl0OjUwfSk7XG59KTtcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZwRGlzdHJpYnV0aW9uLmxhdGVzdCcsIGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIFZQRGlzdHJpYnV0aW9ucy5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDoxfSk7XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnbWlzc2VkYmxvY2tzLnZhbGlkYXRvcicsIGZ1bmN0aW9uKGFkZHJlc3MsIHR5cGUpe1xuICAgIGxldCBjb25kaXRpb25zID0ge307XG4gICAgaWYgKHR5cGUgPT0gJ3ZvdGVyJyl7XG4gICAgICAgIGNvbmRpdGlvbnMgPSB7XG4gICAgICAgICAgICB2b3RlcjogYWRkcmVzc1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2V7XG4gICAgICAgIGNvbmRpdGlvbnMgPSB7XG4gICAgICAgICAgICBwcm9wb3NlcjogYWRkcmVzc1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGZpbmQoKXtcbiAgICAgICAgICAgIHJldHVybiBNaXNzZWRCbG9ja3NTdGF0cy5maW5kKGNvbmRpdGlvbnMpXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZChzdGF0cyl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e2FkZHJlc3M6MSwgZGVzY3JpcHRpb246MSwgcHJvZmlsZV91cmw6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcblxucHVibGlzaENvbXBvc2l0ZSgnbWlzc2VkcmVjb3Jkcy52YWxpZGF0b3InLCBmdW5jdGlvbihhZGRyZXNzLCB0eXBlKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gTWlzc2VkQmxvY2tzLmZpbmQoXG4gICAgICAgICAgICAgICAge1t0eXBlXTogYWRkcmVzc30sXG4gICAgICAgICAgICAgICAge3NvcnQ6IHt1cGRhdGVkQXQ6IC0xfX1cbiAgICAgICAgICAgIClcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e2FkZHJlc3M6MSwgZGVzY3JpcHRpb246MSwgb3BlcmF0b3JfYWRkcmVzczoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gJy4uL3ZhbGlkYXRvcnMvdmFsaWRhdG9ycyc7XG5cbmV4cG9ydCBjb25zdCBWYWxpZGF0b3JSZWNvcmRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3ZhbGlkYXRvcl9yZWNvcmRzJyk7XG5leHBvcnQgY29uc3QgQW5hbHl0aWNzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2FuYWx5dGljcycpO1xuZXhwb3J0IGNvbnN0IE1pc3NlZEJsb2Nrc1N0YXRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ21pc3NlZF9ibG9ja3Nfc3RhdHMnKTtcbmV4cG9ydCBjb25zdCBNaXNzZWRCbG9ja3MgPSBuZXcgIE1vbmdvLkNvbGxlY3Rpb24oJ21pc3NlZF9ibG9ja3MnKTtcbmV4cG9ydCBjb25zdCBWUERpc3RyaWJ1dGlvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndm90aW5nX3Bvd2VyX2Rpc3RyaWJ1dGlvbnMnKTtcbmV4cG9ydCBjb25zdCBBdmVyYWdlRGF0YSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdhdmVyYWdlX2RhdGEnKTtcbmV4cG9ydCBjb25zdCBBdmVyYWdlVmFsaWRhdG9yRGF0YSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdhdmVyYWdlX3ZhbGlkYXRvcl9kYXRhJyk7XG5cbk1pc3NlZEJsb2Nrc1N0YXRzLmhlbHBlcnMoe1xuICAgIHByb3Bvc2VyTW9uaWtlcigpe1xuICAgICAgICBsZXQgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lKHthZGRyZXNzOnRoaXMucHJvcG9zZXJ9KTtcbiAgICAgICAgcmV0dXJuICh2YWxpZGF0b3IuZGVzY3JpcHRpb24pP3ZhbGlkYXRvci5kZXNjcmlwdGlvbi5tb25pa2VyOnRoaXMucHJvcG9zZXI7XG4gICAgfSxcbiAgICB2b3Rlck1vbmlrZXIoKXtcbiAgICAgICAgbGV0IHZhbGlkYXRvciA9IFZhbGlkYXRvcnMuZmluZE9uZSh7YWRkcmVzczp0aGlzLnZvdGVyfSk7XG4gICAgICAgIHJldHVybiAodmFsaWRhdG9yLmRlc2NyaXB0aW9uKT92YWxpZGF0b3IuZGVzY3JpcHRpb24ubW9uaWtlcjp0aGlzLnZvdGVyO1xuICAgIH1cbn0pXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJ1xuaW1wb3J0IHsgU3RhdHVzIH0gZnJvbSAnLi4vc3RhdHVzLmpzJztcblxuTWV0ZW9yLnB1Ymxpc2ggKCdzdGF0dXMuc3RhdHVzJywgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBTdGF0dXMuZmluZCAoeyBjaGFpbklkIDogTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jaGFpbklkIH0pO1xufSk7XG5cbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IFN0YXR1cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdzdGF0dXMnKTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEhUVFAgfSBmcm9tICdtZXRlb3IvaHR0cCc7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi92YWxpZGF0b3JzL3ZhbGlkYXRvcnMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5jb25zdCBBZGRyZXNzTGVuZ3RoID0gNDA7XG5cbk1ldGVvci5tZXRob2RzICh7XG4gICAgJ1RyYW5zYWN0aW9ucy5pbmRleCcgOiBmdW5jdGlvbiAoaGFzaCwgYmxvY2tUaW1lKSB7XG4gICAgICAgIHRoaXMudW5ibG9jayAoKTtcbiAgICAgICAgaGFzaCA9IGhhc2gudG9VcHBlckNhc2UgKCk7XG4gICAgICAgIGNvbnNvbGUubG9nIChcIkdldCB0eDogXCIgKyBoYXNoKVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgbGV0IHVybCA9IExDRCArICcvdHhzLycgKyBoYXNoO1xuICAgICAgICAgICAgbGV0IHJlc3BvbnNlID0gSFRUUC5nZXQgKHVybCk7XG4gICAgICAgICAgICBsZXQgdHggPSBKU09OLnBhcnNlIChyZXNwb25zZS5jb250ZW50KTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChoYXNoKTtcbiAgICAgICAgICAgIHR4LmhlaWdodCA9IHBhcnNlSW50ICh0eC5oZWlnaHQpO1xuICAgICAgICAgICAgbGV0IHR4SWQgPSBUcmFuc2FjdGlvbnMuaW5zZXJ0ICh0eCk7XG4gICAgICAgICAgICBpZiAodHhJZCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0eElkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSByZXR1cm4gZmFsc2U7XG5cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2cgKGUpXG4gICAgICAgIH1cbiAgICB9LFxuICAgICdUcmFuc2FjdGlvbnMuZmluZERlbGVnYXRpb24nIDogZnVuY3Rpb24gKGFkZHJlc3MsIGhlaWdodCkge1xuICAgICAgICAvLyBmb2xsb3dpbmcgY29zbW9zLXNkay94L3NsYXNoaW5nL3NwZWMvMDZfZXZlbnRzLm1kIGFuZCBjb3Ntb3Mtc2RrL3gvc3Rha2luZy9zcGVjLzA2X2V2ZW50cy5tZFxuICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQgKHtcbiAgICAgICAgICAgICAgICAkb3IgOiBbe1xuICAgICAgICAgICAgICAgICAgICAkYW5kIDogW1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBcImV2ZW50cy50eXBlXCIgOiBcImRlbGVnYXRlXCIgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgXCJldmVudHMuYXR0cmlidXRlcy5rZXlcIiA6IFwidmFsaWRhdG9yXCIgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgXCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiIDogYWRkcmVzcyB9XG4gICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICAgICRhbmQgOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICB7IFwiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCIgOiBcImFjdGlvblwiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IFwiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIiA6IFwidW5qYWlsXCIgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgXCJldmVudHMuYXR0cmlidXRlcy5rZXlcIiA6IFwic2VuZGVyXCIgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgXCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiIDogYWRkcmVzcyB9XG4gICAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICAgICRhbmQgOiBbXG4gICAgICAgICAgICAgICAgICAgICAgICB7IFwiZXZlbnRzLnR5cGVcIiA6IFwiY3JlYXRlX3ZhbGlkYXRvclwiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IFwiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCIgOiBcInZhbGlkYXRvclwiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IFwiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIiA6IGFkZHJlc3MgfVxuICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAkYW5kIDogW1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBcImV2ZW50cy50eXBlXCIgOiBcInVuYm9uZFwiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IFwiZXZlbnRzLmF0dHJpYnV0ZXMua2V5XCIgOiBcInZhbGlkYXRvclwiIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7IFwiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIiA6IGFkZHJlc3MgfVxuICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAkYW5kIDogW1xuICAgICAgICAgICAgICAgICAgICAgICAgeyBcImV2ZW50cy50eXBlXCIgOiBcInJlZGVsZWdhdGVcIiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiIDogXCJkZXN0aW5hdGlvbl92YWxpZGF0b3JcIiB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCIgOiBhZGRyZXNzIH1cbiAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH1dLFxuICAgICAgICAgICAgICAgIFwiY29kZVwiIDogeyAkZXhpc3RzIDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICBoZWlnaHQgOiB7ICRsdCA6IGhlaWdodCB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHNvcnQgOiB7IGhlaWdodCA6IC0xIH0sXG4gICAgICAgICAgICAgICAgbGltaXQgOiAxXG4gICAgICAgICAgICB9XG4gICAgICAgICkuZmV0Y2ggKCk7XG4gICAgfSxcbiAgICAnVHJhbnNhY3Rpb25zLmZpbmRVc2VyJyA6IGZ1bmN0aW9uIChhZGRyZXNzLCBmaWVsZHMgPSBudWxsKSB7XG4gICAgICAgIC8vIGFkZHJlc3MgaXMgZWl0aGVyIGRlbGVnYXRvciBhZGRyZXNzIG9yIHZhbGlkYXRvciBvcGVyYXRvciBhZGRyZXNzXG4gICAgICAgIGxldCB2YWxpZGF0b3I7XG4gICAgICAgIGlmICghZmllbGRzKVxuICAgICAgICAgICAgZmllbGRzID0geyBhZGRyZXNzIDogMSwgZGVzY3JpcHRpb24gOiAxLCBvcGVyYXRvcl9hZGRyZXNzIDogMSwgZGVsZWdhdG9yX2FkZHJlc3MgOiAxIH07XG4gICAgICAgIGlmIChhZGRyZXNzLmluY2x1ZGVzIChNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeFZhbEFkZHIpKSB7XG4gICAgICAgICAgICAvLyB2YWxpZGF0b3Igb3BlcmF0b3IgYWRkcmVzc1xuICAgICAgICAgICAgdmFsaWRhdG9yID0gVmFsaWRhdG9ycy5maW5kT25lICh7IG9wZXJhdG9yX2FkZHJlc3MgOiBhZGRyZXNzIH0sIHsgZmllbGRzIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGFkZHJlc3MuaW5jbHVkZXMgKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4QWNjQWRkcikpIHtcbiAgICAgICAgICAgIC8vIGRlbGVnYXRvciBhZGRyZXNzXG4gICAgICAgICAgICB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUgKHsgZGVsZWdhdG9yX2FkZHJlc3MgOiBhZGRyZXNzIH0sIHsgZmllbGRzIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGFkZHJlc3MubGVuZ3RoID09PSBBZGRyZXNzTGVuZ3RoKSB7XG4gICAgICAgICAgICB2YWxpZGF0b3IgPSBWYWxpZGF0b3JzLmZpbmRPbmUgKHsgYWRkcmVzcyA6IGFkZHJlc3MgfSwgeyBmaWVsZHMgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHZhbGlkYXRvcikge1xuICAgICAgICAgICAgcmV0dXJuIHZhbGlkYXRvcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG5cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVHJhbnNhY3Rpb25zIH0gZnJvbSAnLi4vdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uLy4uL2Jsb2Nrcy9ibG9ja3MuanMnO1xuXG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3RyYW5zYWN0aW9ucy5saXN0JywgZnVuY3Rpb24obGltaXQgPSAzMCl7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIFRyYW5zYWN0aW9ucy5maW5kKHt9LHtzb3J0OntoZWlnaHQ6LTF9LCBsaW1pdDpsaW1pdH0pXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh0eCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6dHguaGVpZ2h0fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e3RpbWU6MSwgaGVpZ2h0OjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3RyYW5zYWN0aW9ucy52YWxpZGF0b3InLCBmdW5jdGlvbih2YWxpZGF0b3JBZGRyZXNzLCBkZWxlZ2F0b3JBZGRyZXNzLCBsaW1pdD0xMDApe1xuICAgIGxldCBxdWVyeSA9IHt9O1xuICAgIGlmICh2YWxpZGF0b3JBZGRyZXNzICYmIGRlbGVnYXRvckFkZHJlc3Mpe1xuICAgICAgICBxdWVyeSA9IHskb3I6W3tcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6dmFsaWRhdG9yQWRkcmVzc30sIHtcImV2ZW50cy5hdHRyaWJ1dGVzLnZhbHVlXCI6ZGVsZWdhdG9yQWRkcmVzc31dfVxuICAgIH1cblxuICAgIGlmICghdmFsaWRhdG9yQWRkcmVzcyAmJiBkZWxlZ2F0b3JBZGRyZXNzKXtcbiAgICAgICAgcXVlcnkgPSB7XCJldmVudHMuYXR0cmlidXRlcy52YWx1ZVwiOmRlbGVnYXRvckFkZHJlc3N9XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIFRyYW5zYWN0aW9ucy5maW5kKHF1ZXJ5LCB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6bGltaXR9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjpbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZmluZCh0eCl7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBCbG9ja3Njb24uZmluZChcbiAgICAgICAgICAgICAgICAgICAgICAgIHtoZWlnaHQ6dHguaGVpZ2h0fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWVsZHM6e3RpbWU6MSwgaGVpZ2h0OjF9fVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufSlcblxucHVibGlzaENvbXBvc2l0ZSgndHJhbnNhY3Rpb25zLmZpbmRPbmUnLCBmdW5jdGlvbihoYXNoKXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoe3R4aGFzaDpoYXNofSlcbiAgICAgICAgfSxcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHR4KXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEJsb2Nrc2Nvbi5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2hlaWdodDp0eC5oZWlnaHR9LFxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpZWxkczp7dGltZToxLCBoZWlnaHQ6MX19XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KVxuXG5wdWJsaXNoQ29tcG9zaXRlKCd0cmFuc2FjdGlvbnMuaGVpZ2h0JywgZnVuY3Rpb24oaGVpZ2h0KXtcbiAgICByZXR1cm4ge1xuICAgICAgICBmaW5kKCl7XG4gICAgICAgICAgICByZXR1cm4gVHJhbnNhY3Rpb25zLmZpbmQoe2hlaWdodDpoZWlnaHR9KVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodHgpe1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgICAgICB7aGVpZ2h0OnR4LmhlaWdodH0sXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZmllbGRzOnt0aW1lOjEsIGhlaWdodDoxfX1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHsgQmxvY2tzY29uIH0gZnJvbSAnLi4vYmxvY2tzL2Jsb2Nrcy5qcyc7XG5pbXBvcnQgeyBUeEljb24gfSBmcm9tICcuLi8uLi91aS9jb21wb25lbnRzL0ljb25zLmpzeCc7XG5cbmV4cG9ydCBjb25zdCBUcmFuc2FjdGlvbnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndHJhbnNhY3Rpb25zJyk7XG5cblRyYW5zYWN0aW9ucy5oZWxwZXJzKHtcbiAgICBibG9jaygpe1xuICAgICAgICByZXR1cm4gQmxvY2tzY29uLmZpbmRPbmUoe2hlaWdodDp0aGlzLmhlaWdodH0pO1xuICAgIH1cbn0pIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi90cmFuc2FjdGlvbnMvdHJhbnNhY3Rpb25zLmpzJztcbmltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uLy4uL2Jsb2Nrcy9ibG9ja3MuanMnO1xuaW1wb3J0IHsgRGVsZWdhdGlvbnMgfSBmcm9tICcuLi8uLi9kZWxlZ2F0aW9ucy9kZWxlZ2F0aW9ucy5qcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICAnVmFsaWRhdG9ycy5maW5kQ3JlYXRlVmFsaWRhdG9yVGltZSc6IGZ1bmN0aW9uKGFkZHJlc3Mpe1xuICAgICAgICAvLyBsb29rIHVwIHRoZSBjcmVhdGUgdmFsaWRhdG9yIHRpbWUgdG8gY29uc2lkZXIgaWYgdGhlIHZhbGlkYXRvciBoYXMgbmV2ZXIgdXBkYXRlZCB0aGUgY29tbWlzc2lvblxuICAgICAgICBsZXQgdHggPSBUcmFuc2FjdGlvbnMuZmluZE9uZSh7JGFuZDpbXG4gICAgICAgICAgICB7XCJ0eC52YWx1ZS5tc2cudmFsdWUuZGVsZWdhdG9yX2FkZHJlc3NcIjphZGRyZXNzfSxcbiAgICAgICAgICAgIHtcInR4LnZhbHVlLm1zZy50eXBlXCI6XCJjb3Ntb3Mtc2RrL01zZ0NyZWF0ZVZhbGlkYXRvclwifSxcbiAgICAgICAgICAgIHtjb2RlOnskZXhpc3RzOmZhbHNlfX1cbiAgICAgICAgXX0pO1xuXG4gICAgICAgIGlmICh0eCl7XG4gICAgICAgICAgICBsZXQgYmxvY2sgPSBCbG9ja3Njb24uZmluZE9uZSh7aGVpZ2h0OnR4LmhlaWdodH0pO1xuICAgICAgICAgICAgaWYgKGJsb2NrKXtcbiAgICAgICAgICAgICAgICByZXR1cm4gYmxvY2sudGltZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgLy8gbm8gc3VjaCBjcmVhdGUgdmFsaWRhdG9yIHR4XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9LFxuICAgIC8vIGFzeW5jICdWYWxpZGF0b3JzLmdldEFsbERlbGVnYXRpb25zJyhhZGRyZXNzKXtcbiAgICAnVmFsaWRhdG9ycy5nZXRBbGxEZWxlZ2F0aW9ucycoYWRkcmVzcyl7XG4gICAgICAgIGxldCB1cmwgPSBMQ0QgKyAnL3N0YWtpbmcvdmFsaWRhdG9ycy8nK2FkZHJlc3MrJy9kZWxlZ2F0aW9ucyc7XG5cbiAgICAgICAgdHJ5e1xuICAgICAgICAgICAgbGV0IGRlbGVnYXRpb25zID0gSFRUUC5nZXQodXJsKTtcbiAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9ucy5zdGF0dXNDb2RlID09IDIwMCl7XG4gICAgICAgICAgICAgICAgZGVsZWdhdGlvbnMgPSBKU09OLnBhcnNlKGRlbGVnYXRpb25zLmNvbnRlbnQpLnJlc3VsdDtcbiAgICAgICAgICAgICAgICBkZWxlZ2F0aW9ucy5mb3JFYWNoKChkZWxlZ2F0aW9uLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChkZWxlZ2F0aW9uc1tpXSAmJiBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0aW9uc1tpXS5zaGFyZXMgPSBwYXJzZUZsb2F0KGRlbGVnYXRpb25zW2ldLnNoYXJlcyk7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICByZXR1cm4gZGVsZWdhdGlvbnM7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKXtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGUpO1xuICAgICAgICB9XG4gICAgfVxufSk7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgeyBWYWxpZGF0b3JzIH0gZnJvbSAnLi4vdmFsaWRhdG9ycy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JSZWNvcmRzIH0gZnJvbSAnLi4vLi4vcmVjb3Jkcy9yZWNvcmRzLmpzJztcbmltcG9ydCB7IFZvdGluZ1Bvd2VySGlzdG9yeSB9IGZyb20gJy4uLy4uL3ZvdGluZy1wb3dlci9oaXN0b3J5LmpzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ3ZhbGlkYXRvcnMuYWxsJywgZnVuY3Rpb24gKHNvcnQgPSBcImRlc2NyaXB0aW9uLm1vbmlrZXJcIiwgZGlyZWN0aW9uID0gLTEsIGZpZWxkcz17fSkge1xuICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoe30sIHtzb3J0OiB7W3NvcnRdOiBkaXJlY3Rpb259LCBmaWVsZHM6IGZpZWxkc30pO1xufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3ZhbGlkYXRvcnMuZmlyc3RTZWVuJyx7XG4gICAgZmluZCgpIHtcbiAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZCh7fSk7XG4gICAgfSxcbiAgICBjaGlsZHJlbjogW1xuICAgICAgICB7XG4gICAgICAgICAgICBmaW5kKHZhbCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoXG4gICAgICAgICAgICAgICAgICAgIHsgYWRkcmVzczogdmFsLmFkZHJlc3MgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBzb3J0OiB7aGVpZ2h0OiAxfSwgbGltaXQ6IDF9XG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIF1cbn0pO1xuXG5NZXRlb3IucHVibGlzaCgndmFsaWRhdG9ycy52b3RpbmdfcG93ZXInLCBmdW5jdGlvbigpe1xuICAgIHJldHVybiBWYWxpZGF0b3JzLmZpbmQoe1xuICAgICAgICBzdGF0dXM6IDIsXG4gICAgICAgIGphaWxlZDpmYWxzZVxuICAgIH0se1xuICAgICAgICBzb3J0OntcbiAgICAgICAgICAgIHZvdGluZ19wb3dlcjotMVxuICAgICAgICB9LFxuICAgICAgICBmaWVsZHM6e1xuICAgICAgICAgICAgYWRkcmVzczogMSxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOjEsXG4gICAgICAgICAgICB2b3RpbmdfcG93ZXI6MSxcbiAgICAgICAgICAgIHByb2ZpbGVfdXJsOjFcbiAgICAgICAgfVxuICAgIH1cbiAgICApO1xufSk7XG5cbnB1Ymxpc2hDb21wb3NpdGUoJ3ZhbGlkYXRvci5kZXRhaWxzJywgZnVuY3Rpb24oYWRkcmVzcyl7XG4gICAgbGV0IG9wdGlvbnMgPSB7YWRkcmVzczphZGRyZXNzfTtcbiAgICBpZiAoYWRkcmVzcy5pbmRleE9mKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYmVjaDMyUHJlZml4VmFsQWRkcikgIT0gLTEpe1xuICAgICAgICBvcHRpb25zID0ge29wZXJhdG9yX2FkZHJlc3M6YWRkcmVzc31cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZmluZCgpe1xuICAgICAgICAgICAgcmV0dXJuIFZhbGlkYXRvcnMuZmluZChvcHRpb25zKVxuICAgICAgICB9LFxuICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZpbmQodmFsKXtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFZvdGluZ1Bvd2VySGlzdG9yeS5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAge2FkZHJlc3M6dmFsLmFkZHJlc3N9LFxuICAgICAgICAgICAgICAgICAgICAgICAge3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OjUwfVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmaW5kKHZhbCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gVmFsaWRhdG9yUmVjb3Jkcy5maW5kKFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBhZGRyZXNzOiB2YWwuYWRkcmVzcyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBzb3J0OiB7aGVpZ2h0OiAtMX0sIGxpbWl0OiBNZXRlb3Iuc2V0dGluZ3MucHVibGljLnVwdGltZVdpbmRvd31cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMgfSBmcm9tICcuLi9yZWNvcmRzL3JlY29yZHMuanMnO1xuaW1wb3J0IHsgVm90aW5nUG93ZXJIaXN0b3J5IH0gZnJvbSAnLi4vdm90aW5nLXBvd2VyL2hpc3RvcnkuanMnO1xuXG5leHBvcnQgY29uc3QgVmFsaWRhdG9ycyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2YWxpZGF0b3JzJyk7XG5cblZhbGlkYXRvcnMuaGVscGVycyh7XG4gICAgZmlyc3RTZWVuKCl7XG4gICAgICAgIHJldHVybiBWYWxpZGF0b3JSZWNvcmRzLmZpbmRPbmUoe2FkZHJlc3M6dGhpcy5hZGRyZXNzfSk7XG4gICAgfSxcbiAgICBoaXN0b3J5KCl7XG4gICAgICAgIHJldHVybiBWb3RpbmdQb3dlckhpc3RvcnkuZmluZCh7YWRkcmVzczp0aGlzLmFkZHJlc3N9LCB7c29ydDp7aGVpZ2h0Oi0xfSwgbGltaXQ6NTB9KS5mZXRjaCgpO1xuICAgIH1cbn0pXG4vLyBWYWxpZGF0b3JzLmhlbHBlcnMoe1xuLy8gICAgIHVwdGltZSgpe1xuLy8gICAgICAgICAvLyBjb25zb2xlLmxvZyh0aGlzLmFkZHJlc3MpO1xuLy8gICAgICAgICBsZXQgbGFzdEh1bmRyZWQgPSBWYWxpZGF0b3JSZWNvcmRzLmZpbmQoe2FkZHJlc3M6dGhpcy5hZGRyZXNzfSwge3NvcnQ6e2hlaWdodDotMX0sIGxpbWl0OjEwMH0pLmZldGNoKCk7XG4vLyAgICAgICAgIGNvbnNvbGUubG9nKGxhc3RIdW5kcmVkKTtcbi8vICAgICAgICAgbGV0IHVwdGltZSA9IDA7XG4vLyAgICAgICAgIGZvciAoaSBpbiBsYXN0SHVuZHJlZCl7XG4vLyAgICAgICAgICAgICBpZiAobGFzdEh1bmRyZWRbaV0uZXhpc3RzKXtcbi8vICAgICAgICAgICAgICAgICB1cHRpbWUrPTE7XG4vLyAgICAgICAgICAgICB9XG4vLyAgICAgICAgIH1cbi8vICAgICAgICAgcmV0dXJuIHVwdGltZTtcbi8vICAgICB9XG4vLyB9KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IFZvdGluZ1Bvd2VySGlzdG9yeSA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2b3RpbmdfcG93ZXJfaGlzdG9yeScpO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgRXZpZGVuY2VzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2V2aWRlbmNlcycpO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgVmFsaWRhdG9yU2V0cyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd2YWxpZGF0b3Jfc2V0cycpO1xuIiwiLy8gSW1wb3J0IG1vZHVsZXMgdXNlZCBieSBib3RoIGNsaWVudCBhbmQgc2VydmVyIHRocm91Z2ggYSBzaW5nbGUgaW5kZXggZW50cnkgcG9pbnRcbi8vIGUuZy4gdXNlcmFjY291bnRzIGNvbmZpZ3VyYXRpb24gZmlsZS5cbiIsImltcG9ydCB7IEJsb2Nrc2NvbiB9IGZyb20gJy4uLy4uL2FwaS9ibG9ja3MvYmxvY2tzLmpzJztcbmltcG9ydCB7IFByb3Bvc2FscyB9IGZyb20gJy4uLy4uL2FwaS9wcm9wb3NhbHMvcHJvcG9zYWxzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvclJlY29yZHMsIEFuYWx5dGljcywgTWlzc2VkQmxvY2tzU3RhdHMsIE1pc3NlZEJsb2NrcywgQXZlcmFnZURhdGEsIEF2ZXJhZ2VWYWxpZGF0b3JEYXRhIH0gZnJvbSAnLi4vLi4vYXBpL3JlY29yZHMvcmVjb3Jkcy5qcyc7XG4vLyBpbXBvcnQgeyBTdGF0dXMgfSBmcm9tICcuLi8uLi9hcGkvc3RhdHVzL3N0YXR1cy5qcyc7XG5pbXBvcnQgeyBUcmFuc2FjdGlvbnMgfSBmcm9tICcuLi8uLi9hcGkvdHJhbnNhY3Rpb25zL3RyYW5zYWN0aW9ucy5qcyc7XG5pbXBvcnQgeyBWYWxpZGF0b3JTZXRzIH0gZnJvbSAnLi4vLi4vYXBpL3ZhbGlkYXRvci1zZXRzL3ZhbGlkYXRvci1zZXRzLmpzJztcbmltcG9ydCB7IFZhbGlkYXRvcnMgfSBmcm9tICcuLi8uLi9hcGkvdmFsaWRhdG9ycy92YWxpZGF0b3JzLmpzJztcbmltcG9ydCB7IFZvdGluZ1Bvd2VySGlzdG9yeSB9IGZyb20gJy4uLy4uL2FwaS92b3RpbmctcG93ZXIvaGlzdG9yeS5qcyc7XG5pbXBvcnQgeyBFdmlkZW5jZXMgfSBmcm9tICcuLi8uLi9hcGkvZXZpZGVuY2VzL2V2aWRlbmNlcy5qcyc7XG5pbXBvcnQgeyBDb2luU3RhdHMgfSBmcm9tICcuLi8uLi9hcGkvY29pbi1zdGF0cy9jb2luLXN0YXRzLmpzJztcbmltcG9ydCB7IENoYWluU3RhdGVzIH0gZnJvbSAnLi4vLi4vYXBpL2NoYWluL2NoYWluLmpzJztcblxuQ2hhaW5TdGF0ZXMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSx7dW5pcXVlOnRydWV9KTtcblxuQmxvY2tzY29uLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7aGVpZ2h0OiAtMX0se3VuaXF1ZTp0cnVlfSk7XG5CbG9ja3Njb24ucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlckFkZHJlc3M6MX0pO1xuXG5FdmlkZW5jZXMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6IC0xfSk7XG5cblByb3Bvc2Fscy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2FsSWQ6IDF9LCB7dW5pcXVlOnRydWV9KTtcblxuVmFsaWRhdG9yUmVjb3Jkcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FkZHJlc3M6MSxoZWlnaHQ6IC0xfSwge3VuaXF1ZToxfSk7XG5WYWxpZGF0b3JSZWNvcmRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7YWRkcmVzczoxLGV4aXN0czoxLCBoZWlnaHQ6IC0xfSk7XG5cbkFuYWx5dGljcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2hlaWdodDogLTF9LCB7dW5pcXVlOnRydWV9KVxuXG5NaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlcjoxLCB2b3RlcjoxLCB1cGRhdGVkQXQ6IC0xfSk7XG5NaXNzZWRCbG9ja3MucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtwcm9wb3NlcjoxLCBibG9ja0hlaWdodDotMX0pO1xuTWlzc2VkQmxvY2tzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7dm90ZXI6MSwgYmxvY2tIZWlnaHQ6LTF9KTtcbk1pc3NlZEJsb2Nrcy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3ZvdGVyOjEsIHByb3Bvc2VyOjEsIGJsb2NrSGVpZ2h0Oi0xfSwge3VuaXF1ZTp0cnVlfSk7XG5cbk1pc3NlZEJsb2Nrc1N0YXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXI6MX0pO1xuTWlzc2VkQmxvY2tzU3RhdHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt2b3RlcjoxfSk7XG5NaXNzZWRCbG9ja3NTdGF0cy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3Byb3Bvc2VyOjEsIHZvdGVyOjF9LHt1bmlxdWU6dHJ1ZX0pO1xuXG5BdmVyYWdlRGF0YS5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe3R5cGU6MSwgY3JlYXRlZEF0Oi0xfSx7dW5pcXVlOnRydWV9KTtcbkF2ZXJhZ2VWYWxpZGF0b3JEYXRhLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7cHJvcG9zZXJBZGRyZXNzOjEsY3JlYXRlZEF0Oi0xfSx7dW5pcXVlOnRydWV9KTtcbi8vIFN0YXR1cy5yYXdDb2xsZWN0aW9uLmNyZWF0ZUluZGV4KHt9KVxuXG5UcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt0eGhhc2g6MX0se3VuaXF1ZTp0cnVlfSk7XG5UcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtoZWlnaHQ6LTF9KTtcbi8vIFRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FjdGlvbjoxfSk7XG5UcmFuc2FjdGlvbnMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtcImV2ZW50cy5hdHRyaWJ1dGVzLmtleVwiOjF9KTtcblRyYW5zYWN0aW9ucy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe1wiZXZlbnRzLmF0dHJpYnV0ZXMudmFsdWVcIjoxfSk7XG5cblZhbGlkYXRvclNldHMucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHtibG9ja19oZWlnaHQ6LTF9KTtcblxuVmFsaWRhdG9ycy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2FkZHJlc3M6MX0se3VuaXF1ZTp0cnVlLCBwYXJ0aWFsRmlsdGVyRXhwcmVzc2lvbjogeyBhZGRyZXNzOiB7ICRleGlzdHM6IHRydWUgfSB9IH0pO1xuVmFsaWRhdG9ycy5yYXdDb2xsZWN0aW9uKCkuY3JlYXRlSW5kZXgoe2NvbnNlbnN1c19wdWJrZXk6MX0se3VuaXF1ZTp0cnVlfSk7XG5WYWxpZGF0b3JzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7XCJwdWJfa2V5LnZhbHVlXCI6MX0se3VuaXF1ZTp0cnVlLCBwYXJ0aWFsRmlsdGVyRXhwcmVzc2lvbjogeyBcInB1Yl9rZXkudmFsdWVcIjogeyAkZXhpc3RzOiB0cnVlIH0gfX0pO1xuXG5Wb3RpbmdQb3dlckhpc3RvcnkucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHthZGRyZXNzOjEsaGVpZ2h0Oi0xfSk7XG5Wb3RpbmdQb3dlckhpc3RvcnkucmF3Q29sbGVjdGlvbigpLmNyZWF0ZUluZGV4KHt0eXBlOjF9KTtcblxuQ29pblN0YXRzLnJhd0NvbGxlY3Rpb24oKS5jcmVhdGVJbmRleCh7bGFzdF91cGRhdGVkX2F0Oi0xfSx7dW5pcXVlOnRydWV9KTtcbiIsIi8vIEltcG9ydCBzZXJ2ZXIgc3RhcnR1cCB0aHJvdWdoIGEgc2luZ2xlIGluZGV4IGVudHJ5IHBvaW50XG5cbmltcG9ydCAnLi91dGlsLmpzJztcbmltcG9ydCAnLi9yZWdpc3Rlci1hcGkuanMnO1xuaW1wb3J0ICcuL2NyZWF0ZS1pbmRleGVzLmpzJztcblxuLy8gaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0Jztcbi8vIGltcG9ydCB7IHJlbmRlclRvTm9kZVN0cmVhbSB9IGZyb20gJ3JlYWN0LWRvbS9zZXJ2ZXInO1xuLy8gaW1wb3J0IHsgcmVuZGVyVG9TdHJpbmcgfSBmcm9tIFwicmVhY3QtZG9tL3NlcnZlclwiO1xuaW1wb3J0IHsgb25QYWdlTG9hZCB9IGZyb20gJ21ldGVvci9zZXJ2ZXItcmVuZGVyJztcbi8vIGltcG9ydCB7IFN0YXRpY1JvdXRlciB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuLy8gaW1wb3J0IHsgU2VydmVyU3R5bGVTaGVldCB9IGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiXG5pbXBvcnQgeyBIZWxtZXQgfSBmcm9tICdyZWFjdC1oZWxtZXQnO1xuXG4vLyBpbXBvcnQgQXBwIGZyb20gJy4uLy4uL3VpL0FwcC5qc3gnO1xuXG5vblBhZ2VMb2FkKHNpbmsgPT4ge1xuICAgIC8vIGNvbnN0IGNvbnRleHQgPSB7fTtcbiAgICAvLyBjb25zdCBzaGVldCA9IG5ldyBTZXJ2ZXJTdHlsZVNoZWV0KClcblxuICAgIC8vIGNvbnN0IGh0bWwgPSByZW5kZXJUb1N0cmluZyhzaGVldC5jb2xsZWN0U3R5bGVzKFxuICAgIC8vICAgICA8U3RhdGljUm91dGVyIGxvY2F0aW9uPXtzaW5rLnJlcXVlc3QudXJsfSBjb250ZXh0PXtjb250ZXh0fT5cbiAgICAvLyAgICAgICAgIDxBcHAgLz5cbiAgICAvLyAgICAgPC9TdGF0aWNSb3V0ZXI+XG4gICAgLy8gICApKTtcblxuICAgIC8vIHNpbmsucmVuZGVySW50b0VsZW1lbnRCeUlkKCdhcHAnLCBodG1sKTtcblxuICAgIGNvbnN0IGhlbG1ldCA9IEhlbG1ldC5yZW5kZXJTdGF0aWMoKTtcbiAgICBzaW5rLmFwcGVuZFRvSGVhZChoZWxtZXQubWV0YS50b1N0cmluZygpKTtcbiAgICBzaW5rLmFwcGVuZFRvSGVhZChoZWxtZXQudGl0bGUudG9TdHJpbmcoKSk7XG5cbiAgICAvLyBzaW5rLmFwcGVuZFRvSGVhZChzaGVldC5nZXRTdHlsZVRhZ3MoKSk7XG59KTsiLCIvLyBSZWdpc3RlciB5b3VyIGFwaXMgaGVyZVxuXG5pbXBvcnQgJy4uLy4uL2FwaS9sZWRnZXIvc2VydmVyL21ldGhvZHMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9jaGFpbi9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9jaGFpbi9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvYmxvY2tzL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2Jsb2Nrcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvdmFsaWRhdG9ycy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS92YWxpZGF0b3JzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9yZWNvcmRzL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3JlY29yZHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3Byb3Bvc2Fscy9zZXJ2ZXIvbWV0aG9kcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9wcm9wb3NhbHMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3ZvdGluZy1wb3dlci9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvdHJhbnNhY3Rpb25zL3NlcnZlci9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3RyYW5zYWN0aW9ucy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvZGVsZWdhdGlvbnMvc2VydmVyL21ldGhvZHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvZGVsZWdhdGlvbnMvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbmltcG9ydCAnLi4vLi4vYXBpL3N0YXR1cy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuaW1wb3J0ICcuLi8uLi9hcGkvYWNjb3VudHMvc2VydmVyL21ldGhvZHMuanMnO1xuXG5pbXBvcnQgJy4uLy4uL2FwaS9jb2luLXN0YXRzL3NlcnZlci9tZXRob2RzLmpzJztcbiIsImltcG9ydCBiZWNoMzIgZnJvbSAnYmVjaDMyJ1xuaW1wb3J0IHsgSFRUUCB9IGZyb20gJ21ldGVvci9odHRwJztcbmltcG9ydCAqIGFzIGNoZWVyaW8gZnJvbSAnY2hlZXJpbyc7XG5cbi8vIExvYWQgZnV0dXJlIGZyb20gZmliZXJzXG52YXIgRnV0dXJlID0gTnBtLnJlcXVpcmUoXCJmaWJlcnMvZnV0dXJlXCIpO1xuLy8gTG9hZCBleGVjXG52YXIgZXhlYyA9IE5wbS5yZXF1aXJlKFwiY2hpbGRfcHJvY2Vzc1wiKS5leGVjO1xuXG5mdW5jdGlvbiB0b0hleFN0cmluZyhieXRlQXJyYXkpIHtcbiAgICByZXR1cm4gYnl0ZUFycmF5Lm1hcChmdW5jdGlvbihieXRlKSB7XG4gICAgICAgIHJldHVybiAoJzAnICsgKGJ5dGUgJiAweEZGKS50b1N0cmluZygxNikpLnNsaWNlKC0yKTtcbiAgICB9KS5qb2luKCcnKVxufVxuXG5NZXRlb3IubWV0aG9kcyh7XG4gICAgcHVia2V5VG9CZWNoMzI6IGZ1bmN0aW9uKHB1YmtleSwgcHJlZml4KSB7XG4gICAgICAgIGxldCBidWZmZXI7XG5cbiAgICAgICAgaWYgKHB1YmtleS50eXBlLmluZGV4T2YoXCJQdWJLZXlFZDI1NTE5XCIpID4gMCl7XG4gICAgICAgICAgICAvLyAnMTYyNERFNjQyMCcgaXMgZWQyNTUxOSBwdWJrZXkgcHJlZml4XG4gICAgICAgICAgICBsZXQgcHVia2V5QW1pbm9QcmVmaXggPSBCdWZmZXIuZnJvbSgnMTYyNERFNjQyMCcsICdoZXgnKTtcbiAgICAgICAgICAgIGJ1ZmZlciA9IEJ1ZmZlci5hbGxvYygzNyk7XG4gICAgICAgIFxuICAgICAgICAgICAgcHVia2V5QW1pbm9QcmVmaXguY29weShidWZmZXIsIDApXG4gICAgICAgICAgICBCdWZmZXIuZnJvbShwdWJrZXkudmFsdWUsICdiYXNlNjQnKS5jb3B5KGJ1ZmZlciwgcHVia2V5QW1pbm9QcmVmaXgubGVuZ3RoKVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHB1YmtleS50eXBlLmluZGV4T2YoXCJQdWJLZXlTZWNwMjU2azFcIikgPiAwKXtcbiAgICAgICAgICAgIC8vICdFQjVBRTk4NzIxJyBpcyBzZWNwMjU2azEgcHVia2V5IHByZWZpeFxuICAgICAgICAgICAgbGV0IHB1YmtleUFtaW5vUHJlZml4ID0gQnVmZmVyLmZyb20oJ0VCNUFFOTg3MjEnLCAnaGV4Jyk7XG4gICAgICAgICAgICBidWZmZXIgPSBCdWZmZXIuYWxsb2MoMzgpO1xuICAgIFxuICAgICAgICAgICAgcHVia2V5QW1pbm9QcmVmaXguY29weShidWZmZXIsIDApXG4gICAgICAgICAgICBCdWZmZXIuZnJvbShwdWJrZXkudmFsdWUsICdiYXNlNjQnKS5jb3B5KGJ1ZmZlciwgcHVia2V5QW1pbm9QcmVmaXgubGVuZ3RoKVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJQdWJrZXkgdHlwZSBub3Qgc3VwcG9ydGVkLlwiKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBiZWNoMzIuZW5jb2RlKHByZWZpeCwgYmVjaDMyLnRvV29yZHMoYnVmZmVyKSlcbiAgICB9LFxuICAgIGJlY2gzMlRvUHVia2V5OiBmdW5jdGlvbihwdWJrZXksIHR5cGUpIHtcbiAgICAgICAgLy8gdHlwZSBjYW4gb25seSBiZSBlaXRoZXIgJ3RlbmRlcm1pbnQvUHViS2V5U2VjcDI1NmsxJyBvciAndGVuZGVybWludC9QdWJLZXlFZDI1NTE5J1xuICAgICAgICBsZXQgcHVia2V5QW1pbm9QcmVmaXgsIGJ1ZmZlcjtcblxuICAgICAgICBpZiAodHlwZS5pbmRleE9mKFwiUHViS2V5RWQyNTUxOVwiKSA+IDApe1xuICAgICAgICAgICAgLy8gJzE2MjRERTY0MjAnIGlzIGVkMjU1MTkgcHVia2V5IHByZWZpeFxuICAgICAgICAgICAgcHVia2V5QW1pbm9QcmVmaXggPSBCdWZmZXIuZnJvbSgnMTYyNERFNjQyMCcsICdoZXgnKVxuICAgICAgICAgICAgYnVmZmVyID0gQnVmZmVyLmZyb20oYmVjaDMyLmZyb21Xb3JkcyhiZWNoMzIuZGVjb2RlKHB1YmtleSkud29yZHMpKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0eXBlLmluZGV4T2YoXCJQdWJLZXlTZWNwMjU2azFcIikgPiAwKXtcbiAgICAgICAgICAgIC8vICdFQjVBRTk4NzIxJyBpcyBzZWNwMjU2azEgcHVia2V5IHByZWZpeFxuICAgICAgICAgICAgcHVia2V5QW1pbm9QcmVmaXggPSBCdWZmZXIuZnJvbSgnRUI1QUU5ODcyMScsICdoZXgnKVxuICAgICAgICAgICAgYnVmZmVyID0gQnVmZmVyLmZyb20oYmVjaDMyLmZyb21Xb3JkcyhiZWNoMzIuZGVjb2RlKHB1YmtleSkud29yZHMpKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUHVia2V5IHR5cGUgbm90IHN1cHBvcnRlZC5cIik7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIHJldHVybiBidWZmZXIuc2xpY2UocHVia2V5QW1pbm9QcmVmaXgubGVuZ3RoKS50b1N0cmluZygnYmFzZTY0Jyk7XG4gICAgfSxcbiAgICBnZXREZWxlZ2F0b3I6IGZ1bmN0aW9uKG9wZXJhdG9yQWRkcil7XG4gICAgICAgIGxldCBhZGRyZXNzID0gYmVjaDMyLmRlY29kZShvcGVyYXRvckFkZHIpO1xuICAgICAgICByZXR1cm4gYmVjaDMyLmVuY29kZShNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJlY2gzMlByZWZpeEFjY0FkZHIsIGFkZHJlc3Mud29yZHMpO1xuICAgIH0sXG4gICAgZ2V0S2V5YmFzZVRlYW1QaWM6IGZ1bmN0aW9uKGtleWJhc2VVcmwpe1xuICAgICAgICBsZXQgdGVhbVBhZ2UgPSBIVFRQLmdldChrZXliYXNlVXJsKTtcbiAgICAgICAgaWYgKHRlYW1QYWdlLnN0YXR1c0NvZGUgPT0gMjAwKXtcbiAgICAgICAgICAgIGxldCBwYWdlID0gY2hlZXJpby5sb2FkKHRlYW1QYWdlLmNvbnRlbnQpO1xuICAgICAgICAgICAgcmV0dXJuIHBhZ2UoXCIua2ItbWFpbi1jYXJkIGltZ1wiKS5hdHRyKCdzcmMnKTtcbiAgICAgICAgfVxuICAgIH1cbn0pXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgVW5jb250cm9sbGVkVG9vbHRpcCB9IGZyb20gJ3JlYWN0c3RyYXAnO1xuXG5leHBvcnQgY29uc3QgRGVub21TeW1ib2wgPSAocHJvcHMpID0+IHtcbiAgICBzd2l0Y2ggKHByb3BzLmRlbm9tKXtcbiAgICBjYXNlIFwic3RlYWtcIjpcbiAgICAgICAgcmV0dXJuICfwn6WpJztcbiAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gJ/CfjYUnO1xuICAgIH1cbn1cblxuXG5leHBvcnQgY29uc3QgUHJvcG9zYWxTdGF0dXNJY29uID0gKHByb3BzKSA9PiB7XG4gICAgc3dpdGNoIChwcm9wcy5zdGF0dXMpe1xuICAgIGNhc2UgJ1Bhc3NlZCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtY2hlY2stY2lyY2xlIHRleHQtc3VjY2Vzc1wiPjwvaT47XG4gICAgY2FzZSAnUmVqZWN0ZWQnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLXRpbWVzLWNpcmNsZSB0ZXh0LWRhbmdlclwiPjwvaT47XG4gICAgY2FzZSAnUmVtb3ZlZCc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdHJhc2gtYWx0IHRleHQtZGFya1wiPjwvaT5cbiAgICBjYXNlICdEZXBvc2l0UGVyaW9kJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1iYXR0ZXJ5LWhhbGYgdGV4dC13YXJuaW5nXCI+PC9pPjtcbiAgICBjYXNlICdWb3RpbmdQZXJpb2QnOlxuICAgICAgICByZXR1cm4gPGkgY2xhc3NOYW1lPVwiZmFzIGZhLWhhbmQtcGFwZXIgdGV4dC1pbmZvXCI+PC9pPjtcbiAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gPGk+PC9pPjtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBWb3RlSWNvbiA9IChwcm9wcykgPT4ge1xuICAgIHN3aXRjaCAocHJvcHMudm90ZSl7XG4gICAgY2FzZSAneWVzJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS1jaGVjayB0ZXh0LXN1Y2Nlc3NcIj48L2k+O1xuICAgIGNhc2UgJ25vJzpcbiAgICAgICAgcmV0dXJuIDxpIGNsYXNzTmFtZT1cImZhcyBmYS10aW1lcyB0ZXh0LWRhbmdlclwiPjwvaT47XG4gICAgY2FzZSAnYWJzdGFpbic6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtdXNlci1zbGFzaCB0ZXh0LXdhcm5pbmdcIj48L2k+O1xuICAgIGNhc2UgJ25vX3dpdGhfdmV0byc6XG4gICAgICAgIHJldHVybiA8aSBjbGFzc05hbWU9XCJmYXMgZmEtZXhjbGFtYXRpb24tdHJpYW5nbGUgdGV4dC1pbmZvXCI+PC9pPjtcbiAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gPGk+PC9pPjtcbiAgICB9XG59XG5cbmV4cG9ydCBjb25zdCBUeEljb24gPSAocHJvcHMpID0+IHtcbiAgICBpZiAocHJvcHMudmFsaWQpe1xuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zdWNjZXNzIHRleHQtbm93cmFwXCI+PGkgY2xhc3NOYW1lPVwiZmFzIGZhLWNoZWNrLWNpcmNsZVwiPjwvaT48L3NwYW4+O1xuICAgIH1cbiAgICBlbHNle1xuICAgICAgICByZXR1cm4gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1kYW5nZXIgdGV4dC1ub3dyYXBcIj48aSBjbGFzc05hbWU9XCJmYXMgZmEtdGltZXMtY2lyY2xlXCI+PC9pPjwvc3Bhbj47XG4gICAgfVxufVxuXG5leHBvcnQgY2xhc3MgSW5mb0ljb24gZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKHByb3BzKSB7XG4gICAgICAgIHN1cGVyKHByb3BzKTtcbiAgICAgICAgdGhpcy5yZWYgPSBSZWFjdC5jcmVhdGVSZWYoKTtcbiAgICB9XG5cbiAgICByZW5kZXIoKSB7XG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICA8aSBrZXk9J2ljb24nIGNsYXNzTmFtZT0nbWF0ZXJpYWwtaWNvbnMgaW5mby1pY29uJyByZWY9e3RoaXMucmVmfT5pbmZvPC9pPixcbiAgICAgICAgICAgIDxVbmNvbnRyb2xsZWRUb29sdGlwIGtleT0ndG9vbHRpcCcgcGxhY2VtZW50PSdyaWdodCcgdGFyZ2V0PXt0aGlzLnJlZn0+XG4gICAgICAgICAgICAgICAge3RoaXMucHJvcHMuY2hpbGRyZW4/dGhpcy5wcm9wcy5jaGlsZHJlbjp0aGlzLnByb3BzLnRvb2x0aXBUZXh0fVxuICAgICAgICAgICAgPC9VbmNvbnRyb2xsZWRUb29sdGlwPlxuICAgICAgICBdXG4gICAgfVxufSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IG51bWJybyBmcm9tICdudW1icm8nO1xuXG5hdXRvZm9ybWF0ID0gKHZhbHVlKSA9PiB7XG4gICAgbGV0IGZvcm1hdHRlciA9ICcwLDAuMDAwMCc7XG4gICAgdmFsdWUgPSBNYXRoLnJvdW5kICh2YWx1ZSAqIDEwMDApIC8gMTAwMDtcbiAgICBpZiAoTWF0aC5yb3VuZCAodmFsdWUpID09PSB2YWx1ZSlcbiAgICAgICAgZm9ybWF0dGVyID0gJzAsMCdcbiAgICBlbHNlIGlmIChNYXRoLnJvdW5kICh2YWx1ZSAqIDEwKSA9PT0gdmFsdWUgKiAxMClcbiAgICAgICAgZm9ybWF0dGVyID0gJzAsMC4wJ1xuICAgIGVsc2UgaWYgKE1hdGgucm91bmQgKHZhbHVlICogMTAwKSA9PT0gdmFsdWUgKiAxMDApXG4gICAgICAgIGZvcm1hdHRlciA9ICcwLDAuMDAnXG4gICAgZWxzZSBpZiAoTWF0aC5yb3VuZCAodmFsdWUgKiAxMDAwKSA9PT0gdmFsdWUgKiAxMDAwKVxuICAgICAgICBmb3JtYXR0ZXIgPSAnMCwwLjAwMCdcbiAgICByZXR1cm4gbnVtYnJvICh2YWx1ZSkuZm9ybWF0IChmb3JtYXR0ZXIpXG59XG5cbmNvbnN0IGNvaW5MaXN0ID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5jb2lucztcbmNvbnNvbGUubG9nIChcImxvYWRlZCBjb2luXCIsIGNvaW5MaXN0KTtcbmZvciAobGV0IGkgaW4gY29pbkxpc3QpIHtcbiAgICBjb25zdCBjb2luID0gY29pbkxpc3RbaV07XG4gICAgaWYgKCFjb2luLmRpc3BsYXlOYW1lUGx1cmFsKSB7XG4gICAgICAgIGNvaW4uZGlzcGxheU5hbWVQbHVyYWwgPSBjb2luLmRpc3BsYXlOYW1lICsgJ3MnO1xuICAgIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ29pbiB7XG4gICAgc3RhdGljIFN0YWtpbmdDb2luID0gY29pbkxpc3QuZmluZCAoY29pbiA9PiBjb2luLmRlbm9tID09PSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLmJvbmREZW5vbSk7XG4gICAgc3RhdGljIE1pblN0YWtlID0gMSAvIE51bWJlciAoQ29pbi5TdGFraW5nQ29pbi5mcmFjdGlvbik7XG5cbiAgICBjb25zdHJ1Y3RvciAoYW1vdW50LCBkZW5vbSA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuYm9uZERlbm9tKSB7XG4gICAgICAgIGNvbnN0IGxvd2VyRGVub20gPSBkZW5vbS50b0xvd2VyQ2FzZSAoKTtcbiAgICAgICAgdGhpcy5fY29pbiA9IGNvaW5MaXN0LmZpbmQgKGNvaW4gPT5cbiAgICAgICAgICAgIGNvaW4uZGVub20udG9Mb3dlckNhc2UgKCkgPT09IGxvd2VyRGVub20gfHwgY29pbi5kaXNwbGF5TmFtZS50b0xvd2VyQ2FzZSAoKSA9PT0gbG93ZXJEZW5vbVxuICAgICAgICApO1xuXG4gICAgICAgIGlmICh0aGlzLl9jb2luKSB7XG4gICAgICAgICAgICBpZiAobG93ZXJEZW5vbSA9PT0gdGhpcy5fY29pbi5kZW5vbS50b0xvd2VyQ2FzZSAoKSkge1xuICAgICAgICAgICAgICAgIHRoaXMuX2Ftb3VudCA9IE51bWJlciAoYW1vdW50KTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobG93ZXJEZW5vbSA9PT0gdGhpcy5fY29pbi5kaXNwbGF5TmFtZS50b0xvd2VyQ2FzZSAoKSkge1xuICAgICAgICAgICAgICAgIHRoaXMuX2Ftb3VudCA9IE51bWJlciAoYW1vdW50KSAqIHRoaXMuX2NvaW4uZnJhY3Rpb247XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9jb2luID0gXCJcIjtcbiAgICAgICAgICAgIHRoaXMuX2Ftb3VudCA9IE51bWJlciAoYW1vdW50KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGdldCBhbW91bnQgKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fYW1vdW50O1xuICAgIH1cblxuICAgIGdldCBzdGFraW5nQW1vdW50ICgpIHtcbiAgICAgICAgcmV0dXJuICh0aGlzLl9jb2luKSA/IHRoaXMuX2Ftb3VudCAvIHRoaXMuX2NvaW4uZnJhY3Rpb24gOiB0aGlzLl9hbW91bnQ7XG4gICAgfVxuXG4gICAgdG9TdHJpbmcgKHByZWNpc2lvbikge1xuICAgICAgICAvLyBkZWZhdWx0IHRvIGRpc3BsYXkgaW4gbWludCBkZW5vbSBpZiBpdCBoYXMgbW9yZSB0aGFuIDQgZGVjaW1hbCBwbGFjZXNcbiAgICAgICAgbGV0IG1pblN0YWtlID0gQ29pbi5TdGFraW5nQ29pbi5mcmFjdGlvbiAvIChwcmVjaXNpb24gPyBNYXRoLnBvdyAoMTAsIHByZWNpc2lvbikgOiAxMDAwMClcbiAgICAgICAgaWYgKHRoaXMuYW1vdW50IDwgbWluU3Rha2UpIHtcbiAgICAgICAgICAgIHJldHVybiBgJHtudW1icm8gKHRoaXMuYW1vdW50KS5mb3JtYXQgKCcwLDAuMDAwMCcpfSAke3RoaXMuX2NvaW4uZGVub219YDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBgJHtwcmVjaXNpb24gPyBudW1icm8gKHRoaXMuc3Rha2luZ0Ftb3VudCkuZm9ybWF0ICgnMCwwLicgKyAnMCcucmVwZWF0IChwcmVjaXNpb24pKSA6IGF1dG9mb3JtYXQgKHRoaXMuc3Rha2luZ0Ftb3VudCl9ICR7dGhpcy5fY29pbi5kaXNwbGF5TmFtZX1gXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBtaW50U3RyaW5nIChmb3JtYXR0ZXIpIHtcbiAgICAgICAgbGV0IGFtb3VudCA9IHRoaXMuYW1vdW50XG4gICAgICAgIGlmIChmb3JtYXR0ZXIpIHtcbiAgICAgICAgICAgIGFtb3VudCA9IG51bWJybyAoYW1vdW50KS5mb3JtYXQgKGZvcm1hdHRlcilcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBkZW5vbSA9ICh0aGlzLl9jb2luID09IFwiXCIpID8gQ29pbi5TdGFraW5nQ29pbi5kaXNwbGF5TmFtZSA6IHRoaXMuX2NvaW4uZGVub207XG4gICAgICAgIHJldHVybiBgJHthbW91bnR9ICR7ZGVub219YDtcbiAgICB9XG5cbiAgICBzdGFrZVN0cmluZyAoZm9ybWF0dGVyKSB7XG4gICAgICAgIGxldCBhbW91bnQgPSB0aGlzLnN0YWtpbmdBbW91bnRcbiAgICAgICAgaWYgKGZvcm1hdHRlcikge1xuICAgICAgICAgICAgYW1vdW50ID0gbnVtYnJvIChhbW91bnQpLmZvcm1hdCAoZm9ybWF0dGVyKVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgJHthbW91bnR9ICR7Q29pbi5TdGFraW5nQ29pbi5kaXNwbGF5TmFtZX1gO1xuICAgIH1cbn1cbiIsIi8vIFNlcnZlciBlbnRyeSBwb2ludCwgaW1wb3J0cyBhbGwgc2VydmVyIGNvZGVcblxuaW1wb3J0ICcvaW1wb3J0cy9zdGFydHVwL3NlcnZlcic7XG5pbXBvcnQgJy9pbXBvcnRzL3N0YXJ0dXAvYm90aCc7XG4vLyBpbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCc7XG4vLyBpbXBvcnQgJy9pbXBvcnRzL2FwaS9ibG9ja3MvYmxvY2tzLmpzJztcblxuU1lOQ0lORyA9IGZhbHNlO1xuQ09VTlRNSVNTRURCTE9DS1MgPSBmYWxzZTtcbkNPVU5UTUlTU0VEQkxPQ0tTU1RBVFMgPSBmYWxzZTtcblJQQyA9IE1ldGVvci5zZXR0aW5ncy5yZW1vdGUucnBjO1xuTENEID0gTWV0ZW9yLnNldHRpbmdzLnJlbW90ZS5sY2Q7XG50aW1lckJsb2NrcyA9IDA7XG50aW1lckNoYWluID0gMDtcbnRpbWVyQ29uc2Vuc3VzID0gMDtcbnRpbWVyUHJvcG9zYWwgPSAwO1xudGltZXJQcm9wb3NhbHNSZXN1bHRzID0gMDtcbnRpbWVyTWlzc2VkQmxvY2sgPSAwO1xudGltZXJEZWxlZ2F0aW9uID0gMDtcbnRpbWVyQWdncmVnYXRlID0gMDtcblxuY29uc3QgREVGQVVMVFNFVFRJTkdTID0gJy9kZWZhdWx0X3NldHRpbmdzLmpzb24nO1xuXG51cGRhdGVDaGFpblN0YXR1cyA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCAoJ2NoYWluLnVwZGF0ZVN0YXR1cycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5sb2cgKFwidXBkYXRlU3RhdHVzOiBcIiArIGVycm9yKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcInVwZGF0ZVN0YXR1czogXCIgKyByZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxudXBkYXRlQmxvY2sgPSAoKSA9PiB7XG4gICAgTWV0ZW9yLmNhbGwgKCdibG9ja3MuYmxvY2tzVXBkYXRlJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyAoXCJ1cGRhdGVCbG9ja3M6IFwiICsgZXJyb3IpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2cgKFwidXBkYXRlQmxvY2tzOiBcIiArIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KVxufVxuXG5nZXRDb25zZW5zdXNTdGF0ZSA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCAoJ2NoYWluLmdldENvbnNlbnN1c1N0YXRlJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyAoXCJnZXQgY29uc2Vuc3VzOiBcIiArIGVycm9yKVxuICAgICAgICB9XG4gICAgfSlcbn1cblxuZ2V0UHJvcG9zYWxzID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsICgncHJvcG9zYWxzLmdldFByb3Bvc2FscycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5sb2cgKFwiZ2V0IHByb3Bvc2FsOiBcIiArIGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyAoXCJnZXQgcHJvcG9zYWw6IFwiICsgcmVzdWx0KTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5nZXRQcm9wb3NhbHNSZXN1bHRzID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsICgncHJvcG9zYWxzLmdldFByb3Bvc2FsUmVzdWx0cycsIChlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5sb2cgKFwiZ2V0IHByb3Bvc2FscyByZXN1bHQ6IFwiICsgZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcImdldCBwcm9wb3NhbHMgcmVzdWx0OiBcIiArIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxudXBkYXRlTWlzc2VkQmxvY2tzID0gKCkgPT4ge1xuICAgIE1ldGVvci5jYWxsICgnVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3MnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcIm1pc3NlZCBibG9ja3MgZXJyb3I6IFwiICsgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2cgKFwibWlzc2VkIGJsb2NrcyBvazpcIiArIHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICAvKlxuICAgICAgICBNZXRlb3IuY2FsbCgnVmFsaWRhdG9yUmVjb3Jkcy5jYWxjdWxhdGVNaXNzZWRCbG9ja3NTdGF0cycsIChlcnJvciwgcmVzdWx0KSA9PntcbiAgICAgICAgICAgIGlmIChlcnJvcil7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJtaXNzZWQgYmxvY2tzIHN0YXRzIGVycm9yOiBcIisgZXJyb3IpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocmVzdWx0KXtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIm1pc3NlZCBibG9ja3Mgc3RhdHMgb2s6XCIgKyByZXN1bHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAqL1xufVxuXG5nZXREZWxlZ2F0aW9ucyA9ICgpID0+IHtcbiAgICBNZXRlb3IuY2FsbCAoJ2RlbGVnYXRpb25zLmdldERlbGVnYXRpb25zJywgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyAoXCJnZXQgZGVsZWdhdGlvbnMgZXJyb3I6IFwiICsgZXJyb3IpXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyAoXCJnZXQgZGVsZWdhdGlvbnMgb2s6IFwiICsgcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG59XG5cbmFnZ3JlZ2F0ZU1pbnV0ZWx5ID0gKCkgPT4ge1xuICAgIC8vIGRvaW5nIHNvbWV0aGluZyBldmVyeSBtaW5cbiAgICBNZXRlb3IuY2FsbCAoJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcicsIFwibVwiLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcImFnZ3JlZ2F0ZSBtaW51dGVseSBibG9jayB0aW1lIGVycm9yOiBcIiArIGVycm9yKVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc29sZS5sb2cgKFwiYWdncmVnYXRlIG1pbnV0ZWx5IGJsb2NrIHRpbWUgb2s6IFwiICsgcmVzdWx0KVxuICAgICAgICB9XG4gICAgfSk7XG5cbiAgICBNZXRlb3IuY2FsbCAoJ2NvaW5TdGF0cy5nZXRDb2luU3RhdHMnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcImdldCBjb2luIHN0YXRzIGVycm9yOiBcIiArIGVycm9yKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcImdldCBjb2luIHN0YXRzIG9rOiBcIiArIHJlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5hZ2dyZWdhdGVIb3VybHkgPSAoKSA9PiB7XG4gICAgLy8gZG9pbmcgc29tZXRoaW5nIGV2ZXJ5IGhvdXJcbiAgICBNZXRlb3IuY2FsbCAoJ0FuYWx5dGljcy5hZ2dyZWdhdGVCbG9ja1RpbWVBbmRWb3RpbmdQb3dlcicsIFwiaFwiLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcImFnZ3JlZ2F0ZSBob3VybHkgYmxvY2sgdGltZSBlcnJvcjogXCIgKyBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcImFnZ3JlZ2F0ZSBob3VybHkgYmxvY2sgdGltZSBvazogXCIgKyByZXN1bHQpXG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuYWdncmVnYXRlRGFpbHkgPSAoKSA9PiB7XG4gICAgLy8gZG9pbmcgc29tdGhpbmcgZXZlcnkgZGF5XG4gICAgTWV0ZW9yLmNhbGwgKCdBbmFseXRpY3MuYWdncmVnYXRlQmxvY2tUaW1lQW5kVm90aW5nUG93ZXInLCBcImRcIiwgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyAoXCJhZ2dyZWdhdGUgZGFpbHkgYmxvY2sgdGltZSBlcnJvcjogXCIgKyBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcImFnZ3JlZ2F0ZSBkYWlseSBibG9jayB0aW1lIG9rOiBcIiArIHJlc3VsdClcbiAgICAgICAgfVxuICAgIH0pO1xuXG4gICAgTWV0ZW9yLmNhbGwgKCdBbmFseXRpY3MuYWdncmVnYXRlVmFsaWRhdG9yRGFpbHlCbG9ja1RpbWUnLCAoZXJyb3IsIHJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcImFnZ3JlZ2F0ZSB2YWxpZGF0b3JzIGJsb2NrIHRpbWUgZXJyb3I6XCIgKyBlcnJvcilcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChcImFnZ3JlZ2F0ZSB2YWxpZGF0b3JzIGJsb2NrIHRpbWUgb2s6XCIgKyByZXN1bHQpO1xuICAgICAgICB9XG4gICAgfSlcbn1cblxuXG5NZXRlb3Iuc3RhcnR1cCAoZnVuY3Rpb24gKCkge1xuICAgIGlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkge1xuICAgICAgICBwcm9jZXNzLmVudi5OT0RFX1RMU19SRUpFQ1RfVU5BVVRIT1JJWkVEID0gMDtcbiAgICAgICAgaW1wb3J0IERFRkFVTFRTRVRUSU5HU0pTT04gZnJvbSAnLi4vZGVmYXVsdF9zZXR0aW5ncy5qc29uJ1xuICAgICAgICBPYmplY3Qua2V5cyAoREVGQVVMVFNFVFRJTkdTSlNPTikuZm9yRWFjaCAoKGtleSkgPT4ge1xuICAgICAgICAgICAgaWYgKE1ldGVvci5zZXR0aW5nc1trZXldID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybiAoYENIRUNLIFNFVFRJTkdTIEpTT046ICR7a2V5fSBpcyBtaXNzaW5nIGZyb20gc2V0dGluZ3NgKVxuICAgICAgICAgICAgICAgIE1ldGVvci5zZXR0aW5nc1trZXldID0ge307XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBPYmplY3Qua2V5cyAoREVGQVVMVFNFVFRJTkdTSlNPTltrZXldKS5mb3JFYWNoICgocGFyYW0pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoTWV0ZW9yLnNldHRpbmdzW2tleV1bcGFyYW1dID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLndhcm4gKGBDSEVDSyBTRVRUSU5HUyBKU09OOiAke2tleX0uJHtwYXJhbX0gaXMgbWlzc2luZyBmcm9tIHNldHRpbmdzYClcbiAgICAgICAgICAgICAgICAgICAgTWV0ZW9yLnNldHRpbmdzW2tleV1bcGFyYW1dID0gREVGQVVMVFNFVFRJTkdTSlNPTltrZXldW3BhcmFtXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgTWV0ZW9yLmNhbGwgKCdjaGFpbi5nZW5lc2lzJywgKGVyciwgcmVzdWx0KSA9PiB7XG4gICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nIChlcnIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgIGlmIChNZXRlb3Iuc2V0dGluZ3MuZGVidWcuc3RhcnRUaW1lcikge1xuICAgICAgICAgICAgICAgIHRpbWVyQ29uc2Vuc3VzID0gTWV0ZW9yLnNldEludGVydmFsIChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGdldENvbnNlbnN1c1N0YXRlICgpO1xuICAgICAgICAgICAgICAgIH0sIE1ldGVvci5zZXR0aW5ncy5wYXJhbXMuY29uc2Vuc3VzSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgdGltZXJCbG9ja3MgPSBNZXRlb3Iuc2V0SW50ZXJ2YWwgKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlQmxvY2sgKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5ibG9ja0ludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyQ2hhaW4gPSBNZXRlb3Iuc2V0SW50ZXJ2YWwgKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlQ2hhaW5TdGF0dXMgKCk7XG4gICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5zdGF0dXNJbnRlcnZhbCk7XG5cbiAgICAgICAgICAgICAgICBpZiAoTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5wcm9wb3NhbEludGVydmFsID49IDApIHtcbiAgICAgICAgICAgICAgICAgICAgdGltZXJQcm9wb3NhbCA9IE1ldGVvci5zZXRJbnRlcnZhbCAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2V0UHJvcG9zYWxzICgpO1xuICAgICAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLnByb3Bvc2FsSW50ZXJ2YWwpO1xuXG4gICAgICAgICAgICAgICAgICAgIHRpbWVyUHJvcG9zYWxzUmVzdWx0cyA9IE1ldGVvci5zZXRJbnRlcnZhbCAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2V0UHJvcG9zYWxzUmVzdWx0cyAoKTtcbiAgICAgICAgICAgICAgICAgICAgfSwgTWV0ZW9yLnNldHRpbmdzLnBhcmFtcy5wcm9wb3NhbEludGVydmFsKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB0aW1lck1pc3NlZEJsb2NrID0gTWV0ZW9yLnNldEludGVydmFsIChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZU1pc3NlZEJsb2NrcyAoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLm1pc3NlZEJsb2Nrc0ludGVydmFsKTtcblxuICAgICAgICAgICAgICAgIHRpbWVyRGVsZWdhdGlvbiA9IE1ldGVvci5zZXRJbnRlcnZhbCAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBnZXREZWxlZ2F0aW9ucyAoKTtcbiAgICAgICAgICAgICAgICB9LCBNZXRlb3Iuc2V0dGluZ3MucGFyYW1zLmRlbGVnYXRpb25JbnRlcnZhbCk7XG5cbiAgICAgICAgICAgICAgICB0aW1lckFnZ3JlZ2F0ZSA9IE1ldGVvci5zZXRJbnRlcnZhbCAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBsZXQgbm93ID0gbmV3IERhdGUgKCk7XG4gICAgICAgICAgICAgICAgICAgIGlmICgobm93LmdldFVUQ1NlY29uZHMgKCkgPT0gMCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZU1pbnV0ZWx5ICgpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgaWYgKChub3cuZ2V0VVRDTWludXRlcyAoKSA9PSAwKSAmJiAobm93LmdldFVUQ1NlY29uZHMgKCkgPT0gMCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZUhvdXJseSAoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGlmICgobm93LmdldFVUQ0hvdXJzICgpID09IDApICYmIChub3cuZ2V0VVRDTWludXRlcyAoKSA9PSAwKSAmJiAobm93LmdldFVUQ1NlY29uZHMgKCkgPT0gMCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZURhaWx5ICgpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSwgMTAwMClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0pXG5cbn0pO1xuIl19
